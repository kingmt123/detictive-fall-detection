"""E2 full cache orchestrator - chains 4 batches with disk guard."""
import subprocess, os, sys, time, shutil, json

E2 = r"D:\HermesWorkspace\Detictive-e2-closure-20260824"
E2RUN = r"D:\HermesWorkspace\Detictive\runs\local_cache_20260824\e2-full-cache"
PY = r"D:\HermesWorkspace\Detictive\.worktrees\handoff_g2_reconcile_20260824\.venv-local-cache\Scripts\python.exe"
MODEL = r"D:\HermesWorkspace\Detictive\yolo11n-pose.pt"
MANIFEST = os.path.join(E2RUN, "manifest.trainval.v1.csv")
MIN_DISK_GIB = 20

BATCHES = [("of-syn","train"),("of-syn","val"),("urfd","train"),("urfd","val")]
ENV = {**os.environ, "PYTHONPATH": E2, "TMP": os.path.join(E2RUN,"tmp"), "TEMP": os.path.join(E2RUN,"tmp"), "ULTRALYTICS_CONFIG_DIR": os.path.join(E2RUN,"ultralytics")}

def free_gib():
    return shutil.disk_usage("D:\\").free // (1024**3)

def cache_count():
    c=0
    for r,_,fs in os.walk(os.path.join(E2RUN,"cache")):
        c += sum(1 for f in fs if f.endswith(".npz"))
    return c

def run_batch(ds, sp):
    log = os.path.join(E2RUN,"logs",f"extract_{ds}_{sp}.log")
    cmd = [PY, os.path.join(E2,"tools","extract_keypoints.py"),
           "--manifest",MANIFEST,"--dataset",ds,"--split",sp,
           "--cache-root",os.path.join(E2RUN,"cache"),
           "--temp-root",os.path.join(E2RUN,"temp"),
           "--model",MODEL,"--device","0"]
    with open(log,"w",encoding="utf-8") as fh:
        r = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, env=ENV, cwd=E2)
    return r.returncode

started = time.time()
for ds,sp in BATCHES:
    free = free_gib()
    if free < MIN_DISK_GIB:
        print(f"ABORT: {free}G < {MIN_DISK_GIB}G", file=sys.stderr); sys.exit(3)
    print(f"=== {ds} {sp} start | disk={free}G caches={cache_count()} ===", flush=True)
    rc = run_batch(ds,sp)
    if rc != 0:
        print(f"FAIL {ds} {sp} rc={rc}", file=sys.stderr); sys.exit(1)
    free = free_gib()
    if free < MIN_DISK_GIB:
        print(f"ABORT: {free}G < {MIN_DISK_GIB}G after {ds} {sp}", file=sys.stderr); sys.exit(3)
    eh = (time.time()-started)/3600
    print(f"=== {ds} {sp} done | disk={free}G caches={cache_count()} elapsed={eh:.1f}h ===", flush=True)

eh = (time.time()-started)/3600
print(f"ALL DONE {eh:.1f}h caches={cache_count()}", flush=True)
