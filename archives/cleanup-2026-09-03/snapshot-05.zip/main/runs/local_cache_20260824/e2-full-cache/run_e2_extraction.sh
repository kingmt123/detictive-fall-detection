#!/bin/bash
set -euo pipefail
E2RUN='D:/HermesWorkspace/Detictive/runs/local_cache_20260824/e2-full-cache'
PY='D:/HermesWorkspace/Detictive/.worktrees/handoff_g2_reconcile_20260824/.venv-local-cache/Scripts/python.exe'
export PYTHONPATH='D:/HermesWorkspace/Detictive-e2-closure-20260824'
export TMP="$E2RUN/tmp" TEMP="$E2RUN/tmp" TMPDIR="$E2RUN/tmp" ULTRALYTICS_CONFIG_DIR="$E2RUN/ultralytics"

mkdir -p "$E2RUN/cache" "$E2RUN/temp" "$E2RUN/tmp" "$E2RUN/ultralytics" "$E2RUN/logs"
FREE_GB=$(df -h /d | awk 'NR==2{print int($4)}')
echo "Pre-flight D: free ${FREE_GB}G"
if [ "$FREE_GB" -lt 20 ]; then
  echo "ABORT: D: free ${FREE_GB}G < 20G" >&2; exit 3
fi
nvidia-smi > "$E2RUN/logs/gpu_start.txt"
echo "E2 full cache extraction START $(date -u +%Y-%m-%dT%H:%M:%SZ)"

run_batch() {
  local dataset="$1" split="$2"
  echo "=== $dataset $split ==="
  "$PY" tools/extract_keypoints.py \
    --manifest "$E2RUN/manifest.trainval.v1.csv" \
    --dataset "$dataset" --split "$split" \
    --cache-root "$E2RUN/cache" --temp-root "$E2RUN/temp" \
    --model 'D:/HermesWorkspace/Detictive/yolo11n-pose.pt' \
    --device 0 2>&1 | tee "$E2RUN/logs/extract_${dataset}_${split}.log"
  FREE_GB=$(df -h /d | awk 'NR==2{print int($4)}')
  echo "Disk free after $dataset $split: ${FREE_GB}G"
  if [ "$FREE_GB" -lt 20 ]; then
    echo "ABORT: disk ${FREE_GB}G < 20G after $dataset $split" >&2; exit 3
  fi
}

run_batch of-syn train
run_batch of-syn val
run_batch urfd train
run_batch urfd val

nvidia-smi > "$E2RUN/logs/gpu_end.txt"
echo "E2 full cache extraction DONE $(date -u +%Y-%m-%dT%H:%M:%SZ)"
CACHE_COUNT=$(find "$E2RUN/cache" -name '*.npz' | wc -l)
echo "Cache files: $CACHE_COUNT"
echo "Disk free: $(df -h /d | awk 'NR==2{print $4}')"
