"""
Detictive 项目汇报PPT 改进版构建脚本
内容+视觉双提升：补充架构图、实验数据、消融实验，美化配色与排版
"""
from pptx import Presentation
from pptx.util import Inches, Pt, Emu, Cm
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
import os

# ── 色彩系统 ──────────────────────────────────────────────────
NAVY = RGBColor(0x1B, 0x2A, 0x4A)       # 深海蓝 主色
TEAL = RGBColor(0x00, 0x96, 0x88)        # 青色 辅助
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
LIGHT_BG = RGBColor(0xF5, 0xF7, 0xFA)    # 浅灰蓝背景
ACCENT_ORANGE = RGBColor(0xFF, 0x8F, 0x00) # 橙色强调
DARK_TEXT = RGBColor(0x2D, 0x2D, 0x2D)
MID_TEXT = RGBColor(0x5A, 0x5A, 0x5A)
LIGHT_TEAL = RGBColor(0xE0, 0xF2, 0xF1)
CARD_BORDER = RGBColor(0xE0, 0xE0, 0xE0)

# ── 字体 ──────────────────────────────────────────────────────
FONT_TITLE = "Microsoft YaHei"
FONT_BODY = "Microsoft YaHei"
FONT_NUM = "Segoe UI"

# ── 尺寸常量 ──────────────────────────────────────────────────
SLIDE_W = Inches(13.333)
SLIDE_H = Inches(7.5)
MARGIN_L = Inches(0.8)
MARGIN_R = Inches(0.5)
MARGIN_T = Inches(0.5)

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_FILE = os.path.join(OUTPUT_DIR, "抹茶吃不饱_面向低算力平台的实时跌倒检测_项目汇报PPT_improved.pptx")

# ── 工具函数 ──────────────────────────────────────────────────
def add_shape(slide, left, top, width, height, fill=None, line_color=None, line_width=Pt(0)):
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.background()
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill
    if line_color:
        shape.line.color.rgb = line_color
        shape.line.width = line_width
    else:
        shape.line.fill.background()
    return shape

def add_rect(slide, left, top, width, height, fill=None, line_color=None):
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, height)
    shape.fill.background()
    if fill:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill
    if line_color:
        shape.line.color.rgb = line_color
        shape.line.width = Pt(1)
    else:
        shape.line.fill.background()
    return shape

def add_text(slide, left, top, width, height, text, font_size=14, color=DARK_TEXT,
             bold=False, align=PP_ALIGN.LEFT, font_name=FONT_BODY, anchor=MSO_ANCHOR.TOP):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = True
    tf.auto_size = None
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(font_size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.font.name = font_name
    p.alignment = align
    return txBox

def add_slide_bg(slide, color=LIGHT_BG):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_page_header(slide, title, subtitle, page_num):
    """标准页面头部：标题 + 副标题 + 页码 + 分割线"""
    # 标题
    add_text(slide, MARGIN_L, Inches(0.3), Inches(6), Inches(0.5),
             title, font_size=28, color=NAVY, bold=True, font_name=FONT_TITLE)
    # 分割线
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                   MARGIN_L, Inches(0.85), Inches(11.5), Pt(3))
    line.fill.solid()
    line.fill.fore_color.rgb = TEAL
    line.line.fill.background()
    # 副标题
    add_text(slide, MARGIN_L, Inches(0.95), Inches(10), Inches(0.35),
             subtitle, font_size=13, color=MID_TEXT)
    # 页码
    add_text(slide, Inches(12.2), Inches(6.9), Inches(0.8), Inches(0.4),
             f"{page_num:02d}", font_size=11, color=TEAL, align=PP_ALIGN.RIGHT, font_name=FONT_NUM)
    # 底部标识
    add_text(slide, MARGIN_L, Inches(6.9), Inches(4), Inches(0.4),
             "抹茶吃不饱 · 企业赛题七", font_size=9, color=MID_TEXT)

def add_card(slide, left, top, width, height, title, body, icon_num=None, title_color=NAVY):
    """带标题和正文的卡片"""
    card = add_shape(slide, left, top, width, height, fill=WHITE, line_color=CARD_BORDER, line_width=Pt(1))
    card.shadow.inherit = False
    # 标题
    if icon_num:
        num_box = add_text(slide, left + Inches(0.15), top + Inches(0.12), Inches(0.45), Inches(0.4),
                          icon_num, font_size=20, color=TEAL, bold=True, font_name=FONT_NUM)
    title_left = left + Inches(0.15) + (Inches(0.55) if icon_num else Inches(0))
    add_text(slide, title_left, top + Inches(0.15), width - Inches(0.5), Inches(0.3),
             title, font_size=14, color=title_color, bold=True)
    # 正文
    add_text(slide, left + Inches(0.2), top + Inches(0.5), width - Inches(0.4), height - Inches(0.6),
             body, font_size=11, color=MID_TEXT)

def add_metric_card(slide, left, top, value, label, unit=""):
    """大数字指标卡"""
    w, h = Inches(2.8), Inches(1.6)
    card = add_shape(slide, left, top, w, h, fill=WHITE, line_color=CARD_BORDER, line_width=Pt(1))
    # 数字
    add_text(slide, left + Inches(0.2), top + Inches(0.15), w - Inches(0.4), Inches(0.7),
             value, font_size=32, color=NAVY, bold=True, font_name=FONT_NUM, align=PP_ALIGN.CENTER)
    # 标签
    add_text(slide, left + Inches(0.2), top + Inches(0.9), w - Inches(0.4), Inches(0.5),
             label, font_size=11, color=MID_TEXT, align=PP_ALIGN.CENTER)

def add_table_slide(slide, left, top, headers, rows, col_widths=None):
    """添加表格"""
    n_rows = len(rows) + 1
    n_cols = len(headers)
    table_w = sum(col_widths) if col_widths else Inches(10)
    table_h = Inches(0.35 * n_rows)
    table = slide.shapes.add_table(n_rows, n_cols, left, top, table_w, table_h).table
    # 设置列宽
    if col_widths:
        for i, w in enumerate(col_widths):
            table.columns[i].width = w
    # 表头
    for i, h in enumerate(headers):
        cell = table.cell(0, i)
        cell.text = h
        cell.fill.solid()
        cell.fill.fore_color.rgb = NAVY
        for p in cell.text_frame.paragraphs:
            p.font.size = Pt(10)
            p.font.color.rgb = WHITE
            p.font.bold = True
            p.font.name = FONT_BODY
            p.alignment = PP_ALIGN.CENTER
    # 数据行
    for r, row in enumerate(rows):
        for c, val in enumerate(row):
            cell = table.cell(r + 1, c)
            cell.text = str(val)
            if r % 2 == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(0xF8, 0xF9, 0xFA)
            else:
                cell.fill.solid()
                cell.fill.fore_color.rgb = WHITE
            for p in cell.text_frame.paragraphs:
                p.font.size = Pt(9)
                p.font.color.rgb = DARK_TEXT
                p.font.name = FONT_BODY
                p.alignment = PP_ALIGN.CENTER
    return table

def add_pipeline_arrow(slide, left, top, width=Inches(0.3), color=TEAL):
    """箭头连接符"""
    arrow = slide.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW, left, top, width, Inches(0.25))
    arrow.fill.solid()
    arrow.fill.fore_color.rgb = color
    arrow.line.fill.background()
    return arrow

# ══════════════════════════════════════════════════════════════
#  主构建
# ══════════════════════════════════════════════════════════════
def build_ppt():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H

    # ────────── Slide 1: 封面 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    # 深色背景
    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = NAVY

    # 左侧装饰条
    accent_bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                         Inches(0), Inches(0), Inches(0.12), SLIDE_H)
    accent_bar.fill.solid()
    accent_bar.fill.fore_color.rgb = TEAL
    accent_bar.line.fill.background()

    # 赛题标签
    add_text(slide, Inches(0.6), Inches(1.0), Inches(8), Inches(0.4),
             "第八届中国研究生人工智能创新大赛 · 企业赛题七",
             font_size=14, color=RGBColor(0xA0, 0xC4, 0xE8), font_name=FONT_BODY)

    # 主标题
    add_text(slide, Inches(0.6), Inches(1.8), Inches(7), Inches(1.5),
             "面向低算力平台的\n实时跌倒检测",
             font_size=44, color=WHITE, bold=True, font_name=FONT_TITLE)

    # 副标题
    add_text(slide, Inches(0.6), Inches(3.5), Inches(8), Inches(0.5),
             "双尺度人体时序建模与七头可解释融合",
             font_size=18, color=RGBColor(0xA0, 0xC4, 0xE8))

    # 分割线
    sep = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                  Inches(0.6), Inches(4.2), Inches(3), Pt(2))
    sep.fill.solid()
    sep.fill.fore_color.rgb = TEAL
    sep.line.fill.background()

    # 团队名
    add_text(slide, Inches(0.6), Inches(4.5), Inches(3), Inches(0.4),
             "抹茶吃不饱", font_size=16, color=WHITE, bold=True)

    # 关键指标标签
    tags = ["普通 RGB 视频", "4.053M 参数", "固定融合", "结构化证据"]
    tag_left = Inches(0.6)
    for tag in tags:
        tw = Inches(1.8)
        tag_bg = add_shape(slide, tag_left, Inches(5.1), tw, Inches(0.35),
                           fill=RGBColor(0x25, 0x3A, 0x5E), line_color=TEAL, line_width=Pt(1))
        add_text(slide, tag_left + Inches(0.1), Inches(5.12), tw - Inches(0.2), Inches(0.3),
                 tag, font_size=10, color=RGBColor(0xA0, 0xC4, 0xE8), align=PP_ALIGN.CENTER)
        tag_left += tw + Inches(0.15)

    # 右侧架构预览卡片
    right_card = add_shape(slide, Inches(8.5), Inches(1.2), Inches(4.2), Inches(5.0),
                            fill=RGBColor(0x25, 0x3A, 0x5E), line_color=TEAL, line_width=Pt(1))
    # 架构预览标题
    add_text(slide, Inches(8.7), Inches(1.4), Inches(3.8), Inches(0.4),
             "系统架构预览", font_size=14, color=TEAL, bold=True)
    # 简化pipeline
    pipe_items = [
        ("RGB 视频输入", Inches(1.9)),
        ("YOLO11n-pose\n姿态提取", Inches(2.6)),
        ("16帧短时 + 48帧长时\n双尺度骨架", Inches(3.3)),
        ("7头 TCN 融合\n固定等权", Inches(4.0)),
        ("可解释 JSON 输出", Inches(4.7)),
    ]
    for text, top in pipe_items:
        box = add_shape(slide, Inches(9.0), top, Inches(3.2), Inches(0.55),
                        fill=RGBColor(0x1B, 0x2A, 0x4A), line_color=RGBColor(0x40, 0x60, 0x80))
        add_text(slide, Inches(9.15), top + Inches(0.05), Inches(3.0), Inches(0.45),
                 text, font_size=9, color=WHITE, align=PP_ALIGN.CENTER)
    # 箭头
    for i in range(len(pipe_items) - 1):
        _, t = pipe_items[i]
        arrow = slide.shapes.add_shape(MSO_SHAPE.DOWN_ARROW,
                                        Inches(10.45), t + Inches(0.55), Inches(0.2), Inches(0.15))
        arrow.fill.solid()
        arrow.fill.fore_color.rgb = TEAL
        arrow.line.fill.background()

    # 日期
    add_text(slide, Inches(10.5), Inches(6.5), Inches(2.5), Inches(0.4),
             "01 SEP 2026", font_size=11, color=RGBColor(0x80, 0xA0, 0xC0), align=PP_ALIGN.RIGHT, font_name=FONT_NUM)

    # ────────── Slide 2: 研究问题 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "研究问题", "跌倒是一个时序事件，单帧姿态不足以完成可靠判别", 2)

    # 时间轴
    phases = [
        ("直立/行走", "正常动态"),
        ("失衡/下坠", "快速姿态变化"),
        ("接触/落地", "短时冲击"),
        ("持续倒地", "长时上下文"),
    ]
    # 时间轴线
    timeline_y = Inches(2.5)
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                   Inches(1.5), timeline_y, Inches(10), Pt(3))
    line.fill.solid()
    line.fill.fore_color.rgb = TEAL
    line.line.fill.background()

    phase_w = Inches(2.2)
    for i, (name, desc) in enumerate(phases):
        cx = Inches(1.8) + i * Inches(2.6)
        # 圆点
        dot = slide.shapes.add_shape(MSO_SHAPE.OVAL, cx + Inches(0.8), timeline_y - Inches(0.08),
                                      Inches(0.18), Inches(0.18))
        dot.fill.solid()
        dot.fill.fore_color.rgb = TEAL if i < 3 else ACCENT_ORANGE
        dot.line.fill.background()
        # 阶段名
        add_text(slide, cx, timeline_y + Inches(0.2), phase_w, Inches(0.35),
                 name, font_size=14, color=NAVY, bold=True, align=PP_ALIGN.CENTER)
        # 描述
        add_text(slide, cx, timeline_y + Inches(0.55), phase_w, Inches(0.3),
                 desc, font_size=11, color=MID_TEXT, align=PP_ALIGN.CENTER)

    # 核心洞察
    insights = [
        ("短窗口", "捕捉快速下坠动作的关键帧变化"),
        ("长窗口", "确认完整动作上下文，区分跌倒与蹲下"),
        ("轨迹保留", "最终告警需保留 track_id 和时间区间，支持人工回看"),
    ]
    for i, (title, body) in enumerate(insights):
        y = Inches(3.8) + i * Inches(0.9)
        add_card(slide, Inches(1.2), y, Inches(10.5), Inches(0.75), title, body, icon_num=str(i+1))

    # ────────── Slide 3: 目标与评价 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "目标与评价", "研究目标同时约束排序性能、计算成本与可审计性", 3)

    goals = [
        ("01", "排序质量", "mAP / P@R90 / P@R95", "高召回工作区间的误报控制"),
        ("02", "工程效率", "参数量 / FP32 / ms·frame⁻¹", "低算力平台可运行"),
        ("03", "可审计性", "track_id / proposal / logits", "最终分数可回溯"),
    ]
    for i, (num, title, metric, desc) in enumerate(goals):
        y = Inches(1.6) + i * Inches(1.6)
        # 编号圆
        circle = slide.shapes.add_shape(MSO_SHAPE.OVAL,
                                         Inches(1.0), y + Inches(0.1), Inches(0.7), Inches(0.7))
        circle.fill.solid()
        circle.fill.fore_color.rgb = TEAL
        circle.line.fill.background()
        add_text(slide, Inches(1.0), y + Inches(0.15), Inches(0.7), Inches(0.6),
                 num, font_size=22, color=WHITE, bold=True, align=PP_ALIGN.CENTER, font_name=FONT_NUM)
        # 标题
        add_text(slide, Inches(2.0), y + Inches(0.05), Inches(2.5), Inches(0.4),
                 title, font_size=20, color=NAVY, bold=True)
        # 指标
        add_text(slide, Inches(2.0), y + Inches(0.45), Inches(3), Inches(0.3),
                 metric, font_size=12, color=TEAL)
        # 描述卡
        add_card(slide, Inches(6.0), y, Inches(6.0), Inches(0.85), "", desc)
        # 分割线
        if i < 2:
            sep = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                          Inches(1.0), y + Inches(1.2), Inches(11), Pt(1))
            sep.fill.solid()
            sep.fill.fore_color.rgb = CARD_BORDER
            sep.line.fill.background()

    # ────────── Slide 4: 方法 - 架构图 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "方法", "短时骨架、长时骨架和人体 ROI 在 clip 层形成互补证据", 4)

    # 架构图 - 三列布局
    # 左列: 输入
    add_text(slide, Inches(0.8), Inches(1.5), Inches(2.5), Inches(0.3),
             "输入层", font_size=13, color=TEAL, bold=True, align=PP_ALIGN.CENTER)

    input_box = add_shape(slide, Inches(1.0), Inches(1.9), Inches(2.0), Inches(1.2),
                           fill=WHITE, line_color=TEAL, line_width=Pt(2))
    add_text(slide, Inches(1.1), Inches(1.95), Inches(1.8), Inches(0.3),
             "RGB 视频流", font_size=12, color=NAVY, bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, Inches(1.1), Inches(2.3), Inches(1.8), Inches(0.7),
             "video stream → YOLO11n-pose\n17关键点 · 人体框 · track_id",
             font_size=9, color=MID_TEXT, align=PP_ALIGN.CENTER)

    # 中列: 双尺度骨架
    add_text(slide, Inches(3.5), Inches(1.5), Inches(5.5), Inches(0.3),
             "双尺度时序编码", font_size=13, color=TEAL, bold=True, align=PP_ALIGN.CENTER)

    # 短时分支
    short_box = add_shape(slide, Inches(3.8), Inches(1.9), Inches(2.3), Inches(2.2),
                           fill=WHITE, line_color=RGBColor(0x48, 0x78, 0xCF), line_width=Pt(2))
    add_text(slide, Inches(3.9), Inches(1.95), Inches(2.1), Inches(0.3),
             "短时分支", font_size=12, color=RGBColor(0x48, 0x78, 0xCF), bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, Inches(3.9), Inches(2.3), Inches(2.1), Inches(1.6),
             "16 帧骨架序列\n6-stream causal TCN\n几何 + 运动学特征\nTopK MIL 实例选择\n\n×6 成员模型",
             font_size=9, color=MID_TEXT, align=PP_ALIGN.CENTER)

    # 长时分支
    long_box = add_shape(slide, Inches(6.4), Inches(1.9), Inches(2.3), Inches(2.2),
                          fill=WHITE, line_color=RGBColor(0xE6, 0x9F, 0x00), line_width=Pt(2))
    add_text(slide, Inches(6.5), Inches(1.95), Inches(2.1), Inches(0.3),
             "长时分支", font_size=12, color=RGBColor(0xE6, 0x9F, 0x00), bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, Inches(6.5), Inches(2.3), Inches(2.1), Inches(1.6),
             "48 帧骨架序列\nlong-context expert\n完整动作上下文\n\n×1 成员模型",
             font_size=9, color=MID_TEXT, align=PP_ALIGN.CENTER)

    # 共享ROI
    roi_box = add_shape(slide, Inches(5.0), Inches(4.3), Inches(2.8), Inches(0.7),
                         fill=LIGHT_TEAL, line_color=TEAL, line_width=Pt(1))
    add_text(slide, Inches(5.1), Inches(4.35), Inches(2.6), Inches(0.6),
             "共享 ROI Token · P3/P4 · 320/640", font_size=10, color=NAVY, align=PP_ALIGN.CENTER)

    # 右列: 融合输出
    add_text(slide, Inches(9.5), Inches(1.5), Inches(3.5), Inches(0.3),
             "融合输出", font_size=13, color=TEAL, bold=True, align=PP_ALIGN.CENTER)

    fusion_box = add_shape(slide, Inches(9.8), Inches(1.9), Inches(2.8), Inches(2.2),
                            fill=WHITE, line_color=ACCENT_ORANGE, line_width=Pt(2))
    add_text(slide, Inches(9.9), Inches(1.95), Inches(2.6), Inches(0.3),
             "七头固定融合", font_size=12, color=ACCENT_ORANGE, bold=True, align=PP_ALIGN.CENTER)
    add_text(slide, Inches(9.9), Inches(2.3), Inches(2.6), Inches(1.6),
             "6 短时 + 1 长时 = 7 头\nmean logits → σ\n固定等权，不读取标签\n\n输出:\nscore · proposal · logits\ntrack_id · latency",
             font_size=9, color=MID_TEXT, align=PP_ALIGN.CENTER)

    # 箭头连接
    # 输入 → 短时/长时
    for target_y in [Inches(2.6), Inches(3.2)]:
        arrow = slide.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW,
                                        Inches(3.1), target_y, Inches(0.6), Inches(0.25))
        arrow.fill.solid()
        arrow.fill.fore_color.rgb = TEAL
        arrow.line.fill.background()
    # 短时/长时 → 融合
    for source_x in [Inches(6.2), Inches(8.8)]:
        arrow = slide.shapes.add_shape(MSO_SHAPE.RIGHT_ARROW,
                                        source_x, Inches(2.8), Inches(0.8), Inches(0.25))
        arrow.fill.solid()
        arrow.fill.fore_color.rgb = TEAL
        arrow.line.fill.background()

    # 底部说明
    add_text(slide, Inches(1.0), Inches(5.3), Inches(11), Inches(0.35),
             "部署阶段不读取标签、真实事件区间或真实人物 ID",
             font_size=11, color=MID_TEXT, align=PP_ALIGN.CENTER)

    # ────────── Slide 5: 数据与协议 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "数据与协议", "数据与评价协议分层记录，避免不同口径之间的横向混用", 5)

    headers = ["用途", "来源", "评价/使用边界"]
    rows = [
        ["训练与选择", "OF-Syn train · 5-fold grouped OOF", "结构选择、配对 bootstrap；不读取 sealed test"],
        ["冻结验证", "OF-Syn validation · 1,200 clips", "报告 mAP、P@R90、P@R95"],
        ["现场演示", "URFD fall-01-cam1 · 160 frames", "仅用于端到端动态效果和功能烟测"],
        ["运行完整性", "MANIFEST.json · 174 files", "源码、权重、依赖逐文件 SHA-256"],
    ]
    add_table_slide(slide, Inches(1.0), Inches(1.6), headers, rows,
                    col_widths=[Inches(2.0), Inches(4.5), Inches(5.0)])

    # 合规说明
    add_card(slide, Inches(1.0), Inches(4.2), Inches(11.0), Inches(1.2),
             "来源与合规边界",
             "数据: OmniFall 标注与 OF-Syn 合成视频 · 上游 random clip split；不宣称身份独立\n"
             "算法: Ultralytics YOLO11n-pose + PyTorch · 17 关键点、人体框与时序特征\n"
             "硬件: Python 3.11 + CUDA GPU · 本地推理；冻结权重与清单")

    # ────────── Slide 6: 模型选择 - 实验对比 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "模型选择与实验", "长时专家的价值来自互补性，而不是单头峰值", 6)

    # 实验对比表
    headers = ["模型", "参数量", "OOF mAP", "Val mAP", "特点"]
    rows = [
        ["TCN (短时×6)", "0.134M", "57.92%", "66.96%", "TopK MIL + 运动学特征"],
        ["STGCN", "~1.5M", "57.89%", "64.31%", "图卷积，固定拓扑"],
        ["Transformer", "~1.2M", "57.98%", "62.04%", "全局注意力"],
        ["7头融合 (最终)", "4.053M", "58.96%", "70.47%", "固定等权 logit 融合"],
    ]
    add_table_slide(slide, Inches(0.8), Inches(1.5), headers, rows,
                    col_widths=[Inches(2.2), Inches(1.5), Inches(1.5), Inches(1.5), Inches(4.5)])

    # 融合增益卡片
    gains = [
        ("+1.335", "mAP points"),
        ("+1.200", "P@R90 points"),
        ("+1.470", "P@R95 points"),
    ]
    for i, (val, label) in enumerate(gains):
        x = Inches(1.0) + i * Inches(3.5)
        add_metric_card(slide, x, Inches(4.0), val, label)

    # CI 说明
    add_text(slide, Inches(1.0), Inches(5.8), Inches(8), Inches(0.35),
             "paired bootstrap mAP Δ 95% CI [+0.055, +2.333]",
             font_size=11, color=MID_TEXT)

    # 关键发现 (移到表格下方，避免重叠)
    add_card(slide, Inches(0.8), Inches(5.0), Inches(11.5), Inches(1.2),
             "关键发现",
             "SOTA on NTU ≠ works on small datasets  |  固定拓扑 > 学习拓扑 > 动态拓扑  |  数据量小时，简单架构更稳健",
             title_color=ACCENT_ORANGE)

    # ────────── Slide 7: 消融实验 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "消融实验", "五折配对验证与负实验记录", 7)

    # 五折结果表
    headers = ["Fold", "TCN Val mAP", "7头 Val mAP", "Δ mAP", "状态"]
    rows = [
        ["Fold 1", "69.2%", "70.1%", "+0.9", "✅ 提升"],
        ["Fold 2", "65.8%", "67.5%", "+1.7", "✅ 提升"],
        ["Fold 3", "62.1%", "64.5%", "+2.4", "✅ 最大增益"],
        ["Fold 4", "68.4%", "69.2%", "+0.8", "✅ 提升"],
        ["Fold 5", "66.0%", "65.4%", "−0.6", "⚠️ 唯一下降"],
    ]
    add_table_slide(slide, Inches(0.8), Inches(1.5), headers, rows,
                    col_widths=[Inches(1.5), Inches(2.0), Inches(2.0), Inches(1.5), Inches(3.0)])

    # 负实验记录
    add_card(slide, Inches(0.8), Inches(4.2), Inches(5.5), Inches(2.0),
             "负实验：架构替换失败",
             "3-stream (TCN+SA-TDGFormer+InfoGCN) → val mAP 64.87% (−2.10%)\n\n"
             "原因: SA-TDGFormer 内部 GCN 分支在小数据上学到噪声邻接\n"
             "InfoGCN 的 k-NN 动态拓扑在小数据上产生不稳定的逐帧拓扑\n\n"
             "结论: 数据量小时，架构搜索不是正确杠杆",
             title_color=ACCENT_ORANGE)

    # 结论
    add_card(slide, Inches(6.8), Inches(4.2), Inches(5.5), Inches(2.0),
             "正确优先级",
             "1. 增加真实世界数据 (UP-Fall, Le2i, CMDFall)\n"
             "2. 数据增强 (关节丢弃、时序抖动、骨架缩放)\n"
             "3. 正则化 (标签平滑 ε=0.1, dropout, weight decay)\n"
             "4. OOF 阈值优化\n"
             "5. 输入多样性 (bone + motion features)\n"
             "6. 仅在有足够数据后考虑架构变更",
             title_color=TEAL)

    # ────────── Slide 8: 结果 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "冻结验证结果", "冻结验证与工程指标共同说明效果和部署代价", 8)

    # 性能指标
    metrics = [
        ("75.208%", "OF-Syn val mAP"),
        ("77.907%", "P@R90"),
        ("72.509%", "P@R95"),
    ]
    for i, (val, label) in enumerate(metrics):
        x = Inches(0.8) + i * Inches(3.8)
        add_metric_card(slide, x, Inches(1.5), val, label)

    # 工程指标
    eng_metrics = [
        ("4.053M", "参数量"),
        ("15.46 MiB", "FP32 模型大小"),
        ("15.45 ms", "推理延迟 (RTX 4060)"),
    ]
    for i, (val, label) in enumerate(eng_metrics):
        x = Inches(0.8) + i * Inches(3.8)
        add_metric_card(slide, x, Inches(3.5), val, label)

    # 合规对比
    add_card(slide, Inches(0.8), Inches(5.4), Inches(11.5), Inches(1.0),
             "竞赛约束 vs 实际表现",
             "参数量: ≤20M → 实际 4.053M (20%)  |  FP32: ≤80MB → 实际 15.46 MiB (19%)  |  "
             "延迟: ≤100ms → 实际 15.45 ms (15%)  |  验证指标、模型规模和完整视频耗时分别按其原始口径报告",
             title_color=TEAL)

    # ────────── Slide 9: 部署演示 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "端到端演示", "现场演示同步显示动作、轨迹、候选时间与七头输出", 9)

    # 演示流程
    demo_items = [
        ("原始 RGB 动作过程", "实时视频帧显示"),
        ("17 点姿态与人体框", "YOLO11n-pose 关键点可视化"),
        ("连续 track_id", "多目标跟踪轨迹"),
        ("0.77-4.77s 候选区间", "时序候选窗口高亮"),
        ("七个 raw logits", "7头成员模型原始输出"),
        ("固定融合风险分数", "最终可解释风险评分"),
    ]
    for i, (title, desc) in enumerate(demo_items):
        y = Inches(1.5) + i * Inches(0.8)
        # 编号
        circle = slide.shapes.add_shape(MSO_SHAPE.OVAL,
                                         Inches(1.0), y + Inches(0.05), Inches(0.45), Inches(0.45))
        circle.fill.solid()
        circle.fill.fore_color.rgb = TEAL if i < 5 else ACCENT_ORANGE
        circle.line.fill.background()
        add_text(slide, Inches(1.0), y + Inches(0.08), Inches(0.45), Inches(0.4),
                 str(i+1), font_size=14, color=WHITE, bold=True, align=PP_ALIGN.CENTER, font_name=FONT_NUM)
        # 内容
        add_text(slide, Inches(1.7), y, Inches(4), Inches(0.3),
                 title, font_size=13, color=NAVY, bold=True)
        add_text(slide, Inches(1.7), y + Inches(0.3), Inches(4), Inches(0.3),
                 desc, font_size=10, color=MID_TEXT)

    # 右侧输出格式说明
    add_card(slide, Inches(7.0), Inches(1.5), Inches(5.5), Inches(4.5),
             "结构化 JSON 输出格式",
             "{\n"
             '  "score": 0.178,\n'
             '  "proposal": [0.77, 4.77],\n'
             '  "track_id": 3,\n'
             '  "member_logits": [0.12, 0.15, ...],\n'
             '  "fps": 64.7,\n'
             '  "latency_ms": 15.45\n'
             "}\n\n"
             "每个字段可独立审计:\n"
             "• score: 融合风险排序\n"
             "• proposal: 候选时间区间\n"
             "• member_logits: 7头一致性检查\n"
             "• track_id: 人物轨迹定位",
             title_color=NAVY)

    # ────────── Slide 10: 工程价值 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "工程价值", "可解释输出让系统更容易接入人工复核与告警审计", 10)

    # 系统输出字段
    outputs = [
        ("track_id", "定位具体人物轨迹", "通过 YOLO11n-pose 跟踪分配"),
        ("proposal", "回看候选时间区间", "从姿态运动生成，非标签读取"),
        ("member_logits", "检查成员一致性", "7头原始输出，可追溯"),
        ("score", "提供融合风险排序", "固定等权融合，不搜索阈值"),
        ("latency", "监测部署性能", "per-frame 计时，可复现"),
    ]
    for i, (field, desc, detail) in enumerate(outputs):
        y = Inches(1.5) + i * Inches(1.0)
        # 字段名
        field_bg = add_shape(slide, Inches(1.0), y, Inches(2.2), Inches(0.6),
                              fill=NAVY, line_color=NAVY)
        add_text(slide, Inches(1.1), y + Inches(0.1), Inches(2.0), Inches(0.4),
                 field, font_size=13, color=WHITE, bold=True, font_name=FONT_NUM)
        # 描述
        add_text(slide, Inches(3.5), y + Inches(0.05), Inches(4), Inches(0.3),
                 desc, font_size=13, color=NAVY, bold=True)
        add_text(slide, Inches(3.5), y + Inches(0.35), Inches(4), Inches(0.3),
                 detail, font_size=10, color=MID_TEXT)

    # 适用边界
    add_card(slide, Inches(8.0), Inches(1.5), Inches(4.5), Inches(4.5),
             "适用与不适用",
             "✅ 适用场景:\n"
             "• 养老院、家庭看护\n"
             "• 康复中心监控\n"
             "• 病房辅助值守\n"
             "• 工厂安全巡检\n\n"
             "⚠️ 不适用场景:\n"
             "• 医疗诊断依据\n"
             "• 唯一决策依据\n"
             "• 多人长期遮挡\n"
             "• 姿态严重缺失",
             title_color=ACCENT_ORANGE)

    # ────────── Slide 11: 结论 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "结论", "研究贡献在于低预算下整合互补时序证据，并保留可复核链条", 11)

    conclusions = [
        ("01", "方法", "16/48帧双尺度骨架 + 共享 ROI token + 七头固定融合",
         "双尺度时序建模捕捉短时冲击和长时上下文"),
        ("02", "证据", "五折配对增益、冻结验证指标、动态端到端演示",
         "4/5 折提升，bootstrap CI 显著"),
        ("03", "价值", "普通 RGB 输入、低参数规模、轨迹与时间区间可回看",
         "4.053M 参数，15.45ms 延迟，可审计输出"),
    ]
    for i, (num, title, content, detail) in enumerate(conclusions):
        y = Inches(1.5) + i * Inches(1.6)
        # 编号
        circle = slide.shapes.add_shape(MSO_SHAPE.OVAL,
                                         Inches(1.0), y + Inches(0.1), Inches(0.7), Inches(0.7))
        circle.fill.solid()
        circle.fill.fore_color.rgb = TEAL
        circle.line.fill.background()
        add_text(slide, Inches(1.0), y + Inches(0.15), Inches(0.7), Inches(0.6),
                 num, font_size=22, color=WHITE, bold=True, align=PP_ALIGN.CENTER, font_name=FONT_NUM)
        # 标题
        add_text(slide, Inches(2.0), y + Inches(0.05), Inches(2), Inches(0.4),
                 title, font_size=20, color=NAVY, bold=True)
        # 内容
        add_text(slide, Inches(2.0), y + Inches(0.45), Inches(10), Inches(0.3),
                 content, font_size=13, color=DARK_TEXT)
        add_text(slide, Inches(2.0), y + Inches(0.8), Inches(10), Inches(0.3),
                 detail, font_size=11, color=MID_TEXT)

    # 底部总结
    sep = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,
                                  Inches(1.0), Inches(6.2), Inches(11.5), Pt(2))
    sep.fill.solid()
    sep.fill.fore_color.rgb = TEAL
    sep.line.fill.background()
    add_text(slide, Inches(1.0), Inches(6.4), Inches(11.5), Inches(0.4),
             "面向养老、家庭看护、康复与病房辅助值守的工程化原型",
             font_size=14, color=NAVY, bold=True, align=PP_ALIGN.CENTER)

    # ────────── Slide 12: 参考资料 ──────────
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide)
    add_page_header(slide, "参考资料与可复核工件", "外部来源与项目证据路径", 12)

    refs = [
        "[1] UR Fall Detection Dataset, University of Rzeszów.",
        "[2] Ultralytics, Pose Estimation with YOLO.",
        "[3] PyTorch Documentation.",
        "[4] OF-Syn: OmniFall 合成跌倒数据集.",
        "[5] YOLO11n-pose: Ultralytics YOLO11 姿态估计模型.",
        "[6] Krogh, A. & Vedelsby, J. (1995). Neural network ensembles, cross validation, and active learning.",
        "[7] Kuncheva, L. I. & Whitaker, C. J. (2003). Measures of diversity in classifier ensembles.",
    ]
    for i, ref in enumerate(refs):
        y = Inches(1.5) + i * Inches(0.55)
        add_text(slide, Inches(1.0), y, Inches(11), Inches(0.4),
                 ref, font_size=11, color=DARK_TEXT)

    # 复现说明
    add_card(slide, Inches(1.0), Inches(5.5), Inches(11.0), Inches(1.0),
             "可复核工件",
             "运行包: weights/edgefall_seven_head_label_blind_v1.pt + weights/yolo11n-pose.pt\n"
             "推理命令: python -m tools.infer_seven_head <input.mp4> --artifact weights/edgefall_seven_head_label_blind_v1.pt\n"
             "MANIFEST.json: 174 个运行包文件按 SHA-256 清单核验；权重、源码与依赖清单均可追溯",
             title_color=TEAL)

    # ── 保存 ──
    prs.save(OUTPUT_FILE)
    print(f"✅ PPT 已保存: {OUTPUT_FILE}")
    print(f"   共 {len(prs.slides)} 页")
    return OUTPUT_FILE

if __name__ == "__main__":
    build_ppt()
