# 本机环境与 pose/window/sidecar cache 准备决策卡（DET-LOCAL-CACHE-20260824）

- **任务 ID / owner：**`DET-LOCAL-CACHE-20260824` / default integration lead
- **请求：**为后续、尚未选择的本机改进候选准备可复用的 OF-Syn + URFD `train`/`val` 数据层：锁定 Python/CUDA 环境，生成 pose cache、窗口 cache 和 bbox sidecar；绝不启动模型训练或评测。
- **非目标：**不运行 G2、A0、FallVision、mixed/distillation 或任何 epoch；不读取/生成 OF-Syn 或 URFD `test`；不替换根目录文件、不修改已有 checkpoint/config/manifest、不合并 worktree。

## 固定证据与输入

| 项目 | 证据 | 当前状态 |
|---|---|---|
| 原始数据 | `data/omnifall/data_files/omnifall-synthetic_av1.tar`、`data/sources/urfd` | 本机约 9.1GB OF-Syn tar + 117MB URFD；保留 train/val，test 不进入新 manifest |
| pose 权重 | `yolo11n-pose.pt` | 6,255,593 bytes，存在 |
| improved 初始化 | `checkpoints/handoff_20260824/distilled_tcn_initialization.pt` | 2,436,637 bytes，存在；是后续训练输入，不在本卡加载或训练 |
| 可执行闭包 | `.worktrees/handoff_g2_reconcile_20260824` | 11-file G2 closure + `pipeline/pose_cache.py` reconciliation；此前代码验证 124 tests、CLI/import smoke 通过；该 worktree 不得与根目录混用 |
| GPU | `nvidia-smi` 2026-08-24 | RTX 4060 Laptop 8,188MiB，driver 596.49 / CUDA 13.2；当前被桌面进程占约 2,357MiB（40% utilization），不可假设独占 |
| 环境 / 空间 | 本次实测 | 默认 Python 3.11.15 无 torch；无项目 venv；D: 余约 36GB（96% 使用） |

## 关键前置缺口

1. 不存在 `data/manifest_local.csv`；worker README 明确禁止复制含 sealed/machine-specific 行的主 manifest。
2. 不存在 `.npz` pose cache、window cache 或 sidecar；原始视频和模型参数并不等于训练器的特征输入。
3. 训练闭包本身仍是隔离 worktree 的未跟踪闭包文件；本卡只能在该 worktree 内使用，不能合入 root。
4. GPU 正被用户桌面进程使用，必须先确认资源可用后才开始长期 YOLO extraction。

## 最小单一改变

新增一个**隔离、版本化的本机数据准备 run**，工作区只允许：

```text
worktree: D:\HermesWorkspace\Detictive\.worktrees\handoff_g2_reconcile_20260824
environment: <worktree>\.venv-local-cache
manifest: <worktree>\data\manifest_local_ofsyn_urfd_trainval_v1.csv
artifacts: D:\HermesWorkspace\Detictive\runs\local_cache_20260824\
```

1. 从冻结、已存在的 OF-Syn/URFD metadata 生成一个只含 `dataset in {of-syn,urfd}`、`split in {train,val}` 的本机 manifest；必须独立计数、哈希、验证 identity/group 无跨 split，且在任何 source/cache 操作前拒绝 `test`。
2. 在 worktree 内创建隔离 venv，按照已审查的 requirements 安装；记录 Python、torch、torchvision、CUDA、driver、GPU 名称和磁盘余量。安装或 import/CUDA 失败即停止，不以全局包替代。
3. 先运行 20-clip、train/val、OF-Syn+URFD 的 pose-extraction canary（可恢复）；只在 cache schema、signature、resume（第二次零 YOLO）与 test guard 都通过后，再申请全量 cache。canary 不构成训练或性能评测。
4. 全量 cache 仅在 canary 通过、GPU 空闲且人工确认预算后顺序执行：pose cache → fail-closed audit → window cache → sidecar；每步 hash、数目和大小读回，失败不自动改参数或继续。

## 预算 / 停损

- **环境:** 最多 8GB 新磁盘；必须始终保留至少 20GB 空闲。
- **canary:** 最多 30 分钟 GPU、20 clips、只生成隔离 canary artifacts。
- **全量:** 本卡**不自动授权**。在 canary PASS 后另交 Sol 批准；预估 pose 提取约 10–12 GPU-hours，且不得和用户的现有 GPU 负载并行。
- **硬停：**torch/CUDA 不可用、任意 test 行进入 local manifest、manifest/cache signature 审计失败、canary 有 source/schema/resume 失败、磁盘<20GB、GPU 非空闲、OOM/NaN 或未知数据跳过。

## 验收

**本卡至多达到 E1 canary-ready / canary-passed：**

- isolated venv 可导入 `torch`、`cv2`、`ultralytics`，torch CUDA 可见；
- 版本化本机 manifest 不含 test，且 of-syn/urfd train/val 数据计数与源清单一致；
- canary 的 pose cache 与 audit 都可读；重跑有零 YOLO 调用；
- 新产物路径、命令、hash、资源记录可读回；
- 没有训练 checkpoint、mAP/P@R 指标或训练输出。

## Terra 前置审查（BLOCK）与修订请求

Terra 审查确认本卡所述的 20-clip pose-only canary 与远端 G2/A0 可以正交，但当前**不可执行**：

1. 现有 `tools/build_manifest.py` 会打开并输出 `test` split；现有 extraction/audit 仅拒绝 CLI
   参数 `split=test`，不会在 manifest 出现一条 test row 时于 source/cache/model/output 之前失败。
2. OF-Syn 当前 `group_id=path`，不能证明 subject/identity 不跨 train/val；cache audit 也未核验
   当前 source content identity。
3. 根目录存在历史 `runs/canary20/`（20 NPZ，16 OF-Syn val + 4 URFD val，零 train，且没有
   audit/window/sidecar/provenance），必须隔离，不得 resume/copy/复用。
4. root data 与 `yolo11n-pose.pt` 不在 worktree，任何未来命令必须使用绝对 root 输入路径；
   当前 GPU 非空闲，也触发本卡的 hard stop。

**拟议的 E0 修订（尚未获 Sol 实施批准）：**只新增一个 worktree-local、train/val-only manifest
producer 与回归测试；它不得打开 test metadata，必须在任一 non-`{train,val}` row 出现时、任何
source/model/cache/output 操作前 fail closed，验证 allowlist、schema、uniqueness、per-split count、
group 与 subject overlap，并原子写版本化 manifest。之后才可重新提交 Terra；环境安装、canary、
window/sidecar 与训练仍保持未授权。

## E1 Sol 审查状态

Sol 对 E1 的裁决为 **REVISE**：E0 已获 Terra PASS，但 environment + 20-clip pose canary 仍
需要四份 caller-supplied、train/val-only metadata、冻结 20-ID selection、路径封闭/provenance
envelope 与 OOM hard-stop 控制。用户于 2026-08-24 明确确认当前 GPU 占用**可共用**，因此“GPU
非空闲”不再是本次 canary 的阻断项；开始前仍须记录 GPU/VRAM snapshot，并在 OOM 或资源竞争
导致的异常时立即停止。metadata/provenance/path controls 仍未满足，故未安装环境、未生成 cache。

### 用户授权的 metadata 来源与尚存身份限制

用户于 2026-08-24 明确授权从本机版本化全量 metadata
`data/manifests/ofsyn_urfd_fallvision_v1.csv` **仅过滤** OF-Syn/URFD 的 train/val rows 来生成
caller-supplied canary metadata；不得读 source video、生成/读取任何 test cache，也不得将 test
row 写入任何新的 artifact。该输入 SHA-256 为
`c366da740ca7686222532c2d5f6413e585902a08bc5939a1e568bd2ac01686fe`；过滤后计数是 OF-Syn
train 9,600、val 1,200；URFD train 70、val 14。

但其 OF-Syn `subject=-1`（10,800 rows）且 URFD `subject` 为空（84 rows），无法诚实证明
subject-disjoint。拟议协议只能以现有的 unique clip-level OF-Syn `group_id` 和 URFD trial group
防止已知 group 泄漏，并将 `subject_identity=unknown` 写入 provenance；是否可据此运行 pose-only
canary 必须由 Sol 明确批准，且不得产生 subject-independent 性能声明。

## 交接

### 评审闭环规则

对本卡及后续 Lane B 阶段，Sol 的 `REJECT` / `REVISE` 不是默认终点：必须逐项写明阻断证据、
可验证的修复验收条件和最小预算；integration lead 据此实施限定修复，Terra 对修复及其证据
给出 `PASS/BLOCK/NEEDS-RERUN`，再把已消除和仍存风险交回 Sol 复审。只有目标本身不可行、
用户取消，或 Sol 明确判定不存在符合约束的修复路径，才将任务标为终止。该闭环不授权范围
扩张；每一轮仍须保持 train/val/test 隔离、预算与单变量约束。

### E2 用户资源授权（2026-08-24）

用户已明确授权全量 OF-Syn/URFD train+val pose-cache 阶段的硬上限：**最多 40 GPU 小时、最多
5 GiB 新 E2 产物、D 盘始终至少保留 20 GiB 空闲空间**。该授权只覆盖 cache 构建；不覆盖
window/sidecar、训练 epoch、评测、checkpoint、FallVision 或 test。若 E2 预检根据已冻结的
分 cell 吞吐/空间证据显示任一上限不可满足，必须在 source/model/cache 操作前停止并重新提交
修订预算，不得以自动降配、参数调整或越界继续。

- **From → To：**default integration lead → Terra evidence review → Sol approval → default/MiMo operator
- **请求 Terra：**对 manifest-origin、安全 guard、环境/磁盘预算、canary 隔离和是否与远端主路线冲突给出 `PASS/BLOCK/NEEDS-RERUN`。
- **请求 Sol（仅在 Terra PASS 后）：**是否批准 E1 环境 + 20-clip canary；全量 cache 需单独再审。
- **下一 owner：**Sol；在此之前不写 venv、不创建 manifest、不运行 extraction。
