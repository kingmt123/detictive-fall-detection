# G2 Residual-STGCN + Stage-Auxiliary 训练决策卡

## ID 与所有者

- **Task ID**：`G2-R1-20260824`
- **执行所有者**：`mimo25pro`（仅在 Terra/Sol 审批后）
- **集成基线**：主项目；G2 闭包来源为 Gate2A 后 RTX 5060 工作区 `parallel_worker_20260824`

## 请求的决定

是否批准对恢复后的 G2 多流 MIL 模型进行受控、三 seed 的 GPU 训练与**冻结 validation**评估。

## 假设

以蒸馏 TCN 初始化 474 个可兼容参数，并训练新增 residual-STGCN 与 stage-auxiliary 分支，可能提高冻结 validation 的 clip-level mAP；这是一项待检验假设，不是既有性能结论。

## 冻结基线与输入

| 项目 | 冻结值 |
|---|---|
| 主 manifest | `data/manifest.csv` |
| manifest SHA-256 | `fdea91af1e226a8fda9c863c1484af8a65841ba68d76cda57f2be9bdc45732df` |
| manifest 行数 | 12,100 |
| 训练 split | OF-Syn 9,600 + URFD 70 = **9,670 clips** |
| validation split | OF-Syn 1,200 + URFD 14 = **1,214 clips** |
| test split | OF-Syn 1,200 + URFD 16 = **1,216 clips**；全程封存、不得读取或用于 checkpoint 选择 |
| G2 config | `configs/handoff_20260824/multiscale_multistream_distilled_stage_s1_g2_residual_stgcn_v1.json` |
| config SHA-256 | `54b1c8ea1960daa7de4b3c9978a334e67c37acd05b294c6a3d280c304f6091a8` |
| 初始化 checkpoint | `checkpoints/handoff_20260824/distilled_tcn_initialization.pt` |
| checkpoint SHA-256 | `45a40f762d0f6c53b0b7aeb8f239b7260cdc5fb529776cce2b722afe131f8e0f` |
| checkpoint 审计 | 474 / 474 键和形状兼容；G2 模型 522 keys，其中 48 个 residual/stage 键新初始化 |

历史 checkpoint 的 `best_map=0.6963074949606011` 仅作来源记录：其原始 manifest/split hash 未交接，**不可作为当前可比 baseline**。

## 单一预注册改变

在相同 frozen manifest、相同 train/validation split、相同 clip-level mAP 实现下，训练：

- `use_stgcn_residual_joint=true`
- `use_stage_auxiliary=true`
- `stage_aux_weight=0.2`
- `use_discriminative_kinematics=true`
- `hard_negative_ranking_weight=0.0`（不启用已拒绝的 ranking 方案）

除随机 seed 外，不允许在三次运行之间改变架构、样本、数据、cache、指标、阈值或 config。

## 训练与评测协议

- **Seeds**：`20260817`、`20260818`、`20260819`。
- **每 seed 最大 epoch**：12（来自冻结 G2 config；warmup=1）。
- **设备**：`cuda`，RTX 4060 Laptop，8,188 MiB VRAM。
- **模型选择**：只依据 frozen validation clip-level mAP；不得读取 test split。
- **主要指标**：每 seed 的 validation clip-level mAP，以及三 seed mean / standard deviation。
- **成功阈值**：三 seed mean validation clip-level mAP ≥ **75.0%**；还必须有完整 OOF/每-clip预测、配置哈希、run metadata 与资源记录。任何单 seed 的峰值不构成成功。
- **Guardrails**：参数量记录；单 seed 不得超过 2 GPU-hours；不得产生 OOM、NaN、跳样本、cache 身份/签名不一致或 train/val/test 泄漏。

## Preflight（获批后、训练前）

1. 用 `tools.audit_pose_cache` 对 train 与 validation、OF-Syn 与 URFD 的 pose cache 覆盖、身份、提取签名和窗口可用性执行 fail-closed 审计；审计输出写至 `runs/g2_r1/preflight/pose_cache_audit.json`。
2. 从冻结 cache 构建并校验 train/validation sidecar；禁止重新运行 pose detector。
3. 记录 cache-root、window-cache-root、sidecar SHA-256、环境（Python/PyTorch/CUDA/GPU）、有效 windows 和 clips 数量。
4. 仅在 preflight 全部通过后，以空输出目录分别运行每个 seed；训练工具不支持对非空输出目录 resume。

## 计划产物

- `runs/g2_r1/preflight/`：cache audit、sidecar 与哈希记录；
- `runs/g2_r1/seed20260817/`、`seed20260818/`、`seed20260819/`：每 seed 的 `run.json`、checkpoint、validation/OOF 预测和日志；
- `runs/g2_r1/experiment_summary.json`：三 seed 聚合、资源数据和失败原因；
- `docs/experiment_cards/`：本卡和最终可复现记录。

## 预算、截止与停止条件

- **总 GPU 预算**：最多 **6 GPU-hours**（每 seed最多 2 GPU-hours）；不允许并行 GPU 训练。
- **最大训练运行数**：3；不得基于观察到的 validation 结果追加第四个 seed 或改参重跑。
- **自动停止 / BLOCK**：
  1. manifest/config/checkpoint/cache/sidecar hash 不匹配；
  2. 任一 cache audit 失败，或存在 test split 访问；
  3. OOM、NaN、非空输出目录、样本跳过、缺失 OOF/metadata；
  4. 单 seed 超 2 GPU-hours；
  5. 任何未预注册的超参数、batch size、数据、指标或代码变化。
- **回滚**：不修改主 manifest 或现有 checkpoint；异常时终止本次 seed，保留日志和失败工件，创建新的决策卡而非静默调整。

## 解释规则

- 若三 seed 平均未达 75.0%，结论是该预注册 G2 方案未达到目标，不得以单 seed 峰值替代。
- 即使达到阈值，也仅是 frozen validation 结果；Terra 需审计可比性、泄漏、种子与资源，Sol 再决定是否可进入封存测试或发布阶段。
