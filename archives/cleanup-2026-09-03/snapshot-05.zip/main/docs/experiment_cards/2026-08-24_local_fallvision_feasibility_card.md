# 决策卡：本机 FallVision 可行性闭环（DET-LOCAL-FV-20260824）

- **负责人：**本机集成负责人（default）
- **日期：**2026-08-24
- **决策请求：**在任何 GPU 训练前，决定本机是否可将 FallVision 作为与远端 G2/A0 不重叠的独立数据源；本卡只授权零 GPU 的数据、映射、环境审计。
- **明确不做：**不训练、不生成 pose cache、不访问 OF-Syn/URFD sealed test、不改变 `data/manifest.csv`、不合入或替换远端 G2/A0 的模型、配置或 checkpoint。

## 1. 固定输入与当前盘点

| 项目 | 证据 | 当前事实 |
|---|---|---|
| FallVision 原始资产 | `data/fallvision_subset` | 3,658 个原始 MP4（fall 2,117；non-fall 1,541），约 12 GB；本机实际文件路径均存在 |
| 外部关键点 | 同一目录 | 4,968 个 CSV；并非天然的一对一映射证明 |
| 当前版本化 manifest | `data/manifests/ofsyn_urfd_fallvision_v1.csv` | 3,658 条 FallVision rows：train 2,624、val 429、test 605；2,117 正、1,541 负；共 12 个 raw-directory group |
| 标签粒度 | `tools/build_manifest.py:114-162` | 仅目录级 `f_raw_*`/`nf_raw_*` fall 标签；没有事件时间边界，不能伪装为 fall-vs-controlled-transition 监督 |
| 锁定约束 | `parallel_worker_20260824/AGENTS.md:18,45-46` | OF-Syn test 永久封存；URFD test 保留；≤20M 参数、≤80MB FP32、≤100ms |
| 本机环境 | 本次实测 | RTX 4060 Laptop 8GB 可见；系统 `python` 无 `torch`；无 `.venv`/`venv`/`env`；D: 仅余约 36GB（96% 已用） |

当前 manifest SHA-256、worker/source revision、最终环境锁文件均尚未冻结为可执行训练版本；任何后续候选必须新建版本化目录，不能覆盖已有 manifest 或 runs。

## 2. 关键审计发现

### F0 — 当前 FallVision-only trainer 的 validation 不是 group-safe

`parallel_worker_20260824/tools/train_fallvision_joint_mil.py:117-124` 以 `seed:clip_id` 的哈希逐 clip 切分 train/val。它没有使用 raw-directory `group_id`。而 `tools/build_manifest.py:114-162` 明确把 raw directory 设为当前可获得的最保守 leakage group。故同一目录/会话 batch 的 clips 可同时进入 train 和 val，当前 trainer 的 `best_clip_map` 不可作为泛化或预训练价值的证据。

### F1 — 外部 keypoint CSV 与 MP4 的映射尚未验证

trainer 通过 `_canonical_id()` 去除 `resized/anonymized/keypoints` 后缀后选取 CSV（`train_fallvision_joint_mil.py:35-61`），但未与 MP4 manifest 做一对一覆盖、重复、帧数/时间轴、坐标空间、关节顺序、置信度和缺失值的契约校验。`data/fallvision_subset/...csv` 当前可读，且表头为 `Frame,Keypoint,X,Y,Confidence`，不足以证明其对应视频与项目 pose schema 兼容。

### F2 — 不能把目录级二分类当成主任务性能

FallVision 标签由目录前缀产生（`tools/build_manifest.py:137-159`）；它不提供 controlled lie/sit/stand 的阶段或事件标签。任何 FallVision 训练只能是**外部表征预训练/数据可行性**，不能报告为 OF-Syn/URFD high-recall metric 提升，也不能作为远端 A0 的对照。

### F3 — 当前执行环境未就绪

`requirements.txt:1-8` 声明 CUDA PyTorch，但本机默认 `python` 实测 `ModuleNotFoundError: torch`。并且 `parallel_worker_20260824` 是未跟踪交接树，根目录同族模块是半集成状态。不得以全局/未锁定依赖执行训练。

## 3. 唯一允许的下一工作：FVP0（零 GPU 数据/环境 closure）

**假设：**若 FallVision 的视频与 CSV 可审计地一对一映射，且可构造按 raw-directory group 不泄漏的 train/val（不创建可调 test），它才有资格作为后续独立的 joint-stream 表征预训练候选。

**单一变更：**新增只读 audit（或在独立、版本化目录产出 audit JSON），不修改数据和现有 manifest：

1. 独立盘点 raw MP4、CSV，计算 canonical ID 后的 exact-one / missing / duplicate / ambiguous 映射；输出每条的相对路径与映射状态。
2. 对 exact-one 对进行最小 schema 审计：17 COCO joint names、frame index 单调性、每帧 joint 数、有限坐标与 confidence、CSV frame coverage；只报告可验证项，frame-rate/time alignment 不明时标为 unknown。
3. 用 raw-directory 作为不可穿越 group，构造 **仅 train/val** 的候选 source manifest；保持 held-out 组为 `reserved`，不建立/读取训练 test 指标。
4. 输出 source inventory hash、原 manifest SHA、candidate manifest SHA、split seed、每 group/label/split 计数、泄漏审计和磁盘预算。
5. 建立隔离 `.venv` 或等价锁定环境，并仅验证 `torch` CUDA 可见、模块 imports、静态/数据审计 tests；不运行 epoch。

## 4. FVP0 验收与停损

| 类别 | 通过条件 | BLOCK/停止条件 |
|---|---|---|
| 映射 | 每个纳入 clip 的 MP4 恰好一个经验证 CSV；所有映射异常明列且不静默使用 | 任一未知/歧义映射被训练路径自动选取 |
| Split | train/val 的 group 交集为空；正负均在二者存在；reserved groups 不被读取 | group 跨 split 或仅 clip-level split |
| Schema | 17 joints、有限数、明确 confidence/缺失规则；未知时序对齐明确标 unknown | 发现坐标/关节/帧语义无法映射却仍继续训练 |
| Reproducibility | command、hash、seed、环境版本、产物路径可读回 | 默认解释器无 torch、环境未锁定或使用半集成模块 |
| Resources | FVP0 无 GPU、不可产生缓存；新增可回收产物 ≤1GB，D: 保留 ≥20GB | 空间不足、任何 cache/training/checkpoint 写入 |

## 5. 审核决定与已批准执行的 FVP0

### Terra evidence review — BLOCK FVP1 / PASS the corrective scope

Terra 独立审查确认当前 FallVision-only trainer 不可用于 GPU 训练：它不消费 manifest/group
（`parallel_worker_20260824/tools/train_fallvision_joint_mil.py:146-156`），而是递归发现 CSV 并
按 clip hash 切分（`:47-61,117-124`）。静态复现显示其 20/20 个 mask-keypoint session 目录
都会横跨 train/val；同时 5,831 个 deduplicated CSV clip 中只有 1,509 个 canonical ID 匹配
任一 raw MP4 manifest stem。结论：**GPU FVP1 BLOCK**；只允许 FVP0 新建 CSV-source
manifest、明确全部未配对/歧义文件、按 raw group 切分并把 reserved group 在读 CSV 前拒绝。

### Sol principal decision — REVISE / APPROVE FVP0 only

Sol 批准本卡第 3 节的零 GPU 数据契约闭环，额外固定为每标签 6 个 raw groups 的
**4 train / 1 val / 1 reserved** 分层分配（总 8/2/2 groups），不产生 `test` split 或任何
metric。执行上限：4 CPU wall-hours、0 GPU、≤100MB 可回收审计产物；FVP1/mixed training
仍需 FVP0 的 Terra PASS 和独立 Sol approval。

**执行隔离：**在 clean detached worktree `D:\HermesWorkspace\Detictive-fvp0-audit`
实现 `tools/audit_fallvision_assets.py` 和其 focused tests；输出只写入
`D:\HermesWorkspace\Detictive-fvp0-audit-output\20260824`。未触及 dirty `master`、
`data/manifest.csv`、OF-Syn/URFD、remote G2/A0 或 sealed split。

### FVP0 输出与 Terra read-back — BLOCK

FVP0 运行完成：focused tests `4 passed`，输出总计 3.0MB；审计记录 3,658 MP4、4,968 CSV，
其中 1,615 exact-one、17 ambiguous、2,026 video missing、3,303 CSV orphan。所有 1,142 个
candidate clips 都是 exact-one、schema-valid 且 frame-max match，且无 cross-split group 或
reserved row；但结果只有 `train:0=437`、`train:1=537`、`val:1=168`，**`val:0=0`**，不可能
支持二分类选择或 FVP1。

Terra read-back 还发现 validator 只校验每帧关节的集合而非每 joint 恰有一条记录：候选中
627/1,142 clips 有重复关节记录（含 127/168 val positives）；365/1,142 有 frame-index gaps，
合计 3,813 个 max-frame 之前的缺失编号。`video_frame_count == CSV max_frame` 不能证明时序、
person identity、坐标或 missingness 兼容。因此 **FVP1/mixed training 继续 BLOCK**。

在 Sol 对 FVP0-R1 的零 GPU 修订 scope 决定前，不得调整 split 或放宽 schema gate。

### Sol 对 FVP0-R1 的最终决定 — REVISE / 本机训练路线 BLOCK

Sol 复核确认，严格的 R1 eligibility 在现有产物中仍保留 470 clips（349 negative、121
positive；negative 覆盖 4 raw groups、positive 覆盖 6 raw groups），因此一个 group-isolated
binary train/val **理论上可行**；但不能保留旧的每标签固定 4/1/1 raw-group 规则，负类不具备
六个可用 groups。当前 R1 未实现，且不得把这一可行性判断当作训练授权。

Sol 给出的必经改动是：拒绝 duplicate `(Frame, Keypoint)`、unknown joint、非连续 `1..max_frame`
及失败的 frame probe；先从 exact-one+完整 schema/frame 合格的 assets 推导 eligible groups，再
以版本化 availability-first 规则分层切分；每个未合格 group/CSV 都要 machine-readable
`reserved/excluded` 原因；并且 extraction 和 evaluation 的 source/cache/video read 之前均须
显式拒绝 `reserved`。当前 downstream APIs 只保护 `test`，不保护 `reserved`，且现有测试没有
覆盖 duplicate、gap、eligibility 或 reserved pre-read rejection。

**最终状态（本轮）：**FVP0-R1 未获实施批准；FVP1 FallVision-only pretrain 与任何
FallVision mixed/distillation 训练均为 **BLOCK**。这只阻断 FallVision CSV 路线，**不等同于**
本机没有原始训练数据、初始化 checkpoint 或可执行的 improved-model 训练潜力：本机仍有
OF-Syn/URFD 原始视频、`yolo11n-pose.pt`、G2 initialization checkpoint 与 worker code closure。
该主数据路线的前置工作是锁定环境、在隔离 worktree 生成本机 pose/window/sidecar cache、并为
与远端不重叠的候选另立决策卡；不得把 FallVision 失败误报为“本机不能训练”。保留 clean
worktree 和 3.0MB audit artifact 作为可复核证据，不得把它们接入主工作树或现有训练入口。

## 6. 之后才可申请的 FVP1（未获批准）

只有 Terra 给 FVP0 `PASS` 且 Sol `APPROVE` 后，才可申请一个**FallVision-only、group-safe、joint-stream pretrain smoke**：

- 不混合 OF-Syn，不做蒸馏，不用 remote checkpoint，不训练多流/融合；
- 同一固定 train/val group split，最多 1 seed、最多 3 epochs、单 GPU、最多 45 分钟、产物目录全新；
- 仅记录训练可运行性、group-safe val proxy 及资源；不宣称对主任务的增益；
- 成功门槛不是高分，而是无 leakage、全日志/预测可复现、无 NaN/OOM、≤20M/80MB；
- 任何 CSV 映射、split、环境或资源违反即停止并删除仅本候选的可回收 run 产物。

若 FVP1 通过，下一张独立卡才可讨论：在一个**不用于远端选择**的固定 OF-Syn hard-negative cohort 上，比较 frozen FallVision encoder 与 skeleton-only reference 的错误互补性。没有这个 bridge evidence，不得启动混合训练或蒸馏。

## 7. 交接

- **Task ID：**DET-LOCAL-FV-20260824
- **From → To：**default integration lead → Terra evidence review → Sol approval
- **已完成证据：**本卡、`tools/build_manifest.py`、`parallel_worker_20260824/tools/train_fallvision_joint_mil.py`、`data/manifests/ofsyn_urfd_fallvision_v1.csv`、`tests/test_data_manifest.py`（本机实测 12 passed）
- **请求：**Terra 对 FVP0 给出 `PASS/BLOCK/NEEDS-RERUN`；若 PASS，Sol 对 FVP0 最小实现及 FVP1 是否预先授权给 `APPROVE/REJECT/REVISE`。
- **下一 owner：**Sol 在 Terra review 后决定；在此之前本机不启动训练。
