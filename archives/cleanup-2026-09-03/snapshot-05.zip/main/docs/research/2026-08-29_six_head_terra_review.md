# Terra evidence review — DET-ARCH-20260829-TERRA-RETRY

**Gate verdict: PASS**

The report is a sound, cautious guidance artifact within its declared evidence boundary.

- **Input integrity and reproducibility boundary:** the supplied DOCX hash matches `8d5a959cd7a65afdfe5a5f1f31566ea78c550cd9530353ad8e6229262bd97ab8`. The guidance explicitly distinguishes locally inspectable Stage-S1 skeleton code from the absent Person-ROI/six-head code, weights, fold manifests, bootstrap details and per-clip predictions; it correctly labels the six-head metrics as project records rather than an independent reproduction (§1.2–1.3).
- **Result interpretation:** the six-head anchor is supported as the best recorded template-group OOF candidate (`70.8311/77.5623/64.0998%`), while the P@R95 bootstrap interval crossing zero is retained and no statistical certainty is claimed. The severe-tail 40 FP/40 FN review is correctly treated as taxonomy evidence, not a population estimate or ground-truth rewrite.
- **Effective/failed boundaries:** effective claims are scoped to the reported implementation and protocol. Failed graph, long-context, pooling, quality, augmentation, verifier and fusion experiments are not generalized to entire method families. Transition residual is correctly separated into useful single-head signal versus failed ensemble contribution; missingness is demoted rather than declared universally ineffective.
- **OOF versus random-validation:** template-group OOF remains the sole selection evidence. Random-validation is clearly identified as template-overlapping, frozen, one-time directional confirmation and is prohibited from member, weight, threshold or architecture selection. Sealed OF-Syn and URFD test sets remain excluded.
- **Recommendation proportionality:** freezing the six-head equal-logit anchor, prioritizing artifact closure and end-to-end benchmarking, and deferring new training are proportionate to the deadline and missing reproducibility artifacts. Later ideas are bounded by single-variable canaries, replacement-before-addition, explicit guardrails and stop conditions; no gain promise is made.
- **Authorization boundary:** the document states that it does not authorize training, data, evaluation or release actions. Its P0/P1/P2 cards are recommendations for later governance decisions, not approvals; execution still requires the designated Lane-B gate. No sealed-test access or training is implied.

Residual limitation: this verdict assesses the report’s reasoning and caution, not the truth of the six-head metrics. Acceptance of the six-head model as a reproducible or deployable system still depends on the report’s P0 closure: immutable artifacts, independent metric recomputation, leakage checks, complete clip coverage, and measured size/latency compliance.

Next owner: `default/Hermes`.
