# Sol 最终首席决策 — DET-ARCH-20260829-D48-SOL-R5

## Decision scope

批准 `2026-08-29_seven_head_dense48_architecture_guidance.md`（SHA-256 `afec74d3a7f9b35cc79217f9ef8900e1378e7e79b81e746ec6635db1791ce6c5`）作为当前研究与架构指导报告，并接受其当前最佳模型建议：以**原六头 16-frame/320+640 Person-ROI ensemble，加一个原生连续 dense-48 skeleton/320 ROI 专家，七个 clip logits 固定 `1/7` 等权平均**，替代旧六头研究 anchor。

本批准严格限于“同一 OF-Syn train-only、五折 template-grouped OOF 协议下的当前内部准确率研究 anchor”。它不批准训练、代码或模型实现、阈值变更、random-validation 执行、sealed/URFD test 访问、部署、发布、竞赛提交或资源支出。报告中的截止后 P1–P6 路线仅是条件化研究路线图，不是本裁决授权的执行卡。

## Evidence relied on

本轮已在本机只读核验四个不可变输入，SHA-256 均与任务指定值一致：

- 实验记录：`25dabbcd73c00c9536125bb86b805aaff736d7649a44fee5dae630aaf15f993e`；
- 最终指导：`afec74d3a7f9b35cc79217f9ef8900e1378e7e79b81e746ec6635db1791ce6c5`；
- MiMo 可复现性/算术审计：`17137ca21f669b21e94604d37237a4156dfe52e162ecb5c93d58a4e7716ac1a2`，结论 `REPRO-CONSISTENT`；
- Terra 证据/可比性审计：`acd1044e21c1280eb6dabeaa467ff0cf81c519c3f8f702173cc3c4aa83b84af9`，结论 `PASS`。

核心证据为：六头与七头使用相同 9,600 个 held-out clips 和相同 fold assignments；pooled OOF 从 `70.831/77.562/64.100` 提高到 `72.166/78.762/65.570`；项目分数 mAP* 的绝对增量为 `+1.335` 点，paired template-group bootstrap 95% CI 为 `[+0.055,+2.333]`；P@R90/P@R95 点估计分别增加 `+1.200/+1.470` 点，但区间分别为 `[-0.028,+2.095]` 和 `[-0.603,+3.417]`；fold-2 mAP* 回退 `0.456` 点，fold-3 提升 `2.375` 点；R95 FP 救回 81、引入 19，净减少 62。Part-ROI 加头与替换方案的 pooled 三项均回退。

本轮另进行了三路独立交叉复核。独立架构评审与统计挑战者均支持严格限域批准；统计挑战者确认选择后推断、CI 下界接近零和单工作点不确定性会降低结论强度，但不足以推翻“内部当前 anchor”。部署边界评审指出报告包含截止后的条件训练/成员替换路线，存在被误当授权的风险；本裁决将其明确限定为非授权路线图，因此该问题不构成当前研究指导交付的 consequential defect。

## Threshold result

### 1. 新结果是否足以改变架构推荐：通过

七头候选在相同 clip universe 和 fold assignment 上完成配对比较，pooled 三项同升，mAP* 区间下界为正，且 R95 净救回为正，因此足以把“当前内部研究 anchor”从六头更新为七头。该阈值不要求它已经通过独立确认集或部署门。

成功解释应限定为**异质时间信息与独立时序状态带来的条件互补**：dense 成员使用原生连续 48 帧、独立 `e48` backbone，并与旧成员呈较低相关性；较弱单头进入 ensemble 后仍产生净增益。它不是“成员数增加必然有效”的证据，Part 第八头失败和同源 seed 饱和正好构成反例。同时，这一实验是“连续长历史 + 独立 backbone/head + 七头等权重分配”的组合干预，并非对帧数单因素的因果隔离；报告把推荐落在完整七头配置而非泛化为任意长窗模型，尺度适当。

### 2. 报告是否比例适当且完整：通过

报告已在首个结果区定义 `mAP* = (P@R90 + P@R95) / 2`，并明确它不是标准 Average Precision；已披露 P90/P95 CI 跨零、fold-2 回退、fold-3 仍为最弱折，以及 pooled OOF 不是逐折均值。它没有把三项点估计同升写成每折、每个工作点稳定显著，也没有把选择后的内部 CI 包装成独立外部泛化证明。

报告对 Part-ROI 的否定范围正确：只淘汰已测试的 confidence-constrained Part 表示及其当前加头/替换融合位置，不否定所有人体局部、支撑关系或受控性信息。dense 权重固定为 `1/7`、成员数冻结为七头；当前门期不搜索第八头、learned weights、dynamic gate 或其他融合器。

### 3. 研究接受与残余部署/测试门是否正确分离：通过

报告明确把七头定义为准确率研究 anchor，而不是部署就绪模型；online warm-up/track reset 一致性、七成员重建、完整 pipeline 的参数/FP32 体积/峰值显存/P50/P95 latency，以及七头新错误审计仍是未关闭的后续门。`≤20M / ≤80MB / ≤100ms` 必须按 pose、track、`e16/e48`、320/640 YOLO、七 heads 和 aggregation 的完整链路实测，不能由约 `1.343M` 可训练参数或缓存后 head latency 代替。

random-validation 尚未确认七头；若协议允许，只能在结构、成员、`1/7` 权重和阈值全部冻结后做一次预注册的方向确认，不得根据结果调权、换成员或继续搜索。OF-Syn sealed test 与 URFD test 继续保持未访问。本报告的截止后研究路线必须另行提交执行决策卡；不能从“条件探索/条件批准”字样推导训练或部署授权。

综上，未发现达到任务所定义 consequential threshold 的未解决权衡或指导缺陷；不需要以文字修订阻断当前报告作为研究指导交付。

## Residual risks and uncertainty

1. mAP* 是项目 High-Recall Score，不是标准 AP；任何外部摘录删除星号或公式都会造成实质误读。
2. 当前 bootstrap 是候选被多轮探索选中后的内部配对区间，未校正架构搜索和 continuation selection；`[+0.055,+2.333]` 不应作为确认性泛化显著性声明。
3. P90/P95 的区间均跨零，fold-2 回退说明七头不是跨模板区域一致占优；fold-3 的大增益也不能替代全折稳定性。
4. 两个时序 backbone 仍共享 pose/track 上游错误。离线 dense 窗口收益能否迁移到在线 actor identity、warm-up、缺失帧和 reset 行为尚未证明。
5. 约 `1.343M` 仅是所述可训练 skeleton/ROI 部分；完整模型体积、显存和端到端 P95 latency 尚未通过目标口径。
6. MiMo 的 `REPRO-CONSISTENT` 主要覆盖文本算术与解释一致性；本裁决没有重新训练、读取受限测试集或独立复现原始预测生成过程。
7. 当前 Part-ROI 失败不能外推为人体局部或受控性语义永久无效；只能停止同一表示和融合位置的低价值调参。

## Budget/resource compliance

本裁决遵守只读审查边界：除写入本决策文档外，未修改模型代码、配置、权重或实验工件；未训练、未运行新实验、未执行 random-validation、未访问 sealed/URFD test、未部署或发布。现有 dirty/untracked worktree 状态未被清理、覆盖或纳入本裁决。

**No model or training budget is authorized.** 本批准不产生新的算力、数据访问、测试或实施授权。

## Required follow-up/rollback trigger

下一所有者为 `default/Hermes`。在任何部署、发布或测试授权前，应按依赖顺序完成以下关闭项；本清单本身不构成执行授权：

1. 冻结并复核七成员配置/checkpoint metadata、raw clip logits、dense window/fold signatures、评测脚本和 paired-bootstrap 工件；从 raw logits 重建固定 `1/7` 七头输出，并确认 9,600/9,600 clip 身份及 fold assignment 完整一致。
2. 验证离线与在线 `window_size=48`、`stride=1`、`min_observed_frames=24`、因果左填充、末帧 track 可见、缺失表示和 track reset 语义完全一致。
3. 在声明的目标条件下执行完整 pipeline 模型/体积/显存/延迟门，不得用参数估算、单 head 或缓存后微基准替代。
4. 完成七头 R95 分层错误审计，单列 dense unique rescue、introduced errors、fold-2 回退与 fold-3 救回；在该审计完成前冻结成员数和 dense 权重。
5. 若协议允许 random-validation，一律先预注册“方向确认”的判定和失败处置，只执行一次；结果不得用于任何 retuning。sealed/URFD test 保持 untouched。
6. 截止后 P1–P6 或任何新训练、成员替换、stacking、测试/部署动作，必须另行提交决策卡，不得由本批准继承授权。

研究-anchor 回滚触发器：任一不可变输入哈希不匹配或被静默替换；raw logits 不能重建七头输出/主指标；clip 缺失、重复、标签冲突、fold 污染或 template-group 泄漏；原始工件与 mAP*/CI/R95 救回结论出现足以改变推荐顺序的实质矛盾；或冻结后的独立方向确认按预注册规则显示材料级整体反转。触发后撤回七头研究-anchor认可、恢复六头为临时研究基线并重新裁决，禁止据失败结果调 `1/7` 权重。

部署回滚触发器：在线窗口/track 行为与离线契约不一致，或完整链路任一 `≤20M / ≤80MB / ≤100ms` 门失败。此时回滚/阻断七头部署候选；该部署失败不自动抹除七头的内部 OOF 研究结果。任何将 mAP* 写成标准 AP、将本批准外推为训练/测试/部署/发布许可、或访问 sealed/URFD test 的行为均立即 `BLOCK`。

VERDICT: APPROVE
