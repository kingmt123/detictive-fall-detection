# Terra Evidence Review — Six-Head Post-Experiment Guidance

- Task: `DET-ARCH-20260829-TERRA-EVIDENCE-R4`
- Verdict: **PASS**
- Next owner: `default/Hermes`
- Scope: read-only evidence audit; no training, test execution, sealed-test access, release, or model/data mutation
- Audited guidance SHA-256: `a12a2729e0edac74417ad50cc15c8d9876031c4d0ecb6936bae01b13712a44f8` — matches the supplied hash

## Reasons

1. **A/B/C evidence boundaries are explicit and materially correct.** The report limits A/A- claims to independently recomputed fused-output metrics, fold-level results, R95 error identities, and the observed trade-off among the seven supplied output arrays. It keeps the two-head delta, Person-ROI/architecture attribution, member correlation, parameter topology, random-validation summary, and sealed-test non-access declaration at B/C-level or otherwise explicitly non-independent (`2026-08-29_six_head_post_experiment_architecture_guidance.md:110-135`). This matches the recomputation record’s missing-artifact inventory (`2026-08-29_evidence_recomputation.json:537-552`) and MiMo’s PARTIAL reproduction boundary (`2026-08-29_mimo_evidence_reproduction.md:87-104`).

2. **The nonstandard metric warning is prominent and unambiguous.** The report defines `mAP* = (P@R90 + P@R95) / 2`, states that it is not standard PR-curve Average Precision or AP50/AP50-95, and recommends renaming it for external use (`2026-08-29_six_head_post_experiment_architecture_guidance.md:24-30,137-141`). MiMo independently confirmed the same formula with zero deviation and showed why ordinary AP would differ (`2026-08-29_mimo_evidence_reproduction.md:38-48`).

3. **Equal-logit is presented as a policy trade-off, not as universally dominant.** The report acknowledges that fixed probability averaging is nearly tied, nonnegative logistic is slightly better at P95, and CDF-nonnegative logistic is best at P95 while losing P90 and mAP*. It also states that the available bootstrap intervals do not establish significance between these fusion outputs (`2026-08-29_six_head_post_experiment_architecture_guidance.md:305-326`). The recomputed values match the supplied outputs exactly (`2026-08-29_evidence_recomputation.json:68-205,207-243`). Retaining equal-logit is therefore framed proportionally as a zero-fit, simple research anchor under the declared joint policy, not as proof of method-family superiority.

4. **All material missing artifacts are disclosed and used as hard interpretation boundaries.** The report identifies absent six-member raw logits, two-head baseline arrays, template-group manifest, grouped-bootstrap reproduction inputs, code/config/checkpoints, random-validation arrays, and current end-to-end deployment measurements (`2026-08-29_six_head_post_experiment_architecture_guidance.md:62-68,110-120`). The evidence-pack README independently says the package excludes video, pose, bbox, track, weights, and code (`external_expert_evidence_pack_2026-08-29/README.md:13-33`). The report consequently does not claim training reproduction, member-to-fusion reconstruction, leakage exclusion, independent random-validation reproduction, or deployment compliance.

5. **Implementation failures are not improperly generalized to whole method families.** The report distinguishes the tested sparse 48→16 setup from dense long-history methods, current graph/3D replacement implementations from all graph/heatmap methods, and current augmentation/distillation failures from universal invalidity (`2026-08-29_six_head_post_experiment_architecture_guidance.md:423-433,451-507`). “Stop” recommendations are deadline-aware freezes of tested/current forms; untested families remain conditional research hypotheses rather than disproven facts.

6. **Recommendations are proportional to the evidence and deadline.** The immediate recommendation is to preserve the six-head model only as a research anchor, complete the member/group/baseline/deployment evidence closure, correct the fivefold audit protocol label, and avoid further pre-deadline architecture training (`2026-08-29_six_head_post_experiment_architecture_guidance.md:559-582,779-813`). Later ideas are ordered, bounded to single-variable canaries or no-training replay, equipped with stop gates, and conditioned on random stratified error audit or new observational information (`2026-08-29_six_head_post_experiment_architecture_guidance.md:584-704`). The final summary again distinguishes independently recomputed fused outputs from unreproduced member, baseline, grouping, and deployment claims (`2026-08-29_six_head_post_experiment_architecture_guidance.md:867-869`).

7. **Known provenance defect is surfaced rather than hidden.** The fivefold pair-audit file uses `paired_random_validation_prediction_audit_v1` despite its fivefold OOF context; both the report and MiMo require correction before release (`2026-08-29_six_head_post_experiment_architecture_guidance.md:141,569-570`; `2026-08-29_mimo_evidence_reproduction.md:83-85`). This defect does not invalidate the supplied fused-output recomputation, but correctly remains a release blocker until corrected.

## Residual non-blocking cautions

- “Current best architecture” and “must retain” are acceptable only within the report’s repeatedly stated **research-anchor** scope; they must not be shortened later into a claim of independently reproduced training, leakage-free grouping, or deployment readiness.
- The P0 closure gate includes proving group integrity and deployment limits; the present evidence does not satisfy those gates. A future deployment/release decision therefore requires a new audit, but the current cautious-guidance artifact does not require rerunning.
- The tail audit covers the highest-score 40 FP and lowest-score 40 FN, not the full error distribution; the report correctly requires random stratified audit before prevalence claims or new feature investment.

## Cross-review

An independent reviewer and a skeptical challenger both returned **PASS**. Neither identified a material overclaim, evidence-boundary violation, or disproportionate recommendation that would require blocking or rerunning this guidance audit.
