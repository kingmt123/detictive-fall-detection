# mAP90 完善激进版：旧最佳锚点 + 局部互补专家

日期：2026-08-25  
当前锚点：固定四模型骨架集成，clip mAP 71.1794%  
新增证据：F1（RGB–Pose late fusion 实验，非 F1 指标）、F2（Context ROI）、F3（quality-gated fusion）均已被验证无效

## 1. 核心修正

此前方案仍隐含了一个错误假设：新架构必须作为完整分类器，在总体 mAP 上直接超过旧框架，才具有价值。

更合理的策略是：

> **冻结旧最佳模型作为全局排序锚点。新架构不再承担全部样本，而只学习旧模型在 R90 或 R95 附近的局部错误。只要某个专家能稳定改善一个工作点，即使总体 mAP 暂时不高，也进入可学习专家库。**

最终系统不是“旧模型或新模型二选一”，而是：

```text
旧最佳四模型集成
        │
        ├── 提供全局基础分数 z_old
        ├── 确定 R90/R95 疑难分数带
        └── 保留已经有效的骨架运动先验
                    │
        ┌───────────┴───────────┐
        ▼                       ▼
 R90 Precision Expert     R95 Precision Expert
 专治高分难负例           专治高召回尾部难负例
        │                       │
        └───────────┬───────────┘
                    ▼
         受约束的局部 residual ranking
                    │
                    ▼
             最终 clip 排序分数
```

新架构可以在单项指标上失败或成功，不再要求“一次性替代旧框架”。

## 2. 旧最佳为什么有效

在设计新专家前，必须保留旧模型已经证明有效的部分。

### 2.1 输入表示与任务具有强匹配

旧模型的六流并非任意堆叠：

| 流 | 有效信息 |
|---|---|
| Joint 51D | 绝对姿态与关键点置信度 |
| Bone 32D | 身体结构、倾斜和关节相对关系 |
| Motion 34D | 快速下降和方向变化 |
| Geometry 6D | 人体框尺寸、位置和可靠性 |
| Rules 12D | 躯干角度、高度关系和连续物理提示 |
| Kinematics 15D | 失稳、下降速度和受控/非受控转变 |

这些特征直接描述“跌倒运动”，比未经充分微调的通用 RGB 特征更贴近当前任务。这解释了冻结 R3D-18 只有约 41%–44% mAP，而小型骨架模型能达到 70%以上。

### 2.2 多尺度因果 TCN 与跌倒时间结构匹配

kernel 3/5/7 和 dilation 1/2/4/8 同时覆盖短促速度变化与较长状态转变；因果注意力进一步汇总窗口内历史。16 帧虽然限制上下文，但对快速下降这一局部动作具有高信噪比。

### 2.3 小模型抑制了合成数据过拟合

单模型只有 161,406 参数。OF-Syn 约 9,600 个训练 clips，数据中存在生成纹理和背景偏差；小型姿态模型主动丢弃大量外观细节，反而降低了学习场景捷径的风险。

### 2.4 采样和辅助监督有效

- negative ratio 2:1；
- 对 `lie_down / lying / stand_up` 定向 hard-negative sampling；
- 四阶段辅助头；
- window + clip MIL 联合损失。

这些设置让模型不仅看到跌倒，还持续看到最容易混淆的活动。

### 2.5 四模型集成降低方差

同构集成虽然只增加约 0.90 mAP，但说明随机种子和增强产生了真实互补。它是当前最稳定的全局排序锚点，不应被尚未证明的新主干直接替换。

### 2.6 旧框架的弱点同样清晰

训练 top-k、验证 max-window 会放大孤立高分，因此：

- recall 较强；
- R90/R95 附近仍有大量高分假阳性；
- 新专家最有价值的任务不是重新识别所有视频，而是识别“旧模型为什么在这里给了错误高分”。

## 3. 从全面替代改为局部专家

### 3.1 当前误报规模

根据当前 validation 指标反推：

| 工作点 | TP | FP | 当前 Precision |
|---|---:|---:|---:|
| R90 | 约200 | 约70 | 74.07% |
| R95 | 约211 | 约98 | 68.28% |

局部专家不必一步把这些数字压到90%，分层目标如下：

| 专家等级 | R90目标 | R95目标 |
|---|---|---|
| 可学习 | 减少≥10 FP，损失≤1 TP | 减少≥15 FP，损失≤1 TP |
| 有价值 | 减少≥20 FP，损失≤2 TP | 减少≥30 FP，损失≤2 TP |
| 强专家 | FP≤34，约P85 | FP≤37，约P85 |
| mAP90候选 | FP≤22，约P90 | FP≤23，约P90 |

只要达到“可学习”级别，就说明该输入表示包含旧框架没有的局部判别信息，可以进入融合学习。

### 3.2 专家不是通用分类器

旧做法：

```text
全部正例 + 全部负例
→ 新模型
→ 希望总体mAP超过71.18
```

新做法：

```text
冻结旧模型OOF分数
→ 提取R90/R95附近的局部疑难样本
→ 训练专门的残差专家
→ 只在对应分数带修正旧排序
```

这会显著提高新模型看到有效训练信号的比例。

## 4. 新系统架构

### 4.1 全局 Anchor：保留旧最佳

```text
Anchor = 0.5 × primary
       + 1/6 × seed_1
       + 1/6 × seed_2
       + 1/6 × seed_3
```

输出 `z_old`。旧模型、权重和特征版本全部冻结，不在新实验中重新训练。

### 4.2 R90 Precision Expert

目标：压低旧模型在 R90 周围的高分难负例，同时几乎不损失已找到的跌倒。

推荐输入：

- 64/96帧完整 RGB；
- 可选 pose joint/limb heatmap volume；
- 冻结的 `z_old` 作为 logit offset，而不是普通输入特征。

推荐主干：InternVideo2-S、VideoMAE V2-B 或较小 VideoMambaPro。第一轮只选一个，不做早期多模态融合。

训练样本：

- 旧模型达到约 R80–R96 区间内的所有正负 clips；
- 对旧模型 top-FP 过采样；
- 负类保留具体 subtype。

损失：

```text
z_90 = stop_gradient(z_old) + r_90(video)
L_90 = asymmetric_focal(z_90, y)
     + 0.2 × subtype_CE
     + 0.1 × rank_preservation
```

`r_90` 学习的是旧模型残差，而不是从零学习跌倒分类。

### 4.3 R95 Precision Expert

目标：在更低阈值、更复杂的高召回尾部压低假阳性。

推荐输入优先使用 PoseConv3D 式 heatmap volume 或全帧 RGB，与 R90 expert 保持异构：

- 如果 R90 expert 使用 RGB，R95 expert 优先使用 heatmap VideoMamba；
- 如果 RGB 在 R95 也明显更强，可以使用相同 backbone 但独立数据带和损失。

训练样本：旧模型约 R88–R99 区间的 clips，重点包含：

- `lie_down`；
- `lying`；
- `stand_up`；
- 缓慢跌倒；
- 遮挡跌倒；
- pose failure 和生成畸变。

损失：

```text
z_95 = stop_gradient(z_old) + r_95(video_or_heatmap)
L_95 = high_recall_focal(z_95, y)
     + 0.2 × subtype_CE
     + 0.1 × positive_order_preservation
```

正类排序保护项防止专家为了减少 FP 而大幅压低原本正确的跌倒。

### 4.4 Positive Rescue Expert（可选）

若 R95 后仍有可识别的低分真跌倒，建立第三专家：

- 只训练旧模型低分正例与同分数段负例；
- 目标是追回至少 3–4 个旧 FN；
- 每追回一个正例允许新增 FP 数必须预注册，例如不超过 2 个。

该专家主要改善 PR 曲线最末端和最大召回，不应与 precision expert 共用训练目标。

## 5. 局部分数带的定义

不能在当前 validation 上人工指定阈值。每个 outer fold 内：

1. 用 inner-train 训练旧模型或使用严格 OOF anchor 分数；
2. 在 inner-validation 上确定达到 R80、R90、R95、R99 的分数分位点；
3. R90 expert 使用平滑带 `B90(z_old)`；
4. R95 expert 使用平滑带 `B95(z_old)`；
5. 将带边界冻结到 outer fold。

平滑带可使用 sigmoid 差：

```text
B(z; low, high, τ)
= sigmoid((z-low)/τ) - sigmoid((z-high)/τ)
```

它比硬阈值连续，避免阈值附近跳变。

## 6. 受约束 residual fusion

最终分数：

```text
z_final = z_old
        + α90 × B90(z_old) × clip(r90, -c90, c90)
        + α95 × B95(z_old) × clip(r95, -c95, c95)
        + αR  × BR (z_old) × clip(rR,  -cR,  cR)
```

约束：

- `α ≥ 0`；
- 初始值为0，因此初始系统严格等于旧最佳；
- residual 幅度裁剪，防止一个新专家推翻全局排序；
- 专家只在对应分数带生效；
- 带外 `z_final = z_old`。

这与 F1/F2/F3 的区别：

| 旧实验 | 新融合 |
|---|---|
| 全样本 embedding 融合 | 仅局部疑难带 residual 修正 |
| 新分支必须整体有效 | 专家只需一个工作点有效 |
| 与旧模型联合重新拟合 | 旧 anchor 完全冻结 |
| 没有旧指标保护 | mAP/R90/R95显式约束 |
| validation上容易调权重 | nested OOF 学习权重 |

## 7. 专家准入与生产融合是两层决策

### 7.1 专家准入

只要满足任一条件即可进入专家库：

- P@R90 提升≥2个百分点，R90 recall 损失≤0.5点；
- P@R95 提升≥2个百分点，R95 recall 损失≤0.5点；
- R90 FP 减少≥10且 TP 损失≤1；
- R95 FP 减少≥15且 TP 损失≤1；
- 在一个主要 hard-negative subtype 上 FP 减少≥25%，总体目标指标不恶化。

要求：至少 4/5 outer folds 改善，或 paired bootstrap 置信区间显示稳定正向趋势。

### 7.2 生产融合准入

进入最终融合还必须满足保护约束：

```text
目标工作点：至少 +2pp
另一个P@R工作点：下降不超过0.3pp
mAP：下降不超过0.2pp；最终目标阶段必须净提升
worst fold：下降不超过0.5pp
```

未通过生产融合的专家仍保留，后续可与其他专家组合或用于数据挖掘。

## 8. 融合参数如何学习

使用 nested grouped cross-fitting：

```text
Outer fold
  ├── Inner folds：训练专家、选择band和α/c参数
  └── Outer holdout：只做一次评估
```

融合优化不是单一 BCE，而是受约束目标：

```text
maximize AP(z_final)
subject to
  P@R90(z_final) ≥ P@R90(old) - tolerance90
  P@R95(z_final) ≥ P@R95(old) - tolerance95
```

若优化库实现复杂，第一版只做小规模预注册网格：

```text
α ∈ {0, 0.25, 0.5, 0.75, 1.0}
c ∈ {0.5, 1.0, 2.0}
```

参数少、可审计，优于在当前 validation 上训练复杂 meta-network。

## 9. 激进架构如何与旧最佳融合

### 9.1 InternVideo2/VideoMAE 不需要总体获胜

假设 RGB teacher 总体 mAP 只有 68%，但它能识别旧模型 R90 的 15 个高分假阳性，同时只压低1个真跌倒，那么它已经是合格的 R90 expert。

因此新的评估表必须包含：

| 模型 | 全局mAP | 独立P@R90 | 独立P@R95 | 对旧R90 FP识别率 | 对旧R95 FP识别率 | 与旧错误重叠率 |
|---|---:|---:|---:|---:|---:|---:|
| RGB expert |  |  |  |  |  |  |
| Heatmap expert |  |  |  |  |  |  |
| Old anchor | 71.18 | 74.07 | 68.28 | — | — | — |

局部互补性优先于专家的独立总分。

### 9.2 旧模型作为专家训练的 prior

使用 `z_old` 作为冻结 offset，等价于告诉新模型：

> 不要重新学习旧模型已经会的东西，只学习为什么这个样本应比旧分数更高或更低。

这比普通 concat `embedding_old + embedding_new` 更直接，也更容易在小数据上训练。

### 9.3 级联部署

端侧运行：

```text
所有视频先运行旧最佳骨架模型
   │
   ├── 分数远离疑难带：直接使用旧分数
   └── 进入R90/R95疑难带：调用较重视频专家
```

如果只有约20% clips进入疑难带，重型专家的平均计算成本也只按约20%计入；这允许使用比端侧常驻模型更强的 InternVideo2-S 蒸馏学生或 VideoMamba 模型。

## 10. 数据闭环改为“旧错误驱动”

### 10.1 专家训练集

每个 outer fold 从旧 OOF 预测构建：

```text
old_true_positive_near_R90
old_false_positive_near_R90
old_true_positive_near_R95
old_false_positive_near_R95
old_false_negative_tail
```

为避免只记住少量样本：

- 加入相邻分数带样本；
- 同一源视频/人物只在一个 fold；
- 对 subtype、场景和人物尺度分层；
- 记录重复/近重复视频。

### 10.2 错误标签

每个旧 FP 至少标记：

```text
lie_down
lying
stand_up
sit_or_bend
pose_failure
id_switch
occlusion
camera_motion
synthetic_artifact
annotation_error
```

不同 expert 可以针对不同错误簇，不要求一个模型覆盖全部。

### 10.3 专家增量训练

每一轮只加入在旧模型和已有专家上仍错误的样本，形成 boosting 式闭环：

```text
Anchor errors
→ Expert-1纠正
→ Remaining errors
→ Expert-2纠正
```

新增 expert 必须带来新的错误覆盖；与现有专家错误重叠超过90%则不进入融合。

## 11. 推荐专家顺序

### Expert 1：R95 hard-negative RGB verifier

优先级最高，因为 R95 有约98个FP、改进空间最大。

- 模型：InternVideo2-S 或 VideoMAE V2-B；
- 输入：完整64/96帧RGB；
- 训练：旧R88–R99带；
- 目标：先减少15个FP、损失≤1TP。

### Expert 2：R90 pose-heatmap verifier

- 模型：PoseConv3D/VideoMambaPro；
- 输入：joint+limb heatmap；
- 训练：旧R80–R96带；
- 目标：先减少10个FP、损失≤1TP。

### Expert 3：missed-fall rescue

只在错误审计证明低分正例可被视频模型识别时启动。

### Expert 4：特定 subtype 专家

如果 `lie_down` 占高分FP的30%以上，训练 fall-vs-lie_down 二分类专家；它不处理其他活动。

## 12. 新实验路线

| 阶段 | 实验 | 成功定义 |
|---|---|---|
| A0 | 冻结旧anchor并生成grouped OOF | 完整复现71.18/74.07/68.28附近结果 |
| A1 | 构建R90/R95疑难带 | 每个样本可追溯到fold、subtype和旧分数 |
| E95 | RGB residual expert | R95减少≥15FP、≤1TP损失 |
| E90 | Heatmap residual expert | R90减少≥10FP、≤1TP损失 |
| F0 | 单专家受约束融合 | 目标P@R +2pp，其他指标受保护 |
| F1 | 双专家融合 | mAP净提升≥2点 |
| B1 | 剩余错误boosting | 新专家错误重叠<90% |
| M1 | 中期候选 | mAP≥80、P@R90≥82、P@R95≥76 |
| M2 | 强候选 | mAP≥85、P@R90≥87、P@R95≥82 |
| Final | mAP90候选 | mAP≥90、P@R90≥90、P@R95≥85 |

报告中的 `F1` 实验编号不再复用，避免与已经失败的 late-fusion F1 混淆。

## 13. 停损条件

### 专家停损

- 独立总体分数低不构成停损；
- 对目标旧错误带的 FP 减少不足10%才停损；
- TP损失超过FP收益预注册比例则停损；
- 5折中3折以上反向则停损。

### 融合停损

- 目标指标提升但 mAP下降超过0.5点：保留专家，停止当前融合；
- 当前 validation 有效而outer OOF无效：判定过拟合；
- α最优值反复落在0：专家没有融合价值；
- 两个专家错误重叠>90%：只保留更强者。

## 14. 与 mAP90 的现实关系

局部专家路线不会承诺一次跳到90，但它提供了一条可累积路径：

```text
71.18 old anchor
→ R95专家削掉第一批高分FP
→ R90专家重排中高分难例
→ rescue专家追回低分正例
→ subtype专家继续削减剩余错误
→ AP fine-tuning优化最终局部排序
```

每个模块可以只在一个指标上证明价值，避免“新架构总体不如旧模型，所以全部废弃”的错误结论。同时，旧最佳始终存在于最终公式中，不会丢失已经有效的骨架运动能力。

## 15. 文献依据

1. Duan et al., **PoseConv3D**, CVPR 2022：姿态热图比坐标图序列更抗pose噪声，适合作为异构专家。  
   https://openaccess.thecvf.com/content/CVPR2022/html/Duan_Revisiting_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html
2. Wang et al., **InternVideo2**, ECCV 2024：完整视频迁移表示和小型模型可作为RGB专家。  
   https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/11491.pdf
3. Li et al., **VideoMamba**, ECCV 2024：线性复杂度长视频建模，适合heatmap/RGB专家。  
   https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/03773.pdf
4. Elmi, **PG-ProtoFall**, 2026：appearance与pose具有跨数据集互补性，但本项目F1/F2/F3表明不能直接照搬全局late fusion。  
   https://www.sciencedirect.com/science/article/abs/pii/S174680942601195X
5. Qi et al., **SOAP/AUPRC Optimization**, NeurIPS 2021：最终AP导向精修。  
   https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html
6. Eban et al., **Scalable Learning of Non-Decomposable Objectives**, AISTATS 2017：P@R等非分解目标的直接优化依据。  
   https://proceedings.mlr.press/v54/eban17a.html
7. Schneider et al., **OmniFall**, 2025：跨域验证和错误分层的必要性。  
   https://arxiv.org/abs/2505.19889

## 16. 最终建议

完善后的激进方案不是撤掉旧最佳，也不是让 FallMamba-X 一次性取代它，而是：

> **冻结当前四模型骨架集成作为全局 anchor；把完整RGB、pose heatmap、VideoMamba/InternVideo等激进架构训练成 R90、R95 或特定 subtype 的局部 residual experts。只要某个专家能稳定减少对应分数带的FP或追回FN，即使它总体mAP较低，也进入专家库。最终通过nested OOF学习非负、幅度受限、仅在疑难带生效的残差融合。**

第一优先实验应改为 **R95 hard-negative RGB residual expert**，不是通用RGB分类器。它只需证明：在旧模型R95疑难带中减少至少15个FP、损失不超过1个TP。只要达到这一点，新视频架构就已经产生了可学习互补信息，可以与旧最佳融合并继续boosting。

