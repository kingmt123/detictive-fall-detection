# Detictive Fall Detection：七头 Dense48 深度架构、分层融合与下一阶段完整研究报告

日期：2026-08-29  
任务 ID：`DET-ARCH-20260829-DENSE48-R6`  
性质：**在R5七头报告基础上，对计算图、信息冗余、融合自由度、错误机制和在线部署做第二轮多Agent深审后的完整研究报告**  
选型协议：OF-Syn train-only、五折 template-grouped OOF  
禁止项：不访问 OF-Syn sealed test 或 URFD test；random-validation 不参与成员、权重、阈值或架构搜索  
状态：研究与架构指导；不自动授权新的训练、数据访问、部署或发布

## 0. 结论先行

### 0.1 当前最佳模型已经从六头更新为七头

当前最佳结构是：

> **原六头 16-frame/320+640 Person-ROI ensemble + 一个独立原生连续 48-frame skeleton/320 ROI 专家，七个 clip logits 固定等权平均。**

五折 template-grouped OOF：

| 方案 | mAP* | P@R90 | P@R95 |
|---|---:|---:|---:|
| 原六头 fixed equal-logit | 70.831% | 77.562% | 64.100% |
| **六头 + dense-48/320** | **72.166%** | **78.762%** | **65.570%** |
| **绝对增量** | **+1.335** | **+1.200** | **+1.470** |

> **指标口径：**本项目的`mAP* = (P@R90 + P@R95) / 2`，不是标准Average Precision。下文保留`mAP*`只是为了与实验记录一致。

### 0.2 对此前判断的关键修正

1. **原生 dense-48 有效，旧的稀疏48帧失败不能继续外推。** 旧实验把48帧以stride=3压成16个token并复用短窗编码，真正的连续长历史没有被测试。本轮`window_size=48/stride=1`保留连续时刻，直接证明长历史可以成为有效的新成员。
2. **“不增加第七头”应改成“不得增加同源重复头”。** dense-48虽然是第七头，但它新增的是连续48帧skeleton history，和旧六成员的相关性只有`0.917–0.937`，明显低于旧成员内部的约`0.950–0.972`。它满足的是异质成员准入，而不是继续堆seed。
3. **弱单头不等于无价值成员。** fold-0 dense-48/320单头`68.718/76.734/60.702%`低于16帧单头，但加入六头后fold-0三项均升；ensemble selection应看条件互补和净救回，而非只按单头排名。
4. **Part-ROI未晋级。** 置信度约束的upper/torso/lower token覆盖率很高，但直接加为第八头和替换320/seed30都使五折总体三项下降。局部裁剪增加了特征维度，却没有形成足够独立的新错误集合。
5. **七头的可靠结论是项目综合分数改善，不是每项增益都已稳定显著。** mAP* paired bootstrap 95% CI为`[+0.055,+2.333]`点；P90和P95区间仍跨零，fold-2 mAP*下降`0.456`点。应晋级为当前anchor，但不能写成对每个fold、每个工作点都稳定占优。

### 0.3 当前行动判断

- **冻结当前incumbent为七头`1/7` equal-logit。** 不在现有五折OOF上直接调权或宣布新融合更优；下一轮只预注册RMPTS一维质量守恒时域迁移，并以完整nested template-grouped cross-fitting作候选验证。
- **立即补做七头全链路benchmark。** 新成员不增加320 YOLO pass，但增加一个48帧skeleton temporal pass；参数从约`1.034M`增至约`1.343M`，真正风险是时延、缓存、轨迹历史和在线状态管理，而不是模型体积。
- **random-validation尚未确认七头。** 旧六头random-validation数字不能绑定到七头；若协议允许，只能在全部结构和融合冻结后做一次方向确认，不能再据此调dense权重。
- **后续研究重点仍是actor/track可观测性与受控性语义。** dense-48已补强时间覆盖，但Part-ROI失败说明仅切更多人体局部区域并不能自动解决主动躺下、静态躺卧和缓慢fall的边界。

### 0.4 新实验内部审计

新报告中的主要算术和协议记录一致：

- `mAP*`分别等于对应P90/P95的算术平均；
- 参数增量=`164,122 + 144,903 = 309,025`，总参数=`1,342,565`；
- 七头逐折mAP*变化为`+0.648/+0.500/-0.456/+2.375/+0.234`；
- R95 FP救回81、引入19，净减少62；
- Part第八头delta为`-0.219/-0.147/-0.290`，替换方案为`-0.264/-0.503/-0.025`；
- dense-48 fold map与旧map的9,600个held-out clip身份一致，最终窗口覆盖恢复为9,600/9,600；
- 当前记录未访问sealed test、URFD test或random-validation。

### 0.5 “旧判断→新实验→更新结论”矩阵

| 旧判断 | 新实验 | 更新结论 |
|---|---|---|
| 稀疏48→16、O1/O2失败，dense history未判定 | 原生连续48帧、独立backbone、完整五折 | **长历史方向已获得正结果；旧失败仅属于稀疏/共享实现** |
| 不直接加第七头 | dense成员相关性显著更低，三项总体同升 | **改为禁止同源加头；允许满足互补门的异质成员** |
| 单头应先过门再做替换 | dense单头较弱但ensemble增益明显 | **准入优先看条件互补，单头性能只作安全参考** |
| static/slow FN可能需要更长历史 | fold-3提升`+2.375`，总体P95提升`+1.470` | **时间覆盖确有价值，但仍需错误级归因确认** |
| 局部人体区域可能补足受控性信息 | confidence Part-ROI加头与替换均失败 | **当前Part编码淘汰，不继续扫阈值/margin/部位框** |
| fixed equal-logit是低方差anchor | 七个logits继续固定等权并晋级 | **简单静态融合原则继续成立** |

### 0.6 R6进一步研究后的新增结论

1. **“七个模型等权”并不等于“信息来源最优分配”。** 当前六个短窗head共享`e16`，其中三个320、三个640；Dense48只有一个。因此`1/7` equal-logit把三类成员质量分成`3/7、3/7、1/7`。但Dense同时属于320视觉family与48帧时间family，直接把三block拉到各`1/3`会同时破坏已验证的320/640分辨率平衡。
2. **最值得验证的新融合不是七维stacking，而是RMPTS一维质量守恒时域迁移。** 固定640总质量`3/7`，固定320视觉family总质量`4/7`，只在“320短窗三seed”和“320 Dense48”之间迁移一个`delta`。它保留seed对称性、分辨率质量和一个有效自由度，并允许数据把Dense权重向上或向下调整。
3. **该融合不能在现有OOF表上直接搜索后再回报收益。** 基模型OOF不等于meta-model OOF；Dense成员本身又是在同一研究序列中被选择出来。任何“更好融合”的正式收益必须来自outer holdout隔离、inner grouped OOF选权、outer fold重训基础成员的完整nested protocol。
4. **下一条准确率路线不是再加seed，而是补当前没有覆盖的信息轴。** 七头已覆盖16/48时间跨度、320/640空间尺度和有限seed方差，但仍只看top-1 actor、没有显式支撑/接触语义、对动作阶段主要是隐式建模。
5. **actor/track先于新分类头。** 如果正确跌倒者没有进入当前track，或48帧历史混入另一人，七个head会一起错；共享输入错误无法靠融合修复。第一优先级应是top-k track只读replay与错误切片，而不是训练第八头。
6. **部署优化应先共享缓存和调度，不共享学习参数。** `e16/e48`独立性正是Dense互补来源；可做因果ring buffer、ROI缓存复用和等价流式计算，但不能未经OOF非劣验证就共享backbone前层、hidden state、剪成员或蒸馏。

---

## 1. 实验输入与审计口径

- 最新实验记录：`C:/Users/kingmt/AppData/Local/hermes/attachments/2026-08-29-dense48-and-confidence-part-roi.md`
- 文件 SHA-256：`25dabbcd73c00c9536125bb86b805aaff736d7649a44fee5dae630aaf15f993e`。
- 本次以该记录中的五折结果、配对bootstrap、相关性、参数和数据契约更新当前架构判断；此前六头实验仍作为直接baseline。
- 完整代码与run工件位于另一台电脑，本次不冒充代码复现，也不使用本机旧代码解释最新实现。
- 本报告的目标是审计实验设计是否自洽、结论是否与结果匹配，以及它如何改变当前模型与后续优先级，而不是重新质疑已完成实验的真实性。

### 1.1 选型门

新成员晋级同时考虑：

1. 完整五折template-grouped OOF；
2. mAP*、P@R90、P@R95总体方向；
3. paired template-group bootstrap；
4. 与现有成员的score/error互补；
5. R95救回与引入；
6. 逐折稳定性，尤其是旧弱fold-3；
7. 参数、YOLO pass、temporal pass和在线状态成本。

### 1.2 当前结论强度

- **可冻结为当前研究anchor：**七头固定等权融合；
- **明确淘汰：**当前confidence Part-ROI第八头及替换方案；
- **仍需部署门：**端到端P50/P95、峰值显存、48帧track history在线管理；
- **仍需一次冻结后确认：**七头random-validation（仅当协议允许，且不得用于调参）；
- **不授权：**sealed-test/URFD-test访问、继续架构搜索或外部发布。

---

## 2. 当前模型逐模块结构审计

## 2.1 输入与六流特征

| 流 | 维度 | 作用 | 当前判断 |
|---|---:|---|---|
| Joint | 51D | 17 个 joint 的 `x/y/confidence` | 保留；是最完整的原始姿态流 |
| Bone | 32D | 16 条骨边端点差 | 保留；提供局部相对形状先验 |
| Motion | 34D | 相邻帧 17 joints 的 `dx/dy` | 保留；对快速下落敏感，但会放大 pose jitter |
| Geometry | 6D | bbox 中心、宽高、aspect、observed | 保留；补足人体整体位置/尺度 |
| Rule | 12D | 连续姿态、运动、框变化先验 | 保留；提供受控且低维的物理归纳偏置 |
| Kinematics | 15D | acceleration、jerk、downward velocity、stillness 等 | 保留；与 impact/停止阶段直接相关 |

把 joint、bone、motion、bbox、规则和运动学分流，而不是一次性堆成高维向量，实质上是在小数据下施加结构先验。ST-GCN、CTR-GCN、InfoGCN 分别说明了骨架拓扑、通道特异拓扑和信息约束表征的价值，但本项目的 replacement/fusion 结果表明：论文中的架构优势不能抵消删除现有强 Joint-TCN 或增加同源误差的代价。[19][20][21]

### 缺失语义的最新判断

旧指导报告曾指出 frame-level observed mask 可能让 confidence=0 的 joint 产生伪 bone/motion，这也是本轮 P1/Motion+17D 实验的来源。GRU-D 的核心思想是同时向模型显式提供 missing mask 和距上次观测的时间间隔，说明“缺失模式本身”应被建模，而不是只用零值隐式代表。[22]

但项目新实验已经改变优先级：

- P1 per-joint mask：mAP 极小正向，P95 下降；
- Motion+17D validity：未超过 Primary；
- Real-Q/Real-T：反复伤害 P95。

因此应把 missingness 从“近期主精度候选”降级为：**代码语义/鲁棒性修复候选，仅在真实遮挡和 track 失败切片上证明收益后再训练。**

## 2.2 多尺度 depthwise causal TCN

每个 stream 先做 `1×1` 投影，再经过 dilation=`1/2/4/8` 的四个因果残差块。每块包含 kernel=`3/5/7` 的三条 depthwise Conv1D 分支、拼接后的 `1×1` mixing、BatchNorm、ReLU、dropout 和块内 SE。

TCN 文献表明，因果扩张卷积具有稳定梯度、可并行计算和较长有效记忆等优势；MS-TCN 进一步展示了多尺度/多阶段时序卷积对动作阶段建模的价值。[4][7]

本项目的具体风险是：在 16-token 输入下，kernel=3/5/7 四层名义感受野分别可达 31/61/91 帧，均超过输入长度。后层大量依赖左侧 padding，故继续扩大 kernel、dilation 或层数没有现实依据。

**更新结论：保留同一轻量TCN单元，但采用两个原生时间跨度。** 六个旧成员继续消费16帧；新增专家用独立同构backbone直接消费连续48帧。有效变化来自输入历史和独立编码器，而不是在16-token短窗上继续增大kernel/dilation。

## 2.3 SE 门控

每个因果块使用时间全局平均后的通道 SE，六流拼接后还有一次 384D fusion SE。SENet 的机制是利用全局统计自适应重标定通道响应。[5]

对本项目而言：

- 块内 SE 可抑制局部冗余通道；
- fusion SE 可重标定六流；
- 但 ROI fusion head 又引入了新的投影和融合层，继续增加额外 gate 容易变成重复门控。

**结论：保留现有 SE；不再添加质量 gate 或跨头 gate。** 新报告中 F3 quality cross-head 和 nested quality calibration 均未晋级，已提供项目内反证。

## 2.4 因果 self-attention 与 Joint-only Transformer adapter

每流 TCN 后都有 4-head causal self-attention + residual + LayerNorm。Joint 流额外使用两层 MLP feed-forward adapter，因此“Joint-only Transformer”并不是替换 TCN，而是在 TCN+attention 后补充通道非线性。Transformer 的核心价值是内容相关的全局交互，但它本身不包含骨架拓扑先验。[6]

该设计比“所有流都 Transformer 化”更适合当前小数据：

- TCN 保留局部因果先验；
- attention 只负责 16-token 内的内容相关聚合；
- 额外 FFN 只给信息最完整的 Joint 流；
- 参数仅从旧模型增加到 164,122。

**结论：保留。** 不把局部正向结果外推为“Transformer 家族优于 TCN”；本项目中纯/替换式 Transformer、SA-TDGFormer 等并未形成稳定收益。

## 2.5 last-token readout

每流最终返回 `temporal[:, -1]`，再投影为 64D。因为前面的 TCN 和 attention 都是因果的，最后 token 理论上汇聚最近 16 帧历史，符合在线检测。

风险是：

- static post-fall 中，真正 transition 可能已离开 16 帧；
- slow/partial fall 的判别证据可能分布在多个位置；
- 单一 last-token、窗口级训练和 clip-max 推理形成层层选择。

注意力 MIL 说明 bag 内实例贡献可学习，但本项目 smooth-max、attention pooling、residual attention 和 verifier 已多次失败。[23] 因此不能据论文再次启动同源 pooling sweep。

**更新结论：last-token本身可以保留，但短窗和长窗必须各自形成因果状态。** dense-48正是“不同输入历史+独立readout”的成功实例；它不替换16帧成员，而是补充较长状态记忆。后续不再把“更长历史”与“替换last-token”绑定为同一改动。

### 2.5.1 原生 dense-48 窗口契约

成功版本不是把48帧压缩成16个稀疏token，而是直接生成连续48位置窗口：

| 字段 | 固定值 |
|---|---|
| `window_size` | `48` |
| `stride` | `1` |
| `min_observed_frames` | `24` |
| warm-up | 因果左零填充 |
| 输出条件 | 末帧仍看见该track |
| 缺失表示 | 全零，并由observed/validity区分 |
| 未来帧 | 禁止访问 |

初版若完全禁止warm-up，会因track断裂漏掉3/9,600个clip。最终版本没有降低`min_observed_frames`，而是采用在线一致的因果左填充，恢复9,600/9,600身份。训练窗口共`814,102`，其中正/负为`118,476/695,626`；sidecar shape为`[814102,48,6]`。

这一修正很重要：它避免通过降低最小观测量“修复覆盖率”，也把视频开头、track短暂缺失和真实历史长度明确区分。部署时必须复用同一warm-up、末帧可见与track reset规则，否则离线OOF收益不能直接迁移到在线推理。

## 2.6 六流融合与 skeleton embedding

六个64D stream embedding拼接为`384D`并经过fusion SE。当前系统实际有两套时序embedding：

- `e16`：共享给原320/640六个ROI heads；
- `e48`：由独立同构backbone生成，只供dense-48/320专家使用。

skeleton classifier仍可作为辅助输出，但最终ROI专家消费的是对应时间跨度的skeleton embedding。

这是典型的中后期表征融合：先让各流独立编码，再联合决策。多模态融合研究表明，瓶颈式或晚期融合可以限制跨模态交互成本，但是否有效取决于互补信息而非模块名称。[28]

**结论：保留384D表示维度和六流归纳偏置，同时保留`e16/e48`两套独立时序状态。** dense-48的成功说明，相同特征语义在不同原生时间跨度下也能形成有效互补；关键是独立历史和独立编码，而不是简单复制同一embedding。

## 2.7 Frozen YOLO P3/P4 Person-ROI tokens

每个16-frame RGB采样clip同时以320和640两种分辨率经过frozen YOLO11n；在person ROI上分别对P3的64 channels和P4的128 channels做ROI mean，形成每帧192D token。dense-48专家复用既有16-frame、320分辨率ROI token和同一次YOLO pass，只把配对的skeleton状态替换为`e48`；因此新增信息来自48帧pose/track history，而不是新增RGB推理。

FPN 的机制依据是：高分辨率层提供更精细定位，低分辨率层提供更强语义；多尺度表示尤其有利于尺度变化和小目标。[1] RoIAlign 则说明从检测特征图提取实例级区域表征时，避免量化错位有助于保留空间对应关系。[2]

本项目的关键价值不是“RGB 更强”，而是：

- 视觉 ROI 提供 skeleton 不含的外观、遮挡和局部上下文；
- 320/640 改变目标像素支持和 detector feature distribution；
- 两个 resolution 采用独立 heads，保留决策差异；
- frozen backbone 降低 9,600 clips 上端到端视觉训练的过拟合风险。

**结论：Person-ROI、双分辨率独立heads和dense-48/320的跨时间跨度组合共同构成当前有效结构。** 仍只有320/640两次YOLO extraction；dense成员增加的是第二个skeleton temporal pass。在最新端到端延迟复测前，不能声称满足`≤100 ms`。

## 2.8 每个 ROI fusion head

报告给出的 head：

1. `e_skel 384→128 + LN + GELU`；
2. `ROI 192→128 + LN + GELU`；
3. 三条 causal depthwise Conv1D，kernel=`3/7/15`；
4. branch mean；
5. temporal mean + max，`256→128 + LN + GELU`；
6. skeleton/ROI concat `256→128 + LN + GELU`；
7. binary fall logit + 6-class subtype auxiliary。

按报告拓扑独立计算：四个`Linear projection`均计`bias=True`，每个LayerNorm计weight+bias共`2×128`，仅depthwise conv使用`bias=False`。

| 部分 | 参数 |
|---|---:|
| skeleton projection + LN | 49,536 |
| ROI projection + LN | 24,960 |
| DW kernels 3/7/15 | 3,200 |
| temporal pool projection + LN | 33,152 |
| fusion projection + LN | 33,152 |
| binary head | 129 |
| 6-class subtype head | 774 |
| **合计** | **144,903** |

原六heads=`869,418`，加`e16` skeleton为`1,033,540`。dense-48再增加一个`164,122`参数的skeleton backbone和一个`144,903`参数的320 ROI head，当前七头总计约`1,342,565`参数。该数不含frozen YOLO、pose detector、tracker和缓存生成器。

结构评价：

- kernels 3/7/15 覆盖短、中、全窗尺度；
- depthwise 卷积把参数限制在很低水平；
- mean 捕获持续状态，max 捕获尖峰；
- skeleton 与 ROI 在 128D 后融合，避免视觉高维直接压制姿态；
- subtype auxiliary 提供语义监督，但权重固定为 0.25，避免压倒二分类。

**结论：保留144,903参数的紧凑head，并将其复用于dense-48/320；不再扩展空间统计、attention pooling、context residual或Part-ROI。** 新实验再次说明，增加局部token数量不等于增加条件互补。

## 2.9 Balanced focal + subtype CE + hard-negative sampling

Focal loss通过 `(1-p_t)^γ` 降低易样本权重、突出困难样本；原论文验证对象是极端前景/背景不均衡的密集检测，不能直接证明其在本项目 P@R95 指标上最优。[3]

当前训练使用：

- balanced focal，`γ=2`；
- subtype CE 权重 `0.25`；
- negative ratio=`2.0`；
- lie_down/lying/stand_up 40% hard-negative sampling；
- 每折固定 12 epochs，不用 held-out fold early stopping。

这套配方的优点是监督目标清晰且避免用 held-out fold选 checkpoint；缺点是 focal/BCE 仍非 P@R90/P@R95 的直接 surrogate。非可分解指标和 AUPRC surrogate 文献表明，可以直接构造面向排序/PR 曲线的优化目标，但这些目标通常更难稳定训练。[26][27]

**结论：保留现有 loss 作为 anchor。** 项目中的 pairwise ranking、语义加权、七类 auxiliary 和 verifier 均失败，故 metric-aligned loss 只能是低优先级、单头 canary，而不是默认替换。

## 2.10 从六头到七头 fixed equal-logit fusion

原六头和新七头都采用相同原则：各成员先完成window→clip聚合，再对clip logits固定等权平均，最后sigmoid。学习参数仍为0。

```text
z6 = (1/6) Σ(i=1..6) z_i
z7 = (1/7) [Σ(i=1..6) z_i + z_dense48]
p  = sigmoid(z)
```

它等价于对成员odds做几何平均。Deep Ensembles说明独立初始化可以形成多样性，但新结果进一步强调：ensemble价值来自**输入历史和错误集合互补**，而不是成员数本身。[8]

| 方案 | mAP* | P@R90 | P@R95 | 结论 |
|---|---:|---:|---:|---|
| 六头 equal-logit | 70.831 | 77.562 | 64.100 | 旧anchor |
| **七头 + dense-48/320** | **72.166** | **78.762** | **65.570** | 新anchor |
| delta | +1.335 | +1.200 | +1.470 | 三项总体同升 |

| Fold | 七头mAP* | P@R90 | P@R95 | mAP* delta vs六头 |
|---:|---:|---:|---:|---:|
| 0 | 75.729 | 81.087 | 70.370 | +0.648 |
| 1 | 74.419 | 79.376 | 69.461 | +0.500 |
| 2 | 70.858 | 77.354 | 64.362 | -0.456 |
| 3 | 68.138 | 74.654 | 61.622 | +2.375 |
| 4 | 70.181 | 76.854 | 63.509 | +0.234 |

逐折delta的简单平均为`+0.660`，不等于pooled OOF总体delta`+1.335`。这是因为P@R90/P@R95在全体clip排序上重新取阈值，pooled指标不是逐折指标的算术平均；正式决策使用pooled OOF，同时保留逐折稳定性护栏。

paired template-group bootstrap：

- mAP* delta 95% CI：`[+0.055,+2.333]`点；
- P90 delta 95% CI：`[-0.028,+2.095]`点；
- P95 delta 95% CI：`[-0.603,+3.417]`点；
- R95 FP救回81、引入19，净减少62。

这组结果支持七头晋级，但表述必须准确：

- 项目主综合分数的区间下界为正；
- P90/P95点估计同升，但单项区间跨零；
- fold-2 mAP*下降，说明dense并非对所有模板区域都更好；
- fold-3从`65.763`升至`68.138`，是最大单折收益，但仍是最弱fold；
- 当前不需要给dense学习权重，固定`1/7`避免利用同一OOF标签继续搜索。

经典stacking要求level-one模型使用严格out-of-sample预测；非负约束和交叉验证可降低组合器方差。[16][30][31] 但在当前七头已经三项同升、且dense权重尚未独立确认的情况下，继续拟合权重的收益风险比不合理。

**结论：七头固定等权logit是当前anchor。** 这不是“第七个模型天然有效”，而是dense-48在原生连续历史、较低相关性、fold-3补强和R95净救回上同时满足互补门。固定probability、CDF-logistic等旧六头对照仍可保留为历史结果，但不应绕过七头完整配对评估直接替换当前融合。

## 2.11 当前融合方案的深层结构分析

### 三层互补，而不是七个等价模型

当前多样性分为三层：

1. **时间跨度互补：16 vs 48。** dense专家看到连续三倍长度的skeleton history，并用独立backbone形成`e48`；这是本轮新增且最明显的互补轴。
2. **视觉尺度互补：320 vs 640。** 输入像素支持、P3/P4 token分布和独立ROI head不同；这是原六头中最实质的观测多样性。
3. **初始化多样性：同分辨率三个seeds。** 架构、数据、损失和输入相同，只靠初始化改变决策边界，主要作用是降低方差。

旧六成员score Pearson约`0.9503–0.9715`，而dense-48与它们为`0.917–0.937`。差异虽然不等于独立，但足以解释为什么较弱的dense单头能带来更大的条件增益：它改变了时间信息，而不是只改变随机初始化。[8]

### 为什么独立 320/640 heads 优于共享或残差适配

报告中的 `640-320 token residual` 和 stochastic shared head 均失败，而独立双头成功。这意味着尺度变化不仅是通道值的线性偏差，还改变了：

- 小目标的有效像素和局部纹理；
- P3/P4的空间采样和语义强度；
- ROI mean后的统计分布；
- 最优分类边界与校准。

强制共享 head 会把两个条件压入同一决策面；token residual 又默认 640只是320的可加修正。当前结果更支持“两个尺度是两个视图”，而不是“一个主视图加一个残差”。

### logit平均与 probability平均的差异

当前融合更新为：

```text
z = (1/7) Σ logit(p_i)
p = sigmoid(z)
```

它等价于七个odds的几何平均。与直接平均probability相比：

- 保留成员对高/低置信证据的对数强度；
- 对同一配方、相近校准的成员通常更自然；
- 但极端过置信成员也可能产生更大影响。

旧六头中equal-logit在mAP*/P90上略胜fixed probability，CDF-nonnegative logistic的P95更高。新dense成员加入后只完成了固定等权logit的完整晋级审计，因此当前不应把旧六头融合器排名直接搬到七头。若未来比较七头probability/CDF/stacking，必须重新做完整五折配对，不能假定旧结论自动保持。

### 为什么 clip-first 优于 window-first

当前正确顺序是每个成员先把窗口分数聚合为 clip logit，再融合成员。这样允许：

- skeleton在某个窗口捕获姿态突变；
- 320在另一个窗口捕获局部外观；
- 640在更早/更晚窗口捕获小目标；
- 各成员的强证据无需严格时间对齐。

window-first fusion则隐含“不同成员应在同一个窗口同时高分”的假设。报告中它明确低于clip-first，说明不同专家的峰值具有时间错位。继续保留clip-first是结构上有依据的，不只是经验选择。

### 为什么 transition residual 单头强、进入ensemble却无效

transition residual从源ROI-TCN状态构造last-first和平均帧差。它对单头排序有帮助，但仍是源成员表征的确定性变换，因此score Pearson达到`0.9918`。它救回的多数错误已被旧六头处理，加入后主要改变重复投票比例。

与之相反，dense-48单头更弱，却因输入历史不同而相关性更低，并在七头中形成净救回。这一正反对照把准入规则说得更清楚：**单头强弱不是充分条件，条件互补才是。**

### 为什么 confidence Part-ROI 覆盖率高仍然失败

Part-ROI把upper/torso/lower三个192D token及reliability加入actor表示，总输入达到771D。joint confidence threshold固定`0.35`；upper使用肩肘腕、torso使用肩髋、lower使用髋膝踝，并要求最少`3/6、3/4、3/6`个joint可见。part框限制在person bbox内，加入8% margin，最小边长为person box的15%；只接受同一采样帧、同一track的精确pose，不从邻帧复制keypoints。无效token严格置零，有效token乘`mean confidence × visible coverage`。upper/torso/lower覆盖率分别为`97.51%/95.37%/87.82%`，平均reliability为`0.896/0.923/0.758`，Part head参数为`219,015`。但高覆盖率只说明局部框大多可提取，不说明它们包含新的判别变量。

| 方案 | mAP* | P@R90 | P@R95 | delta vs七头 |
|---|---:|---:|---:|---|
| dense-48七头 | **72.166** | **78.762** | **65.570** | baseline |
| + Part第八头 | 71.947 | 78.615 | 65.280 | `-0.219/-0.147/-0.290` |
| Part替换320/seed30 | 71.902 | 78.259 | 65.545 | `-0.264/-0.503/-0.024`（原始记录；三位展示值相减为`-0.025`） |

替换方案mAP*为3/5 folds上升，却在总体三项上都下降；R95 FP救回40、引入41，净增加1。bootstrap区间也全部跨零。因此它既没有形成总体改善，也没有足够稳定的尾部净救回。

当前失败的合理解释是：

- 局部token仍来自同一次YOLO P3/P4 pass，与person mean共享外观来源；
- upper/torso/lower只是重新分区，没有直接监督“受控下放/失控下落”；
- 置信度与覆盖率缩放提高了输入复杂度，也可能压低困难正例中的弱但真实局部信号；
- 直接加第八头会稀释dense成员权重，替换seed30又损失原有初始化多样性。

因此淘汰的是**当前confidence-part表示和融合位置**，不是“人体局部永远无用”。重启该方向必须引入新的监督或不同局部编码，而不是继续扫threshold、margin和part定义。

### subtype auxiliary的正确角色

6-class subtype head只应作为训练期表示约束，不应被解释为一个独立ensemble专家。当前 severe FP仍集中在lie_down/lying，说明0.25权重不足以完全解决语义边界；但把该类权重提高到2又损伤hard positives。最合理的结论不是继续扫权重，而是当前视觉/姿态表示中“受控性”信息本身不足。

## 2.12 当前模型的主要结构优势与结构性弱点

| 维度 | 优势 | 弱点 |
|---|---|---|
| 归纳偏置 | 六流TCN明确编码姿态、形状、运动和物理量 | 两个backbone仍共享pose/track输入错误 |
| 小样本适应 | skeleton极轻，YOLO冻结，ROI head仅14.5万参数 | 七头有效自由度仍低于表面成员数；不宜继续堆头 |
| 多尺度 | 320/640独立heads已形成稳定互补 | 双YOLO pass可能主导延迟与显存 |
| 多时间跨度 | 原生16/48帧各自编码，dense成员显著降低相关性 | 48帧依赖更长track连续性与warm-up状态 |
| 融合 | clip-first七头equal-logit无参数 | fixed 1/7尚未在独立确认集检验；fold-2有回退 |
| 高召回 | dense使P90/P95点估计同升，R95 FP净减少62 | P90/P95 bootstrap区间仍跨零，不能宣称单项稳定显著 |
| 语义监督 | subtype CE与hard-negative sampling直接针对困难负类 | lie_down/lying与slow/partial fall仍处于相邻表示区域 |

因此当前模型不是“容量不足”。dense-48已修复一部分时间覆盖和条件互补问题；剩余瓶颈更集中在**actor/track可观测性、受控性语义和跨模板稳定性**。继续增加层数、同源head或后置MLP不会直接解决这些问题。

---

## 3. 为什么本轮有效实验有效

| 有效组件 | 项目结果 | 机制解释 | 当前结论 |
|---|---|---|---|
| Stage-S1六流skeleton | 多轮保持强基线 | 低维姿态、形状、运动与物理先验 | 保留16帧和48帧同构backbones |
| FallVision Joint初始化 | 多轮优于从零/弱RGB teacher | 降低小数据优化难度 | 两个backbone均保留相同初始化 |
| Joint-only Transformer | TCN保留时有局部增益 | 给信息最完整Joint流增加通道非线性 | 保留；不外推纯Transformer替换 |
| Person-ROI mean token | 五折相对skeleton形成主要增益 | 增加外观、遮挡和实例化视觉信息 | 保留紧凑person token |
| 320/640独立heads | 双尺度融合持续优于单尺度 | 像素支持、token分布和决策边界不同 | 保留两次YOLO尺度 |
| 三个seeds | 六头相对双头晋级 | 有限初始化多样性降低方差 | 保留；不再增加同构seed |
| **原生dense-48/320** | 七头`+1.335/+1.200/+1.470` | 连续长历史+独立backbone形成条件互补 | **新晋级成员** |
| 七头fixed equal-logit | 三项总体同升，mAP* CI下界为正 | 零拟合参数、避免meta overfit | **当前融合anchor** |
| transition residual单头 | 单头强但相关`0.9918`、ensemble无增益 | 只重表达源状态 | 仅作为反例保留 |

核心规律现在更明确：**有效增益来自新的观测轴（视觉、分辨率、原生时间跨度）和有限初始化多样性；无效增益通常只是在同一输入与同一错误集合上增加更复杂的重表达。**

---

## 4. 失败或未晋级实验的根因审计

## 4.1 时间尺度、长上下文和聚合

| 实验族 | 项目结果 | 不能得出的结论 | 最合理解释 |
|---|---|---|---|
| 0.75/1.0/1.5s 固定时间 | P95 均受损；1.0s mAP微升 | “时间归一化永远无效” | 改变了局部动态速度和尾部排序 |
| 16+48 shared TCN / Joint Transformer | 三项低于16帧Primary | “所有48帧模型无效” | stride=3压成16 token，共享编码导致稀疏/短窗失配 |
| **原生dense-48独立专家** | 七头三项总体同升 | “更长历史必须替换短窗模型” | 成功来自并行互补；16帧局部事件模型仍保留 |
| smooth-max / 2-of-3 support | 不优于 max，压制真 fall | “所有事件聚合都无效” | 高召回尾部需要保留孤立强证据 |
| window-first fusion | 明确低于 clip-first | “早期融合理论错误” | 不同成员峰值发生在不同窗口；先按窗口平均会稀释互补峰值 |
| long-context O1/O2 | mAP 49.87–57.76 | “长历史无价值” | 候选本身召回不足；已被原生dense-48正结果重新界定 |

**更新结论：clip-max-before-fusion继续冻结，原生dense-48已作为长历史成员晋级。** 不再复刻稀疏48→16 token，也不再把SSM/Mamba当作“尚未尝试长历史”的默认下一步；更复杂记忆只有在七头错误审计仍显示明显超48帧历史缺口时才考虑。

## 4.2 损失、辅助任务、verifier 和 suppressor

| 实验族 | 项目结果 | 根因判断 |
|---|---|---|
| 七类 auxiliary B2 | ΔmAP/P95=`-0.954/-1.219` | 多任务梯度与 binary 高召回目标冲突 |
| pairwise hard-negative ranking | lie_down FP 未改善 | 同一表示中 hard negative 与 hard positive 距离太近 |
| window/event verifier | contribution 越大越差；event GRU P95下降 | 使用同源 embedding 做后置纠错，没有新证据 |
| bounded suppressor | 多 seed P95升、P90降 | 改变一端排序同时损伤另一工作点 |
| Motion+17D validity / P1 mask | 未超过 Primary或P95下降 | missingness 实现语义改善不等于排序改善 |
| lie_down/lying weight=2 | 单头和第七头均不晋级 | 对困难负例加权同时压低 slow/partial fall |
| six-head quality calibration | mAP +0.037、P95 -0.069 | 自动质量指标与最终错误排序关联不足 |

多任务学习可能产生互相竞争的目标；项目结果已经证明在当前数据/权重下负迁移比理论收益更重要。Supervised Contrastive Learning 虽能拉近同类并推远异类，但本项目已有 ranking/subtype/semantic weighting 失败，故不能仅换一个对比损失名称便重启。[14]

**结论：停止同源 suppressor、verifier、语义加权和质量校准。** 只有引入新观测信息后，才值得重新讨论纠错器。

## 4.3 图网络和骨架 replacement

ST-GCN、CTR-GCN 和 InfoGCN 在各自数据集上提供了图拓扑或表征约束方面的归纳偏置。[19][20][21]

PoseC3D 则把骨架表示为热图体并使用 3D 卷积建模。[18] 但项目内：

- ST-GCN replacement：`66.40/70.92/61.88`；
- TCN+SA-TDGFormer：`64.68/70.42/58.94`；
- TCN+InfoGCN：`64.34/68.73/59.94`；
- residual ST-GCN：`70.11/73.45/66.77`，有信号但未超最佳；
- PoseConv3D：mAP `51.82`，fall candidate recall 低。

失败边界应写成：**当前实现、输入、预算和 replacement/fusion 方式未通过**，而不是“图网络/3D heatmap无效”。

近期不应重启，因为当前有效视觉增益已经来自 Person-ROI，继续加骨架同源专家大概率提高相关性而非互补性。

## 4.4 RGB、视频骨干和 ROI 结构

| 方向 | 项目观察 | 解释 |
|---|---|---|
| R3D / event-aligned / actor-context | 40.91–56.21 mAP | 冻结视频语义与跌倒高召回排序不匹配 |
| VideoMAE 64-frame | 38.47–39.12 mAP | 通用视频表征不是可直接迁移的 fall teacher |
| context ROI residual | anchor mAP下降 | 场景上下文增加噪声，未提供稳定受控性证据 |
| quality cross-attention | mAP下降1.71 | 质量代理不能可靠指导跨模态融合 |
| ROI 768D空间统计 | fold-0高维过拟合 | 维度增加但独立信息不足 |
| mean+max / attention pooling | P95下降或两折不复现 | 读出改变了困难正例排序 |
| Person-ROI mean token | 五折有效 | 实例化视觉信息确实互补 |
| confidence Part-ROI | 加第八头与替换方案三项均降 | 局部分区仍同源，771D输入未形成新判别变量 |

FPN/ROI 文献支持多尺度实例特征的机制，但不支持“越多空间统计越好”。[1][2]

**结论：保留紧凑mean ROI token；停止context、额外空间矩、attention pooling和当前confidence Part-ROI。** Part方向若重启，必须改变监督或编码机制，不能只扫阈值、margin和部位框。

## 4.5 分辨率、seed 数量与成员适配

- 640 standalone 提高 P90、略降 P95；与 320 固定融合后总体改善，说明其价值是互补而非单独替代。
- 640-320 token residual 和 stochastic shared head 均失败，说明**独立决策空间**比把两个尺度压成通道残差更重要。
- learned resolution weights 在折间从 0.4 到 0.7 摆动，固定 50/50 更稳。
- CDF-rank fusion 失败，说明校准不一致不是当前主要瓶颈。
- 第三seed晋级；更多同构seed不再改善。dense-48第七头成功不推翻饱和判断，因为它改变了原生时间跨度；Part第八头失败再次说明“新增head”本身没有价值。

Ensemble selection 的原则是从模型库中选择能降低组合误差的成员，而不是平均所有可用模型。[29]

**结论：后续默认“替换优先于增加”；只有新成员像dense-48一样引入明确的新信息轴并通过完整互补门，才允许增加。**

## 4.6 增强、真实失真和蒸馏

真实姿态错误增强文献说明，遮挡、关节缺失、左右互换、track fragment 和插值伪影应来自真实误差分布，而非任意噪声。[15] 但本项目已完成 fold-local Real-Q/Real-T：它们仍反复伤害 P95。

因此失败不应解释为“增强论文错误”，而应解释为：

- 当前 hardest positives 本身常伴随低质量；
- 质量增强提高了中等样本鲁棒性，却降低模型对弱正例的置信；
- severity stratification 没有修复这一尾部冲突。

蒸馏原理要求 teacher 输出包含学生难以直接获得的平滑知识。[24] 项目内 in-sample teacher 复制训练记忆，OOF teacher C6又受 fold/full domain gap影响，均未晋级。

**结论：Real-Q/T和accuracy-oriented distillation停止。** 蒸馏只在未来需要压缩七头部署成本时，以“保持anchor排序”为目标重新设计，不能当作近期提分路线。

## 4.7 融合失败

- 旧 C5-2 在 random-val看似较好，但二层复用 OOF labels 有偏；
- nested C5 两成员 meta-OOF 很低；
- F1 与旧专家 nested fusion 未显著超过 F1；
- six-head nonnegative logistic 低于 equal-logit；
- SVM、RBF-SVM、Logistic、MLP clip head 均低于 anchor。

Stacking、Super Learner 和非负 stacked regression 都依赖严格 out-of-sample level-one 预测以及足够多样的基础学习器。[16][30][31]

相关数据上的普通 cross-validation 还会产生过于乐观的估计，因此 template group 必须贯穿所有层级。[25]

**更新结论：dense-48提高了成员异质性，但不自动产生学习权重的必要性。** 当前固定七头已经改善三项总体指标；在没有独立确认集和七头完整nested对照前，继续stacking仍会增加方差与选择偏差。

---

## 5. 当前真正瓶颈

## 5.1 清晰但语义相近的困难负例

此前六头R95最高分40个FP中，13个主动躺下、8个静态躺卧，另有5个`annotation_or_semantic_ambiguity`。这说明严重度尾部主要包含语义近邻。七头在R95净减少62个FP，但当前报告没有给出七头的新top-FP taxonomy；因此不能假定原比例保持不变。下一次错误审计应直接基于七头重新抽样。核心语义问题仍包括：

- 动作是否受控；
- 下落—接触—静止的时序顺序；
- 是否存在主动支撑/缓慢放低身体；
- 动作前后的状态转移。

普通 loss reweight、ranking、verifier 和 transition residual都在当前表示上失败，说明“受控性”尚未成为足够独立的可分信息。

## 5.2 静态 post-fall 与 slow/partial fall

此前六头最低分40个FN中有10个静态post-fall、8个缓慢/局部fall和9个语义歧义。dense-48正面验证了更长连续历史的价值，并把总体P95提高1.470点；但没有错误级对照证明具体救回了多少static/slow样本。更新判断是：**16帧覆盖不足确实是一个有效瓶颈，但不是唯一瓶颈。** 七头仍需重新统计static/slow FN和dense unique rescue，才能决定是否继续扩展历史。

## 5.3 小目标、遮挡、多人竞争和 track 错配

此前六头最低分40个FN中有13个主要归为`visual_quality_limitation`，且更多样本带次要质量因素。dense-48仍依赖相同pose/track输入，因此无法从根本上纠正选错actor或长时间track断裂。Person-ROI和长历史都只能处理“输入对象正确”的情况；若actor错误，继续优化分类head无效。

ByteTrack 的核心机制是把低分检测也纳入关联，减少遮挡导致的真目标丢失和轨迹碎片。[10] 这比继续在分类 head 上加质量 gate 更直接地针对输入错误。

## 5.4 fold-3 domain shift

原六头fold-3为`65.763/71.840/59.686`，七头提升为`68.138/74.654/61.622`，mAP*增加`2.375`点，是dense最大收益fold。这支持长历史在该模板区域有价值，但fold-3仍是七头最弱fold。下一阶段应单列：

- fold-3 actor/view/template metadata；
- 目标尺寸、遮挡率、多人比例、track切换；
- lie_down/lying/fall subtype 构成；
- 七头相对六头的unique rescue/introduced errors及其static/slow/track taxonomy。

---

## 6. 后续可行改进路线

## 6.1 P0：冻结七头配置、完成全链路与新错误审计

**这是竞赛冻结前唯一必做项，不是训练实验。**

六头时期的指标和错误审计已经完成。当前P0只针对新七头：确保dense窗口契约、七成员预测、部署路径和新错误集合一起冻结，避免继续沿用六头的阈值、random-validation或taxonomy。

### 工作内容

1. 冻结并hash：七个member clip logits、六头baseline、dense window/fold signatures、七个config/checkpoint metadata、评测脚本和paired bootstrap明细。
2. 固化`window_size=48/stride=1/min_observed_frames=24`、因果左填充、末帧可见和track reset规则，确保离线与在线一致。
3. 全链路benchmark：pose + track + `e16/e48` skeleton passes + 320/640 YOLO + 七heads + aggregation；报告batch=1、warmup、P50/P95、峰值显存、FP32体积和目标V100条件。
4. 基于七头重新做R95随机分层错误审计，并单列dense unique rescue、introduced errors和fold-2回退。
5. 若协议允许，在所有结构、权重和融合冻结后只做一次random-validation方向确认；不得回头调`1/7`权重。

### 通过门

- 七个成员→七头融合可从raw logits重建，9,600/9,600 clip身份完整；
- dense与六头使用相同held-out fold map，paired template-group bootstrap可重做；
- 七头`72.166/78.762/65.570`与逐折结果在预定容差内；
- 六头→七头的81救回/19引入和fold-2回退可从原始数组复算；
- 离线dense窗口生成与在线warm-up/track reset行为一致；
- `≤20M/≤80MB/≤100ms` 在声明口径下有真实输出；
- sealed test 和 URFD test 均未访问。

## 6.2 P1：track-first 的多人/遮挡修复

### 假设

部分FN源于检测/关联阶段选错人或丢失低置信度目标；这类错误无法由当前七头分类器纠正。

### 单一变化候选

- 保持七头分类模型和权重不变；
- 在现有 detector 输出上测试低分框关联、轨迹连续性或 top-2 track hypothesis；
- 每个 clip 最终仍使用固定、可审计的 actor选择规则；
- 不引入基于标签训练的动态 gate。

ByteTrack 为低分检测关联提供直接机制依据。[10]

### 最小判别实验

先对人工确认的“遮挡/多人/track错配”FN和同类型非跌倒对照做**无训练 replay**。只有能恢复正确 actor token且不引入大量其他人 FP，才进入一个 fold 的 bounded canary。

### 晋级/停止门

- 必须对 track-error slice 有明确恢复；
- 全体 P95 不下降，P90不得出现不可解释损伤；
- 多人 non-fall FP 不增加；
- 端到端 P95 latency 仍在预算内；
- 若 top-2 只重复同一错误或 clip-max 被旁人高分劫持，立即停止。

## 6.3 P2：dense-48后的残余状态转移专家

原transition residual单头有信号，但与源成员相关`0.9918`。现在dense-48已经提供独立长历史，P2只有在七头新错误审计仍显示“48帧内有可见转移却未被利用”时才启动；否则应停止，而不是继续重复时间建模。

### 候选设计

仅允许下列之一作为单变量：

- 对**原始 ROI token**做一阶/二阶 causal difference，再用极小 temporal head；
- 使用 TSM 式零/低参数时间移位，让视觉通道在相邻帧交换信息；TSM 的目标正是低开销时间建模。[11]
- 把“transition发生”和“当前 lying状态”分成两个可解释子分数，但不做负向 suppressor。

不得复刻“TCN最后状态-最初状态+mean frame diff”的现有 residual。

### 融合方式

- 先训练一个320 fold-0/fold-2/fold-3 canary；
- 若单头通过，**替换七头中最弱的同源16帧成员**；
- 不直接加第八头；
- 不学习动态权重。

### 晋级门

- 单头 mAP、P95 不下降；
- 在 controlled lie_down 与 slow/static fall 两类上同时给出净变化；
- 与被替换成员的错误集合有可测互补，不能只报告 score correlation；
- 七头替换版必须改善OOF，且unique R95 rescue大于introduced errors；
- 若仍是 `r≈0.99` 且 ensemble不升，永久停止该表达族。

## 6.4 P3：SWA 作为“成员替换”稳定化 canary

SWA 通过平均同一训练轨迹上的多个权重，倾向找到更宽的解，并几乎不增加推理成本。[9]

### 为什么值得但优先级不高

- 优点：不增加部署参数或 head 数；可能降低单 seed方差；
- 风险：可能使不同 seeds 更相似，损伤 ensemble diversity；当前固定12 epochs也未必形成适合平均的轨迹。

### 最小实验

只对当前最弱的一个16帧head，在原训练预算内预声明最后若干checkpoint的平均规则；不增加超参数搜索。先报告单头，再报告替换版七头。

### 停止门

若单头改善但替换七头不改善，或inter-head error correlation上升，停止；不得转为第八头。

## 6.5 P4：面向高召回指标的低权重 surrogate

当前 focal loss针对困难样本，但不是 P@R90/P@R95 的直接目标。[3] 可扩展的非可分解指标和 AUPRC surrogate提供了理论路径。[26][27]

### 设计约束

- 保留主 balanced focal；
- 只增加一个很小权重的 PR/recall-constrained auxiliary；
- 单头、单fold canary；
- 不同时修改 sampling、backbone 或 fusion；
- 固定阈值扫描代码和工作点定义。

### 风险

本项目已有 ranking loss和hard-negative weighting失败；PR surrogate也可能牺牲极难正例、产生不稳定 batch统计。因此它是**低优先级研究项**，不是近期主线。

## 6.6 P5：显式 floor/support/controlledness 信息

语义 FP若能从画面判断“主动支撑、缓慢下放、与床/地面接触”，当前 person-ROI mean可能把关键空间关系平均掉。未来可考虑极低维、可解释的新信息：

- feet/hip 到估计 floor line 的距离变化；
- bbox底边/姿态与支撑面的相对几何；
- 手部支撑持续时间；
- deceleration—contact—stillness 的有序事件。

但 context ROI和高维空间统计已经失败，所以该路线只有在随机人工审计证明这些线索在足够多 severe FP 中可见时才启动。不得直接引入大场景分割器或高维 context backbone。

## 6.7 P6：超过48帧的 causal state memory

S4和Mamba为长序列提供线性复杂度状态空间建模机制。[12][13] 它们说明“长历史不一定需要全注意力”，但没有证明本项目会获益。

### 何时值得

只有七头新审计确认大量FN是“transition已离开48帧但需要保持事件记忆”，且track identity连续时才启动。

### 最小结构

- 保留当前16/48七头分类；
- 在连续同一 track 的 window embedding 或原始低维 kinematic stream 上增加一个极小 causal state memory；
- 输出只能提供**额外正向历史证据**，不能做 suppressor；
- state在track切换/长缺失时显式reset。

### 为什么不是近期主线

- event GRU verifier已经伤害P95；
- 原生dense-48已经取得正结果，先充分审计和部署，不应立即升级到更复杂框架；
- SSM/Mamba会增加实现和复现风险；
- 截止日前不适合引入新序列框架。

---

## 7. 模型融合指导

## 7.1 当前推荐顺序

1. **保留七头 fixed equal-logit，dense权重固定为`1/7`。**
2. 截止前先完成七头全链路benchmark和新错误审计，不再训练第八头。
3. 新候选默认做“一换一”替换；只有出现新的观测轴并达到dense级互补门，才讨论增加成员。
4. 旧六头CDF/logistic结果不能直接决定七头融合；任何七头融合器比较都必须重新做完整五折配对。
5. dynamic quality gate/MoE继续冻结。
6. distillation仅用于未来部署压缩，不作为准确率提升路径。

## 7.2 新成员准入数据契约

每个候选必须提供同一张 clip-level表：

```text
clip_id
label
activity/subtype
template_group
outer_fold
resolution
member_id
history_frames
window_contract_hash
raw_clip_logit
prediction_source_checkpoint
checkpoint_train_groups_hash
```

硬约束：

- 先在每个成员内部完成 window→clip aggregation；
- 所有成员覆盖完全相同的 9,600 clip IDs；
- 任何 meta learner 的输入都必须来自没有训练该 template group 的模型；
- normalization、calibration、member selection和权重都只在相应 outer-train 内完成；
- random-validation 不参与；
- sealed test不参与。

## 7.3 互补性门，而不是“单头更高”门

候选至少报告：

- 相对被替换成员的 score/error correlation；
- 七头错误中的unique rescue、shared rescue、introduced errors；
- R90和R95分别的FP/FN变化；
- fold-3单列；
- paired template-group bootstrap区间；
- 权重/成员在各 outer folds 的稳定性。

高相关不是自动拒绝条件，但如果没有 unique rescue，高单头分数也不能进入 ensemble。

## 7.4 何时才重启 stacking

经典stacking和Super Learner都依赖严格cross-validated base predictions。[16][31] 旧six-head logistic失败且七头固定融合刚刚晋级后，只有满足以下全部条件才重启：

- 至少一个新成员使用不同观测信息，例如修复后的 actor track、显式floor/support或独立motion token；
- 单头完整 template-group OOF；
- nested outer-fold评估；
- 非负 L2、系数和为1或明确约束；
- 与七头fixed equal-logit使用相同clip logits和评测路径；
- mAP与P95联合过门，系数跨fold稳定。

否则固定融合应继续优先。

## 7.5 校准、rank fusion与动态门控

温度缩放等校准方法可改善概率校准，但单模型单调变换不会直接改变自身排序；它只有在多模型加权时可能改变组合排序。[17] 本项目 CDF-rank和nested quality calibration均失败，表明当前瓶颈不是简单的scale mismatch。

动态门控需要稳定的“哪个专家在当前样本更可靠”的监督；现有质量代理尚未满足这一条件。因此继续冻结。

---

## 8. Deadline-aware 行动方案

## 8.1 截止前：冻结准确率架构

1. 固定七个成员、`1/7` logit融合、dense窗口契约、OOF指标实现和阈值政策；
2. 将七头作为当前准确率anchor，不再搜索第八头或dense权重；
3. 完成离线/在线一致性和目标硬件全链路benchmark；
4. 重新生成七头R95错误审计，特别检查fold-2回退与fold-3救回；
5. 检查匿名提交、模型大小、依赖闭包、缓存与checkpoint hashes；
6. 如协议允许，只做一次冻结后的random-validation确认；
7. 不访问sealed test或URFD test。

## 8.2 截止后研究顺序

1. 七头随机分层R95审计 + dense rescue/introduced taxonomy；
2. fold-2回退与fold-3大幅改善的template/domain对照；
3. track-first top-k无训练replay；
4. 若预算允许，按第14节完整nested protocol验证RMPTS一维质量守恒时域迁移；
5. 若有明确actor恢复，再做一个fold bounded actor canary；
6. 仅在48帧仍遗漏可见转移时做事件阶段/原始运动一换一成员替换；
7. floor/support、超过48帧memory、三block simplex与复杂stacking均后置。

---

## 9. Lane B 决策卡

### DET-ARCH-20260829-D48-P0：七头冻结与部署预检

- **Decision requested**：是否接受七头`16-frame six heads + dense-48/320`为当前冻结候选。
- **Baseline**：六头OOF`70.831/77.562/64.100`。
- **Candidate**：七头OOF`72.166/78.762/65.570`；mAP* CI`[+0.055,+2.333]`。
- **Single intended change**：新增一个原生48帧独立skeleton/320专家，固定七头等权。
- **Controlled variables**：同fold map、相同9,600 clips、相同320 ROI cache、相同loss/epochs/初始化族。
- **Guardrails**：P90/P95、fold-2、在线warm-up/track reset、`≤20M/≤80MB/≤100ms`。
- **Completed result**：总体三项同升，fold-3显著改善，R95 FP净减少62，参数约1.343M。
- **Remaining gate**：七成员融合重建、在线/离线一致性、目标硬件全链路benchmark和七头错误审计。
- **Stop/Rollback**：若dense无法重建、clip身份不一致、在线行为漂移或P95延迟超预算，回滚六头并BLOCK部署。
- **Current recommendation**：**接受七头为准确率anchor；部署冻结需通过P0。**

### DET-ARCH-20260829-P1：track-first canary

- **Hypothesis**：部分严重FN由actor检测/关联错误而非分类能力导致。
- **Single change**：低分检测关联或top-2 track hypothesis；七头权重冻结。
- **Primary metric**：全体mAP/P95 + track-error slice恢复。
- **Guardrails**：多人non-fall FP、P90、延迟不得恶化。
- **Minimum evidence**：先无训练replay，再一个fold；未证明actor恢复则停止。
- **Current recommendation**：**截止后条件批准；当前不花训练预算。**

### DET-ARCH-20260829-P2：dense后的transition替换

- **Hypothesis**：原始ROI token的状态变化包含当前head未编码的受控性信息。
- **Single change**：一个新的causal motion-token head；替换一个16帧成员，不增加第八头。
- **Guardrails**：P95不降；slow/static fall不被压低；unique rescue为正。
- **Stop**：与源成员近重复且替换七头不升。
- **Current recommendation**：**仅在七头新错误审计仍显示48帧内转移未利用时启动。**

---

## 10. 最终建议

### 保留

- Stage-S1 six-stream skeleton backbones：`e16`与独立`e48`；
- Joint-only Transformer adapter；
- frozen YOLO P3/P4 Person-ROI mean tokens；
- 320/640独立heads；
- original/20260829/20260830三个seeds；
- dense-48/320 original head；
- 七头fixed equal-logit，权重固定`1/7`；
- `window_size=48/stride=1/min_observed_frames=24`与因果左填充契约；
- clip-max-before-fusion；
- template-group OOF选择协议。

### 停止

- 第八个同构seed或同源ROI head；
- 当前confidence Part-ROI第八头及替换方案；
- 在现有五折OOF表上直接搜索dense权重、learned resolution weights和未经完整nested重评的CDF/logistic；
- quality gate/cross-head/calibration；
- 同源 verifier/suppressor/ranking；
- Real-Q/Real-T与severity增强；
- context ROI、高维空间统计、attention pooling；
- 稀疏48→16复刻和未经错误审计支持的超过48帧memory；
- ST-GCN/InfoGCN/SA replacement或同源fusion；
- accuracy-oriented蒸馏；
- 使用random-validation继续选型。

### 条件探索

- 七头错误审计、fold-2回退和fold-3救回归因；
- actor track/多人关联修复；
- dense后残余transition成员，只做一换一；
- SWA成员替换；
- 随机错误审计支持后，再研究floor/support或超过48帧state memory；
- RMPTS一维质量守恒时域迁移，只能按完整nested grouped cross-fitting验证；
- 三block simplex或更复杂stacking，只有一维方案显示稳定但分辨率block仍有可重复不对称时才启动。

### 一句话判断

> **原生Dense48证明了当前模型仍能从新的时间尺度获得实质互补。当前已验证incumbent仍是七头`1/7` equal-logit；最有希望的新融合是只有一个自由度、保持320/640分辨率质量不变的RMPTS，但必须在全nested grouped protocol中证明后才能替换。准确率改进优先修actor/track共同上游，再以一换一方式测试事件阶段或新原始信息，部署则优先做等价状态缓存而非共享模型参数。**

## 11. 实验记录索引

本报告整合以下项目实验记录：

| 记录 | 主要内容 |
|---|---|
| `2026-08-29-dense48-and-confidence-part-roi.md` | 原生dense-48七头晋级、Part-ROI淘汰、窗口与参数契约 |
| `2026-08-29_six_head_post_experiment_architecture_guidance.md` | 六头结构、融合、失败实验和错误taxonomy历史基线 |
| `2026-08-29_latest_architecture_guidance_sources.json` | 论文机制来源账本 |

---

## 12. R6：完整计算图与信息流深拆

### 12.1 从视频到告警分数的四层计算图

```text
视频帧
  ├─ frozen pose / detector / tracker / actor selection
  │    ├─ top-1 actor最近16帧 → Joint/Bone/Motion/Geometry/Rule/Kinematics
  │    │    └─ 独立六流因果TCN + causal attention + Joint adapter
  │    │         └─ e16 (384D)
  │    └─ 同一actor最近48帧、stride=1
  │         └─ 独立六流因果TCN + causal attention + Joint adapter
  │              └─ e48 (384D)
  ├─ frozen P3/P4 person ROI
  │    ├─ 320 person mean token序列 (192D/token)
  │    └─ 640 person mean token序列 (192D/token)
  ├─ 七个独立window classifier
  │    ├─ e16 + ROI320 → original / seed29 / seed30
  │    ├─ e16 + ROI640 → original / seed29 / seed30
  │    └─ e48 + ROI320 → Dense48 original
  ├─ 每个成员独立 window → clip 聚合
  │    └─ clip logit = 该成员窗口证据的最大值
  └─ 跨成员融合
       └─ 当前incumbent：七个clip logits固定1/7平均
```

这个顺序不能随意改成“先在同一window上七头投票，再做clip-max”。短窗与长窗成员的峰值可能出现在不同终点；先做成员内clip聚合允许每个时间尺度在最适合自己的时刻提供证据。反过来同步投票会把Dense48的时间错位互补压回短窗节奏。

### 12.2 Stage-S1六流不是六个模型，而是一个有物理先验的共享骨架状态

Joint、Bone、Motion、Geometry、Rule、Kinematics分别覆盖绝对姿态、局部骨向量、帧间位移、人体整体框、低维规则和高阶运动学。多尺度因果TCN在每一流内编码局部与较长依赖，causal attention负责在已观测历史中重分配时刻权重；Joint-only adapter则允许信息最丰富的原始姿态流拥有额外非线性容量。最后六流拼接和SE样式重标定得到`e16/e48`。

这里最重要的结构事实是：六个16帧ROI head都共享同一个`e16`，所以它们不是六个完全独立专家。`e48`虽然拓扑同构，却拥有独立参数、连续48帧输入和独立最后状态，因此形成了新的时域决策边界。Skeleton action recognition研究也表明，空间关节分区与不同时间尺度的关系应显式区分；SkateFormer的价值在于支持“分区与尺度是独立归纳偏置”这一机制，而不是要求本项目直接替换成更大的Transformer。[32]

### 12.3 原六个16-frame ROI heads的真正互补来源

| 变化轴 | 320组三头 | 640组三头 | 互补强度判断 |
|---|---|---|---|
| skeleton状态 | 全部共享`e16` | 全部共享`e16` | 高度同源 |
| visual尺度 | 320 P3/P4 | 640 P3/P4 | 真实空间尺度互补 |
| 初始化seed | 3个 | 3个 | 弱方差互补，不是新信息 |
| loss与标签 | 相同 | 相同 | 同源 |
| actor/track | 相同top-1 | 相同top-1 | 共同失败点 |

320更利于全局稳定和低成本，640更容易保留小目标与局部纹理；三个seed的主要价值是降低初始化方差。此前第三seed可以晋级、第四类同构扩张不再稳定增益，说明seed轴已接近饱和。继续添加seed会增加“投票人数”，但不会增加可见信息。

### 12.4 Dense48的价值与边界

Dense48只在skeleton历史上真正扩展到连续48帧；其ROI仍来自320 person token路径。因此它的结构价值是：

1. 延长从直立、下降、接触到静止的可见区间；
2. 用独立backbone避免把48帧压进短窗表示；
3. 让长窗拥有独立误差边界，而不是成为`e16`的确定性残差；
4. 在clip-first融合中允许长窗与短窗在不同时间点触发。

它的边界同样明确：它没有引入第二actor、场景支撑、深度或新的视觉传感器；相关性`0.917–0.937`只是比旧成员低，不等于统计独立。逐折增益中约72%来自fold-3这一事实说明，当前更准确的措辞是“时间尺度互补与结果一致”，而不是“已证明普遍长时序优势”。多尺度时序模型文献支持同时保留细粒度局部与长程特征，但MS-TCT是离线action detection结构，其复杂度和非因果设置不能直接当作本项目部署方案。[34]

### 12.5 confidence Part-ROI为什么在当前形式失败

upper、torso、lower三个192D token加reliability后把输入显著扩张，但它们仍来自同一次P3/P4 feature pass、同一person box和同一actor。当前失败更可能来自以下组合，而不是“人体局部永远无用”：

- part token与person mean高度重合，新增维度大于新增信息；
- reliability是检测质量代理，不是“该部位对fall判别的重要性”；
- 缺失part的填充、缩放和投影可能让网络先学习可见性模式；
- 二分类与6类subtype监督没有直接约束支撑、接触或受控下放；
- 加为第八头稀释原七头，替换又丢失稳定seed，两种位置都不理想。

因此若未来重启Part路线，只允许低维、单变量、残差式canary：共享小投影、显式missing mask、对person token的gated residual，或有人工可见性/支撑标签的辅助任务。不得继续同时扫描part框、margin、confidence阈值和高维拼接。

### 12.6 clip-max的作用和失败边界

clip-max适合“短暂但强烈的fall证据”，并保留不同成员的异步峰值；它也会放大单窗口噪声、旁人track劫持和错误ROI尖峰。任何超过48帧memory或top-k actor方案若继续使用无约束max，都会增加极值假设数并可能抬高FP。因此未来actor数量、memory时域和聚合器必须一次只改一个，且在R95 introduced-error集合上单独审计。

---

## 13. 当前七头覆盖了什么，仍缺什么

| 信息轴 | 当前覆盖 | 当前强度 | 下一步判断 |
|---|---|---|---|
| 16/48帧时间跨度 | `e16 + e48` | 已有正结果 | 保留，不再复刻稀疏48→16 |
| 320/640视觉尺度 | 六个短窗head | 已有正结果 | 保留独立决策空间 |
| seed方差 | 每尺度3 seed | 接近饱和 | 停止增加同构seed |
| actor身份 | top-1 track | 单点失败 | **首要未覆盖轴** |
| 多人竞争 | 隐式由tracker处理 | 弱 | 先top-k replay，不直接训练gate |
| 动作阶段 | 六流和Dense隐式编码 | 中等 | 仅在错误审计支持时做低维phase canary |
| 支撑/接触 | Rule/Kinematics间接表达 | 弱且可能不可见 | 先判断像素中是否可观察 |
| 受控性语义 | 6类subtype辅助 | 仍有lie-down混淆 | 需要更直接标签，不是更多part token |
| 48帧视觉历史 | Dense仍复用320 ROI短历史 | 不完整 | 条件测试事件帧ROI，不盲跑48次YOLO |
| 超48帧事件记忆 | 无 | 未证实需要 | static FN审计后才启动 |
| 在线状态复用 | 窗口重算为主 | 部署门未闭合 | 做等价stream buffer，不共享权重 |

这张表给出下一阶段的核心原则：新模型必须增加一个尚未覆盖的信息轴，或者以更强的归纳偏置读取现有原始序列；不能把现有embedding再做一次last-first、拼接或高维attention后称为新专家。

---

## 14. 最有希望的新融合：RMPTS质量守恒时域迁移

### 14.1 为什么当前`1/7`仍可能不是最优

设三个320短窗logit为`z_320,s`，三个640短窗logit为`z_640,s`，Dense48 logit为`z_D`。先定义：

\[
u_{320}=\frac{1}{3}\sum_{s=1}^{3}z_{320,s},\qquad
u_{640}=\frac{1}{3}\sum_{s=1}^{3}z_{640,s}.
\]

当前七头等权等价于：

\[
z_{eq}=\frac{3}{7}u_{320}+\frac{3}{7}u_{640}+\frac{1}{7}z_D.
\]

Dense与三个320短窗head共享320视觉尺度，但改变了skeleton时域；三个640短窗head则承担独立分辨率互补。因此最小问题不是把三个block强行等权，而是：**保持320视觉family总质量`4/7`和640 family总质量`3/7`不变，只判断320 family内部应给短窗还是Dense更多质量。**

### 14.2 RMPTS一维公式

RMPTS（Resolution-Mass-Preserving Temporal Shift）只引入一个`delta`：

\[
z_{delta}=(\frac{3}{7}-delta)u_{320}
          +\frac{3}{7}u_{640}
          +(\frac{1}{7}+delta)z_D,
\qquad -\frac{1}{14}\le delta\le\frac{1}{7}.
\]

预注册网格固定为：

\[
delta\in\{-\frac{1}{14},0,\frac{1}{28},\frac{1}{14},\frac{1}{7}\}.
\]

- `delta=0`：完全恢复当前七头每成员`1/7`；
- `delta>0`：只把320短窗质量迁移给Dense；
- `delta<0`：允许结果否定“Dense应加权”，把质量退回320短窗；
- 三个320短窗seed始终等权，每个权重为`(3/7-delta)/3`；
- 三个640 seed始终各`1/7`；
- 320总质量恒为`(3/7-delta)+(1/7+delta)=4/7`，640总质量恒为`3/7`；
- 五个网格点全部非负，总权重恒为1。

该设计只有一个有效自由度，且不把已验证的分辨率互补与新时域问题混在一起。Stacking文献支持以预测表现组合模型，但并不保证高维自由权重在相关成员和小样本下稳定；本项目因此只借用“cross-validated predictive combination”原则，不直接采用七维无约束stacking。[35]

现有Super Learner、stacked generalization和ensemble selection文献也支持用OOF选择组合，同时要求最终比较与调权数据隔离。[25][26][27]

### 14.3 完整nested template-grouped protocol

**不能**直接在现有9,600条OOF上选`delta`再在同一表上报告收益。正式协议如下：

1. 保留五个outer template-group folds，outer holdout从基础成员、Dense准入、融合选择和阈值选择中完全隔离。
2. 对每个outer fold，仅在其outer-train groups内生成inner grouped OOF；七个基础成员的训练、缓存和fold map也必须是outer-isolated版本。
3. 在inner OOF上依次评估五个预注册`delta`，不增加连续搜索、成员删除、温度或额外lambda。
4. 每个`delta`都与同一inner数据上的`delta=0`比较；先要求P@R90和P@R95均不下降，再最大化`mAP*`。
5. 在inner OOF内以template group为paired bootstrap重采样单位，固定2,000次draws和随机种子；对“inner最优`delta`减候选`delta`”的`mAP*` paired delta计算SE。差值`≤1×SE`视为近似并列，并选`|delta|`更小者。
6. 用选定`delta_k`融合该outer fold中从未参与选择的预测；五个outer holdout拼接后只计算一次最终指标。
7. 零值单独计数。只有至少4/5个outer folds的`delta_k`严格同正或严格同负，才允许声称方向稳定；否则最终回退`delta_final=0`。
8. 若相同`|delta|`的正负候选并列，依次比较inner P@R95、inner P@R90；仍相同则选负`delta`，更保守地降低单个Dense权重。
9. 方向稳定时，最终部署`delta_final`取五个`delta_k`中位数；不得再用拼接后的outer OOF标签重新搜索。
10. 候选与`delta=0`分别使用同一冻结evaluator确定自身R95工作点；score tie、`recall≥0.95`阈值和整组同分样本处理完全复用既有政策。
11. metric evaluator、template-group/fold map、9,600 clip universe、window→clip聚合器、RMPTS网格、bootstrap实现和随机种子都在读取结果前记录SHA-256。
12. random-validation、sealed test、URFD test不参与`delta`、阈值、成员或停止条件选择。

Grouped/nested CV的必要性来自template相关性和meta层选择偏差；普通随机行切分会高估可迁移性，结构化数据的CV必须让相关group共同进出fold。[22][39]

超参数选择与误差估计复用同一数据会产生后续选择偏差，所以现有OOF只能支持当前incumbent，不能同时充当新融合的最终确认集。[23][38]

### 14.4 融合晋级硬门

只有同时满足以下条件，`z_delta`才可替换`z_eq`：

- outer cross-fitted pooled `mAP*`高于`delta=0`，且paired template-group bootstrap差值95% CI下界大于0；
- P@R90、P@R95两个点估计均不低于`delta=0`，不得用P90提升补偿P95下降；
- 至少4/5 outer folds的`mAP*`差值非负，任一fold回退不超过预注册的0.5个百分点；
- fold-2不得进一步出现未解释恶化；
- R95 unique rescues多于introduced errors；
- 至少4/5个`delta_k`严格同号；零值、正负混合或跨越三档均判定方向不稳定并回退`delta=0`；
- 最终阈值必须从cross-fitted候选分数重新确定，不能沿用七头旧阈值。

P@R约束是数据依赖、非可分解指标，复杂代理优化可能在训练目标、约束满足和泛化之间产生额外缺口；因此本报告只把P90/P95作为融合选择硬护栏，不授权新的metric-surrogate训练。[21][36]

### 14.5 备选与不推荐方案

| 方法 | 自由度 | 排序变化 | 当前判断 |
|---|---:|---|---|
| 当前七头`1/7` logit | 0 | 已验证 | incumbent |
| RMPTS质量守恒迁移 | 1 | 会变 | **主候选；允许上调或下调Dense** |
| 三block固定各`1/3` | 0，但属于新假设 | 会变 | 破坏320/640质量平衡，不列入F1网格 |
| 三block non-negative simplex | 2 | 会变 | 仅当一维结果稳定但320/640长期不对称时启动 |
| 七维non-negative stacking | 6 | 会变 | 成员高度相关，当前过拟合风险过高 |
| leave-one-member-out | 离散选择 | 会变 | 主要用于效率诊断，不先用于提分 |
| equal-probability | 0 | 会变 | 可作为诊断；旧六头近似并列，不是主线 |
| 最终logit温度校准 | 1 | **不变** | 只能改概率刻度，不能提高P@R排序 |
| member-wise calibration | ≥7 | 会变 | 自由度过高，需nested；当前不做 |
| CDF/rank fusion | 多 | 会变 | 旧实验已伤P95，停止 |
| quality/dynamic gate | 多 | 会变 | hardest positives常低质量，容易把FN继续压低 |

---

## 15. 比“第八头”更强的模型改进路线

### 15.1 P0：先完成七头错误与在线闭包

必须先拿到七成员逐clip raw logits、当前阈值、R90/R95错误身份、fold/template/动作类型、track质量和完整在线窗口签名。没有这些材料，任何新模型都会重复“总体均值提高但不知道修了什么”的搜索。

### 15.2 P1：track-first top-k actor replay

动作识别研究显示，把pose、tracking与动作模型统一考虑能够减少逐帧检测噪声和身份不连续；该机制支持本项目先处理actor轨迹，而不是把所有错误交给分类头，但对应论文的3D tracking设置不能直接外推为fall精度增益。[33]

PoseTrack进一步说明多人pose估计与跨帧身份关联本身就是联合问题；它支持建立独立track-error切片，但不提供本项目top-k规则的现成答案。[40]

最小实验不训练模型：

1. 在已审计的多人、遮挡、ID-switch和低分检测切片中保留top-2 track hypotheses；
2. 七头模型、融合、阈值全部冻结；
3. 分别报告top-1、oracle-top-2和预注册确定性track规则；
4. 单列“正确actor被恢复”“旁人劫持FP”“跨人历史污染”；
5. 若oracle-top-2都无法恢复严重FN，停止actor模型化；若oracle有效而确定性规则无效，才考虑小型set encoder。

这里的价值是真正增加当前系统没有看到的actor候选。风险是候选数量增加后clip-max产生旁人尖峰，所以正式版本必须固定最大actor数、track reset、最短历史和跨人聚合规则。

### 15.3 P2：低维事件阶段/原始运动专家，一换一而非加头

若新错误审计确认大量slow/partial/static错误在正确actor、完整48帧可见时仍被漏检，可测试一个低容量Phase-Motion canary：

- 直接读取48帧body-height归一化的joint速度、加速度、jerk、bbox bottom/centre运动、可见性和stillness；
- 不读取`e16/e48` embedding，避免重演相关性`0.9918`的transition residual；
- 用三个因果阶段readout表示“下降前/下降或接触/接触后静止”，而不是高维attention pooling；
- 与当前最弱的一个16帧seed做一换一，成员数保持7；
- 保留相同binary与subtype任务，第一轮不引入pseudo phase label。

这不是新传感器，仍可能与Motion/Kinematics流重复；其唯一可检验假设是“受限原始运动输入 + 显式阶段readout”能形成不同错误边界。若与任一源成员相关性仍高、R95 unique rescue不为正或替换后P95下降，立即停止。时序分层文献支持同时保留局部阶段和长程上下文，但只能作为结构动机，不能替代本项目canary。[34]

经典TCN action segmentation工作支持用时间卷积表达阶段边界与长程依赖；本报告只借用阶段readout动机，不把其离线分割指标外推为fall收益。[41]

### 15.4 P3：48帧视觉对齐，只复用已有缓存

Dense当前是48帧skeleton配短视觉历史。若错误审计显示受控下放、手部支撑或接触动作在较早时刻可见，可从已存在的ROI cache中预注册少量因果事件帧token，例如最早、最大下降速度附近和当前帧；第一轮不得为48帧每帧新增YOLO pass。

单一变化应是“Dense head的ROI时域”，不是同时改ROI分辨率、part、attention和loss。若现有缓存无法覆盖事件帧，则先报告额外YOLO/feature存储成本，再决定是否值得训练。

### 15.5 P4：support/controlledness只有在可观察且可标注时启动

controlled lie-down与fall的区别往往来自主动支撑、缓慢接触、床/沙发边界和恢复意图。当前Part-ROI没有这些监督。重启条件必须同时满足：

- 随机分层错误审计中多数目标样本确实能从像素或pose观察支撑信息；
- controlledness双人标注一致性达到预注册门；
- 只增加一个低维辅助任务，不作为hard suppressor；
- slow/partial fall召回不下降。

若支撑物在裁剪外、视角无法判断或标签一致性差，应把它归为输入不可辨识，而不是继续堆上下文ROI。

### 15.6 P5：超过48帧memory最后启动

只对“同一actor身份连续、fall transition曾经可见、当前判定时转移已离开48帧”的static post-fall样本有意义。最小版本是正向事件记忆：在同一track保存一次fall-transition evidence，track switch、长缺失或身份不确定立即reset；不得用memory作为负向suppressor。

若96帧等效replay只是重复现有clip-max、片段从躺地开始根本没有早期事件，或记忆滞留增加FP，则停止，不升级S4/Mamba或大型memory Transformer。

---

## 16. 在线部署与结构精简

### 16.1 已知资源量与未知资源量

- 七头可训练参数约`1,342,565`，仅按FP32参数约`5.12 MiB`；这不含frozen pose/YOLO、tracker、运行时激活、ROI cache和框架开销。
- Dense不新增320检测/特征pass，但新增独立48帧六流backbone和head。
- 当前没有目标V100上包含pose、track、320/640 ROI、`e16/e48`、七heads、window/clip聚合的端到端P50/P95实测，所以`≤100 ms`仍未关闭。

### 16.2 可以安全优先做的优化

1. **输入ring buffer共享**：同一track只保存一份规范化pose、几何、质量和ROI索引；`e16/e48`从不同长度视图读取。
2. **ROI cache复用**：320 Dense和三个320短窗head复用同一frozen ROI token，不重复detector pass。
3. **批量调度**：在不改变窗口身份和浮点路径的前提下合并同一时刻的head前向。
4. **等价流式状态**：对因果卷积保存必要历史，对causal attention保存仅来自过去的K/V；每次只更新新终点。
5. **阈值与reset显式化**：warm-up 24/48、left padding、end-visible、track switch、长缺失、clip边界都进入在线契约。

MoViNet的stream buffer证明流式视频网络可以用缓存把内存与视频长度解耦，但它是专门设计的3D CNN；本项目只能借用“状态缓存必须保持离线/在线等价”的工程原则，不能假定当前TCN/attention直接缓存后数值不变。[37]

### 16.3 当前不能做的“优化”

- 共享`e16/e48`早期学习参数或hidden state：可能直接消除Dense互补；
- 删除高相关seed：弱成员仍可能在R95阈值附近提供独特救回；
- 把16帧补齐到48帧后强行合批：会改变padding、attention和SE统计；
- accuracy-oriented蒸馏：学生可能无法复现七成员各自clip-max后的异步证据；
- 未经重评把FP16/INT8称为等价：高召回阈值附近的排序可能改变。

### 16.4 部署benchmark矩阵

| 维度 | 必报设置 |
|---|---|
| 硬件 | 目标V100、CUDA/cuDNN、driver、框架版本 |
| 批量 | batch=1；单track与多track上限 |
| 输入 | 分辨率、视频解码是否计时、16/48 warm-up |
| 阶段 | pose、track、320 ROI、640 ROI、e16、e48、7 heads、aggregation分项 |
| 时延 | 至少预热后P50/P95/P99，不只均值 |
| 资源 | 峰值显存、CPU内存、参数体积、ROI/track cache |
| 准确性 | 离线批处理与在线逐帧raw logits、clip logits、阈值决策逐项一致 |
| 重置 | 新track、ID switch、长缺失、clip边界、进程重启 |

部署硬门：全链路P95`≤100 ms`、参数`≤20M`、FP32体积`≤80MB`，且在线/离线差异不能改变任何OOF clip的排序或R90/R95决策。若缓存实现只能做到近似等价，必须重新跑完整OOF，而不是只比少量logit误差。

---

## 17. 精确消融矩阵与停止条件

| ID | 单一变化 | 训练预算 | 首要回答 | 晋级门 | 立即停止 |
|---|---|---:|---|---|---|
| A0 | 七头incumbent闭包 | 0 | raw logits/阈值/在线契约能否重建 | 9,600身份一致；三指标复算一致 | 任一身份、fold或阈值不一致 |
| F1 | RMPTS一维`delta`迁移 | full nested | 320 family内长窗应获得多少质量 | 第14.4全部通过 | 方向不稳、任一工作点下降 |
| T1 | top-k actor oracle replay | 0 | 严重错误是否来自top-1 actor | actor slice恢复且旁人FP可控 | oracle都无恢复 |
| T2 | 确定性track规则 | bounded | 能否逼近oracle恢复 | 全OOF三指标不降 | ID污染或多人FP增加 |
| M1 | Phase-Motion一换一 | 1 fold→5 fold | 显式阶段readout是否新颖 | P90/P95不降、unique rescue为正 | 高相关、fold canary失败 |
| V1 | Dense事件帧ROI | 1 fold→5 fold | 长视觉是否补受控性 | 不新增pass或成本可接受；P95不降 | 与原Dense近重复 |
| S1 | controlledness辅助 | 标注后1 fold | 监督缺口是否核心 | 标注一致、controlled FP降、slow FN不升 | 标签不稳或P95下降 |
| L1 | 96帧正向memory | replay→1 fold | 转移是否离开48帧 | static FN净恢复、无滞留FP | clip-max重复或跨人传播 |
| D1 | 等价stream buffer | 0 | 能否降时延且保持排序 | 全OOF逐clip等价、P95≤100ms | 任一决策变化 |

统一评价必须同时报告：`mAP*`、P@R90、P@R95、五折差值、template-group paired bootstrap、R95 rescue/introduced身份、成员相关性、参数、P50/P95时延和峰值显存。任何候选只提高`mAP*`平均而压低P95，均不得晋级。

---

## 18. 最终优先级与推荐配置

### 18.1 立即保留的研究incumbent

```text
Stage-S1 e16 六流骨架状态
  + 320 Person-ROI × 3 seeds
  + 640 Person-ROI × 3 seeds
独立Stage-S1 e48 六流骨架状态
  + 320 Person-ROI × 1 Dense48 head
每成员先window→clip max
七个clip logits固定1/7平均
```

该配置仍是唯一已经获得完整五折结果的七头anchor。R6没有把任何未执行方案写成已验证提升。

### 18.2 下一轮研究排序

1. **A0：七头raw-logit、阈值、错误身份、在线窗口和部署benchmark闭包。**
2. **T1：top-k actor无训练oracle replay。** 它最便宜且直接判断共同上游是否是主瓶颈。
3. **F1：RMPTS一维质量守恒时域迁移。** 这是最好的新融合候选，但只在完整nested预算获批后执行。
4. **T2：只有T1阳性才做track规则或小型actor set model。**
5. **M1：只有正确actor且48帧内仍漏时，做Phase-Motion一换一canary。**
6. **V1/S1：只有错误审计证明视觉支撑信息可见时，才做事件帧ROI或controlledness辅助。**
7. **L1：只有转移确实离开48帧时，才研究超48帧正向memory。**
8. **三block simplex、七维stacking、dynamic gate、大型GCN/Transformer/SSM继续后置。**

### 18.3 最终判断

> **更好的融合方向已经收敛到“保持320/640质量、只迁移短窗与Dense时域质量”的RMPTS；更好的模型方向则收敛到“先恢复正确actor，再补事件阶段或真正可观察的新信息”。当前七头并不缺容量，缺的是对共享上游错误、时域质量分配和受控性语义的精确处理。任何下一步都应以一个自由度、一个信息轴、一个明确停止门推进。**

Sources:
[1] https://openaccess.thecvf.com/content_cvpr_2017/html/Lin_Feature_Pyramid_Networks_CVPR_2017_paper.html — Feature Pyramid Networks for Object Detection
[2] https://openaccess.thecvf.com/content_ICCV_2017/html/He_Mask_R-CNN_ICCV_2017_paper.html — Mask R-CNN
[3] https://openaccess.thecvf.com/content_ICCV_2017/html/Lin_Focal_Loss_for_ICCV_2017_paper.html — Focal Loss for Dense Object Detection
[4] https://arxiv.org/abs/1803.01271 — An Empirical Evaluation of Generic Convolutional and Recurrent Networks for Sequence Modeling
[5] https://arxiv.org/abs/1709.01507 — Squeeze-and-Excitation Networks
[6] https://proceedings.neurips.cc/paper/7181-attention-is-all-you-need — Attention Is All You Need
[7] https://openaccess.thecvf.com/content_CVPR_2019/html/Abu_Farha_MS-TCN_Multi-Stage_Temporal_Convolutional_Network_for_Action_Segmentation_CVPR_2019_paper.html — MS-TCN: Multi-Stage Temporal Convolutional Network for Action Segmentation
[8] https://proceedings.neurips.cc/paper_files/paper/2017/hash/9ef2ed4b7fd2c810847ffa5fa85bce38-Abstract.html — Simple and Scalable Predictive Uncertainty Estimation Using Deep Ensembles
[9] https://arxiv.org/abs/1803.05407 — Averaging Weights Leads to Wider Optima and Better Generalization
[10] https://www.ecva.net/papers/eccv_2022/papers_ECCV/html/315_ECCV_2022_paper.php — ByteTrack: Multi-Object Tracking by Associating Every Detection Box
[11] https://openaccess.thecvf.com/content_ICCV_2019/html/Lin_TSM_Temporal_Shift_Module_for_Efficient_Video_Understanding_ICCV_2019_paper.html — TSM: Temporal Shift Module for Efficient Video Understanding
[12] https://openreview.net/forum?id=tEYskw1VY2 — Mamba: Linear-Time Sequence Modeling with Selective State Spaces
[13] https://openreview.net/forum?id=uYLFoz1vlAC — Efficiently Modeling Long Sequences with Structured State Spaces
[14] https://proceedings.neurips.cc/paper/2020/hash/d89a66c7c80a29b1bdbab0f2a1a94af8-Abstract.html — Supervised Contrastive Learning
[15] https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html — Enhancing Skeleton-Based Action Recognition Through Realistic Data Augmentation
[16] https://www.sciencedirect.com/science/article/pii/S0893608005800231 — Stacked Generalization
[17] https://proceedings.mlr.press/v70/guo17a.html — On Calibration of Modern Neural Networks
[18] https://openaccess.thecvf.com/content/CVPR2022/html/Duan_Revisiting_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html — Revisiting Skeleton-Based Action Recognition (PoseC3D)
[19] https://arxiv.org/abs/1801.07455 — Spatial Temporal Graph Convolutional Networks for Skeleton-Based Action Recognition
[20] https://openaccess.thecvf.com/content/ICCV2021/html/Chen_Channel-Wise_Topology_Refinement_Graph_Convolution_for_Skeleton-Based_Action_Recognition_ICCV_2021_paper.html — CTR-GCN: Channel-Wise Topology Refinement Graph Convolution
[21] https://openaccess.thecvf.com/content/CVPR2022/html/Chi_InfoGCN_Representation_Learning_for_Human_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html — InfoGCN: Representation Learning for Human Skeleton-Based Action Recognition
[22] https://doi.org/10.1038/s41598-018-24271-9 — Recurrent Neural Networks for Multivariate Time Series with Missing Values (GRU-D)
[23] https://proceedings.mlr.press/v80/ilse18a.html — Attention-based Deep Multiple Instance Learning
[24] https://arxiv.org/abs/1503.02531 — Distilling the Knowledge in a Neural Network
[25] https://arxiv.org/abs/1904.02438 — Cross Validation for Correlated Data
[26] https://proceedings.mlr.press/v54/eban17a.html — Scalable Learning of Non-Decomposable Objectives
[27] https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html — Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence
[28] https://proceedings.neurips.cc/paper/2021/hash/76ba9f564ebbc35b1014ac498fafadd0-Abstract.html — Attention Bottlenecks for Multimodal Fusion
[29] https://www.cs.cornell.edu/~alexn/papers/shotgun.icml04.revised.rev2.pdf — Ensemble Selection from Libraries of Models
[30] https://statistics.berkeley.edu/sites/default/files/tech-reports/367.pdf — Stacked Regressions
[31] https://doi.org/10.2202/1544-6115.1309 — Super Learner
[32] https://www.ecva.net/papers/eccv_2024/papers_ECCV/html/5796_ECCV_2024_paper.php — SkateFormer: Skeletal-Temporal Transformer for Human Action Recognition
[33] https://openaccess.thecvf.com/content/CVPR2023/html/Rajasegaran_On_the_Benefits_of_3D_Pose_and_Tracking_for_Human_CVPR_2023_paper.html — On the Benefits of 3D Pose and Tracking for Human Action Recognition
[34] https://openaccess.thecvf.com/content/CVPR2022/html/Dai_MS-TCT_Multi-Scale_Temporal_ConvTransformer_for_Action_Detection_CVPR_2022_paper.html — MS-TCT: Multi-Scale Temporal ConvTransformer for Action Detection
[35] https://arxiv.org/abs/1704.02030 — Using Stacking to Average Bayesian Predictive Distributions
[36] https://proceedings.mlr.press/v97/cotter19b.html — Training Well-Generalizing Classifiers for Data-Dependent Constraints
[37] https://openaccess.thecvf.com/content/CVPR2021/html/Kondratyuk_MoViNets_Mobile_Video_Networks_for_Efficient_Video_Recognition_CVPR_2021_paper.html — MoViNets: Mobile Video Networks for Efficient Video Recognition
[38] https://jmlr.org/papers/v11/cawley10a.html — On Over-fitting in Model Selection and Subsequent Selection Bias in Performance Evaluation
[39] https://doi.org/10.1111/ecog.02881 — Cross-validation strategies for data with temporal, spatial, hierarchical, or phylogenetic structure
[40] https://openaccess.thecvf.com/content_cvpr_2018/html/Andriluka_PoseTrack_A_Benchmark_CVPR_2018_paper.html — PoseTrack: A Benchmark for Human Pose Estimation and Tracking
[41] https://openaccess.thecvf.com/content_cvpr_2017/html/Lea_Temporal_Convolutional_Networks_CVPR_2017_paper.html — Temporal Convolutional Networks for Action Segmentation and Detection
