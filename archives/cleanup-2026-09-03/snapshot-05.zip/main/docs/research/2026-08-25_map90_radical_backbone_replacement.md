# mAP90 激进换代方案：替换骨架轨迹与六流 TCN

日期：2026-08-25  
状态：F2（Context ROI）与 F3（quality-gated fusion）已由用户验证无效  
目标：不保留当前坐标六流与 16+48 双尺度因果 TCN 的结构前提，重新设计 clip mAP ≥90% 路线

## 1. 新结论

F2/F3 无效意味着：

- 从 YOLO pose backbone 抽取浅层/中层 ROI 特征，并没有产生足够互补信息；
- 用质量门控制约两个已弱相关的 embedding，也不会自动改善排序；
- 当前问题不宜继续解释为“融合层设计得不够好”。

更合理的解释是：当前表示链存在三次不可逆压缩：

```text
RGB视频
→ 17个坐标关键点
→ 6组手工派生统计
→ 每流只保留末时刻embedding
→ max-window视频分数
```

人体轮廓、空间接触、运动模糊、遮挡形态、场景变化和长时序结构在进入分类器前已经丢失。F2/F3 只在末端补特征，无法修复前面的信息损失。

因此建议正式停止以下主线：

- 坐标六流继续扩展；
- 16+48 双尺度 TCN；
- Person/Context ROI late fusion；
- pose-quality gate；
- max-window / top-k MIL 聚合。

新的主线是 **FallMamba-X：全帧 RGB + 姿态热图早期融合 + 长视频状态空间模型 + 完整 clip 排序**。

## 2. 最新推荐架构

### 2.1 研究阶段：异构双教师

```text
Teacher A：InternVideo2-S/B 或 VideoMAE V2-B
输入完整RGB视频，端到端微调

Teacher B：PoseHeatmap-VideoMambaPro
输入关节/骨骼热图体积，不使用坐标轨迹和手工六流

两者只用train-only OOF预测训练异构融合器
```

Teacher A 负责：

- 人体轮廓与形变；
- 地面、床、沙发和障碍物关系；
- 遮挡、运动模糊和真实纹理；
- 全场景长时序语义。

Teacher B 负责：

- 去背景的人体运动；
- 关键点不确定性；
- 多人物姿态；
- 对光照和外观变化的相对稳定性。

它们是异构模型，不是当前四个同构 seed。最终研究指标允许先由异构融合冲击 90%，再蒸馏到端侧学生。

### 2.2 部署阶段：FallMamba-X 学生

```text
96帧RGB，16 fps，约6秒
        │
        ├───────────────┐
        ▼               ▼
RGB Tube Stem       Pose Heatmap Stem
3D patch embed      17 joint + 16 limb maps
        │               │
        └──────┬────────┘
               ▼
       Token-level Early Fusion
       concat + linear projection
       + pose spatial attention bias
               │
               ▼
     Hierarchical VideoMambaPro-S/T
     local 3D conv + linear-time SSM
               │
               ▼
       Full-clip attention pooling
               │
        ┌──────┼──────────┐
        ▼      ▼          ▼
   Binary AP  6-way ADL   3-state
      head     head        head
               │
               ▼
       clip fall ranking score
```

关键点：

- 不再使用 track ID 组织骨架轨迹；
- 不再把 pose 压成 51D 坐标；
- 不再使用六个手工流；
- 不再使用 max-window；
- RGB 与 pose 在 token 层早期融合，而不是两个最终 embedding 的 late fusion；
- 主干直接看到完整 6 秒时空体积。

## 3. 为什么改用姿态热图

PoseConv3D 的核心结果是：把 2D pose 表示为空间-时间热图体积，比坐标图序列更抗姿态估计噪声，并具有更好的跨数据集泛化；热图层级特征也更容易与 RGB 在早期融合。

### 3.1 热图构造

每帧构造：

- 17 个 joint Gaussian heatmaps；
- 16 个 limb heatmaps；
- 可选 1 个 person occupancy map。

张量：

```text
Pose volume: [T=96, C=33或34, H=56, W=56]
```

高置信关键点使用窄 Gaussian，低置信关键点使用更宽、更低幅度的 Gaussian。这样网络看到的是不确定性分布，而不是错误坐标的确定点。

### 3.2 多人物处理

同一通道内对不同人物热图取 max 或 clipped sum，不依赖长期身份关联。跌倒检测只需要知道画面中是否有人发生跌倒，不必首先解决完美的跨 6 秒 ID tracking。

这直接绕过当前 tracker 的身份切换、轨迹断裂和末帧缺失问题。

### 3.3 与 F2/F3 的本质区别

F2/F3 在已经压缩完成的 skeleton embedding 旁边补一个 ROI embedding；新方案则在 backbone 第一至第二 stage 之前把 pose 空间分布注入 RGB token。后续每一层都能联合学习：

```text
人体区域发生了什么运动
+
该运动与地面/家具/遮挡有什么关系
```

因此，F2/F3 无效并不能否定这种早期时空融合。

## 4. 为什么选择 VideoMambaPro 而不是继续 TCN/Transformer

### 4.1 当前 TCN 的结构限制

当前每流 TCN 最后只读取末时刻表示；即使扩大到 48 帧，六流之间仍然缺少完整的空间结构和逐时刻联合建模。继续增加 dilation 或 stream 数量只会扩大同一种表示。

### 4.2 VideoMamba 的优势

VideoMamba 使用线性复杂度状态空间模型处理长视频，同时保留局部视觉建模。ECCV 2024 论文报告其兼顾短动作敏感性和长视频依赖。

ICCV 2025 的 VideoMambaPro 进一步指出原始 Mamba 存在历史衰减和元素矛盾问题，并通过 masked backward computation 与 elemental residual 改善；相对 VideoMamba 在 Kinetics-400 和 Something-Something V2 上分别提升约 1.6–3.0 和 1.1–1.9 个 top-1 点。

### 4.3 在线部署处理

研究模型可以在 6 秒 clip 内使用双向 VideoMambaPro，允许约 1–2 秒告警确认延迟。部署学生采用：

- 单向 causal SSM；或
- MoViNet-style stream buffer。

MoViNets 已证明流式 3D 视频网络可以在固定内存下处理任意长度视频。先用双向模型验证信息上限，再蒸馏成 causal student，比一开始就受当前 TCN 结构限制更合理。

## 5. RGB 教师必须端到端微调

旧 R3D-18 教师失败的是：

```text
冻结Kinetics全局特征
→ 线性/MLP头
→ mAP约40.9%–44.4%
```

新教师采用完全不同的训练：

```text
InternVideo2-S/B 或 VideoMAE V2-B
→ 64/96帧完整RGB
→ 解冻后半部分乃至全模型
→ fall/ADL多任务微调
→ train-only grouped OOF
```

VideoMAE V2 证明 masked video pretraining 能得到强通用视频表示；InternVideo2 使用 masked modeling、跨模态对比和渐进训练，在大量视频任务上展示了强迁移能力，官方同时提供 S/B/L 小模型。

不要使用 1B/6B 模型作为第一轮训练主体。首选顺序：

1. InternVideo2-S；
2. VideoMAE V2-B；
3. 只有前两者表现明显受容量限制时才上 InternVideo2-B/L。

## 6. 输入与时间设计

### 6.1 完整 clip，而非滑窗 max

OF-Syn 单 clip 约 5 秒。统一读取：

- 80 帧：16 fps × 5秒；或
- pad/sample 到 96 帧，覆盖前后少量上下文。

模型直接输出一个 clip score：

```text
score = classifier(attention_pool(all_video_tokens))
```

不再训练窗口 BCE + top-k MIL，也不在验证时取窗口最大值。

### 6.2 双时间速率

若 96 帧计算过重，使用：

```text
Slow RGB：32帧，stride=3，224×224
Fast motion：96帧，112×112，只用RGB差分/低通道stem
Pose heatmap：96帧，56×56
```

Slow 路径负责场景和接触，Fast/Pose 路径负责快速下降。二者在 stage 2 后融合。只有单路径 96 帧显存不足时才启用该设计，避免首个实验同时引入过多分支。

## 7. 训练流程

### Phase A：强 RGB 教师生死门

```text
Input: 64/96-frame RGB
Model: InternVideo2-S
Loss: weighted focal + 0.2×ADL subtype CE
Protocol: grouped 5-fold OOF
```

通过条件：

- RGB teacher OOF mAP ≥80%；
- 与当前 skeleton ensemble 的 FP 重叠率 <80%；
- `lie_down/lying` 切片至少优于当前模型 5 个百分点。

停损：若端到端 RGB teacher 仍低于 76%，当前数据/标签的可分性不足，不继续声称结构可以冲到 mAP90。

### Phase B：PoseHeatmap-VideoMambaPro

```text
Input: 33/34-channel pose heatmap volume
Model: compact 3D stem + VideoMambaPro-T/S
Loss: focal + ADL subtype CE
```

通过条件：

- OOF mAP ≥当前最佳单骨架模型；
- pose-missing/ID-switch 切片至少改善 3 点；
- 三 seed worst-case 不低于当前单模型 1 点以上。

如果热图分支明显低于当前 70.28%，先检查 heatmap 尺度、置信度和多人物合成，不立即加 RGB 融合。

### Phase C：异构教师融合

使用每折严格 OOF logits 训练一个只有 2–4 个参数的非负融合器：

```text
z = w_rgb × z_rgb + w_pose × z_pose + b
w_rgb,w_pose ≥0
```

不在当前 validation 搜索权重。

通过条件：

- 相对最强教师 ≥+3 mAP；
- P@R90 ≥85%；
- P@R95 ≥80%。

### Phase D：FallMamba-X 早期融合学生

学生由 RGB+pose heatmap token 早期融合，蒸馏目标包括：

- 异构教师融合 logit；
- RGB teacher 中间时序 token；
- pose teacher 中间热图 token；
- ADL subtype soft distribution。

损失：

```text
L = focal_hard_label
  + 0.4 × KL_teacher_logit
  + 0.15 × token_distillation
  + 0.15 × ADL_subtype_CE
  + 0.05 × supervised_contrastive
```

只有学生 mAP ≥85 后，才增加 AP surrogate fine-tuning。

### Phase E：Motion-guided masked pretraining

若标注量仍是上限，使用所有 train 视频做 motion-guided masked autoencoding：

- 只使用 train split，无 validation/test 帧；
- 优先遮挡静态背景 token，保留/重建运动相关 token；
- RGB 与 pose heatmap 联合重建；
- 再做监督 fine-tuning。

MGMAE 的研究表明 motion-guided masking 比普通随机 VideoMAE 更能学习时间一致的运动表征。

## 8. 分类头与 mAP 排序

### 8.1 主头

最终 ranking 只使用一个 binary logit：

```text
Fall ∪ Fallen vs Non-Fall
```

### 8.2 辅助类别

训练时使用：

```text
fall
fallen
lie_down
lying
stand_up
sit_or_bend
other_background
```

辅助类别不做规则式分数扣减，只塑造 backbone 的决策边界。

### 8.3 AP fine-tuning

学生 OOF mAP ≥85 后，用小学习率执行 1–3 epoch AP surrogate：

```text
0.5 × focal + 0.5 × SOAP/AP loss
```

batch 按活动和域平衡。若 P@R95 下降，立即回退蒸馏 checkpoint。

## 9. 数据策略必须同步升级

### 9.1 先清洗排名头部错误

对当前和新 teacher 的 top-200 高分负例逐条分类：

- 标签是否错误；
- clip 是否包含未标注真实跌倒；
- 主体是否出画；
- pose 是否完全失败；
- 视频生成是否有畸变；
- 是否为重复/近重复场景。

mAP90 对标签噪声极敏感。若前 100 个高分负例中超过 10% 存在标签或生成质量问题，先修数据再改模型。

### 9.2 自监督预训练

将 OF-Syn 与许可范围内 OF-Staged 的训练视频用于视频 MAE 预训练，但保持人物/场景/数据集分组，绝不引入 validation/test 内容。

### 9.3 防止背景捷径

全帧 RGB 模型必须使用：

- background swap 或 person-preserving CutMix；
-场景颜色/亮度/压缩增强；
-同活动跨场景正样本；
-同场景不同活动负样本；
-domain-balanced sampler。

同时保存按场景和数据源的 mAP，防止模型靠“某个房间更常跌倒”取得虚高结果。

## 10. 新里程碑

| 阶段 | 模型 | mAP目标 | 继续条件 |
|---|---|---:|---|
| B0 | 当前固定四模型 | 71.18 | 仅作为回归基线 |
| A | InternVideo2-S RGB teacher | ≥80 | <76则停止架构承诺 |
| B | PoseHeatmap-VideoMambaPro | ≥71 | 必须替代坐标六流 |
| C | 异构教师OOF融合 | ≥84 | 相对最强教师 +3 |
| D | FallMamba-X早期融合学生 | ≥85 | 保留教师主要增益 |
| E | motion-guided预训练+蒸馏 | ≥88 | P@R90≥88 |
| F | AP精修+异构最终集成 | **≥90** | P@R90≥90、P@R95≥85 |

这些是通过线，不是保证增益。尤其 mAP90 最可能首先由异构教师融合达到；单个端侧学生可能先停在 85–88，再通过第二轮蒸馏和数据闭环逼近。

## 11. 三条决定性停损线

### 停损 1：RGB teacher 低于 76

如果真正端到端微调的 InternVideo2-S 仍低于 76 mAP，说明现有 RGB 数据并没有提供足够可学习信息，或标签/划分存在上限。此时不实现 FallMamba-X。

### 停损 2：热图分支低于当前骨架 3 点以上

说明 heatmap 构造或预训练失败。先修输入，不与 RGB 强行融合。

### 停损 3：异构教师融合低于 84

即使强 RGB 与热图模型组合仍无法达到 84，则从当前数据直接到 90 缺乏证据。后续预算转向数据质量、真实目标域样本和标签重审。

## 12. 资源预算

本方案把“研究模型”和“部署模型”分开：

| 阶段 | 建议规模 | 用途 |
|---|---:|---|
| RGB teacher | InternVideo2-S/B 或 VideoMAE V2-B | 验证RGB上限、生成软标签 |
| Pose teacher | VideoMambaPro-T/S + heatmap stem | 验证姿态热图上限 |
| Research ensemble | 两个teacher | 首先冲击mAP90 |
| Edge student | 10–25M FallMamba-X | 蒸馏后部署 |
| Extreme edge | MoViNet/causal SSM student | 第二轮压缩 |

当前“时序模型 <1M”的限制不再优先；先证明 90% 是否可达，再做端侧压缩。如果要求一步到位保持当前 16 万参数，则 mAP90 缺乏现实路径。

## 13. 与上一方案的差异

| 项目 | 上一方案 | 本方案 |
|---|---|---|
| Pose表示 | 51D坐标+六流 | 17关节+16骨骼热图体积 |
| Tracker | 必需 | 不作为主表示依赖 |
| RGB | YOLO ROI late fusion | 全帧端到端视频建模 |
| 融合 | quality-gated embedding | token-level early fusion |
| 时序 | 16+48 causal TCN | 80/96帧 VideoMambaPro |
| 视频分数 | max-window/MIL | 完整clip pooling |
| 教师 | 冻结R3D或无 | 端到端InternVideo2/VideoMAE |
| 达标方式 | 单端侧模型 | 先异构教师90，再蒸馏 |

## 14. 实施顺序

```text
第1步：不改现有代码，导出固定OOF基线和top错误清单
  ↓
第2步：InternVideo2-S端到端RGB canary
  ↓ 仅当mAP≥80或至少明显高于当前
第3步：构建pose heatmap cache，训练PoseHeatmap-VideoMambaPro
  ↓
第4步：严格OOF异构融合
  ↓ 仅当mAP≥84
第5步：实现FallMamba-X token早期融合学生
  ↓
第6步：motion-guided masked pretraining与异构蒸馏
  ↓ 仅当mAP≥85
第7步：AP surrogate精修
  ↓
第8步：锁定配置，一次性validation
```

第一项真正需要写代码的实验应该是 **InternVideo2-S 端到端 RGB canary**，而不是马上实现完整 Mamba 多模态网络。它能最快回答：当前原始视频是否包含足以突破骨架上限的信息。

## 15. 文献依据

1. Duan et al., **Revisiting Skeleton-Based Action Recognition (PoseConv3D)**, CVPR 2022. 热图体积、pose噪声鲁棒性和早期多模态融合。  
   https://openaccess.thecvf.com/content/CVPR2022/html/Duan_Revisiting_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html
2. Li et al., **VideoMamba: State Space Model for Efficient Video Understanding**, ECCV 2024. 线性复杂度长视频建模。  
   https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/03773.pdf
3. Lu et al., **Snakes and Ladders: Two Steps Up for VideoMamba**, ICCV 2025. VideoMambaPro的历史衰减修正。  
   https://openaccess.thecvf.com/content/ICCV2025/html/Lu_Snakes_and_Ladders_Two_Steps_Up_for_VideoMamba_ICCV_2025_paper.html
4. Wang et al., **VideoMAE V2: Scaling Video Masked Autoencoders With Dual Masking**, CVPR 2023. 视频masked pretraining和下游迁移。  
   https://openaccess.thecvf.com/content/CVPR2023/html/Wang_VideoMAE_V2_Scaling_Video_Masked_Autoencoders_With_Dual_Masking_CVPR_2023_paper.html
5. Wang et al., **InternVideo2: Scaling Foundation Models for Multimodal Video Understanding**, ECCV 2024. 强视频迁移教师与S/B/L模型。  
   https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/11491.pdf
6. Kondratyuk et al., **MoViNets: Mobile Video Networks for Efficient Video Recognition**, CVPR 2021. stream buffer和端侧流式视频识别。  
   https://openaccess.thecvf.com/content/CVPR2021/html/Kondratyuk_MoViNets_Mobile_Video_Networks_for_Efficient_Video_Recognition_CVPR_2021_paper.html
7. Huang et al., **MGMAE: Motion Guided Masking for Video Masked Autoencoding**, ICCV 2023. 运动引导的视频自监督预训练。  
   https://openaccess.thecvf.com/content/ICCV2023/html/Huang_MGMAE_Motion_Guided_Masking_for_Video_Masked_Autoencoding_ICCV_2023_paper.html
8. Schneider et al., **OmniFall: A Unified Staged-to-Wild Benchmark for Human Fall Detection**, 2025. 数据域上限与真实事故泛化。  
   https://arxiv.org/abs/2505.19889
9. Qi et al., **Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence**, NeurIPS 2021. AP/AUPRC精修。  
   https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html

## 16. 最终建议

F2/F3 无效后，最激进且仍有科学依据的路线是：

> **撤掉坐标轨迹、六流手工特征、16+48 TCN和max-window；使用全帧RGB端到端教师、PoseConv3D式热图体积、VideoMambaPro长视频主干和完整clip pooling。先让InternVideo2/VideoMAE RGB教师与PoseHeatmap教师组成异构OOF集成冲击90%，再蒸馏到FallMamba-X端侧学生。**

这个方案真正改变了输入信息和主干归纳偏置，而不是继续修补当前骨架模型。它的第一生死门非常明确：若 InternVideo2-S 端到端 RGB OOF mAP 仍低于 76%，则当前数据不支持用架构冲到90%，应立即把预算转向数据质量与目标域样本。

