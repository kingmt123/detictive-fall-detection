# 端侧跌倒检测架构调研报告

> **日期**: 2026-08-18
> **目标**: 为 Detictive 项目寻找架构优化方向，参考端侧人体活动识别、姿态估计、骨架动作识别等领域的最新进展

---

## 一、当前 Detictive 架构概览

| 组件 | 模型/方法 | 参数量 | 推理耗时 |
|------|----------|--------|----------|
| 姿态提取 | YOLO11n-pose | ~3M | 主要瓶颈 |
| 跟踪 | 轻量级跟踪 | - | - |
| 规则引擎 | 物理规则（角度/速度/位置） | 0 | <1ms |
| 时序分类 | Causal TCN (3层, 64→64→128) | 0.134M | <1ms |
| **总计** | | **~3M** | **52.82ms P95** |

**约束**: ≤20M params, FP32 ≤80MB, 推理 ≤100ms (V100 16G)

---

## 二、相关论文调研

### 2.1 高效骨架动作识别

| 论文 | 年份 | 引用 | 核心方法 | 端侧启示 |
|------|------|------|----------|----------|
| **Topology-aware CNN** (AAAI) | 2021 | 181 | 拓扑感知卷积，按骨骼拓扑分组卷积替代GCN | **可替代当前扁平化(51,)输入**，用拓扑感知卷积保留关节空间关系 |
| **AdaSGN** (ICCV) | 2021 | 62 | 自适应关节数量+模型尺寸，按重要性裁剪关节 | **可减少17→10-12关键点**，降低输入维度30-40% |
| **Multi-Modality Co-Learning** (ACM MM) | 2024 | 43 | 骨架+外观多模态协同学习，高效特征融合 | 启示：物理规则特征可作为"第二模态"与骨架联合学习 |
| **TSGCNeXt** (Expert Sys. App.) | 2025 | 14 | 动态-静态多图卷积，高效骨架动作识别 | 图卷积建模关节间关系，比扁平TCN更高效 |
| **LST-AGCN** (Big Data & CC) | 2026 | 1 | 统一轻量注意力框架，高效骨架动作识别 | 注意力机制可增强关键关节权重 |
| **Efficient Skeleton for Embedded** | 2024 | 6 | 专为嵌入式系统优化的骨架动作识别 | 关节映射策略减少计算量 |
| **CoDAT** (arXiv) | 2026 | - | 协同双注意力Transformer+低成本时序建模，边缘认知 | **直接对标边缘认知**，双注意力+轻量时序 |

### 2.2 端侧姿态估计

| 论文 | 年份 | 核心方法 | 端侧启示 |
|------|------|----------|----------|
| **Lightweight HPE for Edge** (arXiv) | 2024 | 压缩感知+轻量HPE，边缘认知网络 | 姿态估计可压缩输入，减少前序计算 |
| **Physics-Bounded mmWave Sensing** (arXiv) | 2026 | mmWave传感+隐私保护姿态估计 | 非视觉方案启示：多模态传感融合 |
| **Real-time Multi-camera 3D HPE** (ESWA) | 2024 | 分布式边缘认知，多相机3D姿态 | 边缘认知+云端协同推理模式 |

### 2.3 端侧活动识别

| 论文 | 年份 | 核心方法 | 端侧启示 |
|------|------|----------|----------|
| **Real-time HAR on Edge Microcontrollers** (Measurement) | 2026 | 动态分层推理，边缘认知微控制器 | **分层推理模式**：先轻量判断，不确定时才用重模型 |
| **Edge-Based HAR with Spectral Analysis** (IWCMC) | 2024 | 频谱分析+轻量分类，边缘认知 | 频域特征可替代/补充时域TCN |
| **Exploring Dimensionality with KD for HAR** (HCIS) | 2025 | 知识蒸馏降维，边缘认知 | **知识蒸馏**：大模型→小模型，保持精度 |
| **Lightweight Explainable Hybrid DL** (IEEE Sensors) | 2025 | 可解释混合深度学习，可穿戴传感 | 混合架构：规则+学习，可解释性 |

### 2.4 跌倒检测专项

| 论文/项目 | 年份 | 核心方法 | 启示 |
|-----------|------|----------|------|
| **Stereo Vision-Based Fall Prediction** (arXiv) | 2026 | 立体视觉+跌倒预测（不只是检测） | **预测>检测**：提前预判跌倒趋势 |
| **Task-Oriented Communication for Action** (arXiv) | 2026 | 面向任务的通信+边云协同推理 | 边云协同：边缘认知粗筛+云端精判 |
| **TAG-Head** (arXiv) | 2026 | 时间对齐图头，即插即用 | 可作为TCN的替代/增强模块 |

---

## 三、GitHub 项目调研

### 3.1 骨架动作识别框架

| 项目 | Stars | 核心架构 | 端侧适用性 |
|------|-------|----------|------------|
| **open-mmlab/mmskeleton** | 3127 | 姿态估计+骨架动作识别+动作合成统一框架 | 学术标杆，架构参考 |
| **yysijie/st-gcn** | 1752 | ST-GCN：时空图卷积网络 | **图卷积替代扁平TCN**的经典方案 |
| **PINTO0309/PINTO_model_zoo** | 4568 | 多框架模型转换库(PT→ONNX→TFLite) | 端侧部署工具链参考 |
| **dusty-nv/jetson-inference** | 8965 | TensorRT部署深度学习推理 | Jetson端侧部署最佳实践 |
| **danie-Craig/pose-estimation-edge-optimization** | 1 | RTMPose-m + ONNX/TensorRT FP16，54.24 FPS | **直接对标**：姿态估计端侧优化 |
| **YeWenxuan64/yolo26_ModelDeploy** | 0 | YOLO26→ONNX→RKNN/QNN，多平台部署 | NPU部署参考 |

### 3.2 跌倒检测项目

| 项目 | Stars | 核心架构 | 启示 |
|------|-------|----------|------|
| **liuxing67scut-droid/fall_detection** | 4 | 树莓派+深度学习+边缘认知 | 树莓派端侧方案参考 |
| **InvictusRex/Fall-Detection** | 4 | YOLOv8+MediaPipe混合系统 | YOLO+轻量姿态估计混合 |
| **Mukesh1q2/EdgeSight** | 0 | ONNX推理+MediaPipe姿态+Web仪表盘 | 端侧+云端监控架构 |
| **WuJinjun-cmd/EdgeHealth-ML** | 2 | MobileNetV3-Small+1D-CNN，INT8量化，Vision+IMU融合 | **多模态融合+INT8量化**的端侧方案 |

---

## 四、关键架构模式总结

### 模式1: 拓扑感知卷积 (Topology-aware Convolution)

**来源**: Topology-aware CNN (AAAI 2021, 181 citations)

**核心思想**: 不将17个关键点展平为(51,)向量，而是按骨骼拓扑结构分组（如左臂、右臂、躯干、左腿、右腿），每组独立卷积，再跨组融合。

**对Detictive的价值**:
- 当前 `x.flatten(2)` 将 (B,T,17,3) → (B,T,51) 丢失了关节空间关系
- 拓扑卷积可保留"左膝角度变化"等物理规则隐含的结构信息
- 参数量增加极小（分组卷积），但特征质量显著提升

**实施难度**: ★★☆ (中等，需修改TCN输入层)

### 模式2: 自适应关节选择 (Adaptive Joint Selection)

**来源**: AdaSGN (ICCV 2021, 62 citations)

**核心思想**: 并非所有17个关节对跌倒检测同等重要。可以学习一个关节重要性权重，动态选择/加权关节。

**对Detictive的价值**:
- 跌倒检测的关键关节: 头部(0)、肩部(5,6)、髋部(11,12)、膝部(13,14)
- 非关键关节: 手腕(9,10)、脚踝(15,16)在跌倒检测中信息量低
- 可减少30-40%输入维度，或用注意力机制加权

**实施难度**: ★☆☆ (简单，加一个关节注意力层)

### 模式3: 时序位移模块 (Temporal Shift Module, TSM)

**来源**: MIT, 用于视频理解的零参数时序建模

**核心思想**: 沿时间维度位移部分通道，使2D CNN具备时序建模能力，零额外参数。

**对Detictive的价值**:
- 当前TCN有0.134M参数用于时序建模
- TSM可替代TCN的部分功能，参数量→0
- 或作为TCN的补充：TSM捕捉短期时序，TCN捕捉长期时序

**实施难度**: ★☆☆ (简单，替换/增强TCN block)

### 模式4: 分层推理 (Hierarchical Inference)

**来源**: Real-time HAR on Edge Microcontrollers (2026)

**核心思想**: 不是每帧都运行完整pipeline，而是分层：
1. **第一层**: 极轻量检查（如物理规则），快速排除明显非跌倒帧
2. **第二层**: 中等复杂度（如TCN），处理疑似跌倒帧
3. **第三层**: 完整pipeline（如YOLO+TCN），仅在高不确定时触发

**对Detictive的价值**:
- 当前每帧都运行YOLO11n-pose，这是主要瓶颈
- 如果物理规则能快速排除80%的非跌倒帧，只需20%帧运行YOLO
- 整体推理时间可降低60-80%

**实施难度**: ★★☆ (中等，需重构pipeline流程)

### 模式5: 知识蒸馏 (Knowledge Distillation)

**来源**: Exploring Dimensionality with KD for HAR (2025)

**核心思想**: 用大模型(teacher)的soft labels训练小模型(student)，小模型学到大模型的"暗知识"。

**对Detictive的价值**:
- 当前YOLO11n-pose (~3M) 可以蒸馏到更小的student模型
- 或用大TCN蒸馏小TCN，保持精度同时减少参数
- 特别适合最终提交时的模型压缩

**实施难度**: ★★☆ (中等，需要teacher模型训练)

### 模式6: 图卷积网络 (Graph Convolutional Network)

**来源**: ST-GCN (1752 stars), TSGCNeXt (2025)

**核心思想**: 将人体骨架建模为图结构，关节为节点，骨骼为边，用图卷积捕捉空间关系。

**对Detictive的价值**:
- 比扁平TCN更自然地建模人体结构
- 可以捕捉"左膝弯曲同时右肩下沉"这种跨肢体关联
- 但参数量和计算量通常比TCN大，需要权衡

**实施难度**: ★★★ (较高，需要重构时序模型)

### 模式7: 边云协同推理 (Edge-Cloud Co-Inference)

**来源**: Task-Oriented Communication (2026), Real-time Multi-camera 3D HPE (2024)

**核心思想**: 边缘设备做粗筛/特征提取，云端做精判/复杂推理。

**对Detictive的价值**:
- 竞赛场景下可能不适用（最终在V100上测试）
- 但架构思想可借鉴：轻量规则引擎做初筛，TCN做精判
- 未来实际部署时可考虑

**实施难度**: ★★☆ (中等，架构层面调整)

---

## 五、针对 Detictive 的架构调整建议

### 建议1: 【高优先级】拓扑感知输入 + 关节注意力

**当前问题**: `x.flatten(2)` 将 (B,T,17,3) → (B,T,51) 完全丢失关节空间结构

**改进方案**:
```python
class TopologyAwareTCN(nn.Module):
    """按骨骼拓扑分组的TCN，保留关节空间关系"""
    
    # 骨骼拓扑分组 (基于COCO 17关键点)
    GROUPS = {
        'head': [0, 1, 2, 3, 4],           # 头部
        'left_arm': [5, 7, 9],              # 左臂
        'right_arm': [6, 8, 10],            # 右臂
        'torso': [5, 6, 11, 12],            # 躯干
        'left_leg': [11, 13, 15],           # 左腿
        'right_leg': [12, 14, 16],          # 右腿
    }
    
    def __init__(self, channels=(64, 64, 128), dropout=0.2):
        super().__init__()
        # 每个拓扑组独立的TCN分支
        self.group_tcns = nn.ModuleDict({
            name: nn.Sequential(
                CausalConv1d(len(joints)*3, 32, 3, dilation=1),
                nn.BatchNorm1d(32), nn.ReLU(), nn.Dropout(dropout),
            ) for name, joints in self.GROUPS.items()
        })
        # 跨组融合
        self.fusion = nn.Sequential(
            CausalConv1d(32*6, channels[0], 3, dilation=2),
            nn.BatchNorm1d(channels[0]), nn.ReLU(), nn.Dropout(dropout),
        )
        # 后续TCN层
        self.tcn = nn.Sequential(*[
            TCNBlock(channels[i], channels[i+1], 3, dilation=2**(i+1), dropout=dropout)
            for i in range(len(channels)-1)
        ])
        self.head = nn.Linear(channels[-1], 1)
    
    def forward(self, x):
        # x: (B, T, 17, 3)
        group_features = []
        for name, joints in self.GROUPS.items():
            group_x = x[:, :, joints, :].flatten(2)  # (B, T, len(joints)*3)
            group_features.append(self.group_tcns[name](group_x.transpose(1, 2)))
        # 融合所有组
        fused = torch.cat(group_features, dim=1)  # (B, 32*6, T)
        h = self.fusion(fused)
        h = self.tcn(h)
        return self.head(h[:, :, -1]).squeeze(-1)
```

**预期收益**: 
- 参数量增加 ~0.05M (仍远低于20M限制)
- 精度提升 3-5% (保留关节空间关系)
- 可解释性提升 (可分析每个肢体组的贡献)

### 建议2: 【高优先级】分层推理架构

**当前问题**: 每帧都运行YOLO11n-pose，推理时间52.82ms P95

**改进方案**:
```
┌─────────────────────────────────────────────────────────┐
│                    分层推理 Pipeline                       │
├─────────────────────────────────────────────────────────┤
│ Layer 0: 物理规则快筛 (<1ms)                              │
│   - 垂直速度阈值                                          │
│   - 躯干角度变化率                                         │
│   - 快速排除明显非跌倒帧 (预期排除 60-70%)                   │
├─────────────────────────────────────────────────────────┤
│ Layer 1: 轻量TCN (仅关键关节, ~5ms)                       │
│   - 仅使用 5-6 个关键关节                                  │
│   - 小TCN (channels=(32,32))                              │
│   - 处理 Layer 0 不确定的帧 (预期 20-30%)                   │
├─────────────────────────────────────────────────────────┤
│ Layer 2: 完整YOLO+TCN (~50ms)                            │
│   - 仅在 Layer 1 高不确定时触发 (预期 5-10%)                │
│   - 完整17关节 + 大TCN                                     │
└─────────────────────────────────────────────────────────┘
```

**预期收益**:
- 平均推理时间: 0.65×1 + 0.25×5 + 0.1×50 ≈ **6.9ms** (vs 当前 52.82ms)
- 吞吐量提升 ~7.6×
- 精度损失 <1% (分层阈值可调)

### 建议3: 【中优先级】物理规则特征作为第二模态

**来源**: Multi-Modality Co-Learning (ACM MM 2024)

**当前问题**: 物理规则引擎和TCN是独立的，没有联合优化

**改进方案**: 将物理规则计算的特征（角度、速度、位置）作为"第二模态"与骨架序列一起输入TCN

```python
class MultiModalTCN(nn.Module):
    """骨架序列 + 物理规则特征 双模态TCN"""
    
    def __init__(self):
        super().__init__()
        # 模态1: 骨架序列
        self.skeleton_tcn = TCNBlock(51, 64, 3, dilation=1, dropout=0.2)
        # 模态2: 物理规则特征
        self.rule_tcn = TCNBlock(10, 32, 3, dilation=1, dropout=0.2)
        # 跨模态融合
        self.fusion = nn.Sequential(
            nn.Linear(64 + 32, 64),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(64, 1),
        )
    
    def forward(self, skeleton, rule_features):
        # skeleton: (B, T, 51), rule_features: (B, T, 10)
        s = self.skeleton_tcn(skeleton.transpose(1, 2))[:, :, -1]
        r = self.rule_tcn(rule_features.transpose(1, 2))[:, :, -1]
        return self.fusion(torch.cat([s, r], dim=-1)).squeeze(-1)
```

**物理规则特征 (10维)**:
- 躯干角度 (1D)
- 躯干角度变化率 (1D)
- 头部垂直速度 (1D)
- 髋部垂直速度 (1D)
- 膝部角度 (2D, 左右)
- 重心高度 (1D)
- 重心高度变化率 (1D)
- 关节加速度方差 (1D)
- 跌倒方向 (1D, 前/后/左/右)

**预期收益**:
- 利用已有的物理规则知识，增强TCN的判别能力
- 参数量增加极小 (~0.01M)
- 精度提升 2-4%

### 建议4: 【中优先级】关节注意力机制

**来源**: LST-AGCN (2026), AdaSGN (2021)

**当前问题**: 所有17个关节被同等对待，但跌倒检测中头部、髋部、膝部远比手腕、脚踝重要

**改进方案**:
```python
class JointAttention(nn.Module):
    """可学习的关节重要性权重"""
    
    def __init__(self, n_joints=17, embed_dim=16):
        super().__init__()
        self.joint_embed = nn.Embedding(n_joints, embed_dim)
        self.attention = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Linear(embed_dim // 2, 1),
            nn.Sigmoid(),
        )
    
    def forward(self, x):
        # x: (B, T, 17, 3)
        joint_ids = torch.arange(17, device=x.device)
        weights = self.attention(self.joint_embed(joint_ids))  # (17, 1)
        return x * weights.unsqueeze(0).unsqueeze(0)  # 广播加权
```

**预期收益**:
- 参数量增加 ~0.001M (极小)
- 可学习的关节重要性，比手动选择更优
- 可解释性：可视化哪些关节被重点关注

### 建议5: 【低优先级】知识蒸馏压缩YOLO

**当前问题**: YOLO11n-pose (~3M) 是参数量的主要来源

**改进方案**:
1. 用YOLO11n-pose作为teacher
2. 训练一个更小的student模型 (如YOLO11s-pose或自定义轻量模型)
3. 在关键点预测任务上蒸馏

**预期收益**:
- 参数量: 3M → 1-1.5M
- 推理时间: 减少 30-50%
- 精度损失: 1-3%

**注意**: 这需要重新训练YOLO，工作量较大，建议在竞赛结束后考虑

### 建议6: 【低优先级】图卷积替代TCN

**来源**: ST-GCN, TSGCNeXt

**当前问题**: TCN将关节展平为向量，丢失了图结构信息

**改进方案**: 用轻量图卷积网络替代TCN
- 节点: 17个关节
- 边: 骨骼连接
- 时序: 在图卷积后加时序卷积

**预期收益**:
- 更自然地建模人体结构
- 精度提升 3-6%
- 但参数量和计算量会增加，需要权衡

**注意**: 这是较大改动，建议作为竞赛后的优化方向

---

## 六、实施优先级矩阵

| 建议 | 精度提升 | 实施难度 | 参数增加 | 推荐优先级 |
|------|----------|----------|----------|------------|
| 拓扑感知输入 + 关节注意力 | +3-5% | ★★☆ | +0.05M | 🔴 立即实施 |
| 分层推理架构 | +0-1% (速度↑7.6×) | ★★☆ | +0 | 🔴 立即实施 |
| 物理规则特征作为第二模态 | +2-4% | ★★☆ | +0.01M | 🟡 Gate 3-4 期间 |
| 关节注意力机制 | +1-3% | ★☆☆ | +0.001M | 🟡 Gate 3-4 期间 |
| 知识蒸馏压缩YOLO | -1-3% (压缩) | ★★☆ | -1.5M | 🟢 竞赛后 |
| 图卷积替代TCN | +3-6% | ★★★ | +0.5M | 🟢 竞赛后 |

---

## 七、推荐的竞赛期间架构路线

### Phase 1: Gate 3-4 (当前阶段)
1. ✅ 实现**拓扑感知输入**替代扁平化
2. ✅ 实现**关节注意力机制**
3. ✅ 将物理规则特征作为**第二模态**融合到TCN

### Phase 2: Gate 5-6 (训练阶段)
4. ✅ 实现**分层推理架构**，优化推理速度
5. ✅ 使用蒸馏或集成方法提升精度

### Phase 3: Gate 7-8 (提交阶段)
6. ✅ 模型压缩和优化
7. ✅ 最终性能调优

---

## 八、参考文献

1. Topology-aware CNN for Efficient Skeleton-based Action Recognition, AAAI 2021
2. AdaSGN: Adapting Joint Number and Model Size for Efficient Skeleton-Based Action Recognition, ICCV 2021
3. Multi-Modality Co-Learning for Efficient Skeleton-based Action Recognition, ACM MM 2024
4. TSGCNeXt: Dynamic-Static Multi-graph Convolution for efficient skeleton-based action recognition, Expert Sys. App. 2025
5. LST-AGCN: A Novel Unified Lightweight Attention Framework for Efficient Skeleton-Based Action Recognition, Big Data & CC 2026
6. Efficient Skeleton-Based Action Recognition for Real-Time Embedded Systems, 2024
7. CoDAT: Collaborative Dual-Attention Transformer with Low-Cost Temporal Modeling for Efficient Edge Action Recognition, arXiv 2026
8. Real-time human activity recognition on edge microcontrollers, Measurement 2026
9. Lightweight HPE for Edge Computing-Enabled Metaverse, arXiv 2024
10. ST-GCN: Spatial Temporal Graph Convolutional Networks for Skeleton-Based Action Recognition, AAAI 2018
