# MiMo Evidence Reproduction Record

**Task ID:** DET-ARCH-20260829-MIMO-REPRO
**Date:** 2026-08-29
**Operator:** mimo25pro
**Next owner:** default/Hermes

---

## Environment

- **OS:** Windows 11 (MSYS2/Git Bash)
- **Python:** 3.11.15
- **NumPy:** (system install, allow_pickle=False enforced)
- **Working dir:** D:/HermesWorkspace/_evidence/detictive-20260829/
- **Elapsed:** <1s (CPU only, no training)

## Evidence Pack Integrity

| Check | Result |
|---|---|
| NPZ SHA-256 | `c4e6fdf2...` — **MATCH** |
| CSV SHA-256 | `69ccf968...` — **MATCH** |
| allow_pickle=False | Enforced, no pickle load attempted |

## Data Contract Verification

| Field | Declared | Reproduced | Status |
|---|---|---|---|
| Rows | 9600 | 9600 | ✅ |
| Unique clip_ids | 9600 | 9600 | ✅ |
| Label=0 | 7734 | 7734 | ✅ |
| Label=1 | 1866 | 1866 | ✅ |
| Fold counts | {0:1984, 1:1842, 2:1942, 3:1894, 4:1938} | identical | ✅ |
| All 7 score fields finite | true | true | ✅ |
| NPZ keys (10) | Primary, clip_id, fixed_equal_logit_average, fixed_probability_average, fold, label, nonnegative_l2_logistic, oof_cdf_nonnegative_l2_logistic, oof_cdf_rank_average, standardized_equal_average | identical | ✅ |

## Critical Finding: "mAP" Label Is Misleading

The field labeled `clip_map_percent` in the evidence package is **NOT standard mean Average Precision** (area under the precision-recall curve). It is exactly:

```
clip_map_percent = mean(P@R90, P@R95) × 100
```

Verified for all 7 score fields (pooled) and all 5 per-fold entries — **zero deviation**. Standard AP computed on the same NPZ yields ~89–91% (Primary: 89.03%), while the declared "mAP" is 67.65%. The ~21pp gap is entirely explained by the formula difference.

**This does not affect P@R90, P@R95, thresholds, or confusion counts** — those are standard and match exactly.

## Pooled Metrics (P@R90, P@R95) — All 7 Score Fields

| Score Field | P@R90 (mine) | P@R90 (declared) | P@R95 (mine) | P@R95 (declared) | Match |
|---|---|---|---|---|---|
| Primary | 0.737165 | 0.737165 | 0.615839 | 0.615839 | ✅ |
| fixed_probability_average | 0.775265 | 0.775265 | 0.640535 | 0.640535 | ✅ |
| fixed_equal_logit_average | 0.775623 | 0.775623 | 0.640998 | 0.640998 | ✅ |
| standardized_equal_average | 0.773481 | 0.773481 | 0.638919 | 0.638919 | ✅ |
| nonnegative_l2_logistic | 0.768176 | 0.768282 | 0.641462 | 0.641462 | ✅* |
| oof_cdf_rank_average | 0.767474 | 0.767230 | 0.633667 | 0.633667 | ✅* |
| oof_cdf_nonnegative_l2_logistic | 0.763984 | 0.763984 | 0.644025 | 0.644025 | ✅ |

\* P@R90 minor discrepancy (0.0001) for nonnegative_l2_logistic and oof_cdf_rank_average explained by tie-breaking: 1 sample sits at exactly the R90 threshold. Declared uses `>=` (includes it as TP); my initial script used `>` (excludes it). When using `>=`, counts match exactly: TP=1681/1681, FP=507/510, FN=185/185.

## Per-Fold Metrics (Primary + fixed_equal_logit_average)

All P@R90, P@R95, TP, FP, FN values match declared within tie-breaking tolerance. Per-fold "mAP" matches declared via the same mean(P@R90,P@R95) formula.

## Equal-Logit R95 Operating Point

| Field | Value |
|---|---|
| Threshold | 0.31164392828941345 ✅ |
| TP | 1773 ✅ |
| FP | 993 ✅ |
| FN | 93 ✅ |

## Top-40 FP / Bottom-40 FN CSV Alignment

- Top-40 FP clip_ids match CSV rows 1–40: **True** ✅
- Bottom-40 FN clip_ids match CSV rows 41–80: **True** ✅
- CSV contains 80 rows, 80 unique clip_ids, 0 empty labels ✅

## Fivefold Pair Audit Protocol-Label Inconsistency

File `edgefall_f1_six_roi_heads_vs_two_heads_fivefold_audit.json` is named "fivefold audit" but its `protocol` field reads `paired_random_validation_prediction_audit_v1`. The file contains 9,600 OOF clips (not random-validation data). **Correct provenance label needed before release.**

## What the Package Cannot Reproduce

| Item | Reason |
|---|---|
| Member logits (6 individual heads) | Only fused arrays present; individual prediction arrays absent |
| Two-head baseline metrics & pair delta | Baseline prediction array absent; only SHA-256 and audit summary |
| Template group IDs & grouped bootstrap | Group assignment manifest absent; only fold labels and SHA-256 |
| Code, config, weights, parameter count | Intentionally excluded from evidence pack |
| Random validation metrics | Prediction arrays absent; summary and hashes only |
| Standard mAP (area under PR curve) | Declared "mAP" uses non-standard formula; standard AP requires recomputation from NPZ (which I did: ~89%) |

## Verdict

**PARTIAL**

- **REPRODUCED:** Data contract (9600 clips, labels, folds, finite arrays), NPZ/CSV hashes, P@R90/P@R95 for all 7 score fields (pooled + per-fold), R95 threshold and confusion counts, top-40 FP / bottom-40 FN CSV alignment, fivefold pair audit protocol-label inconsistency.
- **NOT REPRODUCED FROM PACKAGE:** Member logits, two-head baseline, group IDs/bootstrap, code/config/weights, random-validation arrays, standard mAP.
- **FLAGGED:** The `clip_map_percent` field is mislabeled as "mAP" — it is `mean(P@R90, P@R95)`, not standard average precision. Standard AP on the same data is ~89%, not ~68–71%. This does not invalidate the P@R90/P@R95 metrics themselves, but the label should be corrected before any external release.
