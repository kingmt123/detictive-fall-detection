# DET-D48-R6 Terra 当前最终 Lane-B 审计

日期：2026-08-29  
任务 ID：`DET-D48-R6-TERRA-CURRENT-FINAL`  
审计角色：gpt5-6terra / Lane-B  
审计性质：只读证据、可比性、泄漏、指标、fold 异质性与执行风险审计。除覆盖本审计文件外，未修改主报告、代码、配置或实验工件；未训练，未访问 OF-Syn sealed test、URFD test 或 random-validation。

## 1. 输入与字节身份

| 输入 | 本机复算 SHA-256 | 结果 |
|---|---|---|
| `2026-08-29_seven_head_dense48_deep_architecture_and_fusion_report.md` | `44290f607113759acbd89a5eafe64d009d0592229f7c0af02f3e96c0166e6152` | 与指定值一致 |
| `2026-08-29_dense48_r6_sources.json` | `1e342e1e3503e8c2413cfc596213fffca4d6360ed5b792277e3a29ecb96e790b` | 与指定值一致；账本含 41 条来源 |
| `2026-08-29-dense48-and-confidence-part-roi.md` | `25dabbcd73c00c9536125bb86b805aaff736d7649a44fee5dae630aaf15f993e` | 与主报告记录一致 |

本结论仅绑定上述字节身份。工作树原有大量已修改/未跟踪内容；本审计不把它们视为本次生成物，也未清理、覆盖或据此扩大结论。

## 2. 七头证据、可比性与 fold 异质性

1. 六头与七头比较使用同一五折 template-grouped OOF、相同 9,600 个 held-out clip 身份；dense fold map 与旧 map 严格配对。主报告在 R6:6、R6:52、R6:89–95、R6:603–606 明确协议和重建门，实验记录在 S1:63–76 给出窗口覆盖与 assignment 一致性。该比较适合作为当前研究序列内的配对 OOF 选择证据。
2. 七头 pooled OOF 为 `72.166/78.762/65.570`，相对六头为 `+1.335/+1.200/+1.470`。逐折 mAP* 差值为 `+0.648/+0.500/-0.456/+2.375/+0.234`，即 4/5 folds 改善、fold-2 回退、最大收益集中于 fold-3；fold-3 改善后仍是最弱 fold。报告同时说明 pooled 指标不是逐折简单平均（R6:294–322），措辞准确，没有把 fold-3 局部补强外推成普遍长时序优势（R6:976）。
3. paired template-group bootstrap 的 mAP* 95% CI 为 `[+0.055,+2.333]`，而 P90、P95 分别为 `[-0.028,+2.095]`、`[-0.603,+3.417]`，均跨零（R6:310–320；S1:95–103）。报告明确限制为“综合分数改善、单工作点尚未稳定显著”，没有宣称每折或每个工作点稳定占优。

## 3. 连续选择偏差与声明边界

1. Dense48 是同一持续研究序列中筛选出的成员；当前 9,600-clip OOF 因而只能支持 **selection-conditional research incumbent**，不能充当独立确认。报告已承认 Dense 来自同一研究序列（R6:70），说明七头尚未经过独立确认集检验且 random-validation 未确认（R6:40、R6:419），并明确现有 OOF 不能同时作为新融合的最终确认集（R6:1083）。
2. 因此，报告中的“当前最佳”“已验证 incumbent”“证明有效”必须绑定解释为：在已执行的 train-only、template-grouped OOF 研究序列内获得完整配对结果；它不表示无选择偏差的泛化确认。结合 R6:8、R6:99–103、R6:1241–1253 的权限与研究 anchor 限定，全文未冒充独立确认，也未授权 test、训练、部署或发布。
3. 缺少新的独立融合输出不构成交付阻断：R6 没有把 RMPTS 或其他未执行路线写成已观察到的提升（R6:1253）。

## 4. RMPTS、泄漏控制与执行唯一性

1. RMPTS 固定 320 family 总质量 `4/7`、640 family 总质量 `3/7`，只在 320 短窗与 Dense48 之间移动一个预注册 `delta`；七维非负 stacking 有 6 个有效权重自由度。故“RMPTS 更低方差”成立于结构性含义——自由度更低、seed 对称且不同时重估分辨率质量——不是已经由新实验验证的经验结论（R6:1033–1062、R6:1101–1108）。
2. 正式比较被严格限定为完整 nested template-grouped protocol：每个 outer fold 的七个基础成员、缓存和 fold map 均在 outer-train 内重新形成 inner grouped OOF；inner 只选预注册 delta；outer holdout 从基础成员训练、Dense 准入、融合和阈值选择中隔离；五个 outer holdout 只在最后拼接报告（R6:1066–1079）。仅复用现有 base OOF 再调 delta 不被允许。
3. 执行者自由裁量已被充分收窄：五点 delta 网格固定；P90/P95 先做硬护栏；paired template-group bootstrap 固定 2,000 draws 与种子；one-SE 明确比较“inner 最优 delta − 候选 delta”并取较小 `|delta|`；至少 4/5 outer-fold `delta_k` 严格同号，否则回退零；相同 `|delta|` 的异号候选依次按 inner P95、inner P90、负 delta 决胜；最终取 fold 中位数且禁止在 pooled outer OOF 上重搜（R6:1046–1058、R6:1070–1076）。
4. 候选与零基线分别用同一冻结 evaluator 确定 R95 工作点，复用 `recall≥0.95`、score tie 和整组同分样本政策；evaluator、fold map、clip universe、聚合器、网格、bootstrap 实现和随机种子必须在读取结果前记录 SHA-256（R6:1077–1078）。这足以作为未来执行卡的前置约束；实际预哈希清单尚未生成，因为本次未获准执行 RMPTS。
5. 晋级还要求 pooled mAP* 的 paired CI 下界大于零、P90/P95 均不降、至少 4/5 folds mAP* 非负、单 fold 回退不超过 0.5 点、fold-2 不再发生未解释恶化、R95 unique rescue 多于 introduced errors，并重定候选阈值（R6:1087–1097）。RMPTS 当前仍只是候选。

## 5. 指标审计

`mAP* = (P@R90 + P@R95)/2` 是项目自定义综合分数，不是标准 Average Precision；报告在首次展示结果时即明确披露（R6:20–26）。P90、P95 没有被 mAP* 平均掩盖：二者是 inner 选 delta、outer 晋级和统一候选评估的独立硬护栏，任何一项下降均不得晋级（R6:1071、R6:1090、R6:1097、R6:1235）。指标命名和决策语义合格。

## 6. 路线依赖、停止门与执行风险

1. **Track-first：比例适当。** 先做 top-2/oracle 无训练 replay；oracle 不能恢复严重 FN 即停止，只有 oracle 阳性而确定性规则不足才考虑小模型；同时审计旁人劫持、跨人历史污染和延迟（R6:1123–1137、R6:1227–1228、R6:1257–1261）。这优先处理七头共享上游错误，而非盲加分类头。
2. **Phase-Motion：依赖充分。** 仅当 actor 正确、48 帧内转移可见但仍漏检时启动；直接读取低维原始运动量，一换一而不加第八头；高相关、无 unique rescue 或 P95 下降即停止（R6:1139–1151、R6:1229、R6:1261）。
3. **长 ROI 与 support/controlledness：后置合理。** Dense 事件帧 ROI 首轮只复用既有缓存，不得同时改分辨率、part、attention 和 loss；支撑/受控性必须先证明像素可观察、双人标注一致且 slow/partial fall 召回不降（R6:1153–1168、R6:1230–1231、R6:1262）。
4. **超过 48 帧 memory：停止门充分。** 只服务于同一 actor 连续、transition 曾可见但已离开 48 帧的样本；只允许正向证据并在切轨/长缺失时 reset；若只是重复 clip-max、片段缺少早期事件或产生滞留 FP 即停止，不升级大型 SSM/Transformer（R6:1170–1174、R6:1232、R6:1263）。
5. **Stream buffer 与部署：权限隔离清楚。** 只允许输入 ring buffer、ROI 复用、批调度和经过等价验证的因果状态缓存；共享 e16/e48 参数/hidden state、未经重评的量化和近似缓存均被禁止。近似实现必须重新跑完整 OOF；部署仍需目标硬件全链路 P95、资源和逐 clip 在线/离线一致性门（R6:1180–1217、R6:1233）。报告交付不等于这些部署门已经关闭。

## 7. Lane-B 最终裁决

**PASS**

批准范围仅为：上述哈希绑定 R6 报告可作为研究结论、架构指导和未来预注册执行协议交付给下一 owner。该裁决不宣称 RMPTS 成功，不批准任何训练或预算，不批准访问 OF-Syn sealed test、URFD test 或 random-validation，不批准部署、发布、竞赛提交或外部传播。
