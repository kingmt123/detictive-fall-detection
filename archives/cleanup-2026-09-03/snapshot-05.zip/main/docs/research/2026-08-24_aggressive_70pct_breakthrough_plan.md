# Detictive 70% 瓶颈突破：激进模型改进与实验路线

> 日期：2026-08-24  
> 范围：`MultiStreamMultiScaleAttentionTCN` + top-k MIL + 冻结 validation 评测  
> 目标：提出能够改变当前性能上限的高风险高收益方案，而不是继续小幅堆叠流、通道或手工规则  
> 重要边界：文中收益区间是实验优先级假设，不是结果承诺；sealed test 不得用于任何选择

## 1. 执行摘要

当前约 70% 的平台期更像是**目标函数、时序监督和数据域错配共同形成的上限**，而不是模型参数量不足。

最关键的代码事实：

1. 训练时，clip 分数是窗口 logit 的 top-k 20% 均值；验证时，clip 分数却是窗口概率最大值。训练和评测使用了不同的聚合器。
2. 最终指标是 P@R90 与 P@R95 的均值，但训练仍以窗口 BCE + clip BCE 为主，没有直接优化高召回区域的排序质量。
3. `fall` 与 `lie_down/lying/stand_up` 共享一个二分类头；已有 hard-negative ranking 实验只做了全局 pairwise margin，未把“受控下降”和“失控跌倒”建模为独立条件任务。
4. 当前窗口仅 16 帧，编码器最终只读取每流最后时刻表示；完整的“直立→快速下降/旋转→冲击/静止”阶段跨度容易超过单窗口。
5. 当前三 seed 配置只启用轻微 pose jitter；关节连续遮挡、左右互换、帧丢失、track 断裂、bbox 抖动等真实姿态估计错误没有进入训练分布。
6. 当前融合主要是各流 embedding 拼接 + SE，再接线性分类器；它能累积证据，却不会显式判断哪一段是候选事件、哪一段是受控过渡。

因此推荐的主路线是：

> **高召回候选生成器 → 事件片段/阶段建模 → fall-vs-controlled-transition 专用验证器 → P@R90/P@R95 对齐排序目标 → 多 seed OOF 校准。**

并行的激进路线是：使用 PoseConv3D/视频教师在训练期提供时空语义，再蒸馏回当前轻量骨架模型。这样可突破纯 2D 关键点的信息瓶颈，同时不增加最终部署模型体积。

## 2. 当前基线与瓶颈证据

### 2.1 可比较的已知结果

| 候选 | Validation mAP | P@R90 | P@R95 | 结论 |
|---|---:|---:|---:|---|
| Matched control | 69.6996% | 74.0741% | 65.3251% | 当前可靠控制组 |
| Hard-negative ranking | 69.8824% | 72.9927% | 66.7722% | mAP 小升但 P@R90 降，新增 2 个 `lie_down` FP；已拒绝 |
| Joint-only Transformer reference | 70.2288% | 73.2601% | 67.1975% | 单模型已知最高参考，但仍在约 70% 平台 |
| G2 residual-STGCN + stage auxiliary | 尚未运行 | — | — | 已预注册；不得在观察结果后静默改参 |

注意：历史 checkpoint 的 69.6307% 缺少原始 manifest/split hash，只能作来源记录，不能作为严格横向基线。

### 2.2 训练—评测聚合器错位

训练器：

```python
clip_logit = mean(top_k(window_logits, ceil(0.2 * n_windows)))
```

评测器：

```python
clip_score = max(window_probabilities)
```

这会产生两种坏激励：

- 训练希望一批高分窗口共同抬高均值，评测却只关心最高的一个窗口；
- 对负样本而言，只要一个 `lie_down` 窗口形成尖峰，评测就会产生 FP，但 top-k 均值可能掩盖这个尖峰。

这正好解释了为什么 hard-negative ranking 改善 P@R95、却损伤 P@R90：它改变了全局排序，但没有直接压制负 clip 的最大尖峰。

### 2.3 指标错位

比赛目标不是平均准确率，也不是普通 BCE，而是高召回区域的精度。Eban 等人的非可分解目标研究明确指出，当评测使用 precision at fixed recall、PR-AUC 等排序指标时，直接优化相应替代目标通常比希望 BCE 间接改善指标更合理；后续工作也给出了可扩展的 AUPRC 随机优化方法。

当前损失：

```text
L = L_window_BCE + 0.5 L_clip_BCE + 0.2 L_stage
```

它没有表达以下目标：

```text
在 recall >= 0.90/0.95 的阈值区域，尽量让最难负 clip 的最大分数低于正 clip。
```

### 2.4 标准 MIL 忽略事件结构

弱监督时序定位文献反复指出，标准 top-k MIL 会偏向少数最显著片段，并忽略动作完整性、边界和片段内结构。ASM-Loc、CoLA、FTCL、PivoTAL 分别通过 segment modeling、边界困难片段对比、细粒度序列对比和先验引导监督缓解这一问题。

这与当前跌倒任务高度吻合：`fall` 和 `lie_down` 的最终姿态接近，区分信息主要存在于过渡速度、冲击前后与恢复阶段，而不是某个孤立的最高分窗口。

### 2.5 纯关键点的信息上限

OmniFall 的 staged-to-wild 设计本身强调跨背景、视角、域和真实事故场景的性能落差。当前网络只消费 2D pose、confidence 和 bbox 派生量；当 pose extractor 已经把遮挡、人与床/椅接触、支撑动作等信息丢掉后，后端再增加 TCN/GCN 容量无法恢复这些信息。

## 3. 激进方案 A：指标对齐的两阶段事件级模型

### 3.1 架构

```text
窗口序列
   ↓
共享多流编码器
   ├─ 候选头：高召回 fall-transition actionness
   ├─ 阶段头：pre / transition / post-fall / controlled / background
   └─ 验证头：仅对候选片段判断 uncontrolled fall vs controlled transition
                    ↓
          event score + calibrated uncertainty
```

第一阶段只追求 recall，第二阶段专门压制 `lie_down/lying/stand_up/sit_down`。这比让一个二分类头同时学习“是否发生事件”和“事件性质”更容易优化。

### 3.2 聚合器改造

用温度可控的 LogSumExp 代替固定 top-k，并使训练/验证一致：

```text
s_clip = tau * logsumexp(s_window / tau)
```

- 训练初期使用较大 `tau`，让多个窗口获得梯度；
- 后期逐步降低 `tau`，逼近评测 max；
- 对负 clip 增加 `max-spike penalty`，直接惩罚最高分窗口；
- 最终评测仍使用同一聚合规则，或者明确冻结到 `tau→0` 的 max 近似。

同时加入事件完整性约束：候选分数应呈现连续片段，而不是单帧/单窗口尖峰。

### 3.3 指标对齐损失

建议使用三部分：

```text
L_total = L_stage
        + lambda_event * L_event_BCE
        + lambda_rank * L_high_recall_rank
        + lambda_pr * L_AUPRC_surrogate
        + lambda_tv * L_temporal_consistency
```

其中：

- `L_high_recall_rank`：在每个 batch/跨 batch memory bank 中，优先比较低分正样本与高分 hard negative；
- `L_AUPRC_surrogate`：只作用于 clip/event score，避免在所有窗口上引入不稳定的全局目标；
- `L_temporal_consistency`：抑制负 clip 的孤立尖峰，同时保留真实跌倒的连续事件段；
- 不再使用当前“所有正 clip × 所有 hard negative”的平均 margin，它会被大量容易 pair 稀释。

更直接的实现是维护两个可微分约束：

```text
soft_recall(th90) >= 0.90
soft_recall(th95) >= 0.95
```

然后最小化两个阈值处的 soft false positives。该方案风险较高，但它与比赛指标最一致。

### 3.4 专用受控过渡验证器

将验证头训练成四类或层级任务：

1. uncontrolled fall；
2. controlled lie/sit down；
3. reverse transition / stand up；
4. stationary lying/background。

最终 fall logit 可写为：

```text
fall_score = candidate_score
           + verifier_fall_logit
           - logsumexp(controlled, reverse, stationary)
```

这比在输入端继续添加更多物理流更激进，因为它直接重构了决策边界。ACCV 2024 的 class-aware contrastive learning表明，对细粒度相似动作，优先选择相似类别作为困难负样本并利用跨序列 memory bank，是合理的迁移方向。

### 3.5 代码落点

- `models/multiscale_multistream_tcn.py`
  - 暴露每个窗口的 fused embedding，而不是只返回最后时刻；
  - 新增 `candidate_head`、`verifier_head` 和连续事件段输出；
  - 将固定 `flatten + SE` 扩展为候选条件下的 cross-stream attention。
- `models/train_multiscale_multistream_mil.py`
  - 统一训练/评测聚合器；
  - 增加跨 batch hard-negative memory bank；
  - 单独记录 active hard pairs、max-negative score、positive 10th percentile、P@R90/P@R95 surrogate。
- `tools/train_tcn.py`
  - 评测聚合逻辑与训练严格共享同一函数；
  - 输出按 activity、domain、camera 的 FP 分解。

### 3.6 实验门槛

| Gate | 运行范围 | 通过条件 | 停损条件 |
|---|---|---|---|
| A0 聚合器一致性 | 单 seed、短训练 | 相同 checkpoint 的 train/eval 聚合结果一致 | 任一 clip 分数出现实现差异 |
| A1 metric loss canary | 单 seed、冻结 val | mAP ≥ control +0.5pp，且 P@R90 不下降 | 只改善 P@R95、P@R90 下降 ≥0.5pp |
| A2 verifier | 三 seed | mean mAP ≥ control +2pp；`lie_down` FP 至少下降 20% | 召回损失导致 FN 增加 >2% |

规划假设：如果 70% 平台主要由目标错位造成，A 路线有机会贡献 **+2～5pp mAP**。这是待验证假设，不应与论文跨数据集结果直接类比。

## 4. 激进方案 B：重型教师、轻量学生的跨模态蒸馏

### 4.1 为什么值得做

PoseConv3D 使用关键点热图体而不是坐标序列，并报告了对 pose noise 和跨数据集泛化的优势。它不适合作为当前低算力最终模型，但非常适合作为离线教师。

建议训练三个教师之一：

- PoseConv3D teacher：输入 pose heatmap volume，保留空间不确定性；
- RGB/VideoMAE teacher：输入候选事件附近 RGB clip，获得人与床/椅/地面的交互语义；
- 双教师：pose heatmap teacher + RGB teacher，学生只保留当前多流骨架输入。

### 4.2 蒸馏目标

```text
L_student = L_supervised
          + alpha * KL(student_event_logits, teacher_event_logits / T)
          + beta  * cosine(student_embedding, projected_teacher_embedding)
          + gamma * boundary_distillation
```

关键不是蒸馏所有样本，而是只强化：

- teacher 高置信、student 错误的 `lie_down/lying/stand_up`；
- pose confidence 低、遮挡严重的样本；
- teacher 能看到支撑物/接触关系、学生看不到的样本。

对 teacher/student 冲突样本保留 uncertainty mask，避免把教师域偏差硬灌给学生。

### 4.3 预期收益与代价

- 部署参数量基本不变；
- 训练成本显著上升，需要重新读取 RGB 或生成 pose heatmap；
- 若视觉上下文是主要缺失信息，规划假设为 **+2～6pp mAP**；
- 若 teacher 在 OF-Syn 上过拟合背景，蒸馏会放大域偏差，因此必须按 domain/camera 做审计。

该路线优先级高于“再加一层 GCN”，因为它向学生引入了当前输入中不存在的信息。

## 5. 激进方案 C：真实错误分布增强 + 域鲁棒训练

### 5.1 将 jitter 升级为 pose-corruption simulator

WACV 2024 的现实姿态错误增强在真实场景骨架识别上报告了最高 +4.63 accuracy 的改善。当前模型的独立高斯 jitter 不能覆盖 pose estimator 的结构性错误。

建议按真实失败模式建立增强组合：

| 错误类型 | 模拟方式 |
|---|---|
| 连续遮挡 | 随机身体区域在连续 3～12 帧 confidence 置零 |
| 左右互换 | 成对交换左右肩/肘/腕或髋/膝/踝，并同步 confidence |
| track 断裂 | 插入短缺失区间，恢复后产生坐标偏移 |
| bbox 抖动 | 低频漂移 + 偶发跳变，而非逐帧独立噪声 |
| 帧率变化 | piecewise time warp、frame drop、重复帧 |
| 关键点粘连 | 多个末端关节向同一点收缩，模拟遮挡误检 |
| 视角变化 | 保持骨长约束的仿射/透视扰动 |

增强强度应从真实 cache 统计估计：先测量 confidence run length、左右跳变率、bbox acceleration 尾部分布，再拟合增强参数，禁止凭感觉扩大噪声。

### 5.2 域条件鲁棒性

OmniFall 明确展示 staged/synthetic-to-wild 泛化问题。当前 train 中 OF-Syn 9,600 与 URFD 70 极度不平衡，简单混合会让真实域梯度被合成域淹没。

建议：

- domain-balanced batch：每批固定真实/合成比例；
- domain-specific normalization 或小型 adapter，共享主体编码器；
- label-conditional CORAL/MMD：分别对 fall 和 controlled transition 对齐，而不是全局对齐；
- GroupDRO：按 camera/environment/activity 分组优化最差组；
- 将 domain classifier 作为诊断：若 embedding 可轻易识别 synthetic/real，说明域信息仍主导表示。

规划假设：真实错误增强与域平衡训练合计 **+1～4pp mAP**，主要价值是降低跨域方差，而非保证单一 val 峰值。

## 6. 激进方案 D：多尺度阶段记忆，而不是继续固定 16 帧

### 6.1 问题

16 帧约覆盖 0.5 秒；不同视频帧率、动作速度和事件阶段可能使同一窗口只看到最终姿态或部分下降。固定窗口还会把快速跌倒与缓慢躺下压缩成相似局部轨迹。

### 6.2 方案

保留因果部署约束，增加三个时间尺度：

```text
短尺度 8～16 帧：冲击、速度峰值、姿态突变
中尺度 24～32 帧：完整下降/旋转过程
长尺度 48～64 帧：起始姿态与跌倒后恢复/静止
```

不要复制三套完整 encoder；使用共享底层特征 + 三个 dilated temporal pooling head，再由 candidate score 条件融合。

同时加入 phase-order loss：

```text
pre-fall → transition → post-fall
controlled-pre → controlled-transition → stable-lying
```

自监督 skeleton 研究表明，速度变化的一致性与人为打断的运动连续性可以成为有效监督信号。可在全部未使用标签的窗口上预训练“正常时序 vs motion-broken”判别，再微调跌倒任务。

规划假设：**+1～3pp mAP**；若 32/64 帧没有改善 `lie_down` 分离度，应立即停止，不继续扩大 Transformer。

## 7. 集成与校准：将模型多样性变成收益

现有三 seed 配置的价值不是分别挑最高点，而是形成 OOF 多样性：

1. 每个 seed 保存完整 per-clip/per-window OOF logits；
2. 只在 train OOF 上拟合受约束的非负融合权重；
3. 对 rule、TCN、residual-STGCN、teacher-distilled student 分别计算错误交集；
4. 只有错误互补的模型进入融合；高度相关模型不因单模型 mAP 高就加入；
5. 使用温度缩放或 isotonic calibration 时，校准数据必须来自 OOF，不得重复使用最终 frozen val 调参。

优先尝试 `max-recall preserving blend`：限制融合后正样本 5th/10th percentile 不下降，再优化 hard-negative 排序。规划假设为 **+1～3pp mAP**，但高度依赖模型错误互补性。

## 8. 不推荐继续投入的方向

### 8.1 继续增加普通流

joint、bone、motion、geometry、rule、kinematics 已高度相关。增加派生流会增加参数和过拟合机会，但不增加新的观测信息。

### 8.2 单纯把 ST-GCN 替换得更复杂

InfoGCN/CTR-GCN 等动态图方法在大规模 skeleton action recognition 上有效，但当前瓶颈是细粒度二分类、高召回指标与域偏移。它们更适合作为教师或 residual 分支，而不是下一次唯一主赌注。

### 8.3 无选择的生成式数据扩增

生成骨架可能增加数量，却不一定增加真实 `fall↔lie_down` 边界信息。只有在生成样本通过动力学、pose estimator 和 domain classifier 三重审计后才值得加入。

### 8.4 在 frozen val 上反复调阈值

P@R90/P@R95 本身已在曲线上选择可行工作点。继续对同一 val 反复调超参数会迅速形成选择偏差，表面突破 70%，实际泛化不升。

## 9. 推荐实验顺序

### 第 0 阶段：完成已预注册 G2

保持 G2 决策卡不变，完成三 seed 或按既定 stop 条件停止。它提供 residual-STGCN + stage auxiliary 的干净证据，不能与后续激进方案混跑。

### 第 1 阶段：A 路线最小闭环（优先级最高）

1. 统一 train/eval clip aggregator；
2. 加 max-negative spike loss；
3. 增加受控过渡 verifier；
4. 输出 activity/domain 分解与完整 OOF。

预算：1～2 天；三 seed 前先做单 seed canary。

### 第 2 阶段：C + D

1. 从现有 pose cache 统计真实错误分布；
2. 加连续遮挡、左右互换、track gap、time warp；
3. 启用 16/32/64 共享多尺度阶段头；
4. 只保留通过预注册门槛的单一改动。

预算：1～2 天。

### 第 3 阶段：B 教师蒸馏

如果 A/C/D 后仍低于 74%～75%，启动 PoseConv3D 或 RGB teacher。先在 hard-negative 子集证明 teacher 明显优于 student，再决定是否全量蒸馏。

预算：2～4 天，GPU 成本最高。

### 第 4 阶段：OOF 融合与冻结

融合只使用 train OOF；frozen val 只做一次最终比较。若三 seed mean 和 worst-seed 都改善，再进入封存测试流程。

## 10. 建议的预注册主实验

### 实验代号：A3 Metric-Aligned Conditional Verifier

唯一组合变更：

- train/eval 共享 annealed LogSumExp 聚合器；
- candidate + controlled-transition verifier 双头；
- clip-level AUPRC surrogate 权重 0.1；
- hard-negative memory bank 只包含 `lie_down/lying/stand_up/sit_down`；
- 其他 backbone、数据、cache、split 与 G2 控制组保持一致。

主要成功条件：

- 三 seed mean validation mAP ≥ 74.0%；
- mean P@R90 ≥ 74.0%；
- mean P@R95 ≥ 70.0%；
- `lie_down` FP 相对 matched control 下降 ≥20%；
- worst seed mAP ≥ control mean；
- 参数量仍远低于 20M，完整端到端 P95 不超过 100ms。

失败条件：

- P@R90 下降，即使 mAP 上升也判失败；
- 改善只来自一个 seed；
- verifier 只压低所有分数并造成 recall 损失；
- hard-negative memory bank 的 active pairs 在多数 batch 为零；
- train/eval aggregator 或 split/hash 不一致。

## 11. 最终判断

如果只允许押一个方向，选择 **方案 A：指标对齐的两阶段事件级模型**。

原因不是它最潮，而是它直接针对当前实现中已经确认的三个矛盾：

1. top-k 训练与 max 评测不一致；
2. BCE 与 P@R90/P@R95 不一致；
3. 单一 fall 头与受控过渡细粒度判别不一致。

如果允许第二个高风险赌注，选择 **方案 B：PoseConv3D/RGB 教师蒸馏**。它是唯一能向轻量学生注入当前骨架坐标中不存在的信息、又不增加最终部署成本的方案。

## 12. 参考文献与依据

1. Schneider D, et al. *OmniFall: A Unified Staged-to-Wild Benchmark for Human Fall Detection*. 2025. [arXiv](https://arxiv.org/abs/2505.19889)
2. Eban E, et al. *Scalable Learning of Non-Decomposable Objectives*. AISTATS 2017. [PMLR](https://proceedings.mlr.press/v54/eban17a.html)
3. Qi Q, et al. *Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence*. NeurIPS 2021. [NeurIPS](https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html)
4. He B, et al. *ASM-Loc: Action-Aware Segment Modeling for Weakly-Supervised Temporal Action Localization*. CVPR 2022. [CVF](https://openaccess.thecvf.com/content/CVPR2022/html/He_ASM-Loc_Action-Aware_Segment_Modeling_for_Weakly-Supervised_Temporal_Action_Localization_CVPR_2022_paper.html)
5. Zhang C, et al. *CoLA: Weakly-Supervised Temporal Action Localization With Snippet Contrastive Learning*. CVPR 2021. [CVF](https://openaccess.thecvf.com/content/CVPR2021/html/Zhang_CoLA_Weakly-Supervised_Temporal_Action_Localization_With_Snippet_Contrastive_Learning_CVPR_2021_paper.html)
6. Gao J, et al. *Fine-Grained Temporal Contrastive Learning for Weakly-Supervised Temporal Action Localization*. CVPR 2022. [CVF](https://openaccess.thecvf.com/content/CVPR2022/html/Gao_Fine-Grained_Temporal_Contrastive_Learning_for_Weakly-Supervised_Temporal_Action_Localization_CVPR_2022_paper.html)
7. Rizve MN, et al. *PivoTAL: Prior-Driven Supervision for Weakly-Supervised Temporal Action Localization*. CVPR 2023. [CVF](https://openaccess.thecvf.com/content/CVPR2023/html/Rizve_PivoTAL_Prior-Driven_Supervision_for_Weakly-Supervised_Temporal_Action_Localization_CVPR_2023_paper.html)
8. Bian X, et al. *Class-Aware Contrastive Learning for Fine-Grained Skeleton-Based Action Recognition*. ACCV 2024. [CVF](https://openaccess.thecvf.com/content/ACCV2024/html/Bian_Class-Aware_Contrastive_Learning_for_Fine-Grained_Skeleton-Based_Action_Recognition_ACCV_2024_paper.html)
9. Duan H, et al. *Revisiting Skeleton-Based Action Recognition*. CVPR 2022. [CVF](https://openaccess.thecvf.com/content/CVPR2022/html/Duan_Revisiting_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html)
10. Cormier M, et al. *Enhancing Skeleton-Based Action Recognition in Real-World Scenarios Through Realistic Data Augmentation*. WACV Workshops 2024. [CVF](https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html)
11. Chi H, et al. *InfoGCN: Representation Learning for Human Skeleton-Based Action Recognition*. CVPR 2022. [CVF](https://openaccess.thecvf.com/content/CVPR2022/html/Chi_InfoGCN_Representation_Learning_for_Human_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html)
12. Su Y, et al. *Self-Supervised 3D Skeleton Action Representation Learning With Motion Consistency and Continuity*. ICCV 2021. [CVF](https://openaccess.thecvf.com/content/ICCV2021/html/Su_Self-Supervised_3D_Skeleton_Action_Representation_Learning_With_Motion_Consistency_and_ICCV_2021_paper.html)

## 13. 本地证据索引

- `models/multiscale_multistream_tcn.py`：多流编码、融合、stage/transition/physics 辅助头。
- `models/train_multiscale_multistream_mil.py`：top-k MIL、困难负例排序、stage targets 与训练损失。
- `tools/train_tcn.py`：validation 使用 clip 内窗口最大概率。
- `docs/handoffs/parallel_worker_20260824/2026-08-23-distilled-tcn-controlled-improvement-audit.md`：69.7% 控制组、ranking 拒绝结论。
- `docs/experiment_cards/2026-08-24_g2_residual_stgcn_training_card.md`：G2 三 seed 预注册协议。

## 14. 2026-08-24 证据校正与可执行修订（本节覆盖前文的预算、基线和实验顺序）

### 14.1 当前裁决：方向有价值，但 A3 不能按原组合直接开跑

**结论：REVISE，当前不授权 GPU、cache 或训练。**

问题不是“尚未达到 70%”，而是**已达到约 70% 后，受控改进长期只有 `0.0Xpp` 量级**：
matched control 为 `69.6996%`，hard-negative ranking 为 `69.8824%`，净增仅
`+0.1829pp`，同时 P@R90 从 `74.0741%` 降至 `72.9927%`、固定 hard FP 从 48 升到 50。
另有 `70.2288%` 的 joint-only Transformer 单模型参考。因此下一步不应再把“70%”本身
当作目标或门槛，而应寻找能在高召回 precision 上带来**可复制的、多百分点结构性增益**的
单一原因；小于预注册效应门的 `0.0Xpp` 波动一律不进入后续复杂路线。

本计划正确地发现了一个真实的实现不一致：训练中的 clip MIL 使用
`top-k` logit 均值，而当前验证 `evaluate_model()` 用窗口概率的 `max` 得到
clip 分数（`parallel_worker_20260824/tools/train_multiscale_multistream_mil.py:179-195`；
`parallel_worker_20260824/tools/train_tcn.py:312-320`）。这使“聚合器对齐”成为
值得验证的**单变量**假设。

但是，原 A3 同时替换聚合器、增加 candidate/verifier 双头、AUPRC surrogate、
memory bank 和新的 hard-negative 机制；即使结果变好，也无法归因。更严重的是，
Kanban 的基线审计已判定旧三流 `70.4708%` validation-once 和历史约 70% 数字
均不具备决策级 provenance：其 OOF 为 `58.9627%`，相差 `11.5081pp`，缺少可重算
per-clip predictions、源码/config、seed 与 fold→clip 映射。因此它们只能是历史候选
观测，不能作为 A3 的“control”或 74%/75% 的增益锚点。

同时，G2-R1 训练卡已经被 Terra **BLOCK**：它无法执行注册的三 seed、OF-Syn+URFD
组合数据和产物契约，且不存在同代码/同 split control。G2 未修订并通过零 GPU
dry-run 前，不能作为本计划第 0 阶段的前置证据，也不能与后续方案混跑。

### 14.2 需要收回或收紧的断言

| 原断言 | 校正后的表述与理由 |
|---|---|
| A 可带来 `+2～5pp` | 未测得。只保留“可能改善 max-spike 排序”的定性假设；在可比 OOF 上先用 `+1.0pp` paired gain 作为是否复制的 pilot 门。 |
| B 可带来 `+2～6pp` | 没有 teacher 在相同 split/hard-negative cohort 上优于学生的证据；在 E0/R0/M1 前不立项。它是后续、昂贵且可能放大 synthetic-domain shortcut 的研究选项。 |
| C+D 合计 `+1～4pp`/`+1～3pp` | 不可相加，也不能从跨数据集 accuracy 转换为本项目 high-recall clip metric。只保留为独立的、可停损候选。 |
| 当前三 seed 配置已启用“轻微 pose jitter” | 不正确：G2 config 的增强项均为 `0.0`。代码虽已有 jitter、joint dropout、flip、repeat-frame 与短 limb occlusion，但尚未有真实 cache 分布校准，也没有 track fragmentation/bbox drift 的已验证实现。 |
| 16 帧“只读最后时刻”必然丢失事件阶段 | 输入仍限制为 16 帧，但 `StreamEncoder` 在末时刻读取前已有因果 TCN 与 causal attention；这是“上下文长度可能不足”的假设，不是已证明的结构缺陷。先作长度消融，不能默认三套新 encoder。 |
| LogSumExp 可直接替换 max | 原始 `tau * logsumexp` 随窗口数增加约 `tau*log(n)`，会把 clip 长度混进分数。若以后验证软 max，必须使用长度归一的 `tau*logmeanexp`（或显式固定窗口数）、记录温度和 train/eval 的同一函数；首个聚合实验优先用真正的 `max`，避免该混杂。 |
| 2D pose acceleration 是“impact” | 仅可称 `visual_deceleration_proxy`；它不能证明人体与地面真实冲击。 |

### 14.3 Kanban 已确认的不可绕过前置门

1. **E0 evidence contract 是唯一已批准范围。**它必须 fail-closed 地冻结 config、
   manifest、clip list、fold、cache coverage、metric/source hashes、prediction units 和
   test seal；合成 prediction 的独立重算误差必须 `<=1e-6`。E0 的成功不表示性能提升。
2. **禁止 cache-availability 选样。**完整 train 的 clip list 和 strata quota 必须在 cache
   lookup 前冻结；缺失 cache 只能记录为失败，不能换成“当前可用”样本。
3. **repository val 隔离。**它已被多次查看；模型、temperature、threshold、融合权重、
   seed 和 early stopping 只能在 train 内 nested/cross-fitted OOF 完成。仅完全冻结的候选
   才能对 repository val 评一次，test 始终封存。
4. **当前证据优先级。**任何 70%/75% 的历史 validation 数字不得用于接受或拒绝候选；
   第一条可比较数字必须是新的 `reference_v2` 的 per-clip OOF 指标。
5. **指标语义待冻结。**当前是本地 clip-level proxy；在比赛官方 protocol 是否确为 clip
   classification 得到确认前，不能把任一 surrogate 损失称作“competition-aligned”。

### 14.4 修订后的最小鉴别序列

| Gate | 唯一改变 | 目的与通过门 | 明确 stop/rollback |
|---|---|---|---|
| E0 | 可复现、fail-closed 证据契约（CPU/IO） | Terra PASS；无训练/无 cache/无 val/test prediction | 任何 hash、unit、split、prediction completeness 或 test-seal 失败即停止。 |
| P0 / G2 | 先完成 P0 的冻结 source revision、标签/loader、cache/sidecar 和环境 closure；随后 G2 仅作为独立、预注册实验 | P0 不含 GPU；G2 只有在 scope 明确为可执行的 OF-Syn-only 或有签名的 9,670/1,214 combined reader 后，才可按原三 seed / 6 GPU-hours 运行 | G2 不得与 69.6996 当作因果对照，也不检验 aggregation 假设；任何 scope/hash/test/environment 问题即停止。 |
| A0 | **只**改为一个 pre-registered、长度归一的 shared LogSumExp 聚合器；训练和评测调用同一函数，温度/归一化仅由 train-only OOF 冻结 | 同 seed、init、data、schedule 的 G2 anchor 上 gain `>=+2.0pp`，P@R90/P@R95 均不降，fixed hard FP 从 48 降至 `<=38`，才扩至其余两 seed | 禁止 candidate/verifier、stage、max-spike、AUPRC、ranking、memory bank、augmentation、context、domain、calibration 和 fusion；任一门失败即结束 aggregation 路线。 |
| M1 | **只**增加版本化 `motion_dynamics_v2` 输入流；G、fold、loss、aggregation 固定 | cross-fitted G+M OOF pilot `>=+1.0pp`，P@R95 不降，`lie_down/lying/stand_up` FP@R90 下降 `>=10%` | M coefficient 非正、高相关/无增益、任一类 FP 增加 `>25%`，删除 M，不做动态融合。 |
| V1 | 仅在 A0 三 seed 通过后另立卡；若也使用 M1，M1 必须先独立通过。新增候选条件 verifier，标签必须从不可重叠的 event semantics 生成，并输出审计混淆矩阵 | candidate recall `>=95%`，固定 candidate 下 verifier 对 controlled FP 降 `>=20%`，并通过 monotonic/fallback test；随后才谈三 seed paired OOF | label audit、active-pair coverage、candidate recall 或 hard-negative coverage失败即停止。 |
| C1/D1 | 分别做 cache-measured corruption 或 16/32/64 context 的单变量 pilot | 只在对应 error slice 或长事件 slice 有预注册改善，才复制 | 禁止把增强、长度、loss、verifier同时变动。 |

所有 GPU gate 仍需：用户明确恢复、Sol 的逐门预算批准、MiMo 的可复现执行记录以及
Terra 的 `PASS / BLOCK / NEEDS-RERUN` 审计；本文件不构成训练授权。

其中，A0 的 score contract 必须同时以固定 logit fixture 和同一 checkpoint 的 window
logits 验证：train/eval 每个 clip 分数相等（或达到预注册数值容差），并明确只采用一种
logit/probability 顺序。不能仅用“一个 checkpoint 跑通”作为聚合器一致性的证据。

### 14.5 对方案 A 的工程化调整

- 当前 `MultiStreamMultiScaleAttentionTCN` 的各流 encoder 返回的是每个输入 window 的
  最后时刻 embedding（`models/multiscale_multistream_tcn.py:655-672`）。事件级 verifier
  需要明确的新 contract：保存/重算 **所有 window 的 fused embedding、candidate logit、
  clip_id、window offset、valid mask 与 label provenance**。先为该 contract 写单元测试和
  per-clip/window exporter；不能仅“暴露 embedding”后直接训练。
- 现有 hard-negative ranking 对 batch 内所有正×负 pair 求平均，且没有单独记录 active
  pairs（`parallel_worker_20260824/tools/train_multiscale_multistream_mil.py:198-217`；
  `2026-08-23-distilled-tcn-controlled-improvement-audit.md:40-42`）。在任何 memory bank
  前，先记录每 epoch 的 active clips/pairs、正例低分位、hard-negative max 分位和 activity
  slice；若 hard pair 覆盖为零，实验无效而不是“loss=0 成功”。
- stage auxiliary 的优先级修复在 worker copy 中已有 regression test，但它不是 G2 可执行
  性的替代物，也不能把未跟踪测试当作 closure。V1 前必须在冻结实现上运行 regression：
  333 `fall_process`、307 `post_fall_state` 的已知覆盖错误归零，stage checkpoint/OOF
  loader architecture flags 都有覆盖。还必须审计 stage/controlled 标签总数、clip/window
  overlap、source semantics 与 train/OOF 每类覆盖；禁止从目录名覆盖正事件语义。
- 不先加入 AUPRC surrogate。高召回目标确实值得研究，但该损失、memory bank、温度和
  sampling 将额外引入多项选择自由度。仅在 T1/V1 已得到稳定、可复算 OOF 后，另立一个
  single-change 决策卡。

### 14.6 对 B/C/D 的准入条件

- **B 教师蒸馏：**先在同一冻结 hard-negative cohort 做“teacher 相对 G-only 的 per-clip
  OOF 优势”检查；没有至少 `+2.0pp` 或可解释的 `lie_down` slice 优势，不训练学生。
  训练期 RGB 可用性、clip 对齐、teacher 的 domain/camera leakage 与成本需单独审计。
- **C corruption：**先从冻结 pose cache 计算 confidence-run length、track gap、left/right
  flip proxy、bbox drift 的分布并保存参数 JSON。只模拟能测到的失败模式；左右互换和
  track-reset 需要同时检查标签语义是否仍成立。Mixup 不进入首轮，因为它可能制造没有
  真实 action 语义的中间轨迹。
- **D context：**先报告按真实 timestamp 的事件跨度分布和“16-frame 输入内可见 transition
  的比例”。若该证据不支持长上下文，不训练 32/64。若支持，采用共享 encoder + valid mask
  的一个长度变量，而不是三套完整网络。

### 14.7 更新后的成功定义

近期成功不是“突破 70%”，而是从约 70% 的已观测平台中找出一个可比较、可复算且无
test/validation selection leakage 的**多百分点**突破机制。模型改进只有在三 seed paired
OOF、错误切片、资源 envelope 和一次性冻结 val 都一致时，才能称为有效；`0.0Xpp` 的
单次涨幅只作诊断信号，不作架构升级依据。`75%` 保留为竞争目标，不再作为任何单 run 或
任何未经 provenance 证实的历史数字的解释阈值。

### 14.8 Sol 主审复核结论（Task ID `DET-70-PLAN-20260824`）

**VERDICT: REVISE。**本节是对 14.4 中 GPU 顺序与通过门的最终裁决。

- P0 必须先固定可执行 revision：解决 OF-Syn-only 与 OF-Syn+URFD 的矛盾；若保留混合域，
  runner 必须经测试构建一份签名的 `9,670 / 1,214` train/val population；否则将 G2 卡改写
  为 OF-Syn-only，且不得把 `69.6996%` 称为它的 matched control。
- P0 还必须记录 hash、extractor signature、selected clip/window/semantic counts；通过
  stage positive-priority、strict stage/residual checkpoint loader 和 aggregation contract
  regressions。当前环境缺 PyTorch、项目 `.venv` 和 Ruff，故这些不是已经通过的质量门。
- 在 P0 后，G2 可以作为**独立**的预注册验证实验有条件执行；G2 成败都不证明或否定
  aggregation/verifier 假设。
- A0 是唯一可在 G2 closure 后审议的“70% 路线”canary，且严格限于 table 所列的 shared
  normalized LogSumExp。其失败不能通过叠加 verifier、ranking 或其它损失来“挽救”。
- 只有 A0 的三 paired seeds 都满足 mean gain `>=+2.0pp`、每 seed 的 P@R90/P@R95 不降、
  hard-negative FP 不增且部署约束实测通过后，才可以提交 verifier 的新决策卡。
- verifier 还必须先在 train-only OOF 上证明：candidate 在进入 verifier 前保持至少 95%
  fall recall；固定 candidate 下 verifier 对 `lie_down/lying/stand_up/sit_down` FP 降低
  至少 20%，且有 monotonic/fallback test，确保 verifier 故障不会静默压掉 fall candidate。

### 14.9 双机实验分工（2026-08-24）

- **另一台电脑：**独占执行本文件的 P0 → G2 → A0 主路线。它拥有 frozen baseline、
  G2 修订、shared aggregator 和 verifier 的代码/配置/运行目录；不得由本机并行修改这些
  shared execution files 或复用其 validation 结果调其它候选。
- **本机：**只探索与主路线不重叠的替代假设。每个候选必须有独立 config、run root、
  feature-schema/version、clip-list/fold hash 和证据包；不得修改远端主路线的 baseline、
  G2/A0 card 或 checkpoint。
- **本机可优先筛选的方向：**(1) 从 pose cache 实测错误分布后的一种 corruption family；
  (2) 经 timestamp/event-span 统计支持的单一 context-length 变量；(3) 先证明 teacher 在
  预声明 hard-negative cohort 上胜过 skeleton student 的只读 teacher feasibility audit；
  (4) 不同信息源而非新骨架的 motion/quality representation。它们都不得与 aggregation、
  verifier、ranking、fusion 或 validation threshold tuning 绑在同一实验中。
- **交接规则：**本机任何正向观察只能称为 candidate evidence；只有完整的 command、
  revision/hash、seed、per-clip predictions、资源记录和 Terra audit 才能提交 Sol 评审并考虑
  合入远端主路线。任何方案都不访问 sealed test。

#### 本机已选择候选：C1 calibrated pose-corruption

**状态：BLOCKED（本机没有 frozen pose cache；未运行训练）。**本机仓库与 `D:\` 范围的
限定检索未发现可读 `.npz` pose cache；当前只有 cache reader/audit 代码，不能诚实估计
confidence run、track gap、bbox drift 或左右异常分布。因此不得先猜一个 augmentation 概率
或启动增强训练。

获得 cache root 后，先执行只读统计并生成 `corruption_profile_v1.json`：按 dataset/split/
activity/has_fall 分层报告 frame pose coverage、连续无 pose span、每关节低 confidence span、
track-id continuity、bbox center/scale 一阶差分和有效 observation 数。该 profile 与 cache
extractor signature、manifest SHA、clip list SHA 一起冻结。只有 profile 显示一个明显、可
模拟的错误族，才由 Terra 审核一个对应的**单一**训练增强卡；候选优先级由观测数据决定，
不预设为 jitter、occlusion、left/right swap 或 track gap。

