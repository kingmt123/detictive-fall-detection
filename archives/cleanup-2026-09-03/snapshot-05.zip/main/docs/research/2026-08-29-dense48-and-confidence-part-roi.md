# Stage-S1 原生 dense-48 与置信度约束 Part-ROI 实验审计

日期：2026-08-29  
协议：OF-Syn train-only、五折 template-grouped OOF  
结论：dense-48 作为第七专家晋级；Part-ROI 淘汰  
完整性：未访问 OF-Syn sealed test、URFD test 或 random-validation

## 1. 结论摘要

本轮没有用 48 帧模型替换现有 16 帧主干。最终有效结构是在原六头固定融合之外，
增加一个独立的 `48-frame skeleton + 320 Person-ROI/original head` 长时序专家，七个
clip logits 固定等权平均。

| 五折 train OOF | mAP | P@R90 | P@R95 | 决策 |
|---|---:|---:|---:|---|
| 原六头 fixed equal-logit | 70.831 | 77.562 | 64.100 | 旧基线 |
| **六头 + dense-48/320** | **72.166** | **78.762** | **65.570** | **晋级** |
| delta | **+1.335** | **+1.200** | **+1.470** | 三项同升 |

置信度约束 Part-ROI 无论作为第八头直接加入，还是替换 320/seed30，都没有改善五折
总体结果，故不进入最佳架构。

## 2. 新最佳七头架构

```text
最近 16 帧 pose/track
    -> 共享六流 causal TCN + Joint-only Transformer
    -> e16 (384D)
       -> 320 ROI heads: original / seed29 / seed30 ┐
       -> 640 ROI heads: original / seed29 / seed30 ├-> mean(7 logits) -> sigmoid
                                                    │
最近 48 帧原生连续 pose/track                       │
    -> 独立同构六流 causal TCN + Joint-only Transformer
    -> e48 (384D) -> 320 ROI original head ---------┘
```

保持不变的部分：

- 六流仍为 Joint、Bone、Motion、Geometry、Rule、Kinematics；
- 两个 skeleton backbone 都由相同 FallVision Joint checkpoint 初始化；
- ROI 仍是 frozen YOLO11n Pose 的 P3/P4 person ROI mean token；
- dense-48 专家复用现有 16 帧、320 分辨率 ROI cache，唯一新增信息是连续 48 帧
  skeleton history；
- 所有 head 仍用固定 12 epochs、balanced focal loss、subtype auxiliary loss；
- 最终融合没有学习参数、C5、quality gate 或 validation 权重搜索。

原六头约 1,033,540 个可训练参数。dense-48 专家新增一个同构 skeleton backbone
164,122 参数和一个 320 ROI head 144,903 参数；七头总计约 **1,342,565** 参数，
不包含 frozen YOLO、pose detector 和 tracker。部署时需要两个 skeleton temporal passes
（16 与 48），但不增加 320 YOLO pass。

## 3. 原生 dense-48 数据契约

### 3.1 窗口定义

- `window_size=48`、`stride=1`、`min_observed_frames=24`；
- 不做 16 帧复制、均匀重采样或三窗口拼接；48 个位置是原生连续时刻；
- 视频开头允许因果左零填充，但只有累计至少 24 个真实 observation 且末帧看见该
  track 时才生成窗口；
- 左填充和真实 track 缺失均保持全零，并由 observed/validity 信息显式区分；
- 长序列不存在未来帧访问。

初版若禁止 warm-up，会因 track 断裂漏掉 3/9600 个 clip。最终契约没有降低
`min_observed_frames`，而是采用在线推理一致的因果左填充，恢复 9600/9600 身份。

| 工件 | 值 |
|---|---|
| window cache signature | `d1aeb5224ff29fda4b15bbb0bc40ecefd38a06ca148acb54221f63f8d75f8319` |
| windows | 814,102 |
| positive / negative windows | 118,476 / 695,626 |
| zero-window clips | 0 |
| sidecar signature | `2dec23220bbb5eb428cc14498c3d23de6bbbeaef9c85381c45d23ae6210f8014` |
| sidecar shape | `[814102,48,6]` |

新的 fold map 与旧 map 的 9600 rows 和 assignment SHA 完全一致，只有绑定的 cache
signature 改变。因此 dense-48 与六头的 held-out clip 身份是严格配对的。

### 3.2 单头与融合行为

fold-0 dense-48/320 单头为 `68.718/76.734/60.702%`，低于对应 16 帧单头；但它与
六个旧成员的相关系数只有 `0.917–0.937`，作为第七头反而将 fold-0 从
`75.081/80.471/69.691%` 提高到 `75.729/81.087/70.370%`。因此仅看单头淘汰会错误
丢失互补信息。

七头逐折结果：

| Fold | mAP | P@R90 | P@R95 | mAP delta vs 六头 |
|---:|---:|---:|---:|---:|
| 0 | 75.729 | 81.087 | 70.370 | +0.648 |
| 1 | 74.419 | 79.376 | 69.461 | +0.500 |
| 2 | 70.858 | 77.354 | 64.362 | -0.456 |
| 3 | 68.138 | 74.654 | 61.622 | +2.375 |
| 4 | 70.181 | 76.854 | 63.509 | +0.234 |

2000 次 template-group paired bootstrap：

- mAP delta 95% CI：`[+0.055,+2.333]` 点；
- P90 delta 95% CI：`[-0.028,+2.095]` 点；
- P95 delta 95% CI：`[-0.603,+3.417]` 点；
- R95 false positives：救回 81、引入 19、净减少 62。

mAP CI 下界为正，三项总体同升，且最弱 fold-3 明显改善，因此 dense-48 晋级。尚未
使用 random-validation 确认，不能把旧 random-validation 数字绑定到七头。

## 4. 置信度约束局部 Part-ROI

### 4.1 特征定义

在相同 16 个 RGB 采样帧和同一次 frozen YOLO P3/P4 pass 中，保留 192D person token，
再提取三个 192D 局部 token：

| Part | COCO joints | 最低可见数 |
|---|---|---:|
| upper | shoulders, elbows, wrists（5–10） | 3/6 |
| torso | shoulders, hips（5,6,11,12） | 3/4 |
| lower | hips, knees, ankles（11–16） | 3/6 |

约束如下：

- 只接受采样帧上相同 track 的精确 pose，不从邻帧复制 keypoints；
- joint confidence threshold 固定为 `0.35`；
- part 框限制在 person bbox 内，加入 8% margin，最小边长为 person box 的 15%；
- 未达到最低可见数时使用安全框执行 ROIAlign，但缓存前把 token 严格乘零；
- 有效 token 乘以 `mean visible confidence × visible coverage`，并把三个 reliability
  追加到每帧输入；最终 actor token 为 `192 + 3×192 + 3 = 771D`。

完整 train cache 覆盖：upper `97.51%`、torso `95.37%`、lower `87.82%`；平均
reliability 分别为 `0.896/0.923/0.758`。Part head 参数量为 219,015。

### 4.2 结果与淘汰原因

fold-0 Part 单头为 `69.264/76.222/62.306%`。直接加为第八头，fold-0 三项下降；
替换 320/seed30 在 fold-0 有小幅正信号，因此按 canary 规则补齐五折。

| 五折方案 | mAP | P@R90 | P@R95 | delta vs 七头 |
|---|---:|---:|---:|---:|
| dense-48 七头 | **72.166** | **78.762** | **65.570** | baseline |
| + Part-ROI 第八头 | 71.947 | 78.615 | 65.280 | -0.219 / -0.147 / -0.290 |
| Part 替换 320/seed30 | 71.902 | 78.259 | 65.545 | -0.264 / -0.503 / -0.024 |

替换方案逐折 mAP 为 3/5 上升，但总体三项均下降；R95 FP 救回 40、引入 41，净增加
1 个。bootstrap delta CI 为：mAP `[-0.911,+1.081]`，P90 `[-1.377,+0.857]`，
P95 `[-1.424,+2.060]` 点。该信号不足以替换当前成员，Part-ROI 淘汰。

## 5. 权威工件与复核

- dense-48 七头预测：
  `runs/stage_s1_dense48/fivefold_seven_with_dense48_320.npz`
  (`SHA-256 f2e454d7d771d3535bb4a02397adb57b7d8381abeff43eda99539d876a057b20`)
- dense-48 配对审计：
  `reports/stage_s1_dense48_seventh_head_fivefold_audit.json`
- Part-ROI cache：
  `runs/yolo_roi_tokens/ofsyn_train_p3p4_320_confpart035_merged/roi_tokens.npz`
  (`SHA-256 2dbcfcb7c758c22abf010cf825a846ca8b885448bcacc44a4a58ab3399dc07b4`)
- Part 替换预测：
  `runs/edgefall_f1_part_roi/fivefold_replace_320_seed30_confpart035.npz`
  (`SHA-256 15faed05fbf3b3afc43b207eff572ce29ae7290844c04f19d16a84c69801f2eb`)
- Part 替换配对审计：
  `reports/confidence_part_roi_replace_seed30_fivefold_audit.json`

相关代码回归测试共 29 项通过；修改文件的 Ruff 检查全部通过。所有 run summary 和
paired audit 均记录 `test_accessed=false`。

## 6. 下一步约束

1. 当前 train-OOF 最佳是固定七头，不是 Part-ROI 八头，也不是 Part 替换模型。
2. 若协议允许，应只对冻结后的七头做一次独立确认；不得用该确认集搜索 dense 权重。
3. 后续若重做 Part-ROI，需要引入新的监督或真正不同的局部编码方式；仅换置信度阈值、
   part margin 或继续增加同构 Part head 属于低价值调参。
4. 不得重新访问 OF-Syn sealed test；URFD test 继续保留。
