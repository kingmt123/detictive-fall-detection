# Stage-S1 模型结构、失败实验与无泄漏融合路线复核

日期：2026-08-26  
任务 ID：`DET-ARCH-20260826`  
范围：只分析 OF-Syn train / random validation 与 train-only template-group OOF；不访问已封存 test。  
状态：**架构研究与决策卡草案，不构成训练授权。**

## 0. 结论先行

1. **Stage-S1 的主要优点不是“大模型能力”，而是任务先验组织得好。** 六流把姿态、骨向量、速度、框几何、连续规则和判别运动学分开编码；多尺度因果 TCN 提供局部时序先验；阶段辅助头和困难负例采样直接对准 `fall / lie_down / lying / stand_up` 混淆。当前代码实例化结果为 **161,406 参数**，其中六个流合计 140,256 参数，fusion SE 18,840 参数，binary/stage heads 2,310 参数。
2. **当前最值得先修的 Stage-S1 风险不是继续加层，而是输入可靠性语义。** `build_four_stream_features()` 对 bone 和 motion 使用“该帧任意关节可见”的 frame-level mask，而不是 bone 两端/同一关节相邻帧均可见的 per-joint mask。一个关节缺失但同帧其他关节存在时，bone/motion 仍可能产生伪差分。结合 pose-missing 错误队列和遮挡压力测试，这比再加第七流更有直接证据。
3. **过去建议的“优先统一聚合器”已被最新负结果降级。** smooth-max、窗口 verifier、event GRU 和 suppressor 已多次表现为减少部分高分负例、同时压低 R95 尾部真实 fall。除非人工错误审计证明“孤立单窗口尖峰”占主导，且新聚合器引入了独立质量信息，否则不应继续在相同 embedding 上搜索 pooling/gate/cap。
4. **16+48 共享编码残差的已测版本已经失败，但不能外推为“所有长上下文无效”。** 已测方案把最近 48 帧 stride=3 稀疏成 16 token，并与 16 帧共享编码器；它否定该实现，不否定原生密集 48-token、显式长短期记忆或事件边界模型。不过在当前期限和失败密度下，长上下文不是优先路线。
5. **ST-GCN、InfoGCN、SA-TDGFormer 和 PoseConv3D 的 replacement/fusion 失败不等于图模型或热图模型普遍无效。** 图卷积原始工作分别研究了固定骨架图、通道级动态拓扑和信息瓶颈表征。[14][15][16]

   PoseC3D则研究了热图表示的鲁棒性。[17] 本项目结果只支持：删除预训练 Joint-TCN 的 replacement 风险很高；保留主干的 zero-init residual ST-GCN 尚有局部信号；PoseConv3D 在当前表示、数据和门槛下候选召回不足。
6. **未来融合必须先做完整 template-grouped OOF，再谈权重。** 当前 71.1794% 是模板完全重叠的 random validation 结果。合理顺序是：统一 fold 的 OOF clip-max logits → 标准化 → non-negative L2 logistic stacking → 系数/折间稳定性审计 → 冻结后一次 random validation。Stacking 的原始思想就是用 out-of-sample/cross-validation 预测训练二层模型，而非使用基模型的 in-sample 预测。[7][21][23]
7. **动态质量门控暂不启动。** Mixture-of-experts 的 gate 只有在“不同质量区域存在可复现的最优专家切换”时才有统计依据。[8] 当前 quality-gated F3 和多种动态 residual fusion 已失败，且静态 OOF 融合尚未证明稳定。若未来启动，只能做“围绕静态权重的有界零初始化残差 gate”，不能自由生成权重。
8. **不建议把 feature orthogonality loss 当作 quick win。** 先前内部资料把 Diverse Branch Block 错解为正交特征集成依据；该引用不支持该结论。强制去相关还可能移除共同的真实 fall 信号。除非先证明成员存在互补但被表征共线性压制，否则不进入实验队列。
9. **最高价值的两条开放路线是：**（a）修正/建模真实 pose-track missingness；（b）完成 Person ROI F1 与现有异质候选的完整五折 OOF。前者直接改进 Stage-S1，后者为融合引入真正不同的信息源。

## 1. 证据边界与复现状态

### 1.1 已核对的实现

- 当前源码：`models/multiscale_multistream_tcn.py`；
- MIL 训练器：`tools/train_multiscale_multistream_mil.py`；
- clip-max 评估器：`tools/train_tcn.py`；
- Stage-S1 配置副本：`parallel_worker_20260824/configs/multiscale_multistream_distilled_stage_s1_v1.json`；
- 参数量使用项目含 PyTorch 的工作树虚拟环境实际实例化得到：`161,406`。该数字只绑定本次读取的未跟踪源码快照；`models/multiscale_multistream_tcn.py` 的 SHA-256 为 `7ce32c3492234ad43d1ba08a30b8439370713424fa1aae42e6435ffb63a700bb`，在源码冻结前不能称为 commit 可复现参数量；
- 合成输入探针已复现 mask 缺陷：当 t=1 的 joint 0 坐标跳到10但 confidence=0、同帧其他关节可见时，当前实现仍输出 `bone(0,1)=[-10,0]` 和 `motion(joint0)=[10,0]`。这证明伪差分可以发生，但不证明修正后指标一定提高。

### 1.2 当前工作树无法读回的证据

附件列出的以下 canonical 路径在当前主工作树中不存在：

- `configs/multiscale_multistream_distilled_stage_s1_v1.json`；
- `runs/multiscale_multistream_tcn/distilled_stage_s1_v1/run.json`；
- `models/clip_aggregator.py`。

配置只在 `parallel_worker_20260824/configs/` 找到副本；`runs/` 证据未在当前工作树读回。当前 `master` 为 `b18c2c2291120d41934720549176a1f98488b88c`，且存在大量用户未提交修改和未跟踪实验文件；本报告没有改写这些文件。

因此，本报告可以核对**代码结构、附件指标和现有文档的一致性**，但不能独立证明附件所述 checkpoint SHA、run signature、逐 clip 预测完整性或所有负实验的原始运行记录。任何新训练前必须先确定 authoritative revision、materialize canonical config/run/prediction paths，并冻结 hash。

### 1.3 评估边界

- random validation：1,200 clips；报告称 759 个模板组全部与 train 重叠，所有 validation clip 都有 train 模板匹配。该 split 已参与多轮决策，未来只能作为历史描述/兼容性检查，不能再作为 promotion、确认或权重选择门；
- template-group OOF：评估跨 actor/view template 泛化，绝对 mAP 不应与 random validation 横比；
- 选择指标：mAP、P@R90、P@R95；
- 任何权重、阈值、gate、正则强度、成员选择都必须在 train-only grouped OOF 内完成。对相关样本使用普通随机交叉验证会产生偏乐观风险；相关数据需要与预测目标一致的分组结构。[27][28]

## 2. Stage-S1 逐模块结构审计

### 2.1 六个输入流

| 流 | 代码语义 | 有效作用 | 主要风险 | 结论 |
|---|---|---|---|---|
| Joint 51D | 17×`x/y/confidence` | 保留原始姿态与置信度；是 FallVision 初始化的主承载 | 坐标、置信度和缺失值在同一 1×1 投影中混合；缺失坐标的数值语义取决于 cache | **保留**；必须先核验缺失坐标填充值与 confidence=0 契约 |
| Bone 32D | 16 条 COCO 边的端点坐标差 | 提供平移相对不变的肢体关系；joint/bone 多流在骨架动作识别中是成熟做法。[30] | 当前只用 frame-level observed mask；任一端点缺失仍可能产生伪骨向量 | **优先修正 mask**，不先加新图网络 |
| Motion 34D | 相邻帧同名关节坐标差 | 直接暴露下降、旋转、恢复速度；与静态 pose 互补 | 当前只要求相邻两帧“任意关节可见”，没有逐关节 pair mask；缺失/恢复可被解释为大速度 | **优先修正 mask**；随后才讨论真实失真增强 |
| Geometry 6D | bbox 中心、宽高、log aspect、observed | 对人体整体下降、横躺、出画提供低维稳定线索 | bbox jitter/wrong person 会同时污染多项派生流 | **保留**；增加真实 bbox residual 审计，不增加手写阈值 |
| Rule 12D | 连续姿态/运动/框变化/平均置信度 | 把人体工程学先验显式化，降低小模型学习难度 | 与 Joint/Motion/Geometry 高度函数相关；不是独立传感器 | **保留但视为重参数化特征**，不要把它当 ensemble diversity |
| Kinematics 15D | acceleration、jerk、downward velocity、initial posture、peak-to-stop、stillness 等 | 直接对准失控跌倒与受控躺下/起身 | 高阶差分放大 pose 噪声；部分特征与 Rule/Motion 重复 | **保留**；必须与质量/missingness 切片一起审计 |

骨架文献表明，joint、bone、joint-motion、bone-motion 的多流表示可以形成互补视角，但该结论依赖每个视角具有正确的观测语义。[30] 当前 Stage-S1 的最大问题不是没有多流，而是 bone/motion 的可靠性 mask 过粗。

### 2.2 `CausalMultiScaleBlock`

实现为三条 depthwise `Conv1d(k=3/5/7)`，dilation `1/2/4/8`，拼接后 1×1 混合，BatchNorm、ReLU、dropout=0.5、SE，再与 residual 相加。Depthwise+pointwise 的设计以更低参数成本分离逐通道时序滤波和跨通道混合，与 MobileNet 的高效卷积思想一致。[29] Dilated causal convolution 是 TCN 的核心构件；通用序列实验支持把 TCN 作为 recurrent 网络之外的自然起点。[9]

**本项目特有审计：**输入只有 16 帧，而四层 nominal receptive field 已超过窗口：按最短 `k=3` 路径为 31 帧，按最长 `k=7` 路径为 91 帧。对最后 token，dilation=8 的 `k=3/5/7` 分支分别只有 2/3、2/5、2/7 个卷积 tap 落在真实 16 帧内，其余为左侧零填充。这不证明 dilation=8 有害，因为 residual、前层特征和后续 attention 仍可利用它；但说明“继续扩大 dilation/kernel”没有依据。

**结论：**保留当前块作为 anchor；不增加层数、kernel 或 dilation。若后续需要压缩或正则化，只做 `drop dilation=8` 的独立 grouped-OOF ablation，且优先级低于 missingness 修正。

### 2.3 流内 SE 与因果 self-attention

SE 通过全局 squeeze 和 channel excitation 建模通道依赖，原始工作显示它能以较小额外计算对卷积通道进行自适应重标定。[10] Stage-S1 在每个残差块内使用 `residual + fused * SE(fused)`，属于安全的残差增强。

每个流随后使用 4-head `MultiheadAttention` 和上三角 causal mask。Self-attention 可以直接建模远距离 token 关系。[13] 但 Stage-S1 只读取最后 token，因此：

- 对最后 query，16 个 token 全部属于“过去/当前”，causal mask 不再剔除窗口内任何 token；
- 注意力的主要作用是让最后状态读取全窗口，而不是生成每时刻部署输出；
- 模型没有显式位置编码，时间顺序主要由前面的因果卷积状态隐式提供；
- 若最后几帧 pose 缺失，query 本身仍可能不稳定，尽管它可以关注更早 token。

**结论：**attention 不是当前失败根因，也没有证据需要更大 Transformer。若 missingness 审计显示“窗口末端不可观测”显著富集于错误，可测试一个 anchor-preserving readout：`e = e_last + α(q)*(e_quality_pool-e_last)`，`α` 零初始化并由 observed/confidence 质量特征驱动；不要直接 replacement 成 learned attention pooling。

### 2.4 六流融合

当前六个 64D embedding 直接 concat 成 384D，再由 `384→24→384` 的 fusion SE 乘法门控，最后接二分类和四阶段头。fusion SE 本质是**特征通道重标定**，不是跨流时序对齐：当 embedding 已压缩为单个向量后，它无法判断“下降速度与躯干转水平是否在同一时刻发生”。Attention bottleneck 文献说明，中间层的受限信息交换可以优于纯 late fusion，但证据来自音视频等不同模态，不能直接外推到六个高度相关的派生骨架流。[3]

**结论：**不优先加跨流 Transformer。只有在修正 missingness 后，OOF 误差仍显示 Rule/Kinematics 与 Joint/Motion 的“时序错位”占主导，才测试一个零初始化、低秩、只修正旧 logit 的 cross-stream adapter；不替换 concat+SE。

### 2.5 binary head 与 stage auxiliary

二分类 logit 为 `fall - nonfall`。四阶段辅助标签由 immutable event semantic 优先，再把 `lie_down/sit_down/stand_up` 映射为 controlled transition；class-weighted CE 作用在同一 fused 384D 上，权重 0.2。辅助任务能在相关标签下提供归纳偏置，但本项目已经证明更细的七类语义头会负迁移，因此不能从“多任务通常有效”推出继续扩类。

**结论：**四阶段头暂时保留为已用 anchor；在完整 grouped OOF 中必须有一个“关闭 stage head”的 matched ablation，回答它是否仍对最新 Stage-S1 有独立增益。不要改为更复杂 stage verifier，也不要让 stage 分数直接抑制主 logit。

### 2.6 窗口损失、clip Top-20% 与 clip-max

训练同时使用：

- 逐窗口 weighted BCE；
- 每个 clip Top-20% window logits 均值的 clip BCE，权重 0.5；
- stage CE，权重 0.2。

评估则对 clip 内 window probability 取最大值。因为 sigmoid 单调，这等价于对 window logit 取 max 后再 sigmoid。Top-k/positive-and-negative evidence 是弱监督识别中的成熟思路；WELDON 和 attention MIL 都表明 bag 聚合方式决定了哪些实例接收学习信号。[1][11]

但本项目并非纯弱监督 MIL：训练 cache 已有 window label 和 event semantic。Top-20% clip loss更像 bag-level regularizer，而不是唯一监督。训练/评估不一致确实存在，但最新 smooth-max、A3、verifier、GRU 和 suppressor 结果说明“换聚合器”不是低风险确定性收益。

**结论：**

- 继续保留 canonical clip-max 作为当前评分定义；
- 不再搜索 smooth-max 温度、gate、cap 或 suppression scale；
- 只有人工审计确认大量 FP 是孤立尖峰，且 FN 不是低质量 pose 尾部时，才允许新聚合实验；
- 若重启，只能加入**独立质量证据**，并要求候选召回先锁定，再评估抑制器，避免级联系统的 recall 乘法损失。

### 2.7 困难负例采样

训练按 2:1 负/正采样，并让 `lie_down/lying/stand_up` 占负样本的 40%。这与 hard-example mining“把计算集中在当前困难样本”方向一致，但固定 activity oversampling 不是 online hard-example mining，也会改变经验活动先验。

**结论：**保留作为 anchor；每个 fold 记录实际抽样 activity 分布、active clip 数、window 数和重要切片。已失败的 pairwise ranking loss 不恢复。

## 3. 失败实验的根因分类

| 失败族 | 项目证据 | 最合理解释 | 能否整体判死 | 后续边界 |
|---|---|---|---|---|
| 固定秒数重采样 | 0.75/1.0/1.5 秒大多伤害 P@R95 | 时间归一化把局部冲击、下降速度和原 fps 相关线索混在一起 | **该实现关闭** | 不再扫描固定秒数；若有真实时间戳，只做速度物理量重算 |
| 16+48 稀疏共享编码 | TCN/Joint Transformer 三指标不优 | 48 帧 stride=3 只保留 16 token，且共享 encoder 未获得新的时间分辨率；残差可能只复制局部表示 | **只关闭该实现** | 原生密集长上下文理论上仍开放；MS-TCN说明多阶段/长程时序建模可有价值，但任务是动作分割，不能直接外推。[12] 当前不优先 |
| smooth-max / verifier / GRU / suppressor | 常见模式：R90 或 R95 单点改善，mAP/另一高召回点下降 | 相同 embedding 上的抑制分支没有新信息，只重排主干已有不确定性；高召回尾部真 fall 与受控转变共享低分区 | **同信息后置抑制关闭** | 仅在引入质量/ROI等新信息且 OOF 训练时重启 |
| 七类 auxiliary / ranking | B2 和 pairwise ranking 未达门，lie_down FP 增加 | 标签粒度/排序约束与最终 AP、P@R90、P@R95并不一致；额外任务发生负迁移 | **当前损失关闭** | 不扩标签，不恢复全局 pairwise loss |
| ST-GCN replacement | 66.40/70.92/61.88 | 删除了有效的预训练 Joint-TCN；新图分支需重新学习全部时序与拓扑 | **replacement 关闭** | residual ST-GCN 仍开放，因为 zero-init 保留 anchor |
| SA-TDGFormer/InfoGCN fusion | mAP/P@R95显著回退 | 动态/自适应拓扑在本任务数据、窗口和初始化下未形成可靠互补；弱专家拖累高召回尾部 | **当前实现关闭** | 不能用 NTU accuracy 反驳本项目结果；InfoGCN 正确出处是 CVPR 2022，不是 2023。[16] |
| PoseConv3D | mAP 51.82、候选召回70.17 | 热图表示与 3D CNN 没保住本项目的 fall candidate；论文中的 pose-noise/cross-dataset鲁棒性不等于当前任务 AP。[17] | **当前候选关闭** | 不进入融合；除非数据/预训练发生独立变化 |
| frozen R3D / VideoMAE | 约39–52 mAP | RGB teacher自身排序弱；VideoMAE论文强调预训练任务、数据质量和域匹配，小样本不等于任意64帧 canary 自动有效。[19] | **这些 teacher 关闭** | 不蒸馏弱教师，不继续同设置调参 |
| Context ROI / cross-attention / score-band RGB residual | 多次不足或反向 | RGB/context分支没有稳定 conditional advantage；gate只把弱信号注入主干 | **F2/F3 关闭** | Person ROI F1单fold仍开放，必须五折复现 |
| 强合成遮挡/断轨 | clean best 66.99，后续崩至62.89 | corruption分布和真实 detector/tracker错误不匹配，或增强比例过高；增强会生成丢失标签信息的样本并伤害 clean 泛化。[18][26] | **合成Seed-Q关闭** | 只重放fold训练侧实测错误；至少约80% clean；每类失真单独启用 |
| in-sample四教师蒸馏 | best几乎停在epoch0，final退化 | teacher在训练样本上的软标签含训练记忆，不是跨模板泛化知识；教师一致性和训练方案会决定KD能否成立。[5][31] | **同折蒸馏关闭** | 只允许 group-OOF teacher logits |
| window先融合再clip max | P@R95显著低于clip后融合 | 不同模型的峰值发生在不同窗口，先平均会稀释成员各自最强证据，或把错误峰混进同一窗口排序 | **顺序关闭** | 所有候选先独立clip-max，再在clip logit层融合 |
| 动态 residual / quality gate | 多次未稳定超过 anchor | gate自由度相对 OOF样本量过大，且缺乏可复现“质量区域→最佳专家”关系 | **当前动态门控关闭** | 静态 OOF stacking 通过后才允许有界残差 gate |

## 4. 修订后的 Stage-S1 改进优先级

### P0：输入可靠性契约审计（无训练）

**问题：**bone/motion 当前按 frame-level observed mask；Rule/Kinematics 则多处按 per-joint confidence mask。六流对“缺失”含义不一致。

**最小工作：**

1. 从 train cache 抽样验证：confidence=0 时坐标是否为0、保持上一帧、还是其他归一化值；
2. 统计每帧缺失关节数、连续缺失长度、track gap、bbox residual；
3. 对 Stage-S1 OOF/现有预测按末帧可见率、端点缺失率、track gap 分桶；
4. 只读生成 `quality_audit.json`，不改 cache、不训练。

**通过门：**错误切片中至少一个质量变量有稳定富集，且五折方向一致；否则不改输入结构。

### P1：per-joint mask correction 单变量 canary

**唯一变化：**

- bone edge 仅在两个 endpoint confidence 都有效时保留；
- motion joint 仅在该 joint 的相邻两帧都有效时保留；
- 维度保持 32/34，不新增参数；
- 其他模型、采样、损失、聚合、fold 不变。

缺失模式本身可能有信息；GRU-D 的关键启示是 mask 与时间间隔应显式建模，而不是把缺失值当普通数值。[2] 本 canary 先消除伪差分；若有正向证据，再单独测试每关节 missing-age/reliability，而不是一次同时加入。

**canary续跑门：**一折、一matched seed只能做futility screen；要求 `ΔmAP≥+0.30` 个百分点、`ΔP@R95≥0.00`、clean/high-quality切片 `ΔmAP≥-0.30`。  
**最终验收：**五个outer folds、至少两个matched seeds；mean `ΔmAP≥+0.30`、mean `ΔP@R95≥+0.30`、`ΔP@R90≥-0.30`，至少4/5 folds的mAP同向，template-group paired bootstrap的mAP 95% CI下界>0。  
**停止：**canary任一门失败、数据契约/哈希不闭合，或结果只在random validation成立；回退原Stage-S1并关闭该卡，除非出现新的独立证据。

### P2：完整 template-group OOF 与静态融合

先补齐 `Primary / Seed-R / real-Seed-Q / real-Seed-T`；条件成员 `Residual ST-GCN / Joint-only Transformer / Person ROI F1` 必须使用相同 fold、相同 clip list、相同 clip-max定义。

这是当前**最高整体信息价值**的工作，因为它同时回答：

- HFlip收益是镜像不变性还是seed averaging；
- real-Q/T是否真正改变错误分布；
- Residual ST-GCN/Transformer/ROI是否有跨折互补；
- 现有四模型71.1794能否在无模板泄漏的协议下成立。

### P3：真实 pose/track 失真重放

现实姿态增强论文支持根据真实 pose estimator 错误构造训练扰动，但其报告的是其他数据集 accuracy，不能作为本项目收益承诺。[4][18] 设计必须满足：

- 失真模板只从 outer-fold training groups 提取；
- 每次只启用一种 family：joint miss、bbox residual、track gap、repeat/skip；
- 保持约80% clean输入；
- clean、corrupted、pose-missing、unusual-view 分别报告；
- 真实Seed-Q/T只作为新专家，不自动替换Primary。

### P4：质量感知 last-token residual（条件）

仅当P0证明窗口末端缺失/低置信与错误强相关时启动：

```text
e_old  = StreamEncoder(...).last_token
e_pool = quality-weighted pool(all temporal states)
alpha  = sigmoid(g(quality)) * alpha_max
alpha 初始为 0
e_new  = e_old + alpha * (e_pool - e_old)
```

这不是自由 attention pooling replacement；初始输出必须逐元素等于旧模型。只允许一个共享标量或每流一个标量，避免小样本 gate 过拟合。

### P5：Residual ST-GCN 与 Person ROI F1（条件成员）

- Residual ST-GCN：只作为保留 Joint-TCN 的 zero-init residual；不再 replacement。ST-GCN/CTR-GCN的论文支持图结构学习，但不提供本项目小样本增益保证。[14][15]
- Person ROI F1：优先完成五折，因为单fold +10.07 mAP 是目前唯一显示大幅异质信息的结果；在复现前它仍是高方差观察，不是已成立改进。

### P6：OOF ensemble distillation

只有静态OOF融合通过后启动。每个训练clip及其template group必须由未训练过它的teacher评分；teacher成员、标准化和权重全部冻结。KD可以压缩 ensemble，但原始论文并不保证弱教师或过拟合教师会改善学生。[5][31]

### 暂不启动

- 原生密集48-token Transformer；
- cross-stream attention bottleneck；
- AP surrogate fine-tuning；
- orthogonal feature loss；
- Bayesian model averaging；
- dynamic MoE/quality gate；
- 任何validation权重扫描。

AP/AUPRC直接优化在不平衡任务中有理论和算法依据，但它增加优化复杂度，且本项目已经出现多损失负迁移；只有P1-P3后OOF平台仍明确受分类损失限制时再考虑。[24][25]

## 5. 推荐的无泄漏融合协议

### 5.1 OOF 预测契约

每个成员、每个 outer fold 保存：

```text
clip_id, template_group, fold, label, activity,
clip_logit, checkpoint_sha256, config_sha256,
code_signature, fold_train_group_hash, fold_eval_group_hash,
quality summary, runtime_ms
```

强制条件：

- 所有成员的 `clip_id/template_group/fold/label` 完全相等；
- 每条 OOF 预测来自未训练该 template group 的模型；
- 每个成员先独立做 clip-max，再进入融合；
- 缺失预测直接 BLOCK，不允许按共同子集静默删除。

### 5.2 成员准入不是只看单模 mAP

对候选成员同时检查：

1. standalone OOF mAP/P@R90/P@R95；
2. 与Primary的 Spearman/Pearson score correlation；
3. R90/R95 FP/FN错误重叠；
4. 把候选logit加入仅含Primary的正则stack后，系数是否在多数outer folds为正；
5. leave-one-member-out 对ensemble的增量；
6. fold bootstrap中系数为0或符号反转的比例。

大模型库的前向成员选择可以优化集成，但会引入额外选择自由度；当前候选库很小，因此只把它作为 leave-one-member-out 审计依据，不运行贪心权重搜索。[22]

Deep ensembles说明不同初始化的预测平均可以改善不确定性和稳健性，但当前HFlip成员同构且高度相关，不能把“多seed通常有效”当成无限扩成员的理由。[20]

### 5.3 预注册三种静态融合

**A. 固定均值基线**  
每个成员logit先用inner-train OOF均值/标准差标准化，再等权平均。它回答“只做尺度对齐是否足够”。神经网络logit常未校准，温度缩放等方法可改善概率校准；对融合而言，标准化/校准必须只在训练折拟合并冻结。[6]

**B. non-negative L2 logistic stacking（主方案）**

```text
z_i' = (z_i - mu_i) / sigma_i
z_fused = b + Σ_i w_i z_i'
w_i >= 0
objective = weighted log-loss + λ||w||²
```

- `mu/sigma/λ`在inner grouped CV中选择；
- outer fold只评估一次；
- 负系数禁止，避免小样本中用某成员“反向纠错”形成不稳定捷径；
- λ使用极小离散集合，不连续扫描。

这继承Stacked Generalization、Stacked Regressions和Super Learner的核心：二层权重由out-of-sample预测学习，并用交叉验证控制组合风险。[7][21][23]

**C. OOF-CDF rank average（稳健对照）**  
对每个成员用inner-train OOF经验CDF把logit映射到分位数，冻结CDF后映射outer fold，再等权平均。它牺牲幅度信息，检验收益是否只来自排名互补。不要在整个outer/test集合上现算percentile，否则仍使用了评估集分布。

### 5.4 为什么暂不使用 Bayesian model averaging

BMA需要可比较的概率模型、先验和边际似然；当前成员是不同训练/增强/表示下的判别网络，且主要指标是ranking，不具备自然的BMA证据模型。静态正则stack更可审计、更贴近现有logit工件。

### 5.5 动态 gate 的开启条件

只有同时满足下列条件才允许建立新卡：

1. 静态stack在grouped OOF上通过；
2. 至少两个成员在预注册质量区间存在稳定的conditional advantage；
3. 这种最优专家切换在至少4/5 folds同方向；
4. gate输入只含部署时可得质量统计，不含activity、label、未来帧或fold身份；
5. gate为 `w_static + bounded_delta(q)`，delta零初始化、L2正则、幅度有上限；
6. nested outer-fold同时优于static stack，且系数/权重分布稳定。

自由MoE gate会把输入空间划分给不同专家；这正是它的能力，也正是小样本下的过拟合风险。[8] 当前不满足开启条件。

### 5.6 融合通过门

建议以Primary grouped-OOF为基线，而不是71.1794 random-validation集成：

- mean OOF `ΔmAP≥+0.50` 个百分点、`ΔP@R95≥+0.50`；
- `ΔP@R90≥-0.30` 个百分点；
- 至少4/5 outer folds的mAP同向；
- template-group paired bootstrap的mAP 95% CI下界>0；
- 在冻结的R95工作点，困难负例FP不增加；
- 成员只在至少4/5 outer fits系数为正、bootstrap零权重率<20%时保留；
- 参数、模型大小和V100端到端延迟实测满足预算。

## 6. Lane B 决策卡

### 卡 A：Stage-S1 输入可靠性修正

```text
ID and owner: DET-ARCH-P1 / Hermes implementation, MiMo execution
Decision requested: 是否批准 per-joint mask correction 的单变量 grouped-OOF canary
Hypothesis: frame-level mask 产生伪 bone/motion；逐端点/逐关节 mask 可减少 pose-missing FP，而不损害 clean 排名
Baseline: authoritative commit/config/checkpoint/predictions 目前未完整 materialize；UNKNOWN/BLOCKING
Single intended change: bone endpoint-valid + motion same-joint pair-valid
Controlled variables: model, init, folds, seed, sampling, losses, clip-max, metrics
Budget: 先1 fold×1 seed；过门后5 folds×预注册 seeds
Primary metric: grouped-OOF mAP；联合守门P@R95
Guardrails: clean高质量切片、P@R90、runtime、参数不退化
Minimum replication: canary仅作futility；最终5 outer folds×至少2 matched seeds
Failure interpretation: mask语义不是主要瓶颈，或missingness本身被错误抹除
Success thresholds: canary +0.30/+0.00/-0.30；最终mean mAP +0.30、P@R95 +0.30、P@R90 ≥-0.30、4/5 folds同向、paired-bootstrap CI下界>0
Stop conditions: 任一canary门失败；数据契约/哈希不闭合
Rollback: 关闭新feature schema，旧checkpoint与旧cache只读保留
Artifacts: 新schema、quality audit、逐clip OOF、fold hashes
```

### 卡 B：静态 OOF 融合

```text
ID and owner: DET-FUSION-F1 / Hermes integration, MiMo execution
Decision requested: 是否批准完整OOF导出和三种预注册静态融合
Hypothesis: 异质候选在clip层存在稳定互补；正则stack可在不使用validation的情况下利用它
Baseline: Primary grouped-OOF；当前尚未完整生成
Single intended change: fusion only；base predictions immutable
Controlled variables: folds, clip-max, labels, metric code, member artifacts
Budget: 先导出已有成员；不为缺失成员追加训练，除非另立卡
Primary metric: outer grouped-OOF mAP；联合P@R95
Guardrails: P@R90、hard FP、fold variance、coefficient stability、latency
Minimum replication: 5 outer folds；每个outer-train内4-fold grouped base cross-fitting；inner grouped CV冻结mu/sigma/λ
Frozen search: member set先冻结；L2网格≤5个值；标准化范围、solver/seed、group-bootstrap unit和R95工作点全部预注册
Success thresholds: mean mAP +0.50、P@R95 +0.50、P@R90 ≥-0.30、4/5 folds同向、paired-bootstrap CI下界>0；系数正向4/5且零权重率<20%
Failure interpretation: 成员相关性过高或互补不稳定；回退Primary
Stop conditions: prediction不完整、group泄漏、成员fold不一致、系数不稳定
Rollback: 固定Primary；不触碰random validation
Artifacts: oof_predictions.parquet/csv、fusion_config.json、bootstrap.json、audit.md
```

### 卡 C：Person ROI F1 五折复现

```text
ID and owner: DET-ROI-F1-O5 / MiMo bounded execution
Decision requested: 是否把单fold +10.07 mAP观察扩成五折
Hypothesis: Person ROI为低质量pose/unusual-view提供骨架之外的互补外观信息
Baseline: 相同fold的Joint-only Transformer；authoritative config/checkpoint/cache/fold hashes目前缺失，BLOCKING
Single intended change: Person ROI F1；不加context residual或quality gate
Budget: 当前0；只有独立修订卡冻结baseline、seed、数值futility门和non-overwriting artifact root后才能申请
Primary metric: fold mAP；联合P@R90/P@R95和pose-missing切片
Guardrails: 参数/延迟、候选召回、无ROI缓存泄漏
Failure interpretation: fold0高方差或模板特例
Stop conditions: ROI/模板泄漏、缓存不可复现，或预注册futility门失败
Rollback: 不纳入fusion library
```

## 7. 最终排序

| 优先级 | 工作 | 理由 | 当前状态 |
|---:|---|---|---|
| 1 | materialize authoritative revision/config/run/predictions + P0质量审计 | 没有它无法解释新实验，也暴露了直接的mask风险 | 必须先完成 |
| 2 | per-joint bone/motion mask correction canary | Stage-S1内最小、零参数、最贴合pose-missing证据 | 待审批 |
| 3 | 完整template-group OOF与静态stack | 解决validation乐观偏差并验证现有候选互补 | 待基线工件 |
| 4 | 真实失真Seed-Q/T | 以真实错误替代已失败强合成增强 | 待P0统计 |
| 5 | Person ROI F1五折复现 | 最强但仅单fold的异质信号 | 条件高价值 |
| 6 | Residual ST-GCN作为条件成员 | 有局部图信号且可保持anchor | 不替换Primary |
| 7 | OOF教师蒸馏 | 仅在静态ensemble通过后压回单模型 | 条件 |
| 8 | 质量感知动态gate / cross-stream adapter / AP精修 | 自由度高，已有相邻负结果 | 暂缓 |

## 8. 审计结论

**研究结论：REVISE，而不是继续堆模型。** Stage-S1 主体应保留；先修可靠性语义和评估证据，再做静态OOF融合。当前材料足以提出最小实验卡，但不足以授权训练：canonical config/run/checkpoint/prediction工件未在当前主工作树完整读回，且random validation已被多轮使用。

独立审核结果：`gpt5-6terra` 对当前执行证据返回 **BLOCK**；`gpt5-6sol` 对研究方向返回 **REVISE / PASS WITH REVISION**，但对任何训练或OOF预算返回 **REJECT（当前授权计算为0）**。完整审核见 `docs/research/2026-08-26_stage_s1_terra_review.md` 与 `docs/research/2026-08-26_stage_s1_sol_decision.md`。下一步只能只读materialize并哈希 authoritative baseline、group manifest、fold assignments和已有逐clip预测，再重新申请一张单变量执行卡。

**明确不做：**重新访问OF-Syn test、在random validation扫描权重、恢复已失败的同信息suppressor、ST-GCN replacement、强合成Seed-Q、in-sample蒸馏、window先融合、无静态证据的动态MoE，以及基于未经核验“预期+X%”的架构堆叠。

## Sources

[1] https://proceedings.mlr.press/v80/ilse18a.html — Attention-based Deep Multiple Instance Learning
[2] https://doi.org/10.1038/s41598-018-24271-9 — Recurrent Neural Networks for Multivariate Time Series with Missing Values (GRU-D)
[3] https://proceedings.neurips.cc/paper/2021/hash/76ba9f564ebbc35b1014ac498fafadd0-Abstract.html — Attention Bottlenecks for Multimodal Fusion
[4] https://doi.org/10.1109/WACVW60836.2024.00038 — Enhancing Skeleton-Based Action Recognition Through Realistic Data Augmentation
[5] https://arxiv.org/abs/1503.02531 — Distilling the Knowledge in a Neural Network
[6] https://proceedings.mlr.press/v70/guo17a.html — On Calibration of Modern Neural Networks
[7] https://www.sciencedirect.com/science/article/pii/S0893608005800231 — Stacked Generalization
[8] https://doi.org/10.1162/neco.1991.3.1.79 — Adaptive Mixtures of Local Experts
[9] https://arxiv.org/abs/1803.01271 — An Empirical Evaluation of Generic Convolutional and Recurrent Networks for Sequence Modeling
[10] https://arxiv.org/abs/1709.01507 — Squeeze-and-Excitation Networks
[11] https://openaccess.thecvf.com/content_cvpr_2016/html/Durand_WELDON_Weakly_Supervised_CVPR_2016_paper.html — WELDON: Weakly Supervised Learning of Deep Convolutional Neural Networks
[12] https://openaccess.thecvf.com/content_CVPR_2019/html/Abu_Farha_MS-TCN_Multi-Stage_Temporal_Convolutional_Network_for_Action_Segmentation_CVPR_2019_paper.html — MS-TCN: Multi-Stage Temporal Convolutional Network for Action Segmentation
[13] https://proceedings.neurips.cc/paper/7181-attention-is-all-you-need — Attention Is All You Need
[14] https://arxiv.org/abs/1801.07455 — Spatial Temporal Graph Convolutional Networks for Skeleton-Based Action Recognition
[15] https://openaccess.thecvf.com/content/ICCV2021/html/Chen_Channel-Wise_Topology_Refinement_Graph_Convolution_for_Skeleton-Based_Action_Recognition_ICCV_2021_paper.html — CTR-GCN: Channel-Wise Topology Refinement Graph Convolution
[16] https://openaccess.thecvf.com/content/CVPR2022/html/Chi_InfoGCN_Representation_Learning_for_Human_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html — InfoGCN: Representation Learning for Human Skeleton-Based Action Recognition
[17] https://openaccess.thecvf.com/content/CVPR2022/html/Duan_Revisiting_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html — Revisiting Skeleton-Based Action Recognition (PoseC3D)
[18] https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html — Enhancing Skeleton-Based Action Recognition Through Realistic Data Augmentation
[19] https://arxiv.org/abs/2203.12602 — VideoMAE: Masked Autoencoders Are Data-Efficient Learners for Self-Supervised Video Pre-Training
[20] https://proceedings.neurips.cc/paper_files/paper/2017/hash/9ef2ed4b7fd2c810847ffa5fa85bce38-Abstract.html — Simple and Scalable Predictive Uncertainty Estimation Using Deep Ensembles
[21] https://biostats.bepress.com/ucbbiostat/paper222 — Super Learner
[22] https://www.cs.cornell.edu/~alexn/papers/shotgun.icml04.revised.rev2.pdf — Ensemble Selection from Libraries of Models
[23] https://statistics.berkeley.edu/sites/default/files/tech-reports/367.pdf — Stacked Regressions
[24] https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html — Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence
[25] https://proceedings.mlr.press/v54/eban17a.html — Scalable Learning of Non-Decomposable Objectives
[26] https://openaccess.thecvf.com/content/CVPR2021/html/Gong_KeepAugment_A_Simple_Information-Preserving_Data_Augmentation_Approach_CVPR_2021_paper.html — KeepAugment: A Simple Information-Preserving Data Augmentation Approach
[27] https://doi.org/10.1145/2382577.2382579 — Leakage in Data Mining: Formulation, Detection, and Avoidance
[28] https://arxiv.org/abs/1904.02438 — Cross Validation for Correlated Data
[29] https://arxiv.org/abs/1704.04861 — MobileNets: Efficient Convolutional Neural Networks for Mobile Vision Applications
[30] https://arxiv.org/abs/1912.06971 — Skeleton-Based Action Recognition with Multi-Stream Adaptive Graph Convolutional Networks
[31] https://arxiv.org/abs/2106.05237 — Knowledge Distillation: A Good Teacher Is Patient and Consistent
