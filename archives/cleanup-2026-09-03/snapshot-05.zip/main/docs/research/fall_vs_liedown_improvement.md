# Detictive 跌倒检测改进方法文档

> **版本**: v1.0  
> **日期**: 2026-08-18  
> **当前基线**: Top-k MIL 65.354% mAP, 84 FPs @ R90  
> **目标**: 消除 ≥30 FPs, mAP 提升至 70%+

---

## 1. 问题诊断

### 1.1 FP 分类统计

基于 `topkmil_val_r90_false_positives.csv` 的 84 个误报：

| 类别 | 数量 | 占比 | 根因 |
|------|------|------|------|
| lie_down | 32 | 38% | 🔴 模型分不清"主动躺下"和"跌倒" |
| other | 14 | 17% | 日常动作（弯腰、捡东西等）误报 |
| lying | 9 | 11% | 已躺平状态被误判为跌倒事件 |
| stand_up | 9 | 11% | 站起的反向运动被误判 |
| sit_down | 7 | 8% | 坐下过程误判 |
| fall/fallen | 10 | 12% | 真实跌倒但时间匹配失败 |
| walking/standing | 3 | 4% | 偶发误报 |

### 1.2 核心瓶颈

**当前评分公式**（`fusion.py`）：
```python
score = 0.72 * dynamic * posture_change + 0.28 * physical
```

**问题**：只用了"下坠距离"和"姿态变化"两个动态特征，**缺少以下关键判别信号**：

1. **冲击信号**：跌倒有地面冲击（加速度突变），主动躺下没有
2. **旋转速度**：跌倒时躯干快速旋转，躺下时缓慢
3. **速度剖面**：跌倒速度有峰值（先加速后急停），躺下速度平缓
4. **跌倒后状态**：跌倒后人保持不动，躺下后人会调整姿势

---

## 2. 改进方案

### 2.1 新增物理特征

在 `pipeline/rules.py` 的 `compute_pose_features` 中新增 4 个特征：

#### 2.1.1 中心点加速度（冲击检测）

**原理**：跌倒时身体撞击地面产生加速度突变（impulse），主动躺下没有。

**依据**：Bagalà et al. (2012), "Evaluation of Accelerometer-Based Fall Detection Algorithms on Real-World Falls"

```python
# 新增参数
previous_center_velocity: float | None = None,

# 在函数体内
if previous_center_velocity is not None and delta_seconds is not None:
    center_acceleration = max(0.0, center_velocity - previous_center_velocity) / delta_seconds
else:
    center_acceleration = 0.0
```

**预期效果**：消除 ~15-20 个 lie_down FP（这些 clip 没有冲击信号）

#### 2.1.2 躯干角速度

**原理**：跌倒时躯干从竖直快速旋转到水平（角速度大），主动躺下时旋转缓慢。

**依据**：多篇跌倒检测论文使用此特征区分 controlled vs uncontrolled descent

```python
# 新增参数
previous_verticality: float | None = None,

# 在函数体内
if previous_verticality is not None and delta_seconds is not None:
    torso_angular_velocity = abs(verticality - previous_verticality) / delta_seconds
else:
    torso_angular_velocity = 0.0
```

**预期效果**：消除 ~10-15 个 lie_down FP（这些 clip 旋转速度低）

#### 2.1.3 速度峰值比

**原理**：跌倒的速度曲线有明显峰值（先加速后急停），主动躺下速度平缓变化。

**依据**：Klenk et al. (2011), "Comparison of acceleration signals of simulated and real-world backward falls"

```python
# 在 TemporalFallScorer 中维护速度历史
velocity_history: list[float] = []

# 计算峰值比
if len(velocity_history) >= 3:
    peak = max(velocity_history)
    mean = sum(velocity_history) / len(velocity_history)
    velocity_peak_ratio = peak / max(mean, 1e-6)
else:
    velocity_peak_ratio = 1.0
```

**预期效果**：消除 ~10-15 个 lie_down FP（这些 clip 无速度峰值）

#### 2.1.4 手臂展开度

**原理**：跌倒时人本能伸手撑地（手臂展开），弯腰/坐下时手臂通常收拢。

```python
wrist_ids = [9, 10]
shoulder_ids = [5, 6]
if all(valid[i] for i in wrist_ids + shoulder_ids):
    wrist_dist = np.linalg.norm(keypoints[9, :2] - keypoints[10, :2])
    shoulder_dist = np.linalg.norm(keypoints[5, :2] - keypoints[6, :2])
    arm_spread = wrist_dist / max(shoulder_dist, 1e-6)
else:
    arm_spread = 0.0
```

**预期效果**：消除 ~5-8 个 other FP（弯腰、捡东西等）

### 2.2 改进评分公式

将新增特征融入 `TemporalFallScorer` 的评分逻辑：

```python
def update(self, timestamp, features) -> float | None:
    # ... 现有历史维护逻辑 ...
    
    # 原有特征
    dynamic = ...       # 下坠距离
    posture_change = ... # 姿态变化
    
    # 新增特征
    impact = float(np.clip(center_acceleration / 3.0, 0.0, 1.0))
    angular = float(np.clip(torso_angular_velocity / 2.0, 0.0, 1.0))
    peak = float(np.clip((velocity_peak_ratio - 1.5) / 2.0, 0.0, 1.0))
    arm = float(np.clip((arm_spread - 1.5) / 1.0, 0.0, 1.0))
    
    # 跌倒 = 快速下坠 + 冲击 + 快速旋转 + 速度峰值 + 伸手撑地
    # 躺下 = 慢速下坠 + 无冲击 + 缓慢旋转 + 无峰值 + 手臂收拢
    score = (
        0.30 * dynamic * posture_change   # 下坠 + 姿态变化
        + 0.25 * impact                    # 冲击证据
        + 0.20 * angular                   # 旋转证据
        + 0.15 * peak                      # 速度峰值
        + 0.10 * arm                       # 手臂展开
    )
    return float(np.clip(score, 0.0, 1.0))
```

### 2.3 排除规则（快速修复）

针对明确的误报模式，加硬规则排除：

```python
# 规则1: 站起方向排除
if features.center_velocity < 0:  # 负值 = 人在上升
    return None

# 规则2: 初始状态排除
if len(self.history) >= 3:
    initial_verticality = self.history[0][1]
    if initial_verticality < 0.5:  # 开始时已躺平
        return None

# 规则3: 持续时间过短排除
if len(self.history) < 3:  # 不到 3 帧的"跌倒"不可信
    return None
```

**预期效果**：
- 规则1 消除 ~9 个 stand_up FP
- 规则2 消除 ~9 个 lying FP
- 规则3 消除偶发抖动误报

---

## 3. 实施计划

### Phase 1: 快速修复（2-3 小时）

1. 在 `pipeline/fusion.py` 中加 3 条排除规则
2. 重新评估，预期消除 ~18 FPs

### Phase 2: 特征增强（3-4 小时）

1. 在 `pipeline/rules.py` 中新增 4 个物理特征
2. 更新 `PoseFeatures` dataclass
3. 更新 `TemporalFallScorer` 评分公式
4. 重新评估，预期再消除 ~20 FPs

### Phase 3: 阈值优化（1 小时）

1. 针对 MAP = (P@R90 + P@R95) / 2 优化 th_hi 和 th_lo
2. 网格搜索：th_hi ∈ [0.4, 0.6], th_lo ∈ [0.15, 0.35]

---

## 4. 预期效果

| 改进 | 消除 FP 数 | 累计 FP | 预期 mAP |
|------|-----------|---------|----------|
| 当前基线 | - | 84 | 65.35% |
| Phase 1: 排除规则 | ~18 | ~66 | ~67% |
| Phase 2: 特征增强 | ~20 | ~46 | ~69% |
| Phase 3: 阈值优化 | ~5 | ~41 | ~70% |
| **最终预期** | **~43** | **~41** | **~70%** |

---

## 5. 参考文献

1. Bagalà, F., et al. (2012). "Evaluation of Accelerometer-Based Fall Detection Algorithms on Real-World Falls." *PLoS ONE*, 7(5), e37062.
2. Mubashir, M., et al. (2013). "A survey on fall detection: Principles and approaches." *Neurocomputing*, 100, 144-152.
3. Klenk, J., et al. (2011). "Comparison of acceleration signals of simulated and real-world backward falls." *Medical Engineering & Physics*, 33(3), 368-373.
4. arXiv:2604.13279 (2026). "Explainable Fall Detection for Elderly Monitoring via Temporally Stable SHAP in Skeleton-Based Human Activity Recognition."
5. arXiv:2608.13197 (2026). "Beyond Simulated Benchmarks: Evaluating Motion Representations for Fall Detection Under Real-World Data Scarcity."

---

## 附录 A: 需要修改的文件清单

| 文件 | 修改内容 |
|------|----------|
| `pipeline/rules.py` | 新增 4 个物理特征，扩展 `PoseFeatures` |
| `pipeline/fusion.py` | 新增 3 条排除规则，更新评分公式 |
| `tests/test_rules.py` | 新增特征的单元测试 |
| `tests/test_fusion.py` | 排除规则的单元测试 |

## 附录 B: 关键参数说明

| 参数 | 含义 | 建议值 | 调参范围 |
|------|------|--------|----------|
| `acceleration_threshold` | 冲击加速度归一化分母 | 3.0 | [2.0, 5.0] |
| `angular_velocity_threshold` | 角速度归一化分母 | 2.0 | [1.5, 3.0] |
| `peak_ratio_offset` | 速度峰值比偏移 | 1.5 | [1.2, 2.0] |
| `arm_spread_threshold` | 手臂展开度阈值 | 1.5 | [1.2, 2.0] |
