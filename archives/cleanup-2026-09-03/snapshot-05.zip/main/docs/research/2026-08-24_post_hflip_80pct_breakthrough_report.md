# 跌倒检测 71.18% 后的 80% 突破方案

日期：2026-08-24  
依据：`stage_s1_hflip_three_seed_fixed_50_50.json`、当前训练/评估代码、既有实验摘要与公开论文  
目标：在不使用封存 test 调参的前提下，判断 80% 是否可达，并给出比继续堆 seed 更有幅度的技术路线

## 1. 结论先行

当前最优结果不是“模型文件不可用”，而是性能进入了同质模型集成的收益递减区：

- Stage-S1 最佳单模型 mAP 为 **70.2776%**。
- 基线与三个 HFlip seed 的固定 logit 集成达到 **71.1794%**。
- 集成相对单模型只增加 **0.9019 个百分点**；P@R90 和 P@R95 分别只增加约 **0.72** 和 **1.09 个百分点**。
- 三个 seed 与基线的两模型集成均值为 **70.8041%**，种子间仍有明显波动。

因此，继续增加相同结构、相同数据和相同目标函数的 HFlip seed，较合理的预期是再获得小于 1 个百分点，而不是补齐距 80% 的 **8.82 个百分点**。

真正的结构性问题是：数据管线已经解析了 `fall_process`、`post_fall_state`、`hard_negative` 等逐帧/事件区间语义，但当前主训练仍将片段压成视频标签，使用 top-k MIL；验证又以所有窗口概率最大值作为视频分数。也就是说，项目正在用弱监督方法处理已经具备较强时序监督的信息。

**首选突破方向应从“窗口分类器升级”改为“因果事件检测器”：先定位可信跌倒事件，再对事件整体判别。** 这是目前唯一有理由期待多点提升的路线。80% 仍应视为需要实验证明的信息上限目标，而不是一次改参可以保证的结果。

## 2. 当前结果到底说明了什么

### 2.1 当前模型与协议

当前单模型约 16.1 万参数，使用 16 帧窗口、步长 1，输入包含 joint、bone、motion、geometry、rules 和 discriminative kinematics 多流特征；主干是多尺度因果 TCN，并带阶段辅助分类头。

训练与推理的关键路径为：

1. 训练：每个 clip 的窗口 logit 进行 top 20% 聚合，再计算视频级损失。
2. 验证：对同一视频的所有窗口概率取最大值。
3. 选择指标：mAP、P@R90、P@R95。

这里存在两个限制：

- **监督浪费**：精确事件边界和阶段标签没有成为主目标。
- **聚合器偏差**：训练优化 top-k，验证使用 max；单个异常高分窗口可以造成整段视频假阳性。

### 2.2 80% 目标需要削掉多少误报

由当前 P@R 数值可反推验证集约有 222 个正样本：

| 工作点 | 当前 TP | 当前 FP | 当前精度 | 达到 80% 精度允许的 FP | 至少减少 |
|---|---:|---:|---:|---:|---:|
| R90 | 200 | 70 | 74.07% | 50 | 20（28.6%） |
| R95 | 211 | 98 | 68.28% | 52 | 46（46.9%） |

这是按指标分数反推的近似整数计数，但足以给出工程含义：要在高召回区进入 80%，必须消除约三成到近一半的假阳性，同时几乎不能损失真阳性。普通数据增强或多 seed 平均没有展示出这种能力。

### 2.3 已经被当前证据否定或明显降级的方向

以下路线不应继续作为主线：

- **继续堆同质 HFlip seed**：四模型集成仅带来 0.90 个百分点。
- **简单事件级 GRU 抑制器**：已有 seed 出现三项指标同时下降，说明后处理缺少稳定监督或候选定义不可靠。
- **冻结 Kinetics R3D-18 全局特征教师**：holdout mAP 约 40.91%，5 折 OOF MLP 约 44.37%，不具备教师资格。
- **轻量 pose jitter、时序扰动、遮挡**：没有稳定提升，不能承担 8.82 点缺口。
- **继续增加相似手工流**：当前错误更像事件语义和聚合问题，不是再增加一组局部运动统计即可解决。

这并不等于 RGB、长时序模型或事件验证器本身无效；它只否定了已经测试过的具体实现。

## 3. 新主线：从窗口 MIL 改为有边界监督的因果事件检测

### 3.1 为什么这是优先级最高的改动

MS-TCN 证明了多阶段时序卷积与平滑损失可改善帧级动作分割；ASRF 在分割分支之外显式回归动作边界，用边界信息缓解过分割；ActionFormer 则把多尺度时序特征、事件分类和边界回归统一到局部事件提议中。这些工作共同说明：当任务关心一个动作事件是否真实发生时，事件边界和片段一致性比孤立窗口最高分更适合建模。

项目现有标签已经包含 `fall_process` 和 `post_fall_state` 区间，因此无需先解决弱监督定位问题，可以直接训练强监督检测器。

### 3.2 建议的最小可验证结构

第一版不建议直接上大型 Transformer，而应保持当前骨架编码器，替换训练头和聚合方式：

```text
128/256 帧因果序列
        │
共享多尺度 TCN 编码器
        ├── 帧阶段头：background / hard-negative transition / fall / post-fall
        ├── 边界头：onset / offset 概率或距离
        └── 事件质量头：该候选是否为完整可信跌倒事件
        │
边界约束的事件提议
        │
视频分数 = 最佳有效事件的质量 × 跌倒概率
```

建议保留部署友好的因果约束，并做 16/32/64 或 32/64/128 帧的共享特征金字塔。这里的“多尺度”应扩大事件上下文，而不是复制三套完整网络。

### 3.3 损失函数

第一版损失可控制为四项：

\[
L = L_{stage} + \lambda_b L_{boundary} + \lambda_q L_{event} + \lambda_s L_{smooth}
\]

- `L_stage`：逐帧阶段交叉熵或 focal loss，按类别频率加权。
- `L_boundary`：起止边界 BCE，或到最近边界的距离回归。
- `L_event`：候选事件的 fall / hard-negative 二分类。
- `L_smooth`：截断时序平滑，限制相邻帧 log-probability 的不合理跳变。

不要一开始同时加入排序损失、蒸馏、对比学习和新增强。先验证事件建模本身是否带来至少 2 个百分点的 train-only OOF 提升。

### 3.4 候选事件定义

一个有效跌倒候选至少应满足：

1. 存在连续的 fall 阶段，而不是一个孤立尖峰。
2. onset 前存在合理的前置状态/下降运动。
3. fall 后进入 post-fall 或可解释的恢复状态。
4. 边界置信度、持续时间和阶段顺序通过约束。

这会直接攻击当前 max-window 聚合造成的“一个错误窗口否决整段视频”问题。

## 4. 第二主线：高召回候选 + 条件式难负样本验证器

事件检测器先以至少 97% 候选召回率产生少量候选，再由轻量 verifier 区分：

- 真跌倒；
- 主动躺下；
- 坐下/起立；
- 弯腰、蹲下；
- 检测抖动或身份切换；
- 已经躺卧但没有跌倒过程。

验证器输入应是候选前、候选内、候选后的 pooled token，而不是单帧或整段全局平均。可加入：

- 质心高度和垂直速度曲线；
- 身体主轴角度变化；
- 支撑面接近速度；
- 关键点置信度与缺失模式；
- 阶段持续时间和顺序；
- 活动类别条件。

在事件基线成立后，再加入 class-aware supervised contrastive loss。ACCV 2024 的 class-aware contrastive 方法明确针对易混淆细粒度骨架类别，使用相似类别 hard negatives 和 memory bank；它比全局无条件对比损失更贴合“跌倒 vs 主动躺下”问题。

**验收门槛：**候选召回率不低于 97%，并使受控过渡类假阳性减少至少 30%；否则不进入三 seed 正式实验。

## 5. 先做信息上限实验，避免继续盲调

在投入完整工程前，建议建立三层 oracle ladder。所有实验只在训练集内部做分组 5 折 OOF，不能再反复查看项目 validation。

### O1：非因果长上下文骨架 oracle

- 输入完整 track 或 128/256 帧序列。
- 允许双向时序建模和更大容量。
- 使用真实事件边界和阶段监督。

目的不是部署，而是判断现有骨架信息是否足以超过 80%。

### O2：PoseConv3D 热图 oracle

PoseConv3D 将关键点表示为空间-时间热图，保留定位不确定性，比坐标序列对姿态噪声更鲁棒。若 O2 显著高于坐标 oracle，说明当前坐标/手工特征表示是瓶颈，可以再压缩或蒸馏到轻量学生。

### O3：事件对齐 RGB oracle

之前失败的是冻结 Kinetics 全局分类特征，不足以否定视觉信息。新实验应围绕候选事件裁剪，微调 VideoMAE/视频骨干，并显式区分跌倒、主动躺下和遮挡。

决策规则：

| 结果 | 判断 | 下一步 |
|---|---|---|
| O1 ≥ 80 | 骨架信息足够，当前训练表述是主瓶颈 | 蒸馏到因果事件检测器 |
| O1 < 80，O2 ≥ 80 | 坐标表示损失信息 | PoseConv3D 教师或热图轻量化 |
| O1/O2 < 80，O3 ≥ 80 | 场景/外观信息不可缺 | RGB 在线融合或跨模态蒸馏 |
| 三者都 < 80 | 数据标签、任务可分性或划分是上限 | 清洗标签、补充近邻难例、重审 80 目标 |

只有 OOF 教师在整体 mAP 和 hard-negative 切片上都明显领先，才有资格用于蒸馏。建议最低教师门槛为相对当前 OOF 基线 **+3 个百分点**；若目标是冲击 80%，更理想是 **+5 个百分点以上**。

## 6. 蒸馏与现有四模型集成的正确用途

当前固定四模型集成已经证明 HFlip 和随机种子存在少量互补性。它适合解决部署成本，而不是作为 80% 的主要来源：

- 用 train-only OOF teacher logits，避免同折泄漏。
- 蒸馏帧阶段分布、边界分布、事件质量和中间 embedding。
- 加原图/HFlip 的事件级一致性约束。
- 学生保持一个共享因果主干。

目标是让单模型保留至少 95% 的教师增益。例如教师比单模型高 0.90 点，学生至少应保留约 0.86 点；这仍不会创造缺失的 8 个点，所以应排在事件检测主线之后。

## 7. 指标对齐：放在事件基线之后

当前 BCE 并不直接优化高召回区的 precision。完成事件级建模后，可在候选事件上增加：

- 正事件与同活动 hard negative 的 pairwise ranking；
- P@R90/P@R95 附近的局部难例采样；
- 可微 AUPRC surrogate。

NeurIPS 2021 的 AUPRC 优化工作和非分解指标优化研究说明，可以直接针对 PR 指标设计优化器；但这类损失对 batch 组成、类别先验和估计稳定性敏感。它应作为已有正确事件候选后的精修手段，不能替代候选定义和边界监督。

## 8. 验证协议必须升级

当前 validation 已被用于多次接受/拒绝 event GRU、多个增强和集成权重，因此它实际上已经是开发集，不能再称为完全未触碰的最终选择集。

后续采用：

1. 按源视频/人物/场景分组，在 train 内做固定 5 折 OOF。
2. 所有结构、阈值、损失权重和 teacher 选择只看 OOF。
3. 保存每个 clip 的预测、标签、活动、域、候选事件和错误原因。
4. 项目 validation 只用于已经锁定配置的一次确认。
5. test 始终封存。

必须同时报告：

- mAP、P@R90、P@R95；
- 三 seed 均值、标准差和 worst seed；
- R90/R95 的 TP/FP/FN 绝对数量；
- `lie_down`、`sit_down`、`stand_up`、遮挡/丢点等切片；
- 候选召回率与候选数/视频；
- 参数量、延迟和峰值显存。

## 9. 分阶段实验计划与停损线

### 阶段 E0：证据冻结（0.5 天）

- 冻结 split、特征版本、事件边界解析和当前基线预测。
- 建立 FP/FN 清单，人工抽查 R95 附近前 50 个负样本。
- 验证同一源视频/人物没有跨折泄漏。

通过条件：可以用同一脚本复现当前指标，且每个 FP 能追溯到活动、时刻和姿态质量。

### 阶段 O：oracle ladder（2–5 天/实验）

- O1 长上下文骨架。
- O2 PoseConv3D。
- O3 事件对齐 RGB，仅在 O1/O2 不足时启动。

停损：若最强 oracle 的 OOF mAP 仍低于 76%，先暂停部署模型优化，转向标签与数据可分性审计。

### 阶段 T：强监督时序事件基线（2–4 天）

- 当前 TCN 编码器 + 阶段头 + 边界头 + 平滑损失。
- 只比较聚合/监督表述，不同时改增强和主干。

通过条件：相同 OOF 划分上，mAP 至少增加 2 点，且 R95 的 FP 至少减少 20%，worst seed 不下降。

### 阶段 V：难负样本 verifier（2–3 天）

- 构造高召回事件候选。
- 加事件前/中/后条件验证器。
- 若基础 verifier 有效，再加入 class-aware contrastive。

通过条件：候选召回 ≥97%，受控过渡假阳性减少 ≥30%，整体 P@R95 不下降。

### 阶段 M：多尺度上下文与蒸馏（3–5 天）

- 共享 16/32/64 或 32/64/128 因果特征金字塔。
- 从胜出的 oracle/事件 teacher 蒸馏。

通过条件：三 seed 平均再增加至少 1.5 点，并保留 ≥95% teacher gain。

### 阶段 F：最终锁定

- 锁定配置、权重、阈值和随机种子。
- 仅一次运行 validation。
- 只有 validation 也满足预注册目标，才进入封存 test。

## 10. 目标拆解

不建议把“80%”写成单一 mAP 数字后不断试验。建议按下面的梯度决策：

| 里程碑 | mAP | P@R90 | P@R95 | 意义 |
|---|---:|---:|---:|---|
| 当前固定集成 | 71.18 | 74.07 | 68.28 | 已确认基线 |
| M1 | ≥73.5 | ≥76 | ≥72 | 事件监督成立 |
| M2 | ≥76.0 | ≥78 | ≥75 | verifier/长上下文成立 |
| M3 | ≥78.0 | ≥80 | ≥78 | 已接近产品级高召回 |
| Stretch | ≥80.0 | ≥80 | ≥80 | 需要 oracle 证明信息上限 |

若只提升 mAP 而 P@R95 仍在 70% 左右，不能宣称真正突破；实际难点正是高召回下的假阳性。

## 11. 最激进但仍有证据的方案

如果算力允许，建议将最终研究架构定义为：

> **长上下文 PoseConv3D/坐标双教师 + 轻量因果多尺度事件学生 + 边界监督 + 条件式 hard-negative verifier + OOF 跨模态蒸馏。**

它与当前路线的区别不是“更深一点”，而是同时解决四个信息损失：

1. 从 16 帧局部窗口扩展到事件级上下文。
2. 从视频弱标签恢复到已存在的阶段与边界监督。
3. 从 max-window 尖峰变为有合法边界的事件评分。
4. 从冻结全局 RGB 特征改为事件对齐教师，并只在教师确实更强时蒸馏。

这条路线工程量更大，但它有可逐级否证的 oracle 和停损线；比继续增加 seed、手工特征或轻量扰动更有机会接近 80%。

## 12. 近期不该做的事情

- 不再追加第 4、5、6 个同配置 HFlip seed 期待大幅提升。
- 不在当前 validation 上搜索 ensemble 权重或阈值。
- 不复用冻结 R3D-18 全局特征作为教师。
- 不把另一个简单 GRU/LSTM 后处理器当作主实验。
- 不同时修改主干、损失、采样、增强和聚合器，导致无法归因。
- 不在没有 oracle 证据时承诺 80%。

## 13. 文献依据

以下优先列原论文或官方会议页面：

1. Abu Farha & Gall, **MS-TCN: Multi-Stage Temporal Convolutional Network for Action Segmentation**, CVPR 2019. 多阶段 TCN、逐帧分类和平滑损失。  
   https://openaccess.thecvf.com/content_CVPR_2019/html/Abu_Farha_MS-TCN_Multi-Stage_Temporal_Convolutional_Network_for_Action_Segmentation_CVPR_2019_paper.html
2. Ishikawa et al., **Alleviating Over-Segmentation Errors by Detecting Action Boundaries**, WACV 2021. 分割与边界回归双分支。  
   https://openaccess.thecvf.com/content/WACV2021/html/Ishikawa_Alleviating_Over-Segmentation_Errors_by_Detecting_Action_Boundaries_WACV_2021_paper.html
3. Zhang et al., **ActionFormer: Localizing Moments of Actions with Transformers**, ECCV 2022. 多尺度事件分类与边界估计。  
   https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/136640485.pdf
4. Duan et al., **Revisiting Skeleton-Based Action Recognition**, CVPR 2022. PoseConv3D 与热图骨架表示。  
   https://openaccess.thecvf.com/content/CVPR2022/html/Duan_Revisiting_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html
5. Bian et al., **Class-Aware Contrastive Learning for Fine-Grained Skeleton-Based Action Recognition**, ACCV 2024. 面向易混淆骨架类别的 class-aware hard negative 与 memory bank。  
   https://openaccess.thecvf.com/content/ACCV2024/html/Bian_Class-Aware_Contrastive_Learning_for_Fine-Grained_Skeleton-Based_Action_Recognition_ACCV_2024_paper.html
6. Khosla et al., **Supervised Contrastive Learning**, NeurIPS 2020. 监督式对比学习基础。  
   https://proceedings.neurips.cc/paper/2020/hash/d89a66c7c80a29b1bdbab0f2a1a94af8-Abstract.html
7. Qi et al., **Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence**, NeurIPS 2021. 可微 AUPRC 优化。  
   https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html
8. Eban et al., **Scalable Learning of Non-Decomposable Objectives**, AISTATS 2017. 非分解指标优化。  
   https://proceedings.mlr.press/v54/eban17a.html
9. Lee et al., **Decomposed Cross-Modal Distillation for RGB-Based Temporal Action Detection**, CVPR 2023. 时序检测中的跨模态蒸馏。  
   https://openaccess.thecvf.com/content/CVPR2023/html/Lee_Decomposed_Cross-Modal_Distillation_for_RGB-Based_Temporal_Action_Detection_CVPR_2023_paper.html
10. Gao et al., **Fine-Grained Temporal Contrastive Learning for Weakly-Supervised Temporal Action Localization**, CVPR 2022. 细粒度时序对比与动作/背景分离。  
    https://openaccess.thecvf.com/content/CVPR2022/html/Gao_Fine-Grained_Temporal_Contrastive_Learning_for_Weakly-Supervised_Temporal_Action_Localization_CVPR_2022_paper.html
11. Duan et al., **SkeleTR: Towards Skeleton-Based Action Recognition in the Wild**, ICCV 2023. 面向真实场景多人物骨架识别。  
    https://openaccess.thecvf.com/content/ICCV2023/html/Duan_SkeleTR_Towards_Skeleton-Based_Action_Recognition_in_the_Wild_ICCV_2023_paper.html
12. Cormier et al., **Enhancing Skeleton-Based Action Recognition in Real-World Scenarios Through Realistic Data Augmentation**, WACV Workshops 2024. 现实姿态错误增强。  
    https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html
13. Noor et al., **A Lightweight Skeleton-Based 3D-CNN for Real-Time Fall Detection and Action Recognition**, ICCV Workshops 2023. 轻量骨架跌倒识别。  
    https://openaccess.thecvf.com/content/ICCV2023W/JRDB/html/Noor_A_Lightweight_Skeleton-Based_3D-CNN_for_Real-Time_Fall_Detection_and_Action_ICCVW_2023_paper.html
14. **OmniFall: A Unified Benchmark for Generalizable Fall Detection**, arXiv 2025. 跨数据集、跨域跌倒检测基准。  
    https://arxiv.org/abs/2505.19889

## 14. 最终判断

三个新模型可以组成有效集成，但其作用已经被实验定量限定：它们把结果从 70.28% 推到 71.18%，说明模型并非损坏，也说明同质多 seed 不是 80% 的路线。

下一轮研发应优先回答一个问题：**利用现有精确事件边界和长时序上下文后，骨架信息本身能否在严格 train-only OOF 上超过 80%？**

- 若能，实施因果事件检测与蒸馏，80% 有技术路径。
- 若不能但事件对齐 RGB oracle 能，必须引入外观信息或跨模态教师。
- 若所有 oracle 都不能，继续微调当前 TCN 只会消耗实验预算，应转向标签、数据和任务上限。

