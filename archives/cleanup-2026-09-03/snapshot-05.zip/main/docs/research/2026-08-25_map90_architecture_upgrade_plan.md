# clip mAP 90% 最新架构改良方案

日期：2026-08-25  
当前基线：固定四模型集成 clip mAP 71.1794%  
目标：在严格、未泄漏的验证协议下达到 clip mAP ≥90%，同时保持端侧纯视觉部署能力

## 1. 执行结论

从 71.18% 到 90% 需要增加 **18.82 个百分点**。当前四个同构骨架模型集成只增加 0.90 点，说明继续堆 seed、增加相似手工流、延长训练轮数或再加一层普通 Transformer，不具备足够的信息增量。

要冲击 mAP 90%，主架构必须从“骨架运动分类”升级为：

> **Pose 运动 + 人体外观 + 人体周边场景的 actor-centric 双模态时序模型，并通过类别原型和 AP 导向损失重塑排序。**

推荐新架构命名为 **EdgeFall-X90**：

```text
YOLO11n-Pose 共享前端
   ├── 17点骨架与轨迹 → 六流双尺度因果 TCN
   └── 共享特征图 → 人体 ROI + 周边 Context ROI → 轻量时序卷积
                         │
              Pose-quality gated cross-attention
                         │
          Fall / ADL-subtype / 3-state / prototype heads
                         │
       Focal + class-aware SupCon + prototype + AP fine-tuning
```

它不是第二个完整 RGB 网络：RGB 分支复用 YOLO11n-Pose 已经计算的特征图，只增加 ROI adapter、轻量时序模块和融合头。目标是把新增时序部分控制在约 2–3M 参数以内，总系统继续满足此前的 <20M 约束。

必须先说明：**没有任何现有证据能保证该项目一定达到 mAP 90%。** 近期通用时序动作检测在更复杂数据上的 mAP 也远低于 90；OmniFall 的真实事故跨域结果同样显示巨大上限差距。因此 90% 应作为分阶段、可停损的研究目标，而不是单次训练承诺。

## 2. 当前 mAP 瓶颈意味着什么

当前集成：

| 指标 | 数值 |
|---|---:|
| clip mAP | 71.1794% |
| P@R90 | 74.0741% |
| P@R95 | 68.2848% |

在约 222 个正例的 validation 上，可反推：

- R90：约 200 TP、70 FP；若 precision 也达到 90%，FP 必须降到不超过约 22，即减少至少 48 个。
- R95：约 211 TP、98 FP；若 precision 达到 85%，FP 必须降到不超过约 37，即减少至少 61 个。
- 若 R95 precision 也要求 90%，FP 必须降到不超过约 23，即减少约 75 个。

mAP 90%要求整条 precision-recall 排序曲线都接近高精度，而不是只在某个阈值上达到 90% Accuracy。现有模型要解决的核心问题是：

1. 将 `lie_down / lying / stand_up / sit_down` 等近邻负例排到绝大多数真跌倒之后；
2. 在关键点缺失、身份切换和遮挡时，不产生孤立极高分；
3. 在保持 90%–95% recall 时，大幅减少假阳性。

骨架坐标只描述“人怎样运动”，却缺少“人与什么接触、在哪里发生、关键点为什么消失”等信息。要削掉 50–75 个高排名 FP，必须引入当前模型没有的判别信息。

## 3. 新文献给出的最有价值证据

### 3.1 PG-ProtoFall：RGB + Pose 是最直接的新方向

2026 年 PG-ProtoFall 使用 EfficientNet-B0 外观分支和 ST-GCN pose 分支，将两者融合到共享 embedding，并联合优化：

- cross-entropy；
- supervised contrastive learning；
- prototype regularization。

论文报告，相对 pose-only baseline：

- URFD F1 从 90.7% 提升到 94.8%；
- UP-Fall F1 从 88.2% 提升到 93.0%；
- 严格 source-only 跨数据集 F1 分别增加 8.9 和 21.4 点；
- calibration error 同时下降。

这些是当前调研中最接近本项目问题的证据：只有新增长相、人体轮廓和场景关系等 appearance 信息，才展示过足以支撑多点提升的幅度。论文没有给出可直接外推到 OF-Syn 的精确 AP90 保证，因此只采用其结构原理，不复制其预期数字。

### 3.2 TubeLite：actor-centric ROI 与稳定轨迹优于整帧重模型

2026 年 TubeLite 强调：许多视频动作错误来自检测抖动、轨迹碎片和不稳定 actor representation，而不只是网络容量不足。它使用 actor-centric ROI、轻量时序传播和 tube consistency，在 UCF101-24 上获得 71.7 video-mAP@0.5，并较对比方法提高至少 7 点。

本项目不应照搬其边界检测头，因为上一版事件检测路线已被验证不可行；但可以迁移两点：

- 从整帧改为围绕跟踪人体提取稳定 ROI token；
- 把轨迹质量作为显式输入和正则，而不是假设 tracker 永远正确。

### 3.3 ContextDet：大/小核混合聚合比盲目堆 Transformer 更合适

ContextDet 使用多尺度的大核与小核时间卷积聚合局部和长上下文。对当前端侧模型而言，这比增加多层全局注意力更可控。建议 RGB ROI 分支使用 depthwise temporal kernels 3/7/15，而不是新的 GRU 抑制器或大型 Transformer。

### 3.4 class-aware contrastive 与 prototype regularization

ACCV 2024 的 class-aware contrastive learning 专门处理细粒度骨架类别相似问题，通过优先选择相似类别 hard negatives 和 memory bank 增强区分能力。它与 PG-ProtoFall 的 prototype regularization 共同支持：

> 训练时不能只告诉模型“这是负例”，还应告诉模型“这是主动躺下、站起或已经躺卧”，并为每类建立结构化原型。

这与已失败的全局 hard-negative ranking 不同：旧损失直接推整个 clip 分数，容易损伤召回；新损失作用于融合 embedding，并按活动类别选择近邻负例。

### 3.5 直接优化 AP 可以做，但只能作为最后精修

NeurIPS 的 SOAP 方法提供了可收敛的 AUPRC/AP 优化思路。它有机会改善排序，但不能凭空补回骨架里不存在的场景信息。因此必须在 RGB–Pose 融合已经取得稳定提升后，才进行 AP surrogate fine-tuning。

### 3.6 OmniFall 仍然是可信边界

OmniFall 显示 staged、synthetic 和 in-the-wild 域高度分离。其 combined staged + synthetic 在真实事故域的 Fall F1 约 65.6%，加入目标域训练数据后约 76.0%。因此：

- 当前 validation 上达到 mAP90，不等于真实场景 mAP90；
- 若最终验收包含跨域，数据多样性和少量目标域训练数据是必要条件；
- 不允许用单个经典数据集的 99% Accuracy 为本项目承诺 mAP90。

## 4. EdgeFall-X90 完整架构

### 4.1 共享视觉前端

保留当前 `YOLO11n-Pose`：

```text
RGB Frame
   │
   ▼
YOLO11n-Pose Backbone + Neck
   ├── pose detections / 17 keypoints
   └── P3/P4 feature maps
```

同一次前向同时提供 pose 与 RGB 特征，不新增 EfficientNet-B0。第一阶段冻结 YOLO；只有融合模型证明有效后，才解冻 backbone 最后一个 stage，并使用主学习率的 0.05–0.1 倍微调。

### 4.2 Skeleton Motion Branch

最大程度复用当前六流 checkpoint：

```text
17 keypoints + confidence
   ├── Joint 51D
   ├── Bone 32D
   ├── Motion 34D
   ├── Geometry 6D
   ├── Rules 12D
   └── Kinematics 15D
        │
        ├── Local: 最近16帧，原始帧率
        └── Context: 最近48帧，每2帧采样
             │
             ▼
       共享多尺度因果TCN
       kernels 3/5/7, dilation 1/2/4/8
             │
             ▼
       skeleton tokens: [B,T,128]
```

重要变化是保留时序 token，而不是每个流只取最后一帧 embedding。六流先在每个时间点融合到 128D，再送入跨模态融合。

### 4.3 Actor Appearance Branch

对每个 track 从 YOLO P3/P4 特征图提取两种 ROI：

```text
Person ROI：原人体框，强调人体轮廓、姿态遮挡和接触形态
Context ROI：人体框扩大到1.4–1.6倍，包含地面、床、沙发和障碍物
```

处理方式：

```text
ROIAlign 7×7
→ depthwise separable 2D adapter
→ spatial attention pooling
→ 128D/frame
→ causal depthwise temporal conv，kernels 3/7/15
→ appearance tokens: [B,T,128]
```

不直接使用整帧 RGB，避免模型记住房间背景；Context ROI 只保留与人体接触相关的有限范围。

### 4.4 Pose Quality Branch

每帧构建约 10–16D 质量向量：

- visible-joint ratio；
- mean/min keypoint confidence；
- bbox confidence；
- association IoU；
- center/scale jump；
- missing streak；
- track age；
- left/right swap risk。

经过小 MLP 得到 `quality token` 和两个门值：

```text
g_pose ∈ [0,1]
g_rgb  ∈ [0,1]
```

当 pose 可靠时以骨架为主；pose 缺失或跳变时提高 appearance 权重。门控必须连续可学习，不使用硬阈值覆盖分类结果。

### 4.5 Cross-modal Fusion

采用一层双向 cross-attention：

```text
Skeleton queries ← Appearance keys/values
Appearance queries ← Skeleton keys/values
```

然后按质量门控融合：

```text
z = LayerNorm(
      g_pose × z_pose
    + g_rgb  × z_rgb
    + z_cross
)
```

只使用一层、4 heads、`d_model=128`。若一层不能提升，不增加第二层。

### 4.6 多头输出

```text
z
├── Binary AP head：Fall vs Non-Fall，最终排名分数
├── ADL subtype head：fall / lie_down / lying / stand_up / sit_down / other
├── 3-state head：Normal / Falling / Fallen
├── Prototype head：到各类别原型的余弦距离
└── Quality head：预测该窗口/clip是否受pose错误影响
```

最终 clip 分数仍由 binary AP head 产生。辅助头仅塑造 embedding，不通过手写规则直接修改 mAP 分数。

## 5. 训练目标

分三阶段训练，不能从第一轮同时打开所有损失。

### Stage 1：稳定融合

```text
L1 = weighted focal binary
   + 0.25 × ADL subtype CE
   + 0.15 × 3-state CE
```

- 冻结 YOLO backbone；
- current skeleton checkpoint 初始化运动分支；
- 新 RGB/fusion heads 随机初始化；
- 先训练新 heads 2–3 epochs，再联合训练时序模块。

### Stage 2：结构化表示

Stage 1 收敛后加入：

```text
L2 = L1
   + 0.10 × class-aware supervised contrastive
   + 0.05 × prototype compactness/separation
```

对比样本只从同一数据域、相同人物尺度区间内选择，重点构造：

- fall vs lie_down；
- fall vs stand_up；
- falling vs sitting/bending；
- fallen vs lying。

不把所有负例都当同一种 hard negative。

### Stage 3：AP fine-tuning

只有 Stage 2 的 grouped OOF mAP 已超过 82%，才执行：

```text
L3 = 0.5 × L2 + 0.5 × AP surrogate
```

训练 batch 必须包含足够正例和活动平衡负例。SOAP/LibAUC 类方法对 batch 组成敏感，先做 1–3 epoch 小学习率 fine-tuning，不从头训练。

## 6. 数据管线改造

### 6.1 新建 actor-tube feature cache

现有 pose cache 继续保留；新增与其严格对齐的 RGB tube cache：

```text
clip_id / track_id / timestamp
person ROI feature
context ROI feature
track quality vector
pose feature reference
```

必须记录 YOLO checkpoint hash、输入尺寸、ROI 扩张比例、feature level 和 tracker 版本，避免不同缓存静默混用。

### 6.2 防止 RGB 分支记住背景

训练时使用：

- person ROI / context ROI 随机门控；
- color jitter、灰度、亮度和压缩伪影；
- context dropout；
- 同活动跨场景正对；
- 不同活动同场景负对；
- 按 dataset/domain 平衡采样。

不能使用会改变动作语义的大幅时序扰动。此前 pose jitter 失败不代表 RGB photometric/domain augmentation 无效，两者作用对象不同。

### 6.3 数据扩展

开发顺序：

1. OF-Syn 内部 grouped OOF，验证架构增益；
2. OF-Syn + OF-Staged 联合训练；
3. 按 dataset 留一域验证；
4. 若产品目标包含真实视频，必须加入合法获取的目标域训练/校准集。

禁止在当前反复使用过的 validation 上搜索损失权重和融合策略。

## 7. mAP90 分阶段里程碑

不允许从 71.18 直接启动一个“全功能模型”。按以下里程碑推进：

| 里程碑 | 目标 mAP | 必须达到的辅助指标 | 说明 |
|---|---:|---:|---|
| B0 | 71.18 | 复现当前 P@R90/P@R95 | 当前固定基线 |
| M1 | ≥76 | P@R90 ≥78 | actor ROI 信息确有互补 |
| M2 | ≥82 | P@R90 ≥83，P@R95 ≥76 | 融合与长上下文成立 |
| M3 | ≥86 | P@R90 ≥87，P@R95 ≥82 | prototype/SupCon成立 |
| M4 | ≥88 | P@R90 ≥89，P@R95 ≥85 | 数据扩展和AP精修成立 |
| Stretch | **≥90** | P@R90 ≥90，P@R95 ≥85 | 最终 mAP90 候选 |

这些提升不能简单相加。每一级必须由独立 OOF 结果证明，未达门槛就停止组合。

## 8. 实验矩阵和停损条件

| ID | 唯一改动 | 通过条件 | 失败处理 |
|---|---|---|---|
| R0 | RGB person/context ROI 单分支 | 单分支 mAP ≥65，且与骨架错误相关性 <0.85 | 若无互补，停止 RGB 主线 |
| F1 | 当前 skeleton + person ROI late fusion | 相对单模型 +3 mAP | 检查ROI/track对齐，不先加损失 |
| F2 | 增加 Context ROI | `lie_down/lying` FP -20%，总体 +1.5 mAP | context无效则删除 |
| F3 | quality-gated cross-attention | pose-error FP -25%，总体 +1 mAP | 回退简单concat |
| T1 | 16+48 skeleton context | 相对 F3 +1.5 mAP | 长上下文无效则保留16帧 |
| C1 | class-aware SupCon | 相对 T1 +1.5 mAP，worst seed不降 | 降低权重或停用 |
| P1 | prototype regularization | hard-negative切片 +2 F1，总体 +1 mAP | 原型不稳定则停用 |
| A1 | AP surrogate fine-tune | 相对 P1 +1 mAP，P@R95不降 | 回退 focal checkpoint |
| D1 | OF-Staged联合训练 | 留一域 BAcc/F1 +3 | 重审域采样比例 |
| Q1 | INT8/FP16部署 | mAP损失 <0.3 | 保持FP16相关层 |

三条硬停损线：

1. `F1 + F2 + F3` 后 mAP 仍低于 78：RGB tube 信息没有被正确提取或数据本身不可分，不继续堆损失。
2. `T1 + C1 + P1` 后 mAP 仍低于 84：停止承诺当前数据上的 mAP90，优先数据清洗和新增目标域样本。
3. 任一改动只提升反复使用过的 validation、但 train-only grouped OOF 不提升：视为验证集过拟合，立即撤销。

## 9. 错误驱动的数据闭环

每次 OOF 保存前 200 个高分负例和低分正例，按以下标签人工/半自动归因：

```text
FP:
  controlled_lie_down
  already_lying
  stand_up
  sit_or_bend
  pose_missing
  id_switch
  camera_motion
  scene_bias
  annotation_error

FN:
  occluded_fall
  small_person
  slow_fall
  partial_fall
  rapid_recovery
  unusual_view
  pose_failure
  annotation_error
```

只有占 FP 至少 10% 的错误类别才值得增加专门模块。mAP90需要错误数量真正减少，而不是平均指标偶然波动。

## 10. 为什么不选择其他路线

### 不再增加同质 seed

已有四模型集成增益只有 0.90 点，无法覆盖 18.82 点缺口。

### 不再使用冻结 R3D-18 全局特征

旧实验 holdout/OOF mAP 约 40.9%/44.4%。新 RGB 分支的区别是：actor-aligned ROI、复用 pose backbone feature、端到端训练和 context pairing，而不是冻结整段全局特征。

### 不重复事件分割/oracle 主线

该方案已被用户验证不可行。EdgeFall-X90 只做 clip ranking，并使用轨迹对齐 token；不要求边界回归或精确事件 proposal。

### 不使用简单 GRU 抑制器

旧 GRU 已有不稳定结果。新 RGB 分支使用多核 causal temporal conv；tracker 质量通过显式 token 进入模型。

### 不先上 ST-GCN/CTR-GCN replacement

当前最缺的是 appearance/context，而不是骨架拓扑容量。PG-ProtoFall 的价值是双模态结构化融合，不是单独证明 ST-GCN 必然优于当前多流 TCN。

## 11. 参数与端侧预算

建议预算：

| 模块 | 新增参数预算 |
|---|---:|
| Skeleton双尺度投影/融合 | 0.3–0.6M |
| ROI spatial adapters | 0.5–1.0M |
| ROI temporal conv | 0.3–0.6M |
| Cross-modal fusion | 0.3–0.6M |
| 多任务/prototype heads | <0.2M |
| **新增合计** | **约1.4–3.0M** |

加上当前 YOLO11n-Pose，整体仍应远低于 20M。部署优先 FP16；只有 FP16 通过后再做 INT8。由于 ROI 特征来自共享 backbone，计算增加主要来自 ROIAlign 和小型时序头，而不是第二次完整图像推理。

## 12. 推荐实施顺序

```text
Phase 0：基线冻结与OOF预测归档
    ↓
Phase 1：构建person/context ROI cache，训练RGB单分支R0
    ↓ 仅当R0有互补错误
Phase 2：late fusion F1 → context F2 → quality gate F3
    ↓ 仅当mAP≥78
Phase 3：16+48双尺度T1
    ↓
Phase 4：class-aware SupCon C1 → prototype P1
    ↓ 仅当mAP≥82
Phase 5：AP surrogate A1
    ↓
Phase 6：OF-Staged联合训练D1与域验证
    ↓ 仅当OOF mAP≥88
Phase 7：锁定一次validation，冲击mAP90
```

第一轮不要实现全部架构。最小 canary 是：

> **冻结 YOLO11n-Pose → 提取 person/context ROI tokens → 与当前 skeleton embedding 做简单 concat late fusion。**

如果这个 canary 不能带来至少 3 个 mAP 点，就说明 RGB 特征选择或数据对齐有问题；此时直接实现 cross-attention、SupCon 和 prototype 只会放大复杂度。

## 13. 文献清单

1. Elmi, **PG-ProtoFall: Hybrid appearance–pose representation with supervised contrastive and prototype-based regularization for robust, calibrated cross-dataset fall detection**, Biomedical Signal Processing and Control, 2026.  
   https://www.sciencedirect.com/science/article/abs/pii/S174680942601195X
2. Schneider et al., **OmniFall: A Unified Staged-to-Wild Benchmark for Human Fall Detection**, 2025.  
   https://arxiv.org/abs/2505.19889
3. Soltaninezhad et al., **TubeLite: Lightweight Multi-Actor Spatio-Temporal Action Detection**, 2026 preprint.  
   https://arxiv.org/abs/2607.04684
4. Wang et al., **ContextDet: Temporal Action Detection with Adaptive Context Aggregation**, 2024 preprint.  
   https://arxiv.org/abs/2410.15279
5. Bian et al., **Class-Aware Contrastive Learning for Fine-Grained Skeleton-Based Action Recognition**, ACCV 2024.  
   https://openaccess.thecvf.com/content/ACCV2024/html/Bian_Class-Aware_Contrastive_Learning_for_Fine-Grained_Skeleton-Based_Action_Recognition_ACCV_2024_paper.html
6. Qi et al., **Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence**, NeurIPS 2021.  
   https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html
7. Cormier et al., **Enhancing Skeleton-Based Action Recognition in Real-World Scenarios Through Realistic Data Augmentation**, WACV Workshops 2024.  
   https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html
8. Yu et al., **A Real-time skeleton-based fall detection algorithm based on temporal convolutional networks and transformer encoder**, Pervasive and Mobile Computing, 2025.  
   https://www.sciencedirect.com/science/article/abs/pii/S1574119225000057
9. Liu et al., **End-to-End Temporal Action Detection with 1B Parameters Across 1000 Frames**, CVPR 2024. 其复杂任务最好结果为 75.4% mAP，说明“加大模型即可90%”没有普遍依据。  
   https://openaccess.thecvf.com/content/CVPR2024/html/Liu_End-to-End_Temporal_Action_Detection_with_1B_Parameters_Across_1000_Frames_CVPR_2024_paper.html

## 14. 最终判断

如果目标是真正的 clip mAP ≥90%，最新且最合理的主线不是继续优化纯骨架 TCN，而是：

> **复用 YOLO11n-Pose 特征的 actor-centric RGB–Pose 双流模型，加入人体/场景双 ROI、pose-quality 门控融合、class-aware supervised contrastive、类别原型约束，并在最后阶段直接优化 AP。**

这条路线具备三个当前系统没有的能力：

1. 利用床、地面、沙发、障碍物和人体轮廓信息消除近邻假阳性；
2. 在 pose 错误时动态依赖 appearance，而不是让错误骨架产生极高分；
3. 通过 subtype prototype 和 AP loss 直接改善高召回区排序。

最先要做的不是完整实现，而是 RGB ROI canary。它是整个 mAP90 路线的关键生死门：**若简单 RGB–Pose late fusion 都不能稳定增加至少 3 个 mAP 点，则当前数据或标签不足以支撑该架构，应停止堆模型并转向数据闭环。**

