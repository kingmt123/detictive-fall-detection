# 沿原最佳模型继续改进：Stage-S1-R2 工程报告

日期：2026-08-25  
目标：不更换骨架轨迹输入和六流因果 TCN 主体，在旧最佳可精确复现、可随时回退的前提下继续提高 clip mAP、P@R90 和 P@R95

## 1. 结论

沿原最佳模型继续走是可行的，但合理目标应分成两层：

- **第一目标：mAP 75%–78%**。主要依靠训练/推理聚合对齐、16+48 帧共享权重双时间尺度、四模型知识回灌和低容量残差聚合器。
- **条件目标：mAP 80% 左右**。只有前述改造在严格 train-only grouped OOF 中已经达到至少 76%，再启动跨流残差适配和 AP 导向精修。
- **mAP 90% 不应由这条路线直接承诺**。输入仍是同一套 2D 骨架、bbox 和派生运动量，无法凭结构调整补回已经丢失的接触、遮挡和场景信息。从 71.18% 到 90% 是 18.82 点缺口，现有同质集成只证明了约 0.90 点增益。

推荐架构命名为 **Stage-S1-R2（Anchor-Preserving Multi-Horizon Residual TCN）**：

```text
                         ┌─ 原16帧六流编码器 ─ 原fusion/head ─ z_old(t)
48帧历史骨架轨迹 ────────┤                         │
                         └─ 每3帧采样16点 ─ 共享六流编码器 ─ context residual
                                                   │
                                  z_window(t) = z_old(t) + Δcontext(t)
                                                   │
                     旧max分数 + 低容量证据残差聚合器
                                                   │
                                          clip ranking score
```

核心原则只有一条：**所有新增模块均零初始化为残差，初始输出必须等于旧模型；任何改动未通过 OOF，就将该残差系数归零，而不是重训整套替代模型。**

## 2. 已验证基线与事实边界

### 2.1 当前真正落地的最佳模型

当前单模型 `MultiStreamMultiScaleAttentionTCN` 的有效配置为：

| 项目 | 当前值 |
|---|---|
| 窗口 | 16 帧，stride 1，至少 8 帧可观测 |
| 六流 | joint 51D、bone 32D、motion 34D、geometry 6D、rules 12D、kinematics 15D |
| 单流编码 | 1×1 投影到 32 通道；卷积核 3/5/7；膨胀率 1/2/4/8 |
| 时序读取 | 4 头因果注意力后只读取最后一个 token |
| 融合 | 六流 embedding 拼接、SE 门控、二分类头 |
| 辅助任务 | 4 类阶段头，权重 0.2 |
| 训练聚合 | 每个 clip 的 top 20% window logits 均值 |
| 验证聚合 | 每个 clip 的 window probability 最大值 |
| 参数量 | 约 161,406 |

当前最佳候选是 Stage-S1 基线与三个 HFlip seed 的固定 logit 集成：

| 指标 | Stage-S1 单模型 | 固定四模型集成 |
|---|---:|---:|
| mAP | 70.2776% | **71.1794%** |
| P@R90 | 73.3577% | **74.0741%** |
| P@R95 | 67.1975% | **68.2848%** |

### 2.2 必须澄清的架构状态

当前代码和三个新 JSON 配置的 `window_size` 都是 **16**。因此：

- “六流 16 帧因果 TCN”是已训练、已验证的旧最佳主体；
- “16+48 帧双尺度”是本报告建议新增的第一项结构升级，不应写成既有模型已经具备的能力；
- 三个 JSON 是训练配置，不是权重文件；是否可推理还需要对应 checkpoint、缓存协议和代码版本。

## 3. 为什么旧最佳有效

旧模型不是因为某个新颖大模块有效，而是多个强先验恰好与任务匹配：

1. **六流分解降低学习难度**：位置、骨骼关系、速度、bbox、姿态规则和判别运动学分别编码，使 16 万参数也能学习有效决策。
2. **多核因果 TCN 同时覆盖快慢局部运动**：3/5/7 核和 1/2/4/8 膨胀率对快速冲击、缓慢下降和姿态稳定均有响应。
3. **困难负例采样对准真实混淆**：`lie_down / lying / stand_up` 被显式提高采样概率。
4. **阶段辅助头提供弱时序语义**：即使最终仍是窗口分类，表示空间不只学习 fall/non-fall。
5. **HFlip 多种子集成降低方差**：四模型增益虽小但稳定，证明镜像不变性和训练方差仍有可利用空间。

因此，下一步应保护这些有效部分，优先修正信息读取和优化协议，而不是替换骨架输入或重写主干。

## 4. 当前瓶颈

### 4.1 训练和推理的 clip 聚合不一致

训练优化 top 20% logits 均值，验证使用单个最大概率。一个短暂的错误高峰在训练损失中会被其余 top-k 稀释，但推理时可以单独决定视频分数。这是最明确、最便宜的可修复瓶颈。

### 4.2 每个流最终只保留最后 token

因果注意力允许最后 token 查看历史，但网络仍被要求把整个 16 帧事件压进一个位置。姿态缺失、窗口切边或最后几帧无效时，这个读取方式容易不稳定。

### 4.3 六流在编码完成前互不通信

joint、motion、rules、kinematics 分别形成一个 64D 向量，直到最终拼接才交互。模型可以知道“存在水平姿态”和“存在下降速度”，但较难在中间时序层直接学习二者是否同时发生。

### 4.4 16 帧只能看到局部片段

`fall` 与 `lie_down/stand_up` 的差异常由更长的前因和后续稳定状态决定。直接把窗口扩大到 48 帧会改变输入分布和旧权重行为；更稳妥的方法是保留原 16 帧分支，再添加共享权重的稀疏 48 帧残差分支。

### 4.5 集成知识没有回到单模型

固定四模型比任一基础成员更稳，说明不同 seed 和 HFlip 视图包含少量互补排序信息。目前这些信息只在推理时求平均，没有成为下一代模型的训练目标。

## 5. Stage-S1-R2 完整架构

### 5.1 不动的部分

以下模块第一阶段完全复用旧 checkpoint：

- 六种输入特征及其维度；
- 每流 32 通道、64D 输出；
- 3/5/7 多核深度卷积；
- 1/2/4/8 因果膨胀率；
- 原六流 encoder 参数；
- 原 fusion SE、binary classifier 和 stage classifier；
- 原 hard-negative activity 采样集合。

### 5.2 M1：聚合一致化残差

对每个视频保留完整窗口 logit 序列 `z_1...z_n`，构造以下固定统计量：

```text
max_logit
top3_mean
top20pct_mean
max - top3_mean
超过 top1-δ 的连续峰宽
对应窗口的 fall-process / post-fall 阶段置信
```

最终分数定义为：

```text
S_old = max(z_1...z_n)
S_new = S_old + clip(r_pool(stats), -c_pool, c_pool)
```

`r_pool` 只使用一个 8–16D bottleneck MLP，最后线性层权重和偏置置零。这样初始 `S_new == S_old`。它不是新的 GRU 事件抑制器：不生成候选、不递归建模、不用手写阈值否决，只学习“孤立尖峰与持续证据”对旧 max 分数的微小校正。

训练时 clip loss 必须直接作用于 `S_new`，消除 top-k 训练、max 推理的目标错位；窗口 BCE 和阶段辅助损失继续保留。

### 5.3 M2：16+48 帧共享权重双时间尺度

对每个时刻 `t` 构造：

- local：`x[t-15:t]`，即原模型 16 帧输入；
- context：`x[t-45:t:3]`，在最近约 48 帧内每 3 帧取样，共 16 个时点；不足部分使用显式 mask，不复制首帧。

两个尺度调用同一组六流 encoder，避免复制主干：

```text
e_local   = Encoder6(x_local)
e_context = Encoder6(x_context)
Δ_context = Linear_zero(MLP([e_local, e_context, e_local-e_context]))
z_window  = z_old(x_local) + clip(Δ_context, -c_ctx, c_ctx)
```

`Linear_zero` 零初始化，训练第一步的每个 window logit 与旧模型严格相同。上下文分支只负责修正旧模型，不能绕过旧 classifier 独立决定结果。

建议先冻结旧六流 encoder 2 个 epoch，只训练 context adapter；通过 canary 后再解冻每流最后一个 TCN block，学习率为新 adapter 的 0.1 倍。不要一开始全量微调。

### 5.4 M3：跨流残差适配器

将六个 64D stream embedding 视为 6 个 token，增加一层低容量交互：

```text
E ∈ R[B,6,64]
E_cross = TransformerEncoder(E, heads=2, FFN=128)
Δ_stream = Linear_zero(flatten(E_cross - E))
z = z_previous + clip(Δ_stream, -c_stream, c_stream)
```

此模块只在 M1+M2 已稳定提升后测试。它解决“六流直到末端才交互”，但不替换原 concat+SE。最后投影零初始化，保证旧路径仍是 anchor。

### 5.5 M4：四模型 OOF 教师回灌

HFlip 有效的最直接利用方式不是继续增加 seed，而是让下一代模型学习固定集成的排序：

```text
L_distill = T² × BCEWithLogits(z_student/T, sigmoid(z_teacher_oof/T))
L_flip    = SmoothL1(z_student(x), z_student(HFlip(x)))
```

- teacher 必须是 train-only grouped OOF 四模型预测，不能用同折模型给训练样本打软标签；
- 对 teacher 四成员分歧大的样本降低蒸馏权重，避免学习偶然错误；
- HFlip 一致性只约束 clip/window logit，不要求中间坐标逐点相同；
- 第一目标是让一个 Stage-S1-R2 单模型达到或超过旧四模型 71.18%，第二目标才是将它作为异质新成员重新集成。

## 6. 训练目标与开启顺序

不要同时打开所有损失。完整候选目标为：

```text
L = L_window_bce
  + 0.5 × L_clip_aligned
  + 0.2 × L_stage
  + λ_distill × L_distill
  + λ_flip × L_flip
  + λ_ap × L_ap
```

其中：

- `L_clip_aligned` 直接使用最终 `S_new`；
- `λ_distill` 从 0.1、0.25 两档做 canary，不连续搜索；
- `λ_flip` 只在蒸馏单独通过后测试；
- `L_ap` 只在 grouped OOF mAP 已达到 76% 后，以小学习率精修 1–3 epoch；
- 不恢复已经无稳定增益的通用 hard-negative ranking loss；当前 activity-aware 采样保留不变。

## 7. 实验矩阵

所有实验使用完全相同的 train-only grouped 5-fold OOF、三个固定 seed；当前 frozen validation 只允许锁定最终配置后运行一次。

| ID | 相对上一阶段的唯一改动 | 通过条件 | 停损条件 |
|---|---|---|---|
| R0 | 复现旧单模型与固定集成 | 指标误差 ≤0.1 点 | 不能复现则停止全部研发 |
| R1 | M1 聚合一致化残差 | mAP +≥1.0，P@R95 +≥1.5，P@R90 下降 <0.3 | 3 seed 中 2 个反向即删除 M1 |
| R2 | M2 共享 16+48 context residual | 相对 R1 mAP +≥1.5，`lie_down/stand_up` FP -≥15% | context 系数趋近 0 或 recall 明显下降即删除 |
| R3 | M4 OOF 集成蒸馏 | 单模型达到旧集成增益的 ≥90%，worst seed 提升 | 只提升同折预测视为泄漏/过拟合 |
| R4 | M3 跨流残差适配器 | 相对 R3 mAP +≥0.8，P@R90/P@R95均不降 | 错误重叠不变或 worst fold -≥0.5 即删除 |
| R5 | AP surrogate 精修 | mAP +≥0.8，P@R95不降 | batch/seed不稳定则回退 R4 |
| E1 | 将最佳 R 模型加入旧 ensemble | ensemble mAP +≥0.5，至少一个 P@R 提升 | 与旧成员错误相关性过高则只部署单模型 |

“通过”要求三 seed 均值达标、至少 4/5 outer folds 同向，并报告 worst seed；不能用某一个最好 seed 替代。

## 8. 指标和统计验收

每次实验至少保存：

- 每个 clip 的 `clip_id / group_id / label / activity / fold / score`；
- mAP、P@R90、P@R95；
- R90/R95 下的 TP、FP、FN 绝对数；
- `lie_down / lying / stand_up / sit_down / pose_missing / id_switch` 切片；
- 五折结果、三 seed 均值/标准差/worst seed；
- 与 R0 的 group-paired bootstrap 95% CI。

采用 10,000 次按 source-video/group 的配对 bootstrap。只有点估计提升但 95% CI 大量跨过 0 的实验标记为“待确认”，不进入下一阶段叠加。

## 9. 防泄漏约束

1. 以源视频、人物或生成模板为 group，group 不得跨折。
2. OOF teacher 的每条训练预测必须来自未见过该 group 的模型。
3. 聚合器、残差裁剪幅度、蒸馏权重和 AP 精修轮数只在 inner folds 选择。
4. outer fold 只评估一次；当前 1,200 条 frozen validation 不参与结构选择。
5. 缓存必须记录 config hash、checkpoint hash、代码签名和 fold id；不匹配时直接失败。

## 10. 代码改造边界

建议新增而非重写现有文件：

```text
models/stage_s1_r2.py                     # 旧模型包装器、双尺度和零初始化残差
models/evidence_pooling.py                # clip证据统计与低容量残差聚合器
tools/export_stage_s1_oof.py              # grouped OOF预测与教师生成
tools/train_stage_s1_r2.py                # 分阶段冻结/解冻训练
tools/evaluate_stage_s1_r2.py             # clip指标、切片和bootstrap
configs/stage_s1_r2/r1_pool.json
configs/stage_s1_r2/r2_context48.json
configs/stage_s1_r2/r3_distill.json
configs/stage_s1_r2/r4_cross_stream.json
```

第一阶段不修改 `models/multiscale_multistream_tcn.py` 的旧类签名和 checkpoint schema；在包装器中调用旧模型，避免破坏三个现有配置和权重加载。

## 11. 必须先写的回归测试

| 测试 | 验收 |
|---|---|
| 零残差等价 | 所有新增 head 零初始化时，window/clip logits 与旧模型数值一致 |
| 16 帧路径等价 | 关闭 context 后，旧 checkpoint 全量 strict load 并复现输出 |
| 因果性 | 修改时刻 `t` 之后的帧不得改变 `t` 的 window logit |
| mask 正确性 | 48 帧历史不足时 padding 不产生伪 motion/kinematics |
| flip 对称 | 两次 HFlip 恢复原坐标及左右关节顺序 |
| 聚合一致 | 训练和评估调用同一 clip scorer；禁止一边 top-k、一边 max |
| OOF 隔离 | teacher fold 与样本 group 有交集时直接报错 |
| 带外回退 | 残差关闭或被裁剪为 0 时，输出严格回退旧分数 |
| 指标回归 | 固定预测文件复现 71.1794/74.0741/68.2848 附近指标 |

## 12. 两周执行顺序

| 时间 | 工作 | 决策产物 |
|---|---|---|
| Day 1 | 冻结 R0、导出逐 clip/window OOF 分数 | 可复现基线与错误清单 |
| Day 2–3 | 实现 M1 和等价性/聚合测试 | R1 单 seed canary |
| Day 4 | R1 三 seed/五折确认 | 保留或删除聚合残差 |
| Day 5–7 | 实现共享权重 16+48 M2 | R2 单 seed canary |
| Day 8 | R2 OOF 和错误切片 | 判断长上下文是否有效 |
| Day 9–10 | 生成严格 OOF 四模型 teacher，测试 M4 | R3 蒸馏结果 |
| Day 11–12 | 仅在 R1–R3 ≥76% 时测试 M3 | 跨流适配器去留 |
| Day 13 | 仅在前项通过时做 AP 精修 | R5 候选 |
| Day 14 | bootstrap、锁配置、写最终实验卡 | 是否允许一次 frozen validation |

每个 canary 先跑一个 seed；未达到预注册门槛，不扩成三 seed，不继续叠加下一模块。

## 13. 目标拆解与现实上限

| 里程碑 | mAP | P@R90 | P@R95 | 含义 |
|---|---:|---:|---:|---|
| B0 | 71.18 | 74.07 | 68.28 | 当前固定集成 |
| M1 | ≥73 | ≥75 | ≥71 | 聚合错位被部分修复 |
| M2 | ≥75 | ≥77 | ≥73 | 48 帧上下文产生稳定信息 |
| M3 | ≥76 | ≥78 | ≥75 | 蒸馏和单模型稳定性成立 |
| M4 | ≥78 | ≥80 | ≥77 | 跨流/AP精修继续有效 |
| Stretch | ≥80 | ≥82 | ≥80 | 同一骨架框架的条件上限目标 |

这些数字是阶段门槛，不是可相加的收益预测。若 R1–R3 完成后 OOF mAP 仍低于 75%，说明主要瓶颈不是读取/聚合，而是输入信息或数据可分性；此时继续在原 TCN 上堆层数、流或损失没有依据。

## 14. 明确不做的事情

- 不替换为 ST-GCN、Mamba、RGB 或 pose heatmap 主干；这些不属于“沿原最佳模型改进”。
- 不再追加同配置 HFlip seed 期待多点提升。
- 不加入新的手工第七/第八流，除非错误审计证明某类信息完全缺失且占 FP ≥10%。
- 不复用已失败的事件 GRU、全局 hard-negative ranking、F1/F2/F3 融合方案。
- 不同时改窗口、主干、采样、损失和聚合器。
- 不在 frozen validation 上搜索 ensemble 权重、残差幅度或阈值。
- 不以 Accuracy 90% 替代 mAP 90%，也不承诺同一骨架输入必然达到 mAP 90%。

## 15. 最优先实施建议

第一项实验不是直接实现 16+48，而是 **R1 聚合一致化残差**：它直接修复现有代码中最明确的训练/推理错位，改动最小，能保持旧 max 分数为 anchor，也能快速判断“孤立窗口尖峰”是否确实是主要 FP 来源。

R1 通过后，第二项才是 **R2 共享权重 16+48 context residual**。不要建立两套六流 TCN；同一 encoder 分别读取原始 16 帧和稀疏 48 帧，新增参数只放在零初始化残差 adapter。这样既沿用原最佳模型，又让长期上下文有机会纠正 `lie_down / lying / stand_up` 的局部混淆。

最终推荐顺序为：

```text
旧模型严格复现
→ 聚合一致化残差
→ 共享权重16+48上下文残差
→ 四模型OOF蒸馏
→ 跨流残差适配器
→ AP小学习率精修
→ 必要时重新组成固定集成
```

这条路线的价值不是承诺一次从 71% 跳到 90%，而是让每一项改动都从旧最佳起步、可独立证明、可回退，并优先攻击当前实现中已经看得见的结构性损失。

## 16. 参考依据

1. Abu Farha & Gall, **MS-TCN: Multi-Stage Temporal Convolutional Network for Action Segmentation**, CVPR 2019. 多阶段时序卷积与时序平滑。  
   https://openaccess.thecvf.com/content_CVPR_2019/html/Abu_Farha_MS-TCN_Multi-Stage_Temporal_Convolutional_Network_for_Action_Segmentation_CVPR_2019_paper.html
2. Khosla et al., **Supervised Contrastive Learning**, NeurIPS 2020. 表示空间的监督式类内聚合与类间分离。  
   https://proceedings.neurips.cc/paper/2020/hash/d89a66c7c80a29b1bdbab0f2a1a94af8-Abstract.html
3. Qi et al., **Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence**, NeurIPS 2021. AUPRC 直接优化仅用于最后精修。  
   https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html
4. Eban et al., **Scalable Learning of Non-Decomposable Objectives**, AISTATS 2017. P@R 等非分解目标的优化依据。  
   https://proceedings.mlr.press/v54/eban17a.html
5. Cormier et al., **Enhancing Skeleton-Based Action Recognition in Real-World Scenarios Through Realistic Data Augmentation**, WACV Workshops 2024. 姿态错误建模与增强边界。  
   https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html

