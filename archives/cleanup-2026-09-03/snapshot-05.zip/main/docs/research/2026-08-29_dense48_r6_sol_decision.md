VERDICT: APPROVE

Decision scope:
- 批准 SHA-256 为 `44290f607113759acbd89a5eafe64d009d0592229f7c0af02f3e96c0166e6152` 的当前 R6 报告，作为完整的中文研究结论、架构解释、未来候选协议与停止条件指导报告交付。
- 当前事实锚点仅为同一持续研究序列内、OF-Syn train-only、五折 template-grouped OOF 下的 selection-conditional incumbent：七头 fixed `1/7` equal-logit，`mAP*=72.166 / P@R90=78.762 / P@R95=65.570`。本裁决不把它升级为独立确认结论。
- 本批准不授权训练、算力或预算支出、指标/阈值政策变更、random-validation、OF-Syn sealed test、URFD test、部署、发布、竞赛提交或外部传播；也不把 RMPTS 或任何条件路线写成实证成功。

Evidence relied on:
- 当前 R6 报告：`D:/HermesWorkspace/Detictive/docs/research/2026-08-29_seven_head_dense48_deep_architecture_and_fusion_report.md`，本机复核 SHA-256 为 `44290f607113759acbd89a5eafe64d009d0592229f7c0af02f3e96c0166e6152`；1311 行，§1–§18 完整。
- 当前 R6 来源账本：`D:/HermesWorkspace/Detictive/docs/research/2026-08-29_dense48_r6_sources.json`，本机复核 SHA-256 为 `1e342e1e3503e8c2413cfc596213fffca4d6360ed5b792277e3a29ecb96e790b`；41 条来源。主 agent 已给出 41/41 与 strict-citation exit 0，凭据扫描 0 的机械验证。
- 当前 Terra Lane-B 审计：`D:/HermesWorkspace/Detictive/docs/research/2026-08-29_dense48_r6_terra_review.md`，本机复核 SHA-256 为 `1e1466a114c0e254c0333a3f6e87474ae7f8a8f4695a43d87a440c28611c561f`；结论 `PASS`，并明确绑定当前报告 hash。
- Dense48 MiMo 可复现性审计：`D:/HermesWorkspace/Detictive/docs/research/2026-08-29_dense48_mimo_reproducibility.md`，本机复核 SHA-256 为 `17137ca21f669b21e94604d37237a4156dfe52e162ecb5c93d58a4e7716ac1a2`。该文件仅作为七头实验算术、参数链和原始可比性的佐证；它不绑定当前 R6 新增文字，本裁决不把它冒充当前-hash MiMo 审计。
- 当前报告保留了关键反证与不确定性：4/5 folds 改善、fold-2 `mAP*` 回退 `0.456` 点；mAP* paired bootstrap 95% CI 为 `[+0.055,+2.333]`，而 P90、P95 分别为 `[-0.028,+2.095]`、`[-0.603,+3.417]`，均跨零；Dense48 来自同一连续研究选择过程，不是独立确认。
- Principal 另组织了四路只读交叉评审：证据/不确定性评审与 MiMo-gap challenger 均为 `APPROVE`、无阻断；融合评审和路线评审给出保守 `REVISE`，分别挑战“resolution mass/低方差”是否被误当经验事实、outer fold 自适应 `delta_k` 与最终固定中位数 `delta_final` 的估计对象差异，以及 T1 阳性时 F1 排在 T2 前和 Phase-Motion canary fold 口径的执行歧义。Principal 接受这些挑战为下述解释约束和未来执行卡前置项，但因所有相关路线均未执行、未获授权，且不改变当前七头事实锚点，判定它们不是“只交付研究报告”的阻断性缺陷。

Threshold result:
- **R6 报告交付：通过。** 报告完整地区分了已观察七头 anchor、未关闭的部署门和未执行的未来候选；没有把 pooled 点估计外推成逐折稳定显著，也没有隐去 fold-2、P90/P95 跨零或 selection-conditional 边界。其范围和措辞足以作为研究与架构指导报告交付。
- **RMPTS 候选判断：通过，但仅为方法优先级。** RMPTS 固定 320 family 总质量 `4/7` 与 640 family 总质量 `3/7`，只在 320 短窗三 seed 和 Dense48 之间迁移一个预注册 `delta`；相对七维 non-negative stacking 的 6 个有效权重自由度，它在先验上更低自由度、保留 seed 对称性、较少同时重估分辨率与时域效应，因此是更合理、预期方差更低的下一轮融合候选。这里的“更低方差”是结构性判断，不是已观察到的经验成功。只有 fresh、full nested template-grouped cross-fitting 完成全部 §14.4 晋级门后，RMPTS 才可替换 `delta=0`；否则保持七头 `1/7`。
- **RMPTS 估计对象约束：** `4/7` 对 `3/7` 是有意施加的低维正则化假设，不是数据已经识别出的“真实信息质量”。Nested outer pooled 结果评价的是“每个 outer-train 内选择 `delta_k`”这一选择程序，不自动等同于对一个最终固定中位数 `delta_final` 的独立确认。未来执行卡必须在读取结果前冻结最终参数形成与报告口径；若不能无泄漏地区分选择程序成绩和最终固定参数成绩，不得以 RMPTS 替换 incumbent。
- **路线优先级与停止条件：通过，并附执行顺序解释。** track-first 先做无训练 top-k/oracle replay，直接检验共享上游 actor/identity 错误；oracle 无恢复即停止。若 T1 阳性，T2 确定性 track 修复优先于 F1 RMPTS；F1 只能作为不阻断 track 修复的独立预算 lane，或在该分支关闭后再排期。Phase-Motion 仅在 actor 正确且 48 帧内仍存在未利用转移时，以一换一方式测试，高相关、无 unique rescue 或 P95 下降即停止；具体 canary fold 数和从 canary 扩展至五折的门必须在另行执行卡中预注册。长 ROI 先复用缓存且一次只改 ROI 时域；support/controlledness 先过可观察性与标注一致性门；超过 48 帧 memory 仅服务于同一 actor、转移曾可见但已离窗的窄切片；stream buffer 必须证明离线/在线等价，不能借优化共享 `e16/e48` 学习参数。经上述约束后，依赖顺序、成本与风险总体比例适当。
- **部署门：通过其“隔离性”，未通过部署本身。** 参数约 `1.343M` 或约 `5.12 MiB` 不能替代完整 pose、track、320/640 ROI、`e16/e48`、七 heads 与 aggregation 的端到端 P50/P95/P99、峰值显存和在线/离线一致性实测。报告交付不关闭 `≤20M / ≤80MB / ≤100ms` 部署门。
- **当前-hash MiMo 缺口：接受为非阻断残余。** provider 两次 API connection failure 属于审计可用性缺口，不是反向证据。当前 hash 已有 Terra PASS、主 agent 的结构/引用/凭据/RMPTS 机械检查，以及旧 MiMo 对稳定实验算术与参数链的有限佐证；而当前 R6 新增内容没有声称新的 RMPTS 实证结果。故仅交付研究报告不要求为补齐审计对称性而新增实验，也不应因 provider 故障判 REVISE。若未来生成当前-hash MiMo 审计，只能作为追加交叉核验；若其发现材料级矛盾，则按下述回滚触发器处理。

Residual risks and uncertainty:
- 七头优势仍受连续架构搜索后的 selection bias 影响；mAP* CI 下界仅略高于零，不等价于独立、确认性泛化证明。
- P90/P95 单项 CI 跨零，fold-2 回退，且最大单折收益集中在 fold-3；不能宣称每个工作点、每个模板区域或所有长时序场景稳定占优。
- Dense48 与短窗成员仍共享 pose、top-1 actor、tracker 和部分 320 ROI 上游；共同输入错误不能由 fixed fusion 或 RMPTS 修复。
- RMPTS 尚未执行；其 nested protocol 只能降低选择泄漏和自由度风险，不能预先保证收益、方向稳定或计算上值得执行。
- RMPTS outer cross-fitted 结果与最终固定 `delta_final` 不是天然同一估计对象；若未来执行卡未消除该口径歧义，只能保留 `delta=0`。
- §18 的列表顺序在 T1 阳性分支上可能被误读为 F1 先于 T2，Phase-Motion 的 canary fold 口径也需执行前唯一化；本裁决已把二者限制为非授权路线的解释/预注册事项，不把它们升级为当前报告交付阻断。
- 当前-hash MiMo 一致性文件不可用；旧 MiMo 审计不得用于证明当前 R6 新增文字的全文一致性。
- 在线 warm-up、track reset、长缺失、clip 边界、缓存等价、完整链路时延/显存及目标硬件行为尚未闭环，因此不得据本报告批准部署。

Budget/resource compliance:
- 本裁决遵守只读边界：除写入本决策文件外，未修改主报告、来源账本、审计文件、代码、配置、权重或实验工件；未训练、未运行模型、未访问 OF-Syn sealed test、URFD test 或 random-validation，未部署、发布或提交。
- 未授权任何计算、训练、标注、硬件、测试访问或实施预算。RMPTS full nested、track/Phase-Motion/ROI/support/memory 路线及部署 benchmark 均须另行获得执行授权；本报告交付不能被解释为预算批准。
- 工作树既有 modified/untracked 内容保持不动，未清理、覆盖或纳入本裁决。

Required follow-up or rollback trigger:
- 交付前只要求下一 owner 对本决策文件和四个输入执行最终 SHA-256、必需字段/结构、41 条来源对应关系与凭据扫描；不得仅为了报告交付要求新实验或重新调用失败的 provider。
- 任何未来路线执行前须另开执行决策卡：RMPTS 卡必须唯一化“outer 选择程序”与“最终固定 `delta_final`”的形成、评估和声明口径；路线卡必须固定 T1 阳性时 `T2 → F1` 的优先关系，并唯一化 Phase-Motion canary fold 与扩展门。这些是未来授权前置项，不是本次交付前置项。
- 研究-anchor 回滚触发器：任一绑定 hash 变化或来源/结构检查失败；七成员 raw logits 无法重建 `72.166/78.762/65.570`；9,600 clip 身份、fold/template group、标签或阈值政策出现不一致/泄漏；CI、R95 rescue/introduced 或参数链出现足以改变推荐顺序的材料级矛盾；或后续当前-hash 审计发现未披露的实证化表述。触发后撤回本批准并以 `REVISE` 重新裁决，不得利用该失败结果反向调权。
- RMPTS 回滚/停止触发器：未完成 fresh full nested grouped protocol、outer 隔离不完整、方向不稳、P90/P95 任一下降、fold-2 进一步无解释恶化、4/5 folds 或 paired-CI 门失败、R95 introduced errors 不少于 unique rescues，均保持或回退 `delta=0`。不得降级为在现有 OOF 表上直接搜索。
- 路线停止触发器：top-k oracle 无 actor 恢复；Phase-Motion 高相关/无 unique rescue/P95 下降；事件帧 ROI 需无界新增 pass 或与原 Dense 近重复；support 不可观察或标注不一致；>48 memory 重复 clip-max、跨人传播或产生滞留 FP；stream buffer 改变任何 OOF 排序/决策。停止后不得自动升级到更复杂 stacking、gate、SSM/Transformer 或第八头。
- 部署阻断触发器：在线窗口/track/reset 与离线契约不一致，或完整链路任一 `≤20M / ≤80MB / ≤100ms` 门失败。该情形只阻断/回滚部署候选，不自动抹除 hash 绑定的内部研究结果。

Next owner:
`default/Hermes`：执行最终 hash、结构、41 条来源与凭据检查后交付；检查完成即停止，不继承任何训练、测试、部署、发布或预算授权。
