# Detictive Fall Detection：六头模型结构、融合与实验结果证据包复核报告

日期：2026-08-29  
任务 ID：`DET-ARCH-20260829-EVIDENCE-R4`  
性质：**基于上一版指导方案执行实验后的结果复盘与后续研究建议**  
选择证据：2026-08-29 DOCX + 外部专家证据包；仅 OF-Syn train-only template-group 五折 OOF 承担选型  
禁止项：不重新访问 OF-Syn sealed test；不使用 URFD test 选型；random-validation 只保留冻结后的单次方向确认  
状态：研究与决策支持，**不构成新的训练、数据、评测或发布授权**

## 0. 结论先行

用户提供的 2026-08-29 DOCX 不是旧报告的简单改写，而是**依据此前指导完成一轮受控实验后形成的结果报告**。因此，本报告的重点不是重复旧建议，而是判断哪些建议已被证实、哪些已被否定、当前瓶颈如何变化。

### 0.1 当前正式研究 anchor

当前最佳架构为：

> **共享 Stage-S1 六流 skeleton backbone + 320 Person-ROI heads × 3 seeds + 640 Person-ROI heads × 3 seeds + 六头 fixed equal-logit fusion。**

> **分析边界：完整模型代码、权重、配置和成员级预测仍位于另一台电脑；本次新增证据包包含六头融合后的 9,600 条 OOF 预测、折号、标签、融合方法输出、双头对比摘要和 80 条错误审计。** 因而下文能够独立复算融合输出指标和错误集合，但仍不能声称复现训练、核验成员级融合公式、证明 template-group 无泄漏或确认部署时延。

项目内五折 template-group OOF：

| 指标 | 数值 |
|---|---:|
| mAP*（项目兼容字段） | **70.8311%** |
| P@R90 | **77.5623%** |
| P@R95 | **64.0998%** |

> **指标命名警告：**本项目的`mAP* = (P@R90 + P@R95) / 2`，不是标准PR曲线Average Precision，也不是检测领域AP50/AP50-95。为兼容既有工件，本报告保留`mAP*`名称；对外发布应改名为`High-Recall Score`或明确加星号和公式。下文所有“mAP”均指该项目兼容字段，而非标准AP。

冻结后的单次 random-validation 确认为 `74.5126/77.0115/72.0137%`，但它与 train 模板完全重叠，不能用于继续选成员、搜权重、挑阈值或改变架构。

### 0.2 本轮实验对旧指导的实质更新

1. **Person-ROI 从“待五折验证候选”升级为主要有效视觉分支。** 项目报告记录其五折 OOF 稳定优于 skeleton control；证据包独立复算了最终六头输出，但未包含该对照数组，因此“方向保留”为B级结构归因。
2. **简单静态融合仍是最稳妥选择，但不能写成“所有指标都胜过复杂融合”。** 独立复算显示 equal-logit 的 mAP/P@R90 最高；CDF-nonnegative logistic 的 P@R95 略高。equal-logit 晋级依据是主要指标、P95护栏、零拟合参数和低方差的联合权衡，而不是对所有工作点的支配。
3. **旧报告优先提出的 per-joint missingness 修复没有晋级。** P1 mask 两折 mAP 仅 `59.18 vs 59.08`，且 P95 下降；Motion+17D validity 也未超过 Primary。该方向仍有代码语义价值，但已不再是近期精度主线。
4. **显式 transition residual 证明“状态转移”有单头信号，但没有形成 ensemble 价值。** fold-0 单头提升明显，但与源成员 score Pearson=`0.9918`；加为第七头或替换源头均未改善六头 P95。
5. **真实质量失真并非可靠专家来源。** Real-Q/Real-T 和严重度分层均提高部分 P90、伤害 P95，说明它们把中等样本排序得更好，却压低最难正例。
6. **继续堆模型、堆损失、堆同构头已经进入低回报区。** 当前首要问题已从“是否存在异质视觉信息”转为“如何解决语义相近困难负例、静态/缓慢 fall、遮挡及多人 track 错配”。

### 0.3 最重要的后续判断

- **竞赛冻结前：保留六头 anchor，不再做大结构修改。** 当前最新端到端参数、显存和 V100 延迟尚未复测；双分辨率 YOLO extraction 是比再训练一个分支更紧迫的交付风险。
- **研究上：下一条有希望的路线必须引入新的观测信息或新的错误集合，而不是同一 embedding 上再做 suppressor/gate。**
- **融合上：新候选先“替换一个弱成员”，不直接加第七头。** 单头提升不是准入条件；必须证明对六头的条件互补和高召回尾部净救回。
- **不要给预期增益承诺。** 下文论文只提供机制依据，不能把其他数据集的提升数字外推到本项目。

### 0.4 新证据包使哪些结论升级、哪些仍受限

证据包 ZIP SHA-256 为 `e989ae425901992cf4078cc3d83ad62f2091602d4327bbb523e49d3296ac9d8e`，共 108 项、解压后 13,859,979 bytes；ZIP CRC 全量检查通过，无加密项和路径穿越项。

本次独立复算得到：

- OOF NPZ SHA-256=`c4e6fdf2c576100ea45aae859e566731b1cd896776824ef2847bf91f657e81f2`，同时匹配 OOF 汇总和五折双头对比文件中的 challenger hash；
- 9,600/9,600 clip IDs 唯一，标签为 1,866 正/7,734 负，五折行数为 `1984/1842/1942/1894/1938`，七个分数字段全部有限；
- 自行实现同一 P@R90/P@R95 定义后，七种输出的总体与逐折指标和 JSON **差异为 0**；
- 六头 R95 threshold=`0.3116439283`，复算为 993 FP、93 FN；最高分 40 FP和最低分40 FN的 clip顺序与确认 CSV 完全一致；
- 确认 CSV hash 与摘要一致；10张 contact sheets（80格）逐格复核未见与 taxonomy 明显矛盾，但它们不是完整视频，也不是错误总体的随机样本。

仍不能独立确认：

- 六个成员 raw logits 未提供，无法从成员重新计算 equal-logit，也无法复算成员相关矩阵；
- 双头 baseline 预测数组未提供，`+1.6261/+2.3834/+0.8687`点和 `128 rescued/90 added`只能核对摘要内部一致性；
- `template_group` ID和分组清单未提供，只有 `fold`和 assignment hash，无法独立排除模板泄漏或复做 grouped bootstrap；
- 模型代码、配置、checkpoint和环境未提供，参数量与训练配方仍是报告规格事实；
- random-validation 只有摘要和源文件 hashes，没有预测数组；sealed-test 未访问是包内多份元数据的一致声明，不是本机可独立证明的否定事实。

### 0.5 “旧指导→新实验→当前结论”矩阵

| 旧指导/假设 | 本轮执行证据 | 结果 | 当前结论 |
|---|---|---|---|
| Person-ROI必须完成五折OOF | F1、320/640、六头汇总；六头融合NPZ | 六头输出可独立复算为当前最高mAP/P90 | **支持方向**；具体Person-ROI对skeleton归因仍为B级 |
| per-joint validity/missingness优先 | P1 mask两折、Motion+17D、Real-Q/T | mAP极小或P95下降 | **否定为近期提分主线**；仅保留语义/鲁棒性价值 |
| 使用template-group OOF而非random-val选型 | 五折fold输出与单次random-val摘要 | 主结论由9,600 OOF输出承担 | **支持协议方向**；group manifest缺失，尚未独立证明无泄漏 |
| 先静态融合，再考虑动态gate | fixed/rank/logistic/CDF/quality多种输出 | 简单fixed方法最高mAP/P90；quality gate未晋级 | **支持简单融合**；equal-logit与probability近乎并列 |
| 非负L2 stacking可能优于等权 | nested logistic/CDF outputs | P95可略高，但mAP/P90下降 | **不作为当前anchor**；不是方法族永久失效 |
| 真实质量失真可形成互补专家 | Real-Q/Real-T/severity | P90偏置、P95下降 | **当前实现失败，停止** |
| transition信息可能重要 | zero-init transition residual | 单头强，成员相关`0.9918`，进入ensemble失败 | **支持信息假设，否定当前成员形式** |
| 错误审计应驱动下一步 | 40最高FP+40最低FN taxonomy/contact sheets | 尾部语义与可见性模式明确 | **部分完成**；仍需总体随机分层审计 |
| dense长历史可能解决静态/缓慢fall | 既有48→16稀疏方案、O1/O2 | 未晋级 | **仍未判定方法族**；dense history尚未测试 |

---

## 1. 证据边界与可复现性

### 1.1 最新权威输入

- 最新结果报告：`C:/Users/kingmt/AppData/Local/hermes/attachments/Detictive_Fall_Detection_外部专家离线审计包_2026-08-29.docx`
- DOCX SHA-256：`8d5a959cd7a65afdfe5a5f1f31566ea78c550cd9530353ad8e6229262bd97ab8`；证据包内副本 hash 完全相同。
- 最新证据包：`C:/Users/kingmt/AppData/Local/hermes/attachments/Detictive_Fall_Detection_外部专家证据包_2026-08-29.zip`
- ZIP SHA-256：`e989ae425901992cf4078cc3d83ad62f2091602d4327bbb523e49d3296ac9d8e`。
- 报告声明：9,600 train clips、五折 template-group OOF、1,866 positives、7,734 negatives；六头 R95 工作点 threshold=`0.3116439`、recall=`95.0161%`、precision=`64.0998%`、993 FP、93 FN。

### 1.2 已独立核对的内容

本轮不依赖项目训练代码，直接从只读 NPZ/JSON/CSV 做了以下核验：

1. **包完整性**：ZIP 108项均可读取，CRC检查无坏项；无加密项和危险路径。
2. **预测完整性**：NPZ含9,600唯一 clip IDs、全部标签和fold，七个score arrays均为 `(9600,)` 且全部有限。
3. **指标复算**：Primary、fixed probability、fixed equal-logit、standardized equal、nonnegative L2 logistic、CDF-rank、CDF-nonnegative logistic 的 pooled/逐折 P@R90、P@R95和项目mAP均与汇总JSON完全一致，最大绝对差为0。
4. **错误集合**：equal-logit在R95复算得到TP=1773、FP=993、FN=93；80条严重度尾部样本顺序与CSV完全一致。
5. **错误标签工件**：确认CSV hash与confirmation JSON一致，80 IDs唯一、无空标签；FP taxonomy计数和FN taxonomy计数与审计摘要一致。
6. **视觉一致性**：逐格检查10张8-up contact sheets，未发现taxonomy与可见缩略图的明显冲突；此结论不替代完整视频时序判断。
7. **结构算术**：按报告给出的层和维度复算每个 ROI head=`144,903`、六 heads=`869,418`、加 skeleton=`1,033,540`。

报告所述当前 skeleton 参数为 **164,122**，相对旧 `161,406` 版本增加 Joint-only Transformer adapter并移除旧 stage auxiliary；本任务将这一点视为报告事实，而不是重新实例化后的独立实现证明。

### 1.3 仍不能独立核对的内容

证据包刻意排除代码、权重、配置、原始视频和受限测试集；同时只提供融合输出而非成员预测。因此：

- 六头**融合输出的指标和错误集合已独立复算**，不再只是项目内文字记录；
- 六个成员分数及双头baseline分数缺失，不能从原始成员复算融合、成员相关矩阵、双头→六头的配对delta或R95救回集合；
- fold只有整数编号，没有template-group ID、group assignment表或生成脚本；不能仅凭fold列独立证明无模板泄漏，也不能复做template-group bootstrap；
- 参数量只能按报告拓扑做算术一致性检查；
- 训练时所谓“共享 skeleton backbone”究竟是一次联合训练后共享、固定 embedding 复用，还是多个独立训练实例在部署时折叠共享，报告没有完整说明；
- random-validation没有逐clip数组，不能独立复算；
- 不应声称本任务重现了六头训练、核验了训练代码、独立证明未访问sealed test或确认最新端到端时延。

### 1.4 证据等级

| 结论 | 等级 | 依据 | 当前表述边界 |
|---|---|---|---|
| 六头融合输出 `70.8311/77.5623/64.0998%` | A | 9,600行NPZ独立复算，差异0 | 可写“独立复算通过” |
| 六头逐折结果和fold-3最低 | A | NPZ fold列逐折复算 | 可写“输出层可复现” |
| R95 993 FP/93 FN及80条尾部抽样身份 | A | NPZ+CSV独立对齐 | taxonomy只代表尾部样本 |
| equal-logit优于包内其他融合输出的总体权衡 | A- | 七种输出可复算 | 成员公式和生成链不能复算；P95并非最高 |
| 六头相对双头 `+1.6261/+2.3834/+0.8687`点 | B | 决策/配对审计摘要与challenger hash | baseline array缺失，不能独立复算 |
| P95 5/5 folds上升、bootstrap区间、128救回/90引入 | B | 配对审计摘要 | group manifest和baseline array缺失 |
| Person-ROI相对skeleton、320/640结构归因 | B | 完整研究报告和历史受控实验摘要 | 对应原始预测/config不在包内 |
| 164,122 + 6×144,903 参数拓扑 | B | 报告规格与算术一致 | 不含代码/checkpoint独立证明 |
| random-validation `74.5126/77.0115/72.0137%` | C+ | summary+input/output hashes | 预测数组缺失且split仅sanity check |
| sealed test/URFD未访问 | C | 多份元数据一致声明 | 无法由排除内容证明“未访问” |

### 1.5 指标命名与元数据缺陷

MiMo独立复算确认，`clip_map_percent`在全部七种输出和五折中都严格等于`mean(P@R90,P@R95)×100`，不是标准Average Precision。该定义本身可作为竞赛指标使用，也不影响P@R90/P@R95、阈值和混淆计数；问题在于字段名容易让外部读者误解。发布前应统一改成`high_recall_score_percent`，或至少在表头写`mAP*`并紧邻公式。

`edgefall_f1_six_roi_heads_vs_two_heads_fivefold_audit.json`文件名、9,600 clips和上下文均指向五折 OOF，但其`protocol`字段写成`paired_random_validation_prediction_audit_v1`。这很可能是复用脚本后的标签遗留，而非指标本身错误；不过在对外冻结前必须更正并重新签名，否则五折/随机验证的来源标签存在歧义。

---

## 2. 当前模型逐模块结构审计

## 2.1 输入与六流特征

| 流 | 维度 | 作用 | 当前判断 |
|---|---:|---|---|
| Joint | 51D | 17 个 joint 的 `x/y/confidence` | 保留；是最完整的原始姿态流 |
| Bone | 32D | 16 条骨边端点差 | 保留；提供局部相对形状先验 |
| Motion | 34D | 相邻帧 17 joints 的 `dx/dy` | 保留；对快速下落敏感，但会放大 pose jitter |
| Geometry | 6D | bbox 中心、宽高、aspect、observed | 保留；补足人体整体位置/尺度 |
| Rule | 12D | 连续姿态、运动、框变化先验 | 保留；提供受控且低维的物理归纳偏置 |
| Kinematics | 15D | acceleration、jerk、downward velocity、stillness 等 | 保留；与 impact/停止阶段直接相关 |

把 joint、bone、motion、bbox、规则和运动学分流，而不是一次性堆成高维向量，实质上是在小数据下施加结构先验。ST-GCN、CTR-GCN、InfoGCN 分别说明了骨架拓扑、通道特异拓扑和信息约束表征的价值，但本项目的 replacement/fusion 结果表明：论文中的架构优势不能抵消删除现有强 Joint-TCN 或增加同源误差的代价。[19][20][21]

### 缺失语义的最新判断

旧指导报告曾指出 frame-level observed mask 可能让 confidence=0 的 joint 产生伪 bone/motion，这也是本轮 P1/Motion+17D 实验的来源。GRU-D 的核心思想是同时向模型显式提供 missing mask 和距上次观测的时间间隔，说明“缺失模式本身”应被建模，而不是只用零值隐式代表。[22]

但项目新实验已经改变优先级：

- P1 per-joint mask：mAP 极小正向，P95 下降；
- Motion+17D validity：未超过 Primary；
- Real-Q/Real-T：反复伤害 P95。

因此应把 missingness 从“近期主精度候选”降级为：**代码语义/鲁棒性修复候选，仅在真实遮挡和 track 失败切片上证明收益后再训练。**

## 2.2 多尺度 depthwise causal TCN

每个 stream 先做 `1×1` 投影，再经过 dilation=`1/2/4/8` 的四个因果残差块。每块包含 kernel=`3/5/7` 的三条 depthwise Conv1D 分支、拼接后的 `1×1` mixing、BatchNorm、ReLU、dropout 和块内 SE。

TCN 文献表明，因果扩张卷积具有稳定梯度、可并行计算和较长有效记忆等优势；MS-TCN 进一步展示了多尺度/多阶段时序卷积对动作阶段建模的价值。[4][7]

本项目的具体风险是：在 16-token 输入下，kernel=3/5/7 四层名义感受野分别可达 31/61/91 帧，均超过输入长度。后层大量依赖左侧 padding，故继续扩大 kernel、dilation 或层数没有现实依据。

**结论：保留当前 TCN，不扩张。** 若研究长时序，应改变“输入历史的表达方式”，而不是在 16 token 上继续增大名义感受野。

## 2.3 SE 门控

每个因果块使用时间全局平均后的通道 SE，六流拼接后还有一次 384D fusion SE。SENet 的机制是利用全局统计自适应重标定通道响应。[5]

对本项目而言：

- 块内 SE 可抑制局部冗余通道；
- fusion SE 可重标定六流；
- 但 ROI fusion head 又引入了新的投影和融合层，继续增加额外 gate 容易变成重复门控。

**结论：保留现有 SE；不再添加质量 gate 或跨头 gate。** 新报告中 F3 quality cross-head 和 nested quality calibration 均未晋级，已提供项目内反证。

## 2.4 因果 self-attention 与 Joint-only Transformer adapter

每流 TCN 后都有 4-head causal self-attention + residual + LayerNorm。Joint 流额外使用两层 MLP feed-forward adapter，因此“Joint-only Transformer”并不是替换 TCN，而是在 TCN+attention 后补充通道非线性。Transformer 的核心价值是内容相关的全局交互，但它本身不包含骨架拓扑先验。[6]

该设计比“所有流都 Transformer 化”更适合当前小数据：

- TCN 保留局部因果先验；
- attention 只负责 16-token 内的内容相关聚合；
- 额外 FFN 只给信息最完整的 Joint 流；
- 参数仅从旧模型增加到 164,122。

**结论：保留。** 不把局部正向结果外推为“Transformer 家族优于 TCN”；本项目中纯/替换式 Transformer、SA-TDGFormer 等并未形成稳定收益。

## 2.5 last-token readout

每流最终返回 `temporal[:, -1]`，再投影为 64D。因为前面的 TCN 和 attention 都是因果的，最后 token 理论上汇聚最近 16 帧历史，符合在线检测。

风险是：

- static post-fall 中，真正 transition 可能已离开 16 帧；
- slow/partial fall 的判别证据可能分布在多个位置；
- 单一 last-token、窗口级训练和 clip-max 推理形成层层选择。

注意力 MIL 说明 bag 内实例贡献可学习，但本项目 smooth-max、attention pooling、residual attention 和 verifier 已多次失败。[23] 因此不能据论文再次启动同源 pooling sweep。

**结论：当前部署保留 last-token；只有在新成员使用不同输入历史且能救回 static/slow FN 时，才考虑替换式 readout。**

## 2.6 六流融合与 skeleton embedding

六个 64D stream embedding 拼接为 `e_skel=384D`，经过 fusion SE；skeleton classifier 仍存在，但 Person-ROI head主要消费共享 embedding。

这是典型的中后期表征融合：先让各流独立编码，再联合决策。多模态融合研究表明，瓶颈式或晚期融合可以限制跨模态交互成本，但是否有效取决于互补信息而非模块名称。[28]

**结论：保留 384D 共享 skeleton anchor。** 图网络、规则、质量头或高维统计若只重表达同一姿态信息，不能自动增加互补性。

## 2.7 Frozen YOLO P3/P4 Person-ROI tokens

每个 16-frame clip 同时以 320 和 640 两种分辨率经过 frozen YOLO11n；在 person ROI 上分别对 P3 的 64 channels 和 P4 的 128 channels 做 ROI mean，形成每帧 192D token。

FPN 的机制依据是：高分辨率层提供更精细定位，低分辨率层提供更强语义；多尺度表示尤其有利于尺度变化和小目标。[1] RoIAlign 则说明从检测特征图提取实例级区域表征时，避免量化错位有助于保留空间对应关系。[2]

本项目的关键价值不是“RGB 更强”，而是：

- 视觉 ROI 提供 skeleton 不含的外观、遮挡和局部上下文；
- 320/640 改变目标像素支持和 detector feature distribution；
- 两个 resolution 采用独立 heads，保留决策差异；
- frozen backbone 降低 9,600 clips 上端到端视觉训练的过拟合风险。

**结论：Person-ROI 和双分辨率独立 heads 是本轮最可信的结构增益，必须保留。** 但双分辨率需要两次 YOLO extraction；在最新端到端延迟复测前，不能声称满足 `≤100 ms`。

## 2.8 每个 ROI fusion head

报告给出的 head：

1. `e_skel 384→128 + LN + GELU`；
2. `ROI 192→128 + LN + GELU`；
3. 三条 causal depthwise Conv1D，kernel=`3/7/15`；
4. branch mean；
5. temporal mean + max，`256→128 + LN + GELU`；
6. skeleton/ROI concat `256→128 + LN + GELU`；
7. binary fall logit + 6-class subtype auxiliary。

按报告拓扑、depthwise conv `bias=False` 独立计算：

| 部分 | 参数 |
|---|---:|
| skeleton projection + LN | 49,536 |
| ROI projection + LN | 24,960 |
| DW kernels 3/7/15 | 3,200 |
| temporal pool projection + LN | 33,152 |
| fusion projection + LN | 33,152 |
| binary head | 129 |
| 6-class subtype head | 774 |
| **合计** | **144,903** |

六 heads=`869,418`；加 skeleton=`1,033,540`，与 DOCX 完全一致。该数不含 frozen YOLO、pose detector、tracker 和缓存生成器。

结构评价：

- kernels 3/7/15 覆盖短、中、全窗尺度；
- depthwise 卷积把参数限制在很低水平；
- mean 捕获持续状态，max 捕获尖峰；
- skeleton 与 ROI 在 128D 后融合，避免视觉高维直接压制姿态；
- subtype auxiliary 提供语义监督，但权重固定为 0.25，避免压倒二分类。

**结论：保留当前 head，不再扩展空间统计、attention pooling 或 context residual。** 这些方向已被本项目两折/五折结果否定到当前实现层面。

## 2.9 Balanced focal + subtype CE + hard-negative sampling

Focal loss通过 `(1-p_t)^γ` 降低易样本权重、突出困难样本；原论文验证对象是极端前景/背景不均衡的密集检测，不能直接证明其在本项目 P@R95 指标上最优。[3]

当前训练使用：

- balanced focal，`γ=2`；
- subtype CE 权重 `0.25`；
- negative ratio=`2.0`；
- lie_down/lying/stand_up 40% hard-negative sampling；
- 每折固定 12 epochs，不用 held-out fold early stopping。

这套配方的优点是监督目标清晰且避免用 held-out fold选 checkpoint；缺点是 focal/BCE 仍非 P@R90/P@R95 的直接 surrogate。非可分解指标和 AUPRC surrogate 文献表明，可以直接构造面向排序/PR 曲线的优化目标，但这些目标通常更难稳定训练。[26][27]

**结论：保留现有 loss 作为 anchor。** 项目中的 pairwise ranking、语义加权、七类 auxiliary 和 verifier 均失败，故 metric-aligned loss 只能是低优先级、单头 canary，而不是默认替换。

## 2.10 六头 fixed equal-logit fusion

六个 probability 先转 logit，再等权平均，最后 sigmoid。它等价于对六个成员 odds 做几何平均，学习参数为 0。

Deep Ensembles 支持独立初始化形成预测多样性；但 ensemble 价值来自错误互补，而非成员数量本身。[8]

经典 stacking 要求 level-one 模型使用严格 out-of-sample 预测；非负约束和交叉验证可降低组合器方差。[16][30][31]

证据包允许独立复算七种已生成的融合输出：

| 输出 | mAP* | P@R90 | P@R95 | R95 FP | 解释 |
|---|---:|---:|---:|---:|---|
| Primary（320 seed1） | 67.6502 | 73.7165 | 61.5839 | 1106 | 单头参照 |
| fixed probability average | 70.7900 | 77.5265 | 64.0535 | 995 | 与equal-logit近乎并列 |
| **fixed equal-logit** | **70.8311** | **77.5623** | 64.0998 | 993 | mAP/P90最高，当前anchor |
| standardized equal | 70.6200 | 77.3481 | 63.8919 | 1002 | 标准化未带来净收益 |
| nonnegative L2 logistic | 70.4872 | 76.8282 | 64.1462 | 991 | P95略高，mAP/P90较低 |
| CDF-rank average | 70.0448 | 76.7230 | 63.3667 | 1025 | 排名归一化损伤P95 |
| CDF-nonnegative L2 logistic | 70.4004 | 76.3984 | **64.4025** | **980** | P95最高，但mAP/P90下降 |

这张表修正了“equal-logit全面优于learned fusion”的过强表述：

- equal-logit相对fixed probability只高`0.0411` mAP点、`0.0358` P90点、`0.0463` P95点，R95只少2个FP；两者在证据上接近并列；
- learned/CDF方法能换取更高P95，但代价是P90和mAP下降；因此它们不是“完全无效”，而是没有通过当前联合选择政策；
- 包内bootstrap区间是各方法相对Primary，不是equal-logit与fixed probability或CDF logistic的直接配对区间；不能宣称这几个融合器之间差异显著；
- NPZ未包含六个成员raw logits，故本次验证的是**所提供融合输出的指标**，不是从成员重建融合公式。

双头→六头的`+1.6261/+2.3834/+0.8687`点、P95 5/5 folds上升和`128 rescued/90 added`由配对摘要支持，challenger hash与本包NPZ一致；但baseline array缺失，证据等级为B。

**结论：固定等权 logit仍是当前合理anchor，但理由应写成“最高主要指标 + P95不退 + 无拟合参数 + 实现简单”，而不是“在所有工作点上显著优于其他融合”。** 若部署目标把P95置于mAP/P90之上，应在完整成员/双头数组补齐后，把CDF-nonnegative logistic作为预注册对照重新做严格配对审计，而不是直接替换。

## 2.11 当前融合方案的深层结构分析

### 两层互补，而不是六个完全独立模型

六头的多样性实际分为两层：

1. **强互补层：320 vs 640。** 输入图像尺度、目标像素支持、P3/P4 token 分布和独立 ROI head 都不同；这是六头中最实质的观测多样性。
2. **弱互补层：同分辨率三个 seeds。** 架构、数据、损失和输入相同，只靠初始化形成决策边界差异；它能降低方差，但理论上比跨分辨率更相关。

所有 heads 又共同依赖同一 skeleton 表征和同一 frozen YOLO特征族，所以不能把它们视为六个完全独立的专家。OOF JSON报告六成员score Pearson约为`0.9503–0.9715`：存在差异，但相关性仍高；由于成员数组未入包，该矩阵本次只能核对记录、不能独立复算。第三 seed晋级但继续增头失败，符合“初始化多样性有边际价值、很快饱和”的判断。[8]

### 为什么独立 320/640 heads 优于共享或残差适配

报告中的 `640-320 token residual` 和 stochastic shared head 均失败，而独立双头成功。这意味着尺度变化不仅是通道值的线性偏差，还改变了：

- 小目标的有效像素和局部纹理；
- P3/P4的空间采样和语义强度；
- ROI mean后的统计分布；
- 最优分类边界与校准。

强制共享 head 会把两个条件压入同一决策面；token residual 又默认 640只是320的可加修正。当前结果更支持“两个尺度是两个视图”，而不是“一个主视图加一个残差”。

### logit平均与 probability平均的差异

当前融合为：

```text
z = (1/6) Σ logit(p_i)
p = sigmoid(z)
```

它等价于六个 odds 的几何平均。与直接平均 probability 相比：

- 保留成员对高/低置信证据的对数强度；
- 对同一配方、相近校准的成员通常更自然；
- 但极端过置信成员也可能产生更大影响。

当前 equal-logit在mAP/P90上略胜fixed probability并胜过rank/learned方法，但CDF-nonnegative logistic的P95更高。因此应以**预注册联合门**而非单一“谁最大”判断；若将来加入异构成员，必须重新比较，不能假定logit平均永远最优。

### 为什么 clip-first 优于 window-first

当前正确顺序是每个成员先把窗口分数聚合为 clip logit，再融合成员。这样允许：

- skeleton在某个窗口捕获姿态突变；
- 320在另一个窗口捕获局部外观；
- 640在更早/更晚窗口捕获小目标；
- 各成员的强证据无需严格时间对齐。

window-first fusion则隐含“不同成员应在同一个窗口同时高分”的假设。报告中它明确低于clip-first，说明不同专家的峰值具有时间错位。继续保留clip-first是结构上有依据的，不只是经验选择。

### 为什么 transition residual 单头强、进入ensemble却无效

transition residual从源ROI-TCN状态构造last-first和平均帧差。它对单头排序有帮助，但仍是源成员表征的确定性变换，因此score Pearson达到`0.9918`。它救回的多数错误已被现有六头其他成员处理，加入后主要改变重复投票比例。

这说明 ensemble准入必须看**条件增益**：一个模型可以单头更强，但如果它没有独特救回现有ensemble的错误，就不应成为新成员。

### subtype auxiliary的正确角色

6-class subtype head只应作为训练期表示约束，不应被解释为一个独立ensemble专家。当前 severe FP仍集中在lie_down/lying，说明0.25权重不足以完全解决语义边界；但把该类权重提高到2又损伤hard positives。最合理的结论不是继续扫权重，而是当前视觉/姿态表示中“受控性”信息本身不足。

## 2.12 当前模型的主要结构优势与结构性弱点

| 维度 | 优势 | 弱点 |
|---|---|---|
| 归纳偏置 | 六流TCN明确编码姿态、形状、运动和物理量 | 多个derived streams仍共享同一pose/track误差 |
| 小样本适应 | skeleton极轻，YOLO冻结，ROI head仅14.5万参数 | 六个同构heads的有效自由度小于表面成员数 |
| 多尺度 | 320/640独立heads已形成稳定互补 | 双YOLO pass可能主导延迟与显存 |
| 时序 | 3/7/15 ROI卷积 + 16帧skeleton因果编码覆盖局部事件 | static post-fall与slow fall可能超出16帧有效历史 |
| 融合 | clip-first equal-logit无参数、低泄漏风险 | shared skeleton与同源ROI使专家相关性仍高 |
| 高召回 | clip-max保留孤立真fall；P95 5/5 folds相对双头上升 | max也容易保留孤立FP；既有抑制器又会伤害真fall |
| 语义监督 | subtype CE与hard-negative sampling直接针对困难负类 | lie_down/lying与slow/partial fall仍处于相邻表示区域 |

因此当前模型不是“容量不足”，而是**观测信息、时序覆盖和成员条件互补不足**。继续增加层数、head数或后置MLP不会直接解决这些问题。

---

## 3. 为什么本轮有效实验有效

| 有效组件 | 项目内证据 | 机制解释 | 证据强度与结论 |
|---|---|---|---|
| Stage-S1 六流 skeleton | 历史 random-val `70.278/73.358/67.198` | 低维任务先验强，参数仅 16.4 万 | C+/B：保留规格anchor；不作为跨模板新证据 |
| FallVision Joint 初始化 | 多轮稳定优于从零/弱 RGB teacher | 降低小数据优化难度 | B：保留；本包无权重/日志独立复算 |
| Joint-only Transformer | TCN 保留时有局部增益 | 只给信息完整 Joint 流增加非线性 | B：保留；不外推纯 Transformer |
| Person-ROI F1 | 报告称五折相对 skeleton control 全折明显提升 | 增加外观、遮挡、局部视觉信息 | B：核心方向已获项目证据；对照数组未入包 |
| 320/640 独立 heads | 报告称 OOF vs 320：mAP +1.555、P95 +1.647 | 多尺度目标支持 + 独立决策空间 | B：结构归因合理；双头原始数组未入包 |
| 第三个 seed | 六头相对双头摘要：mAP/P90 CI下界为正、P95 5/5上升 | 独立初始化形成有限多样性 | B：六头输出A，增量归因B；继续增头已停止 |
| fixed equal-logit | 输出层复算为最高mAP/P90，P95护栏通过 | 零拟合参数、低方差、避免meta overfit | A-：当前融合anchor；不宣称P95最优或显著胜出 |
| transition residual 单头 | fold-0 `71.800/78.082/65.517` | 显式状态差确有判别信息 | B/C+：摘要信号；未形成ensemble价值 |

核心规律是：**有效增益来自新的观测轴（Person-ROI、分辨率）和受控的初始化多样性，而不是同一 embedding 上增加更复杂的纠错器。**

---

## 4. 失败或未晋级实验的根因审计

## 4.1 时间尺度、长上下文和聚合

| 实验族 | 项目结果 | 不能得出的结论 | 最合理解释 |
|---|---|---|---|
| 0.75/1.0/1.5s 固定时间 | P95 均受损；1.0s mAP微升 | “时间归一化永远无效” | 改变了局部动态速度和尾部排序 |
| 16+48 shared TCN / Joint Transformer | 三项低于 16帧 Primary | “所有48帧模型无效” | 实际是 stride=3 压成16 token，共享编码导致稀疏/短窗失配 |
| smooth-max / 2-of-3 support | 不优于 max，压制真 fall | “所有事件聚合都无效” | 高召回尾部需要保留孤立强证据 |
| window-first fusion | 明确低于 clip-first | “早期融合理论错误” | 不同成员峰值发生在不同窗口；先按窗口平均会稀释互补峰值 |
| long-context O1/O2 | mAP 49.87–57.76 | “长历史无价值” | 候选本身召回不足，且没有证明 dense state memory |

**结论：当前 clip-max-before-fusion 继续冻结。** 若未来研究长历史，必须用 dense 历史状态或跨窗口 causal memory做单变量实验，而不是复刻稀疏 48→16 token。

## 4.2 损失、辅助任务、verifier 和 suppressor

| 实验族 | 项目结果 | 根因判断 |
|---|---|---|
| 七类 auxiliary B2 | ΔmAP/P95=`-0.954/-1.219` | 多任务梯度与 binary 高召回目标冲突 |
| pairwise hard-negative ranking | lie_down FP 未改善 | 同一表示中 hard negative 与 hard positive 距离太近 |
| window/event verifier | contribution 越大越差；event GRU P95下降 | 使用同源 embedding 做后置纠错，没有新证据 |
| bounded suppressor | 多 seed P95升、P90降 | 改变一端排序同时损伤另一工作点 |
| Motion+17D validity / P1 mask | 未超过 Primary或P95下降 | missingness 实现语义改善不等于排序改善 |
| lie_down/lying weight=2 | 单头和第七头均不晋级 | 对困难负例加权同时压低 slow/partial fall |
| six-head quality calibration | mAP +0.037、P95 -0.069 | 自动质量指标与最终错误排序关联不足 |

多任务学习可能产生互相竞争的目标；项目结果已经证明在当前数据/权重下负迁移比理论收益更重要。Supervised Contrastive Learning 虽能拉近同类并推远异类，但本项目已有 ranking/subtype/semantic weighting 失败，故不能仅换一个对比损失名称便重启。[14]

**结论：停止同源 suppressor、verifier、语义加权和质量校准。** 只有引入新观测信息后，才值得重新讨论纠错器。

## 4.3 图网络和骨架 replacement

ST-GCN、CTR-GCN 和 InfoGCN 在各自数据集上提供了图拓扑或表征约束方面的归纳偏置。[19][20][21]

PoseC3D 则把骨架表示为热图体并使用 3D 卷积建模。[18] 但项目内：

- ST-GCN replacement：`66.40/70.92/61.88`；
- TCN+SA-TDGFormer：`64.68/70.42/58.94`；
- TCN+InfoGCN：`64.34/68.73/59.94`；
- residual ST-GCN：`70.11/73.45/66.77`，有信号但未超最佳；
- PoseConv3D：mAP `51.82`，fall candidate recall 低。

失败边界应写成：**当前实现、输入、预算和 replacement/fusion 方式未通过**，而不是“图网络/3D heatmap无效”。

近期不应重启，因为当前有效视觉增益已经来自 Person-ROI，继续加骨架同源专家大概率提高相关性而非互补性。

## 4.4 RGB、视频骨干和 ROI 结构

| 方向 | 项目观察 | 解释 |
|---|---|---|
| R3D / event-aligned / actor-context | 40.91–56.21 mAP | 冻结视频语义与跌倒高召回排序不匹配 |
| VideoMAE 64-frame | 38.47–39.12 mAP | 通用视频表征不是可直接迁移的 fall teacher |
| context ROI residual | anchor mAP下降 | 场景上下文增加噪声，未提供稳定受控性证据 |
| quality cross-attention | mAP下降1.71 | 质量代理不能可靠指导跨模态融合 |
| ROI 768D空间统计 | fold-0高维过拟合 | 维度增加但独立信息不足 |
| mean+max / attention pooling | P95下降或两折不复现 | 读出改变了困难正例排序 |
| Person-ROI mean token | 五折有效 | 实例化视觉信息确实互补 |

FPN/ROI 文献支持多尺度实例特征的机制，但不支持“越多空间统计越好”。[1][2]

**结论：保留紧凑 mean ROI token；停止 context、额外空间矩、attention pooling 和局部 RGB纠错。**

## 4.5 分辨率、seed 数量与成员适配

- 640 standalone 提高 P90、略降 P95；与 320 固定融合后总体改善，说明其价值是互补而非单独替代。
- 640-320 token residual 和 stochastic shared head 均失败，说明**独立决策空间**比把两个尺度压成通道残差更重要。
- learned resolution weights 在折间从 0.4 到 0.7 摆动，固定 50/50 更稳。
- CDF-rank fusion 失败，说明校准不一致不是当前主要瓶颈。
- 第三 seed 晋级；第七、第八同构头不再改善，说明 head-count 增长已饱和。

Ensemble selection 的原则是从模型库中选择能降低组合误差的成员，而不是平均所有可用模型。[29]

**结论：后续“替换优先于增加”。**

## 4.6 增强、真实失真和蒸馏

真实姿态错误增强文献说明，遮挡、关节缺失、左右互换、track fragment 和插值伪影应来自真实误差分布，而非任意噪声。[15] 但本项目已完成 fold-local Real-Q/Real-T：它们仍反复伤害 P95。

因此失败不应解释为“增强论文错误”，而应解释为：

- 当前 hardest positives 本身常伴随低质量；
- 质量增强提高了中等样本鲁棒性，却降低模型对弱正例的置信；
- severity stratification 没有修复这一尾部冲突。

蒸馏原理要求 teacher 输出包含学生难以直接获得的平滑知识。[24] 项目内 in-sample teacher 复制训练记忆，OOF teacher C6又受 fold/full domain gap影响，均未晋级。

**结论：Real-Q/T 和 accuracy-oriented distillation 停止。** 蒸馏只在未来需要压缩六头部署成本时，以“保持 anchor 排序”为目标重新设计，不能当作近期提分路线。

## 4.7 融合失败

- 旧 C5-2 在 random-val看似较好，但二层复用 OOF labels 有偏；
- nested C5 两成员 meta-OOF 很低；
- F1 与旧专家 nested fusion 未显著超过 F1；
- six-head nonnegative logistic 低于 equal-logit；
- SVM、RBF-SVM、Logistic、MLP clip head 均低于 anchor。

Stacking、Super Learner 和非负 stacked regression 都依赖严格 out-of-sample level-one 预测以及足够多样的基础学习器。[16][30][31]

相关数据上的普通 cross-validation 还会产生过于乐观的估计，因此 template group 必须贯穿所有层级。[25]

**结论：当前不是“stacking实现还不够复杂”，而是六个成员过于同构、样本量有限、固定融合已经位于更低方差解。**

---

## 5. 当前真正瓶颈

## 5.1 清晰但语义相近的困难负例

证据包确认这40条确为当前R95下分数最高的40个FP：clip顺序、score和CSV完全对齐。标签为13个主动躺下、8个静态躺卧，另有5个`annotation_or_semantic_ambiguity`。10张contact sheets复核未见明显taxonomy矛盾，但“受控/失控”仍不能仅凭稀疏缩略图完全判定。由此可以较强地说**严重度尾部**主要是语义近邻，而不能外推为全部993个FP的比例。核心缺口不是单纯图像质量，而是：

- 动作是否受控；
- 下落—接触—静止的时序顺序；
- 是否存在主动支撑/缓慢放低身体；
- 动作前后的状态转移。

普通 loss reweight、ranking、verifier 和 transition residual都在当前表示上失败，说明“受控性”尚未成为足够独立的可分信息。

## 5.2 静态 post-fall 与 slow/partial fall

证据包确认这40条确为当前R95下分数最低的40个FN；其中10个静态post-fall、8个缓慢/局部fall、9个语义歧义。16-frame last-token对短时突发事件合适，但transition一旦离开窗口，当前embedding只看到“已经躺着”。这可能是lie_down与post-fall难分的原因之一，但需要完整视频和track连续性验证，不能由contact sheet单独证明。

## 5.3 小目标、遮挡、多人竞争和 track 错配

40个最低分FN中有13个被正式taxonomy归为`visual_quality_limitation`；报告另称至少21/40带次要质量因素。contact sheets支持这些样本确有小目标、遮挡、多人竞争、边缘构图或结构遮挡，但不能独立判定实际track ID是否错配。Person-ROI已补充视觉信息；若后续中间工件证明确实选错person track，分类器再强也只能处理错误对象。

ByteTrack 的核心机制是把低分检测也纳入关联，减少遮挡导致的真目标丢失和轨迹碎片。[10] 这比继续在分类 head 上加质量 gate 更直接地针对输入错误。

## 5.4 fold-3 domain shift

六头 fold-3 为 `65.763/71.840/59.686`，明显低于其他 folds。平均分继续上升并不能保证这个模板区域被修复。下一阶段每个候选都应单列：

- fold-3 actor/view/template metadata；
- 目标尺寸、遮挡率、多人比例、track切换；
- lie_down/lying/fall subtype 构成；
- 当前六头相对双头的 unique rescue / introduced errors。

---

## 6. 后续可行改进路线

## 6.1 P0：补齐成员级复现闭包、完成全链路与随机错误审计

**这是竞赛冻结前唯一必做项，不是训练实验。**

证据包已经完成P0的一部分：融合输出NPZ、指标汇总、双头对比摘要、R95错误列表、80条尾部标签和缩略图均已落盘并通过本轮一致性检查。剩余工作应聚焦缺口，不必重复制作已存在的摘要。

### 工作内容

1. 补充并hash：六个成员raw clip logits、双头baseline数组、`clip_id→template_group→fold` manifest、六个配置、checkpoint metadata、评测脚本和grouped bootstrap明细。
2. 修正五折配对审计的`protocol`字段，重新生成并签名，避免被误读为random-validation。
3. 最新全链路 benchmark：pose + track + skeleton + 320 YOLO + 640 YOLO + 六 heads + aggregation；报告 batch=1、warmup、P50/P95、峰值显存、FP32权重体积和目标 V100条件。
4. 对 R95 FP/FN 做**随机分层人工审计**，而不是继续只看最高分40 FP/最低分40 FN。
5. 专门解释 fold-3，不再只汇报总体均值。

### 通过门

- 已提供融合结果可从逐clip scores独立复算；六个成员→融合也能从raw logits重建；
- 9600/9600 clips完整，template-group manifest可证明分组约束并允许复做grouped bootstrap；
- 指标与 DOCX一致到预定数值容差；
- 双头baseline数组可复算六头增量和R95 rescue/introduced集合；
- `≤20M/≤80MB/≤100ms` 在声明口径下有真实输出；
- sealed test 和 URFD test 均未访问。

## 6.2 P1：track-first 的多人/遮挡修复

### 假设

部分 FN源于检测/关联阶段选错人或丢失低置信度目标；这类错误无法由当前六头分类器纠正。

### 单一变化候选

- 保持六头分类模型和权重不变；
- 在现有 detector 输出上测试低分框关联、轨迹连续性或 top-2 track hypothesis；
- 每个 clip 最终仍使用固定、可审计的 actor选择规则；
- 不引入基于标签训练的动态 gate。

ByteTrack 为低分检测关联提供直接机制依据。[10]

### 最小判别实验

先对人工确认的“遮挡/多人/track错配”FN和同类型非跌倒对照做**无训练 replay**。只有能恢复正确 actor token且不引入大量其他人 FP，才进入一个 fold 的 bounded canary。

### 晋级/停止门

- 必须对 track-error slice 有明确恢复；
- 全体 P95 不下降，P90不得出现不可解释损伤；
- 多人 non-fall FP 不增加；
- 端到端 P95 latency 仍在预算内；
- 若 top-2 只重复同一错误或 clip-max 被旁人高分劫持，立即停止。

## 6.3 P2：状态转移专家，但必须使用新的时序信息

现有 transition residual 单头有强信号，说明方向不是完全错误；失败点在于它与源成员相关性 `0.9918`。

### 候选设计

仅允许下列之一作为单变量：

- 对**原始 ROI token**做一阶/二阶 causal difference，再用极小 temporal head；
- 使用 TSM 式零/低参数时间移位，让视觉通道在相邻帧交换信息；TSM 的目标正是低开销时间建模。[11]
- 把“transition发生”和“当前 lying状态”分成两个可解释子分数，但不做负向 suppressor。

不得复刻“TCN最后状态-最初状态+mean frame diff”的现有 residual。

### 融合方式

- 先训练一个 320 fold-0 / fold-3 canary；
- 若单头通过，**替换六头中最弱的同分辨率成员**；
- 不直接加第七头；
- 不学习动态权重。

### 晋级门

- 单头 mAP、P95 不下降；
- 在 controlled lie_down 与 slow/static fall 两类上同时给出净变化；
- 与被替换成员的错误集合有可测互补，不能只报告 score correlation；
- 六头替换版必须改善 OOF，且 unique R95 rescue 大于 introduced errors；
- 若仍是 `r≈0.99` 且 ensemble不升，永久停止该表达族。

## 6.4 P3：SWA 作为“成员替换”稳定化 canary

SWA 通过平均同一训练轨迹上的多个权重，倾向找到更宽的解，并几乎不增加推理成本。[9]

### 为什么值得但优先级不高

- 优点：不增加部署参数或 head 数；可能降低单 seed方差；
- 风险：可能使不同 seeds 更相似，损伤 ensemble diversity；当前固定12 epochs也未必形成适合平均的轨迹。

### 最小实验

只对当前最弱的一个 head，在原训练预算内预声明最后若干 checkpoint 的平均规则；不增加超参数搜索。先报告单头，再报告替换版六头。

### 停止门

若单头改善但替换六头不改善，或 inter-head error correlation上升，停止；不得转为第七头。

## 6.5 P4：面向高召回指标的低权重 surrogate

当前 focal loss针对困难样本，但不是 P@R90/P@R95 的直接目标。[3] 可扩展的非可分解指标和 AUPRC surrogate提供了理论路径。[26][27]

### 设计约束

- 保留主 balanced focal；
- 只增加一个很小权重的 PR/recall-constrained auxiliary；
- 单头、单fold canary；
- 不同时修改 sampling、backbone 或 fusion；
- 固定阈值扫描代码和工作点定义。

### 风险

本项目已有 ranking loss和hard-negative weighting失败；PR surrogate也可能牺牲极难正例、产生不稳定 batch统计。因此它是**低优先级研究项**，不是近期主线。

## 6.6 P5：显式 floor/support/controlledness 信息

语义 FP若能从画面判断“主动支撑、缓慢下放、与床/地面接触”，当前 person-ROI mean可能把关键空间关系平均掉。未来可考虑极低维、可解释的新信息：

- feet/hip 到估计 floor line 的距离变化；
- bbox底边/姿态与支撑面的相对几何；
- 手部支撑持续时间；
- deceleration—contact—stillness 的有序事件。

但 context ROI和高维空间统计已经失败，所以该路线只有在随机人工审计证明这些线索在足够多 severe FP 中可见时才启动。不得直接引入大场景分割器或高维 context backbone。

## 6.7 P6：dense causal history / state-space memory

S4和Mamba为长序列提供线性复杂度状态空间建模机制。[12][13] 它们说明“长历史不一定需要全注意力”，但没有证明本项目会获益。

### 何时值得

只有随机审计确认大量 FN 是“transition已离开16帧但需要保持事件记忆”，且 track identity连续时才启动。

### 最小结构

- 保留当前 16-frame六头分类；
- 在连续同一 track 的 window embedding 或原始低维 kinematic stream 上增加一个极小 causal state memory；
- 输出只能提供**额外正向历史证据**，不能做 suppressor；
- state在track切换/长缺失时显式reset。

### 为什么不是近期主线

- event GRU verifier已经伤害P95；
- 既有48帧候选召回不足；
- SSM/Mamba会增加实现和复现风险；
- 截止日前不适合引入新序列框架。

---

## 7. 模型融合指导

## 7.1 当前推荐顺序

1. **保留六头 fixed equal-logit。**
2. 新候选先做单头完整 OOF，再做“一换一”替换。
3. CDF-nonnegative logistic只保留为“P95优先政策”的审计对照；在成员数组、group manifest和直接配对区间补齐前不替换anchor。
4. 只有出现真正异质的新成员，才比较固定小权重与 nested nonnegative L2 stacking。
5. dynamic quality gate / MoE 继续冻结。
6. distillation 仅用于部署压缩，不作为准确率提升路径。

## 7.2 新成员准入数据契约

每个候选必须提供同一张 clip-level表：

```text
clip_id
label
activity/subtype
template_group
outer_fold
resolution
member_id
raw_clip_logit
prediction_source_checkpoint
checkpoint_train_groups_hash
```

硬约束：

- 先在每个成员内部完成 window→clip aggregation；
- 所有成员覆盖完全相同的 9,600 clip IDs；
- 任何 meta learner 的输入都必须来自没有训练该 template group 的模型；
- normalization、calibration、member selection和权重都只在相应 outer-train 内完成；
- random-validation 不参与；
- sealed test不参与。

## 7.3 互补性门，而不是“单头更高”门

候选至少报告：

- 相对被替换成员的 score/error correlation；
- 六头错误中的 unique rescue、shared rescue、introduced errors；
- R90和R95分别的FP/FN变化；
- fold-3单列；
- paired template-group bootstrap区间；
- 权重/成员在各 outer folds 的稳定性。

高相关不是自动拒绝条件，但如果没有 unique rescue，高单头分数也不能进入 ensemble。

## 7.4 何时才重启 stacking

经典 stacking 和 Super Learner都依赖严格 cross-validated base predictions。[16][31] 当前 six-head logistic 失败后，只有满足以下全部条件才重启：

- 至少一个新成员使用不同观测信息，例如修复后的 actor track、显式floor/support或独立motion token；
- 单头完整 template-group OOF；
- nested outer-fold评估；
- 非负 L2、系数和为1或明确约束；
- 与 fixed equal-logit 使用相同 clip logits和评测路径；
- mAP与P95联合过门，系数跨fold稳定。

否则固定融合应继续优先。

## 7.5 校准、rank fusion与动态门控

温度缩放等校准方法可改善概率校准，但单模型单调变换不会直接改变自身排序；它只有在多模型加权时可能改变组合排序。[17] 本项目 CDF-rank和nested quality calibration均失败，表明当前瓶颈不是简单的scale mismatch。

动态门控需要稳定的“哪个专家在当前样本更可靠”的监督；现有质量代理尚未满足这一条件。因此继续冻结。

---

## 8. Deadline-aware 行动方案

## 8.1 截止前：冻结准确率架构

1. 固定六头模型、logit融合公式、OOF指标实现和阈值政策；
2. 接受六头为**研究anchor**，但在成员级复现闭包和端到端benchmark完成前，不称为已复现部署模型；
3. 补齐P0剩余工件、修正五折audit protocol元数据，并完成V100等价条件benchmark；
4. 检查匿名提交、模型大小、依赖闭包、缓存与checkpoint hash；
5. 不再启动P1–P6训练；
6. 不访问sealed test或URFD test。

## 8.2 截止后研究顺序

1. 随机分层R95人工审计 + fold-3 domain shift；
2. track-first无训练replay；
3. 若有明确track恢复，再做一个fold bounded canary；
4. transition新表达的一换一成员替换；
5. SWA替换canary；
6. 只有证据继续指向static-history问题，才做dense state memory；
7. metric surrogate、floor/support和stacking均后置。

---

## 9. Lane B 决策卡

### DET-ARCH-20260829-P0：六头事实闭包与部署预检

- **Decision requested**：是否接受六头为冻结候选。
- **Baseline**：DOCX SHA-256 `8d5a...97ab8`；OOF `70.8311/77.5623/64.0998`。
- **Single intended change**：无模型变化；只物化工件、复算指标、benchmark。
- **Budget**：只读评测与部署预检；不训练；不访问test。
- **Completed evidence**：融合输出9,600行完整；七种输出指标/逐折结果差异0；R95错误和80条尾部样本对齐；NPZ/CSV hashes通过。
- **Remaining gate**：成员→融合可重建、双头delta可复算、template-group无泄漏可验证、参数/体积/延迟满足约束。
- **Stop**：clip缺失、fold污染、指标无法复算或P95延迟超预算即BLOCK。
- **Current recommendation**：**研究anchor可接受；复现/部署冻结仍为PARTIAL，优先补齐缺口。**

### DET-ARCH-20260829-P1：track-first canary

- **Hypothesis**：部分严重FN由actor检测/关联错误而非分类能力导致。
- **Single change**：低分检测关联或top-2 track hypothesis；六头权重冻结。
- **Primary metric**：全体mAP/P95 + track-error slice恢复。
- **Guardrails**：多人non-fall FP、P90、延迟不得恶化。
- **Minimum evidence**：先无训练replay，再一个fold；未证明actor恢复则停止。
- **Current recommendation**：**截止后条件批准；当前不花训练预算。**

### DET-ARCH-20260829-P2：transition异质成员替换

- **Hypothesis**：原始ROI token的状态变化包含当前head未编码的受控性信息。
- **Single change**：一个新的causal motion-token head；替换一个成员，不增加第七头。
- **Guardrails**：P95不降；slow/static fall不被压低；unique rescue为正。
- **Stop**：与源成员近重复且替换六头不升。
- **Current recommendation**：**仅研究候选，需先完成P0/P1证据。**

---

## 10. 最终建议

### 保留

- Stage-S1 six-stream skeleton backbone；
- Joint-only Transformer adapter；
- frozen YOLO P3/P4 Person-ROI mean tokens；
- 320/640独立heads；
- original/20260829/20260830三个seeds；
- 六头 fixed equal-logit；
- clip-max-before-fusion；
- template-group OOF选择协议。

### 停止

- 第七/第八同构head；
- learned resolution weights、CDF-rank和当前准确率政策下的six-head logistic；CDF-nonnegative只保留为P95政策对照，不直接部署；
- quality gate/cross-head/calibration；
- 同源 verifier/suppressor/ranking；
- Real-Q/Real-T与severity增强；
- context ROI、高维空间统计、attention pooling；
- ST-GCN/InfoGCN/SA replacement或同源fusion；
- accuracy-oriented蒸馏；
- 使用random-validation继续选型。

### 条件探索

- actor track/多人关联修复；
- 使用不同原始时序信息的transition成员，并只做一换一；
- SWA成员替换；
- 随机错误审计支持后，再研究floor/support或dense state memory；
- 只有出现真正异质成员后才重启nested stacking。

### 一句话判断

> **证据包把六头融合的9,600条输出、逐折指标和R95错误集合从“报告声明”升级为“可独立复算”；它没有把成员级融合、双头增量、template-group无泄漏或部署闭包升级为可复现事实。当前应保留equal-logit研究anchor，停止同源复杂化，优先补齐成员/group工件与全链路benchmark，再围绕actor可观测性和真正异质的状态转移信息做一换一实验。**

## 11. 本地证据账本

以下为本报告对项目事实的直接依据；它们是本地只读工件，不替代后面的论文机制来源。

| ID | 工件 | 用途 | 独立核验结果 |
|---|---|---|---|
| EV-1 | `.../01_report/外部专家离线审计包.docx` | 最新实验结果叙述 | hash=`8d5a...7ab8`，与外部DOCX一致 |
| EV-2 | `.../01_report/完整研究审计报告_可检索源稿.md` | 结构、实验和限制全文 | 已全文读取589行 |
| EV-3 | `.../02_metrics_and_predictions/edgefall_f1_six_roi_heads_fivefold_oof_meta_oof_predictions.npz` | 9,600条OOF融合输出 | hash=`c4e6...81f2`；七种指标与逐折结果差异0 |
| EV-4 | `.../02_metrics_and_predictions/edgefall_f1_six_roi_heads_fivefold_oof.json` | 融合协议、member hashes、汇总、相关矩阵 | NPZ hash一致；成员源文件不在包内 |
| EV-5 | `.../02_metrics_and_predictions/edgefall_f1_six_roi_heads_vs_two_heads_fivefold_audit.json` | 双头→六头配对摘要 | challenger hash一致；baseline array缺失；protocol字段需修正 |
| EV-6 | `.../03_error_audit/gpt56_confirmed_review_labels.csv` | 80条尾部taxonomy | hash=`69cc...f7c2`；80 IDs唯一且与NPZ错误顺序一致 |
| EV-7 | `.../03_error_audit/mosaics/*.jpg` | 10张8-up视觉复核 | 80格无明显静态矛盾；不替代完整视频 |
| EV-8 | `docs/research/2026-08-29_evidence_recomputation.json` | 本轮独立复算记录 | 9,600 rows、七种输出、五折、R95和缺口清单 |
| EV-9 | `docs/research/2026-08-29_evidence_mosaic_review.json` | 本轮contact-sheet复核记录 | 10 mosaics/80 tiles；0明显矛盾，限制已声明 |
| EV-10 | `docs/research/2026-08-29_mimo_evidence_reproduction.md` | MiMo独立复现记录 | `PARTIAL`：score层复现，成员/group/代码/随机验证仍缺；发现mAP*命名问题 |

## Sources

[1] https://openaccess.thecvf.com/content_cvpr_2017/html/Lin_Feature_Pyramid_Networks_CVPR_2017_paper.html — Feature Pyramid Networks for Object Detection
[2] https://openaccess.thecvf.com/content_ICCV_2017/html/He_Mask_R-CNN_ICCV_2017_paper.html — Mask R-CNN
[3] https://openaccess.thecvf.com/content_ICCV_2017/html/Lin_Focal_Loss_for_ICCV_2017_paper.html — Focal Loss for Dense Object Detection
[4] https://arxiv.org/abs/1803.01271 — An Empirical Evaluation of Generic Convolutional and Recurrent Networks for Sequence Modeling
[5] https://arxiv.org/abs/1709.01507 — Squeeze-and-Excitation Networks
[6] https://proceedings.neurips.cc/paper/7181-attention-is-all-you-need — Attention Is All You Need
[7] https://openaccess.thecvf.com/content_CVPR_2019/html/Abu_Farha_MS-TCN_Multi-Stage_Temporal_Convolutional_Network_for_Action_Segmentation_CVPR_2019_paper.html — MS-TCN: Multi-Stage Temporal Convolutional Network for Action Segmentation
[8] https://proceedings.neurips.cc/paper_files/paper/2017/hash/9ef2ed4b7fd2c810847ffa5fa85bce38-Abstract.html — Simple and Scalable Predictive Uncertainty Estimation Using Deep Ensembles
[9] https://arxiv.org/abs/1803.05407 — Averaging Weights Leads to Wider Optima and Better Generalization
[10] https://www.ecva.net/papers/eccv_2022/papers_ECCV/html/315_ECCV_2022_paper.php — ByteTrack: Multi-Object Tracking by Associating Every Detection Box
[11] https://openaccess.thecvf.com/content_ICCV_2019/html/Lin_TSM_Temporal_Shift_Module_for_Efficient_Video_Understanding_ICCV_2019_paper.html — TSM: Temporal Shift Module for Efficient Video Understanding
[12] https://openreview.net/forum?id=tEYskw1VY2 — Mamba: Linear-Time Sequence Modeling with Selective State Spaces
[13] https://openreview.net/forum?id=uYLFoz1vlAC — Efficiently Modeling Long Sequences with Structured State Spaces
[14] https://proceedings.neurips.cc/paper/2020/hash/d89a66c7c80a29b1bdbab0f2a1a94af8-Abstract.html — Supervised Contrastive Learning
[15] https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html — Enhancing Skeleton-Based Action Recognition Through Realistic Data Augmentation
[16] https://www.sciencedirect.com/science/article/pii/S0893608005800231 — Stacked Generalization
[17] https://proceedings.mlr.press/v70/guo17a.html — On Calibration of Modern Neural Networks
[18] https://openaccess.thecvf.com/content/CVPR2022/html/Duan_Revisiting_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html — Revisiting Skeleton-Based Action Recognition (PoseC3D)
[19] https://arxiv.org/abs/1801.07455 — Spatial Temporal Graph Convolutional Networks for Skeleton-Based Action Recognition
[20] https://openaccess.thecvf.com/content/ICCV2021/html/Chen_Channel-Wise_Topology_Refinement_Graph_Convolution_for_Skeleton-Based_Action_Recognition_ICCV_2021_paper.html — CTR-GCN: Channel-Wise Topology Refinement Graph Convolution
[21] https://openaccess.thecvf.com/content/CVPR2022/html/Chi_InfoGCN_Representation_Learning_for_Human_Skeleton-Based_Action_Recognition_CVPR_2022_paper.html — InfoGCN: Representation Learning for Human Skeleton-Based Action Recognition
[22] https://doi.org/10.1038/s41598-018-24271-9 — Recurrent Neural Networks for Multivariate Time Series with Missing Values (GRU-D)
[23] https://proceedings.mlr.press/v80/ilse18a.html — Attention-based Deep Multiple Instance Learning
[24] https://arxiv.org/abs/1503.02531 — Distilling the Knowledge in a Neural Network
[25] https://arxiv.org/abs/1904.02438 — Cross Validation for Correlated Data
[26] https://proceedings.mlr.press/v54/eban17a.html — Scalable Learning of Non-Decomposable Objectives
[27] https://proceedings.neurips.cc/paper/2021/hash/0dd1bc593a91620daecf7723d2235624-Abstract.html — Stochastic Optimization of Areas Under Precision-Recall Curves with Provable Convergence
[28] https://proceedings.neurips.cc/paper/2021/hash/76ba9f564ebbc35b1014ac498fafadd0-Abstract.html — Attention Bottlenecks for Multimodal Fusion
[29] https://www.cs.cornell.edu/~alexn/papers/shotgun.icml04.revised.rev2.pdf — Ensemble Selection from Libraries of Models
[30] https://statistics.berkeley.edu/sites/default/files/tech-reports/367.pdf — Stacked Regressions
[31] https://doi.org/10.2202/1544-6115.1309 — Super Learner
