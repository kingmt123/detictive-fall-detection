VERDICT: REVISE

Decision scope:
- (a) Analysis report as decision support: REVISE. Its principal research direction is accepted: retain Stage-S1 as the anchor; prioritize input-missingness semantics; stop architecture expansion and same-information suppressors; require clip-max-before-fusion and leakage-free static OOF stacking before any dynamic gating. However, it is currently a research synthesis—not an auditable execution decision record.
- (b) Authorization to spend training or OOF budget: REJECT at this gate. No mask-correction training, five-fold OOF generation, ROI replication, specialist training, stacking execution, or validation confirmation is authorized.
- Authorized next work is read-only evidence materialization and protocol specification only. Sealed test access remains prohibited.

Evidence relied on:
- Architecture report: `D:/HermesWorkspace/Detictive/docs/research/2026-08-26_stage_s1_architecture_failure_and_fusion_review.md`
- Terra audit: `D:/HermesWorkspace/Detictive/docs/research/2026-08-26_stage_s1_terra_review.md`
- Historical attachment: `C:/Users/kingmt/AppData/Local/hermes/attachments/2026-08-26-model-architecture-and-negative-experiment-review.md`
- Repository read-back: `master@b18c2c2291120d41934720549176a1f98488b88c`, with substantial dirty/untracked state.
- Instantiated snapshot parameter count: 161,406, but only for the reviewed untracked source; Terra records source SHA-256 `7ce32c3492234ad43d1ba08a30b8439370713424fa1aae42e6435ffb63a700bb`.
- Synthetic probe and source inspection establish that frame-level masking can emit spurious bone/motion values when individual joints are confidence-zero. This proves a semantic defect candidate, not a performance gain.
- Canonical config, run, checkpoint, full predictions, grouping manifest, and compatible nested OOF implementation are not materialized.
- The available fusion script is clip-stratified rather than template-grouped, fits and evaluates the meta-model on the same OOF rows, lacks nested base cross-fitting, and does not enforce non-negative coefficients.

Threshold result:
- Research-direction threshold: PASS WITH REVISION. The evidence supports preserving Stage-S1 and investigating missingness before adding capacity.
- Architecture-change threshold: NOT MET. No reproducible baseline tuple or five-fold slice evidence exists.
- Fusion-execution threshold: NOT MET. The current “OOF” implementation is incompatible with the proposed leakage controls.
- The reported `71.1794%` random-validation result is descriptive historical evidence only. Because that split has already informed repeated decisions, it must not be used as a future promotion or confirmation gate.
- Negative architecture conclusions must remain scoped to the tested implementations/configurations; they do not permanently reject entire model families.

Residual risks and uncertainty:
- Historical metrics cannot currently be bound to one immutable code/config/cache/checkpoint/prediction tuple.
- The proposed template-group key has not been independently shown to block every synthetic dependency.
- Correcting per-joint masks may remove spurious differences but could also remove missingness information currently exploited by the model.
- Person ROI F1 remains a single-fold observation and may be template-specific.
- Similar HFlip members may not provide enough OOF diversity to justify their compute.
- Nested stacking will require more base-model execution than the report’s “export existing members” wording implies.
- End-to-end V100 latency of any retained multi-model ensemble remains unverified.

Budget/resource compliance:
- This review remained read-only.
- No files were written or edited.
- No training, OOF generation, metric creation, or sealed-test access occurred.
- Current authorized compute spend: zero.

Required follow-up/rollback trigger:
1. Smallest next step—no training:
   - Freeze one authoritative source snapshot or immutable source archive.
   - Materialize the canonical config, exact command/run record, initialization and best-checkpoint hashes, dependency versions, cache/manifest signatures, existing per-clip predictions, raw metrics, and invalidated-run markers.
   - Record the dirty/untracked manifest rather than treating `b18c2c2` alone as the implementation revision.

2. Grouping prerequisites:
   - Produce exactly one unique grouping row for each of the 9,600 train clips: `clip_id`, label, and `template_group`.
   - Require zero missing IDs, duplicate IDs, conflicting labels, or unmapped clips.
   - Freeze the clip-ID grammar, parser source hash, grouping-manifest hash, and fold-assignment hash.
   - Use five outer folds with zero template-group overlap in every train/evaluation split.
   - If stacking is requested, define nested grouped base cross-fitting inside each outer-training split; four inner folds are the default unless a revised card justifies another fixed number.
   - Missing, duplicate, or misaligned prediction rows must fail closed; common-subset deletion is prohibited.

3. Revised Card A prerequisites:
   - Freeze baseline source/config/checkpoint/cache/fold hashes, controlled variables, seed policy, artifact root, runtime/storage budget, and exact slice definitions.
   - A one-outer-fold, one-matched-seed mask canary may later be requested only as a futility screen—not as a success claim.
   - Canary continuation gate: `ΔmAP ≥ +0.30` percentage points, `ΔP@R95 ≥ 0.00`, and clean/high-quality-slice `ΔmAP ≥ -0.30`.
   - Final architecture acceptance requires five outer folds and at least two matched seeds; mean `ΔmAP ≥ +0.30`, mean `ΔP@R95 ≥ +0.30`, `ΔP@R90 ≥ -0.30`, positive mAP direction in at least four of five folds, and a template-group-paired bootstrap 95% CI for mAP whose lower bound is above zero.
   - Failure of the canary gate rolls back to unchanged Stage-S1 and closes mask correction unless new independent evidence is presented.

4. Revised fusion prerequisites:
   - Implement and test nested template-grouped stacking; do not adapt the current clip-stratified script and call its outputs equivalent evidence.
   - Freeze the member set before execution. Do not add real Seed-Q/T, ROI, Residual ST-GCN, dynamic gating, or distillation under the fusion card.
   - Freeze the standardization scope, no-more-than-five-value L2 grid, deterministic solver/seed, template-group bootstrap unit, and operating point for hard-FP comparison.
   - Each outer-fold prediction must come from a base model untrained on that group; meta-training features must come from inner-cross-fitted base predictions.
   - Fusion acceptance requires mean OOF `ΔmAP ≥ +0.50` percentage points and `ΔP@R95 ≥ +0.50`, `ΔP@R90 ≥ -0.30`, positive mAP direction in at least four of five outer folds, paired-bootstrap 95% CI lower bound above zero, no hard-FP increase at the frozen R95 operating point, and deployment resource limits of ≤20M parameters, ≤80MB FP32, and ≤100ms measured end-to-end latency.
   - A member is retained only if its coefficient is positive in at least four of five outer fits and its bootstrap zero-weight rate is below 20%.
   - Failure of leakage, alignment, uncertainty, coefficient-stability, or resource gates rolls fusion back to Primary Stage-S1.

5. Scope boundary:
   - After the artifact and protocol package is complete, request a new decision for exactly one bounded execution card.
   - Do not combine mask correction, new specialists, ROI replication, static fusion, dynamic gating, and distillation into one rerun.
   - Next owner: `default/Hermes`.
