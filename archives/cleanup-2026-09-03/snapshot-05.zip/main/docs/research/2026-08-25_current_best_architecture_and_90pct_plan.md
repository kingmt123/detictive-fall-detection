# 当前最优架构展示与 90% 目标改进方案

日期：2026-08-25  
依据：当前模型代码、固定四模型集成结果、端侧纯视觉调研和原始论文核验  
约束：上一版“强监督事件检测 + oracle ladder”方案按已验证不可行处理，不再作为主路线

## 1. 先回答：目前最有效的架构是什么

当前效果最好的不是单个 `best.pt`，而是一个**固定权重的四模型 logit 集成**：

```text
RGB 视频
   │
   ▼
YOLO11n-Pose（17 个 COCO 关键点）
   │
   ▼
MultiPoseTracker
IoU + 常速度中心预测，多人轨迹
   │
   ▼
每条轨迹构造 16 帧窗口（stride=1，最少观测 8 帧）
   │
   ├── Joint：51D（17 × x/y/conf）
   ├── Bone：32D
   ├── Motion：34D
   ├── Geometry：6D
   ├── Pose Rules：12D
   └── Discriminative Kinematics：15D
        │
        ▼
六个同构 StreamEncoder
每流：1×1 投影到 32 通道
  → 4 个因果多尺度 TCN block
    kernel = 3/5/7，dilation = 1/2/4/8
    depthwise conv + residual + SE
  → 4-head causal self-attention
  → 末帧表示投影到 64D
        │
        ▼
6 × 64D 拼接 = 384D
        │
        ▼
Fusion SE 门控
        ├── 二分类头：Fall / Non-Fall
        └── 训练辅助头：4 类阶段
        │
        ▼
四个同构模型做固定 logit 融合
0.5 × primary + 1/6 × seed1 + 1/6 × seed2 + 1/6 × seed3
        │
        ▼
视频级分数
```

单模型精确参数量为 **161,406**，六个流分别约 2.3–2.4 万参数；四模型时序部分合计约 **645,624** 参数，不包含 YOLO11n-Pose 前端。

当前明确没有启用的模块：

- LSTM；
- ST-GCN replacement/residual；
- Transformer feed-forward encoder；
- gated convolution；
- motion-guided cross-stream attention；
- transition-rule late fusion；
- physics auxiliary。

训练使用窗口 BCE、clip top-20% MIL 和权重 0.2 的阶段辅助损失；验证使用视频内窗口最大概率。当前固定集成结果：

| 指标 | 当前结果 |
|---|---:|
| clip mAP | **71.1794%** |
| P@R90 | **74.0741%** |
| P@R95 | **68.2848%** |

## 2. 重要纠正：普通 Accuracy 90% 实际上已经达到

新调研里的 92%–99% 多数是 Accuracy，而当前 71.18% 是 mAP。二者不能直接比较。

当前 validation 共 1,200 clips。由 P@R 分数可以反推约 222 个正样本、978 个负样本：

| 工作点 | TP | FP | FN | TN | Accuracy | Balanced Accuracy | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|
| R90 | 200 | 70 | 22 | 908 | **92.33%** | 约 **91.47%** | 约 81.3% |
| R95 | 211 | 98 | 11 | 880 | **90.92%** | 约 **92.51%** | 约 79.5% |

这些计数由公开指标分数反推，阈值并未在独立 test 上锁定，因此只能说明：

> 当前系统在开发 validation 上已经具备 90% 以上普通 Accuracy；真正的瓶颈是正类 precision、F1、mAP 和跨域稳定性，而不是 Accuracy 本身。

如果项目验收只写“Accuracy ≥90%”，现有系统已经可以满足，但这个指标会掩盖大量误报。更合理的 90% 目标应定义成以下至少一种：

1. **F1 ≥90%，Fall Recall ≥95%**；
2. **Precision ≥90% @ Recall ≥90%**；
3. **mAP ≥90%**；
4. **跨人物/跨视角 Balanced Accuracy ≥90%**。

难度差异很大。其中第 1 项在 R95 下要求 precision 至少约 85.3%，即 FP 从 98 降到不超过约 36，至少减少约 62 个；第 2 项在 R90 下要求 FP 从 70 降到不超过约 22，至少减少约 48 个。

## 3. 对新调研的判断

### 3.1 可直接采用的结论

- Pose → Tracking → Skeleton temporal model 是端侧主线，与当前项目方向一致。
- TCN 捕获局部运动、Transformer 捕获更长依赖的组合值得做受控升级。
- Normal / Falling / Fallen 三状态比单纯 Fall / Non-Fall 更符合告警过程。
- weighted focal loss、姿态可靠性建模和状态机适合类别不平衡、连续告警场景。
- 端侧主要开销来自 pose extractor，时序模型完全可以保持小于 1M 参数。
- 数据划分和 staged-to-wild 泛化比论文中的单数据集 Accuracy 更重要。

### 3.2 不能直接搬用的结论

- TCNTE 在 UP-Fall、Le2i、GMDCSA-24 上的 92.99%–99.58% Accuracy，不代表当前 OF-Syn 协议可以复制同样数字。
- FallNet 的高 Accuracy 主要证明端侧可运行性，不证明跨数据集 90%。
- LTC-Fall 是 2026 年预印本，当前只验证二分类；论文自己也把完整三状态预测留到未来工作。
- 单帧 YOLO 的 mAP 不能当视频跌倒 Accuracy。
- “工程置信度 92%”是原调研作者的主观判断，不是统计置信区间，也不能作为项目验收证据。

OmniFall 的最新结果尤其重要：单一 staged 数据集上的近饱和结果在真实事故域明显下降；组合 staged + synthetic 训练在 OF-ItW 上的 Fall F1 仍约 65.6%，加入 in-the-wild 训练数据后也只到约 76.0%。因此，若目标是**跨域 F1/mAP 90%**，当前公开证据并不支持仅靠一个轻量 Transformer 达到。

## 4. 新主架构：在当前最优模型上做 TCNTE 兼容升级

上一方案要求改变任务为事件分割并建立多个重型 oracle，既然已验证不可行，本方案不再依赖事件边界检测、PoseConv3D teacher 或重型 RGB teacher。

建议的新主架构为 **Current-v2：六流局部 TCN + 共享长时序 Transformer + 三状态头**。它最大程度复用当前 checkpoint 和特征工程。

```text
YOLO11n-Pose + 当前 MultiPoseTracker
                 │
                 ▼
       48 帧轨迹，保留 pose confidence
                 │
      ┌──────────┴──────────┐
      ▼                     ▼
最近 16 帧局部分支       48 帧上下文分支
当前六流因果 TCN         每 2 帧采样，六流 TCN
      │                     │
      └──────────┬──────────┘
                 ▼
       每时刻/尺度融合到 128D
                 │
                 ▼
       1 层 causal Transformer
       d_model=128, heads=4, FFN=256
                 │
        ┌────────┼─────────┐
        ▼        ▼         ▼
     Normal   Falling    Fallen
        │        │         │
        └────────┼─────────┘
                 ▼
      迟滞状态机 + 最短持续时间
                 ▼
               Alarm
```

### 为什么是 16 + 48 双时间尺度

- 16 帧分支保留当前最优模型已经学到的快速下降和姿态变化。
- 48 帧分支补足“站立 → 失稳 → 下落 → 接触地面”的上下文。
- 48 帧全部高分辨率计算没有必要；上下文分支可以 2 倍降采样，控制延迟和显存。
- 两个分支优先共享 TCN 权重，减少过拟合；只有验证显示明显欠拟合时才拆开。

### Transformer 应加在哪里

当前每个流内部已经有四头 causal attention，但每流最终只输出末帧向量，六流之间仅通过拼接和 SE 融合。新 Transformer 不应再塞进每个流，而应放在：

> 六流融合之后、分类头之前，对融合后的长时序 token 建模。

这样才真正补充当前缺失的跨流、长时序阶段关系。只设置 1 层；若一层没有独立提升，不增加第二层。

## 5. 修改项及预期作用

### A1：长上下文双尺度输入——最高优先级

唯一改动：`window_size 16 → local 16 + context 48`，先不加 Transformer。

目标：确认 16 帧是否是主要信息瓶颈。

通过线：三 seed OOF mAP 平均至少 **+2.0 点**，且 worst seed 不下降超过 0.5 点。

停损：若平均提升小于 0.8 点，停止继续扩大到 64/96 帧。

### A2：融合后单层 causal Transformer

在 A1 胜出配置上增加 1 层 Transformer，`d_model=128`、4 heads、FFN 256、dropout 0.2–0.3。

通过线：相对 A1 至少 **+1.0 mAP**，P@R95 不下降。

停损：若只提高 Accuracy 而 mAP/F1 不提高，删除 Transformer。

### A3：三状态主头，而不是辅助头

把当前四阶段辅助监督简化为部署一致的三状态主任务：

- Normal：包括普通 ADL 与静态非跌倒；
- Falling：不可控下降过程；
- Fallen：跌倒后的持续地面状态。

同时保留一个二分类 fall-union head，输出 `Falling ∪ Fallen`。不做精确事件边界回归。

损失：

```text
L = focal_binary + 0.3 × weighted_three_state + 0.05 × temporal_consistency
```

三状态头用于学习阶段，最终排名仍由二分类 head 给出，避免阶段误差直接破坏 mAP。

### A4：基于真实 pose 错误的增强

之前的轻量 jitter 没有稳定提升，不应继续调 jitter 标准差。改成从当前 YOLO11n-Pose/Tracker 日志统计真实错误，再采样：

- 连续 2–6 帧人体完全缺失；
- 左右关键点镜像交换；
- 单侧肢体块状缺失；
- track ID 短暂切换；
- bbox 尺度和中心缓慢漂移；
- 低置信关键点的条件噪声。

WACV 2024 的现实骨架增强工作报告在真实场景骨架识别上最高约 +4.63 accuracy，但项目必须以自身 pose 错误分布驱动，不能直接复制其增强概率。

通过线：clean OOF 不下降，pose-corruption 切片至少提高 3 点。

### A5：跟踪与质量 token

当前 tracker 是 IoU + 常速度中心预测，不是 BoT-SORT。先不整体替换，而是增加可审计的质量特征：

- track age、missing streak、association IoU；
-检测置信度、可见关节比例；
-bbox 跳变、人体尺度跳变；
-左右关节交换风险。

这些质量量作为额外 token/门控输入，让模型在 pose 不可靠时降低孤立高分。只有错误审计显示 ID switch 占主要 FP，才比较 BoT-SORT。

### A6：确定性三状态机

状态机不是学习式 GRU 后处理器：

```text
Normal --连续 Falling 高分--> Falling
Falling --Fallen 高分持续--> Fallen
Falling --快速恢复且证据不足--> Normal
Fallen --恢复动作持续--> Normal
```

阈值和持续帧数只在 train-only OOF 上确定。它主要优化 false alarms/hour 和告警稳定性，不应宣称提高 ranking mAP。

### A7：物理残差分支——二线创新，不作为首发

当前已有 15D discriminative kinematics，因此不能原样再堆一套“物理特征”。只有 A1–A3 后仍出现受控躺下误报，才将现有运动学拆成：

- CoM proxy：髋/肩中心高度、垂直速度和加速度；
- BoS proxy：踝间距、支撑宽度、躯干投影与支撑关系；
- TTC proxy：下降趋势到地面接触的估计时间。

使用两个小型 LTC/GRU 分支，经过零初始化 residual gate 接入融合向量。LTC-Fall 只作为结构灵感；由于它仍是新预印本和单数据集二分类验证，不把论文 96.63% 当作预期结果。

## 6. 数据与训练调整比再加网络更重要

当前主要训练/验证来自 OF-Syn。若最终目标是现实视频 90%，仅在 OF-Syn 上改结构没有足够证据。

建议按顺序构建三个训练域：

1. **OF-Syn**：保持现有基线可比较。
2. **OF-Syn + OF-Staged**：按 subject/view 分组，验证跨人物和跨视角。
3. **少量目标域校准集**：仅用于训练/校准，真实 test 完全隔离。

训练策略：

- 先冻结 pose extractor，只训练时序模型；
- weighted focal loss 替代当前主 BCE 的受控实验；
- batch 中固定包含 fall、lie-down/lying/stand-up 和普通背景；
- 不再使用已证伪的通用 hard-negative ranking loss；
- 当前四模型集成只作为 teacher/回归基线，不继续增加 seed。

## 7. 面向 90% 的两套验收合同

### 合同 A：如果目标字面上就是 Accuracy ≥90%

当前系统已经达到。接下来需要做的是让数字可交付：

1. 在 train-only OOF 上选择 R90 或 R95 阈值。
2. 锁定阈值，不再查看 validation。
3. 在一次性 validation 上报告 Accuracy、Balanced Accuracy、Recall、Precision、F1 和混淆矩阵。
4. test 仍封存。

成功条件：Accuracy ≥90%、Recall ≥95%，并明确接受当前约 68% precision 的误报水平。

### 合同 B：如果目标是“有效性能 90%”

推荐定义：

| 指标 | 最低目标 | 90% 完整目标 |
|---|---:|---:|
| Accuracy | 92% | ≥94% |
| Balanced Accuracy | ≥90% | ≥92% |
| Fall Recall | ≥95% | ≥95% |
| Precision | ≥85% | ≥90% |
| F1 | ≥90% | ≥92% |
| mAP | ≥82% | **90% stretch** |
| False alarms/hour | <1 | <0.2 |

这里把 mAP 90% 明确标为 stretch，因为当前到目标仍差 18.82 点，现有论文的 in-domain Accuracy 不能证明这段差距可由模型结构补齐。

## 8. 实验矩阵与停损线

所有开发实验使用固定 grouped OOF；每一行只增加一个变量。

| 编号 | 相对当前模型的唯一变化 | 主要判断 | 通过线 |
|---|---|---|---|
| B0 | 当前最佳单模型/固定集成复现 | 基准 | 指标完全复现 |
| M0 | OOF 阈值锁定，不改模型 | 证明 Accuracy 90 | Acc≥90、R≥95 |
| A1 | 16 + 48 双尺度，不加 Transformer | 长上下文价值 | mAP +2.0 |
| A2 | 融合后 1 层 causal Transformer | 全局时序价值 | mAP +1.0，P@R95不降 |
| A3 | 三状态主头 + binary union head | 阶段监督价值 | F1 +2.0，mAP不降 |
| A4 | 真实 pose-error 增强 | 鲁棒性 | corruption切片 +3.0 |
| A5 | track quality token | 抑制跟踪假阳性 | 对应 FP -25% |
| A6 | 确定性状态机 | 告警稳定性 | FA/hour -50%，Recall损失<1点 |
| D1 | OF-Syn + OF-Staged | 跨域泛化 | cross-view/subject BAcc +3 |
| P1 | 物理 residual branch | lie-down 区分 | lie-down FP -30%，整体不降 |

任何实验若三 seed 平均提升小于 0.8 点且没有明确切片收益，立即停止，不进入组合实验。

## 9. 推荐执行顺序

```text
第 1 周：B0 + M0
先证明当前系统普通 Accuracy 已过 90%，锁定指标合同

第 2 周：A1
只验证长上下文，不加新损失和 Transformer

第 3 周：A2
只加融合后单层 Transformer

第 4 周：A3 + A5
三状态主头；跟踪质量 token 单独消融

第 5 周：A4 + A6
真实 pose-error 鲁棒性；状态机做产品级告警评估

第 6 周以后：D1
扩展到 OF-Staged 和跨域协议

仅在明确存在 lie-down 误报瓶颈时：P1 物理残差
```

预期决策：

- 如果 A1 无效，说明 16 帧不是主要瓶颈，不做 Transformer 扩张。
- 如果 A1 有效而 A2 无效，保留双尺度 TCN，删除 Transformer。
- 如果 A1–A5 后 mAP 仍低于 80%，停止承诺 mAP 90，优先增加真实目标域数据。
- 如果 Accuracy 已过 90 但 F1 仍低于 85，不再以 Accuracy 作为对外主指标。

## 10. 文献依据与可信边界

1. Yu et al., **A Real-time skeleton-based fall detection algorithm based on temporal convolutional networks and transformer encoder**, Pervasive and Mobile Computing, 2025. TCNTE、weighted focal loss、Jetson Orin NX 端侧验证。  
   https://www.sciencedirect.com/science/article/abs/pii/S1574119225000057
2. Bach et al., **A lightweight and efficient deep learning model for real-time fall detection on edge device**, Biomedical Signal Processing and Control, 2026. YOLOv8n-Pose + LSTM 的端侧 FallNet。  
   https://www.sciencedirect.com/science/article/pii/S1746809425014533
3. Schneider et al., **OmniFall: A Unified Staged-to-Wild Benchmark for Human Fall Detection**, 2025. 跨 subject/view/domain 和 staged-to-wild 的关键证据。  
   https://arxiv.org/abs/2505.19889
4. Xia et al., **Real-time fall detection based on vision for low-power edge platforms**, arXiv, 2026. 双 LTC、CoM/BoS 和稳定性建模；目前仍是初步二分类验证。  
   https://arxiv.org/abs/2607.12909
5. Cormier et al., **Enhancing Skeleton-Based Action Recognition in Real-World Scenarios Through Realistic Data Augmentation**, WACV Workshops 2024. 基于 pose estimator 实际错误的骨架增强。  
   https://openaccess.thecvf.com/content/WACV2024W/RWS/html/Cormier_Enhancing_Skeleton-Based_Action_Recognition_in_Real-World_Scenarios_Through_Realistic_Data_WACVW_2024_paper.html
6. Duan et al., **SkeleTR: Towards Skeleton-Based Action Recognition in the Wild**, ICCV 2023. 短骨架片段、关联错误与真实多人场景。  
   https://openaccess.thecvf.com/content/ICCV2023/html/Duan_SkeleTR_Towards_Skeleton-based_Action_Recognition_in_the_Wild_ICCV_2023_paper.html
7. Ultralytics, **YOLO11 official documentation**. 当前 pose 前端的训练、推理和导出能力。  
   https://docs.ultralytics.com/models/yolo11

## 11. 最终建议

1. **先不要改模型来追普通 Accuracy 90%**：当前系统在 development validation 上已经达到约 90.9%–92.3%。
2. 把真正目标改成 **Recall ≥95%、F1 ≥90%、Precision ≥85%**；mAP 90%作为 stretch。
3. 新架构只做一条主线：在当前六流因果 TCN 上增加 **16 + 48 双尺度上下文、融合后单层 causal Transformer、三状态主头和 track quality token**。
4. 不再依赖已验证不可行的事件分割/oracle 方案，不继续增加同质 seed，也不复用已失败的 GRU 抑制器和通用 hard-negative ranking。
5. 若 A1–A5 后 mAP 仍低于 80%，瓶颈应判定为数据域和 pose/tracking 质量，而不是时序模型容量；此时增加目标域数据比继续加层更合理。

