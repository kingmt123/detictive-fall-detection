# Devil's Advocate Cross-Review: Fall Detection Architectures

> **Date**: 2026-08-20
> **Baseline**: mAP=65.35%, 84 FPs, main FP = fall vs lie_down (38%)
> **Deadline**: 2026-09-01 (~12 days)
> **Constraint**: RTX 4060 8GB training, V100 16G eval, ≤20M params, ≤100ms

---

## 0. The Two Evaluations Being Cross-Reviewed

### Evaluation A ("Ambitious") — architecture_optimization_report.md
- Proposes 4 architectures (A-D) with expected mAP improvements
- Architecture A: Physical features + Gated Conv → **~72%** (+6-7%)
- Architecture B: GCN-LSTM → **~76%** (+10-11%)
- Architecture C: Gated Conv + Contrastive Learning → **~78%** (+12-13%)
- Architecture D: Lightweight ST-GCN + LSTM → **~74%** (+8-9%)
- Recommends A first (lowest risk), then D (quick validation)

### Evaluation B ("Conservative") — ARCHITECTURE_DIAGNOSIS.md + ANALYSIS.md + TRAINING_DIAGNOSIS.md
- Discovered 4-stream TCN actually hit 61.42% at epoch 2 (not ~40% as initially reported)
- Claims **training strategy is the bottleneck, not architecture**
- Recommends simpler approaches: rule features + MLP (50-60%), expanded TCN (48-55%), rule + TCN hybrid (52-62%)
- Training fixes alone expected to reach 65-75% mAP

---

## 1. INCONSISTENCIES BETWEEN THE TWO EVALUATIONS

### 1.1 Baseline Confusion — CRITICAL

**Eval A** works from baseline **65.35% mAP** (Top-k MIL, pure rules, no trained classifier).

**Eval B** works from baseline **42.93% mAP** (a trained 4-stream TCN model that was underperforming). Then discovers 61.42% was achievable with training fixes.

**Problem**: These two baselines measure **fundamentally different things**:
- 65.35% is a rule-engine mAP (no ML, pure hand-crafted fusion)
- 42.93%/61.42% is a trained TCN mAP

The two evaluations are comparing apples to oranges. Eval A's improvements (+6-13%) are relative to the rule engine baseline. Eval B's improvements are relative to a broken training run. **Neither evaluation clearly establishes what happens when you combine both approaches.**

### 1.2 Overlapping Claim: "Simple > Complex"

Both evaluations claim "simple > complex" — but they mean different things:

- **Eval A** says: Physical features + gated convolution is simpler than GCN-LSTM, so start there
- **Eval B** says: Rule features + MLP is simpler than any TCN, so start there

These are **different levels of simplicity**. Eval B's "simple" is an order of magnitude simpler than Eval A's "simple." Both can't be right about the marginal value of their respective simplicity levels.

### 1.3 Contradictory Parameter Budget Narratives

- **Eval A** says all 4 architectures fit within 3M params (barely above current 3M), citing "classifier params are tiny (1.5K~142K)"
- **Eval B** discusses expanding to 8.9M params with 4-stream TCN
- **Eval A** also separately mentions 8.9M as a "maximum" scenario

**The inconsistency**: Eval A's architectures A-D claim 3M total, but they're ignoring the fact that the current system's 3M is almost entirely YOLO. The actual *classifier* parameters in Eval A's proposals range from 1.5K (gated conv) to ~2M (GCN-LSTM). This is fine, but the presentation is misleading — the architectures aren't really 3M models, they're YOLO + tiny classifiers.

### 1.4 Disagreement on What Caused the Problem

- **Eval A** implies the rule engine is fundamentally limited because it uses fixed weights and linear combinations
- **Eval B** implies the training pipeline was broken (LR decay too fast, no early stopping, too few epochs) and the architecture was actually fine

**These can't both be true.** If Eval B is right that training fixes alone get you to 65-75%, then Eval A's architectures are unnecessary complexity. If Eval A is right that the rule engine's 65.35% is a hard ceiling, then Eval B's training fixes are irrelevant.

---

## 2. CHALLENGING OVER-OPTIMISTIC CLAIMS

### 2.1 Eval A's mAP Predictions Are Unsupported

| Architecture | Claimed mAP | Evidence Basis | Realistic Range |
|---|---|---|---|
| A: Gated Conv | ~72% (+6-7%) | arXiv:2605.20275 reports +3.2% accuracy in a DIFFERENT task | **65-70%** |
| B: GCN-LSTM | ~76% (+10-11%) | 4.2% accuracy gain on URFD (different dataset, different metric) | **66-72%** |
| C: Contrastive | ~78% (+12-13%) | TranCLR +5-10% on skeleton action recognition (NOT fall detection) | **67-74%** |
| D: ST-GCN+LSTM | ~74% (+8-9%) | DDNet competitive on action recognition (vague benchmark) | **66-72%** |

**Why the estimates are too high:**

1. **Cross-domain transfer is NOT free.** The cited papers report gains on URFD, UP-Fall, NTU RGB+D — large, well-curated datasets with 97-99% baseline accuracy. Your data is a competition dataset with synthetic training data and a 65% baseline. The improvements from the literature are relative to much stronger baselines, where the "easy" gains have already been captured.

2. **The cited papers measure accuracy, not mAP.** Your metric is mAP = (P@R90 + P@R95) / 2, which requires maintaining precision at 90-95% recall. This is MUCH harder than accuracy. A +3% accuracy improvement might translate to +0-1% mAP because the FP rate at high recall is what matters.

3. **The 38% lie_down FP problem is harder than it looks.** The papers claim "impulse detection" and "angular velocity" can distinguish fall from lie_down. But in your data, many lie_down clips likely have SOME downward motion that resembles fall onset. The 38% is not all clean cases — some will be genuinely ambiguous.

4. **OmniFall paper's own data contradicts the optimism.** Eval A itself cites: "OF-Syn trained VMAE: 45-52% BAcc" — this is the synthetic data ceiling. Your training data is synthetic (OF-Syn). The architecture can't break through the data quality ceiling.

### 2.2 Eval B's Training Fix Claims Are Also Over-Optimistic

| Claim | Evidence | Problem |
|---|---|---|
| "LR fix: +3-5%" | ep2 was best at 61.42% | The 61.42% was on a DIFFERENT model (4-stream TCN with 103K params) trained on different data. Can't extrapolate to current 65.35% rule engine. |
| "Early stopping: +1-2%" | Standard practice | Reasonable, but the gains from early stopping on the rule engine (which doesn't train) are ZERO. |
| "Stronger regularization: +2-3%" | Standard practice | Only applies to trained models, not rule engines. |
| "Longer training: +2-3%" | ep2 was best early | If the model overfits by ep2, training longer HURTS, not helps. |
| **Total: "+8-13%"** | Additive | **The gains aren't additive — they interact non-linearly. Also, these only apply to trained classifiers, not the current rule engine.** |

**Critical problem**: Eval B's TRAINING_DIAGNOSIS.md analyzes a 4-stream TCN with 103K params that peaked at 61.42%. But the current baseline (65.35%) is a RULE ENGINE, not a trained model. The training fixes only matter if you're training a model — and the rule engine doesn't train.

### 2.3 Both Evaluations Underestimate the Fall↔Lie Down Problem

Both evaluations assume the fall↔lie_down confusion can be "solved" by:
- Eval A: Adding impulse/angular velocity features, contrastive learning
- Eval B: Adding more physics features, expanding the rule engine

**Reality check**: If 38% of FPs are lie_down, that's 32 clips out of 84. Even if you perfectly eliminate all lie_down FPs (impossible), you'd go from 84→52 FPs. The mAP improvement from this alone would be modest because mAP also depends on P@R95, where other FP types (other=14, lying=9, stand_up=9) also matter.

**The math**:
- Current: 84 FPs → mAP 65.35%
- If you eliminate ALL 32 lie_down FPs: 52 FPs → estimated mAP ~70-72%
- If you eliminate HALF of lie_down FPs (realistic): 68 FPs → estimated mAP ~67-68%
- Both evaluations predict gains of +6-13% — but the theoretical maximum from fixing lie_down alone is only +5-7%

### 2.4 The "PIFR 97% Accuracy" Claim Is Misleading

Both evaluations cite PIFR (PMC 2025) achieving 97% accuracy with "simple angles." But:

1. PIFR tested on a small, clean dataset (likely <500 samples)
2. "Accuracy" on balanced binary classification is NOT comparable to your mAP metric
3. PIFR's 97% likely means "correctly classifying 97% of clips" — including many easy non-fall clips
4. Your 65.35% mAP is measured at R90/R95, which is a much harder evaluation protocol
5. PIFR's "simple features" may not generalize to your competition dataset's distribution

---

## 3. BLIND SPOTS BOTH REVIEWERS MISSED

### 3.1 🔴 Neither Addresses the Validation Set Size Problem

1,200 validation clips is small. With 84 FPs, you're optimizing mAP based on ~84 data points. A single FP elimination changes mAP by ~0.3-0.5%. This means:
- **Your mAP estimate has high variance** — ±2-3% based on which specific clips are FP
- Any architecture change could improve OR degrade mAP by 2-3% purely by luck
- **You cannot reliably distinguish a +3% improvement from noise**

### 3.2 🔴 Nobody Discussed the Interaction Between YOLO and Classifier

The pipeline is: YOLO → Tracker → Features → Classifier. But:
- YOLO's pose estimation quality affects ALL downstream features
- If YOLO misdetects a pose (wrong joint positions), the classifier can't recover
- **Upgrading YOLO from n→s (9.9M params) might give more mAP than any classifier change**
- Neither evaluation seriously considers this option (though lightweight_options.md mentions it)

### 3.3 🔴 The Competition Metric Specifics Are Under-Explored

mAP = (P@R90 + P@R95) / 2 means:
- You MUST achieve 90% recall — missing fall events is penalized
- At 95% recall, precision will be even lower (more FPs tolerated)
- **The optimal strategy might be to LOWER the detection threshold** (accept more FPs) rather than trying to eliminate FPs
- Neither evaluation analyzes the current threshold's position relative to optimal

### 3.4 🟡 Data Augmentation Is Underestimated as a Quick Win

Both evaluations mention augmentation but treat it as secondary. For a competition with synthetic training data:
- **Random skeleton noise** (simulating pose estimation errors) could be worth +2-3% alone
- **Speed perturbation** (simulating different fall speeds) directly addresses the fall/lie_down boundary
- **Mixup between fall and lie_down** clips creates hard negative training examples
- These are 0-cost in parameters and <1 day of implementation

### 3.5 🟡 The Threshold Optimization Is Free Money

Both evaluations mention threshold optimization but don't prioritize it. For your metric:
- Grid-searching th_hi and th_lo over the validation set is a 1-hour task
- Expected gain: +1-3% mAP (significant given the baseline)
- **This should be done FIRST, before any architecture change**, because it establishes a fair baseline

### 3.6 🟡 Neither Evaluation Considers Ensemble Methods

With 12 days, you could train 2-3 different classifiers and ensemble them:
- Rule engine + trained TCN → weighted average
- Different window sizes (16, 24, 32 frames) → vote
- This is low-risk and often gives +2-3% mAP for free

### 3.7 🟢 The "No Trained Classifier Yet" Fact Changes Everything

The user says "Current system is pure rules, no trained classifier yet." This means:
- The 65.35% is achieved WITHOUT any ML — just hand-crafted features and rules
- ANY trained classifier (even a simple MLP on the existing 5 features) might improve this
- The training fix discussion in Eval B is moot — there's nothing to fix yet
- **The first thing to do is train ANY classifier on the existing features to see if it beats 65.35%**

---

## 4. FINAL OBJECTIVE RANKING

### Ranking Criteria
- **Expected mAP gain** (honest estimate, not optimistic)
- **Implementation time** (days, given 12-day deadline)
- **Risk** (probability of the gain materializing)
- **Confidence** (how certain I am about the estimate)

### Ranking

| Rank | Architecture | Expected mAP | Time | Risk | Confidence | Notes |
|------|---|---|---|---|---|---|
| **1** | **Training fix + threshold optimization on existing features** | **67-70%** | **0.5-1 day** | **Low** | **High** | Free money. Train a simple classifier on existing 5 features, optimize thresholds. This establishes a real ML baseline. |
| **2** | **Physical features expansion + rules (Eval A's Phase 1)** | **68-71%** | **1-2 days** | **Low** | **High** | Add acceleration, angular velocity, arm spread. Directly targets the 38% lie_down FPs. Minimal code change. |
| **3** | **Gated convolution classifier (Eval A's Architecture A)** | **69-73%** | **2-3 days** | **Medium** | **Medium** | Replaces hand-crafted weights with learnable gates. The paper evidence (arXiv:2605.20275) is relevant but from a different task. |
| **4** | **Data augmentation + focal loss + hard negative mining** | **68-72%** | **2-3 days** | **Low** | **Medium** | Standard ML improvements. Gains are reliable but modest (+2-4%). Should be combined with any trained classifier. |
| **5** | **Dual-stream TCN (Joint + Motion)** | **68-74%** | **3-4 days** | **Medium** | **Low-Medium** | Motion features are the most informative addition. But the improvement from single-stream to dual-stream is uncertain on this dataset size. |
| **6** | **GCN-LSTM (Eval A's Architecture B)** | **67-73%** | **4-5 days** | **High** | **Low** | GCN needs more data than you have (10.8K clips). High overfitting risk. The 4.2% gain from the literature was on a different, larger dataset. |
| **7** | **Contrastive learning (Eval A's Architecture C)** | **68-74%** | **5-7 days** | **High** | **Low** | Contrastive learning is finicky. Temperature, negative sampling, and training stability all need tuning. Not enough time for proper ablation. |
| **8** | **4-stream multi-scale TCN (Eval B's ANALYSIS.md)** | **66-72%** | **4-6 days** | **High** | **Low** | Already demonstrated overfitting issues (42.93% → 61.42% with training tricks, but that was a different run). 4 streams on 10.8K data = overfitting risk. |

### Honest Confidence Levels

| Claim | Confidence |
|---|---|
| "Threshold optimization gives +1-3% mAP" | 90% |
| "Adding physics features eliminates 15-25 FPs" | 75% |
| "Gated convolution outperforms fixed weights" | 70% |
| "Any single architecture achieves >72% mAP" | 40% |
| "GCN-LSTM achieves >76% mAP" | 15% |
| "Contrastive learning achieves >78% mAP" | 10% |

---

## 5. RECOMMENDED STRATEGY (12-Day Plan)

### The Brutal Truth

You have 12 days, a 65.35% baseline from pure rules, and no trained classifier yet. The biggest risk is spending time on complex architectures that overfit on 10.8K training samples. **Your time is better spent on data and features than on architecture.**

### Day-by-Day Plan

| Day | Task | Expected mAP | Risk |
|---|---|---|---|
| **1** | **Baseline establishment**: Train a simple MLP/TCN on existing 5 features. Optimize thresholds on val set. This is your REAL baseline. | 66-69% | Low |
| **2** | **Feature expansion**: Add acceleration, angular velocity, velocity_peak_ratio, arm_spread (4 new features → 9 total). Retrain. | 68-71% | Low |
| **3** | **Exclusion rules**: Add stand_up direction exclusion, initial-state exclusion, duration exclusion. | 69-72% | Low |
| **4-5** | **Gated convolution classifier**: Replace hand-crafted weights with learnable gated conv on 9 features. Add focal loss + label smoothing. | 70-73% | Medium |
| **6-7** | **Data augmentation**: Skeleton noise, speed perturbation, mixup. Hard negative mining (oversample lie_down FPs). | 71-74% | Low-Medium |
| **8-9** | **Dual-stream TCN**: Add Motion stream (frame diffs) to Joint stream. If this doesn't improve over single-stream, abandon quickly. | 71-75% | Medium |
| **10** | **Ensemble**: Average predictions from rule engine + gated conv + TCN. | 72-76% | Low |
| **11** | **Threshold re-optimization**: Final grid search on ensemble predictions. | 73-77% | Low |
| **12** | **Buffer / YOLO upgrade experiment**: If time allows, try YOLO11s-pose and see if better poses help. | ? | High |

### What NOT to Do

1. ❌ **Don't build GCN-LSTM.** Too complex for 10.8K samples, too many days to implement and debug.
2. ❌ **Don't implement contrastive learning.** Too many hyperparameters to tune in 12 days.
3. ❌ **Don't expand to 4-stream TCN.** Already demonstrated overfitting issues.
4. ❌ **Don't spend more than 1 day on any single architecture.** If it doesn't show improvement within 1 day of training, move on.
5. ❌ **Don't trust any mAP prediction above 75%.** The synthetic data ceiling, small val set, and hard metric make higher gains very unlikely.

### Key Risk Mitigation

- **Checkpoint everything.** Every experiment should save the best model. You can always ensemble later.
- **Measure on the actual competition metric.** Don't proxy-optimize on accuracy or loss.
- **If mAP doesn't improve by Day 5, pivot to feature engineering.** More features on a simple model often beats fewer features on a complex model.
- **Keep the rule engine as a fallback.** It's already at 65.35% with zero training. If all ML experiments fail, submit the rule engine.

---

## 6. SUMMARY OF KEY FINDINGS

1. **The two evaluations are inconsistent** on baselines, what caused the problem, and what "simple" means.
2. **All mAP predictions are inflated** by 3-5% due to cross-domain transfer, metric mismatch, and data ceiling effects.
3. **Both evaluations missed** the small val set variance problem, the YOLO upgrade option, and the free money from threshold optimization.
4. **The optimal strategy** is feature engineering + simple classifiers + ensembles, NOT complex architectures.
5. **Honest expected mAP**: 70-75% with optimal strategy. Above 75% is unlikely given the data constraints.
6. **The biggest single improvement** might come from training ANY classifier to replace the fixed-weight rule engine — this hasn't been tried yet.

---

*Cross-review completed 2026-08-20. All estimates are honest best-guesses with explicit confidence levels.*
