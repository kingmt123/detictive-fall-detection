# Sol final principal decision — DET-ARCH-20260829-SOL

VERDICT: APPROVE

Decision scope: 仅批准 `2026-08-29_six_head_post_experiment_architecture_guidance.md` 作为研究与架构指导工件；不批准模型、训练、数据、评测、部署、发布或 sealed-test 行动。

Evidence relied on: 已核验源 DOCX SHA-256 为 `8d5a959cd7a65afdfe5a5f1f31566ea78c550cd9530353ad8e6229262bd97ab8`；审阅该 DOCX、最终指导稿、引用台账及 Terra `PASS`。本裁决依赖报告内记录，不把缺失的代码、权重、逐 clip logits、fold manifests 或执行环境视为已复现证据。

Threshold result:
- 架构分析深度：通过。逐层覆盖六流 Stage-S1、双分辨率 Person-ROI、每头时序融合、参数算术、有效感受野与结构弱点，并正确把瓶颈归因于观测信息、时序覆盖及 actor/track 错误，而非简单容量不足。
- 融合推理：通过。清楚区分 320/640 的强互补与同分辨率 seeds 的弱互补；对 clip-first、equal-logit、transition residual 高相关及 learned/rank/quality fusion 失败的解释一致，且采用“替换优先于增加”。
- 优先级与截止期比例：通过。截止前冻结六头 anchor，只做 P0 工件闭包和全链路预检；P1–P6 后置，避免在缺少可复现工件和延迟证据时扩大范围。
- 可证伪性：通过。P0/P1/P2 及后续候选均给出单变量、切片、OOF、unique rescue/introduced errors、延迟守卫和停止条件；建议不是不可检验的技术清单。

Residual risks and uncertainty: 六头指标真实性、完整 clip 覆盖、无泄漏、bootstrap 明细、端到端参数/体积/显存/延迟均未被本机独立复核；P@R95 相对双头的区间仍跨零。故本批准不等于可复现性、部署性或发布批准。

Budget/resource compliance: **No model or training budget is authorized.** 本裁决也不授权任何新执行预算、测试集访问或模型改动。

Required follow-up: 下一所有者 `default/Hermes`。若后续申请执行，须按 Lane B 另行提交决策卡；首先完成 P0 事实闭包，任一 clip 缺失、fold 污染、指标不可复算或资源门失败即 `BLOCK`。
