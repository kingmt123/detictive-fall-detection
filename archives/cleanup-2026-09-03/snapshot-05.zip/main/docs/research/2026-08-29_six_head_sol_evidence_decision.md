# Sol final principal evidence decision — DET-ARCH-20260829-SOL-EVIDENCE-R4

**VERDICT: APPROVE**

## 1. Decision scope

批准 `2026-08-29_six_head_post_experiment_architecture_guidance.md` 按当前文本交付为**研究与架构指导报告**。

本批准仅覆盖报告交付和研究建议的适证性，不批准或暗示批准以下事项：训练、模型实现或修改、指标或阈值政策变更、sealed/URFD 数据访问、部署、发布、竞赛提交、代码/配置/权重冻结，或任何新的计算与数据预算。本文也不把六头系统判定为已复现模型、无泄漏模型、部署合规模型或发布候选。

下一所有者：`default/Hermes`。

## 2. Evidence relied on

本裁决只依赖以下本地只读工件及其已核验 SHA-256：

- 外部专家证据 ZIP：`e989ae425901992cf4078cc3d83ad62f2091602d4327bbb523e49d3296ac9d8e`（与不可变输入一致）。
- 待交付指导报告：`a12a2729e0edac74417ad50cc15c8d9876031c4d0ecb6936bae01b13712a44f8`（与不可变输入一致）。
- MiMo reproduction：`a9e165b264390c5ac4790dad0bd35b50d1bf303c9f7bfeb9e62f3e96b072e998`，结论 `PARTIAL`（与不可变输入一致）。
- Terra evidence review：`0245f38f31e52d88ab3986f0d7a887655ad9026057d3becad35ea956caf4eec6`，结论 `PASS`（与不可变输入一致）。
- Parent recomputation：`2026-08-29_evidence_recomputation.json`，本机 SHA-256=`4df609986944bf4c91312d6786ca85b473aef57f6827492fcf99505ded4b6fde`。

关键已复算事实为：9,600 条唯一 OOF clip、1,866 正例/7,734 负例、五折行数 `1984/1842/1942/1894/1938`、七个融合输出字段均有限；所有已提供输出的 pooled/逐折 P@R90、P@R95 和项目兼容分数与摘要最大差异为 0；fixed equal-logit 的 R95 threshold=`0.31164392828941345`，TP/FP/FN=`1773/993/93`；80 条严重尾部 FP/FN 身份与确认 CSV 对齐。

本裁决不将报告摘要或哈希引用替代缺失的原始数组、代码、权重、配置、group manifest 或部署测量。

## 3. Acceptance-threshold result

### 3.1 Equal-logit research-anchor recommendation — PASS

将六头 fixed equal-logit 保留为当前**研究 anchor**是连贯且与证据强度相称的建议：

- 已提供的 equal-logit 输出在联合政策的主要字段上为 mAP*=`70.8311%`、P@R90=`77.5623%`、P@R95=`64.0998%`。
- fixed probability 几乎并列；nonnegative/CDF logistic 在 P95 可略优，但以 P90 和 mAP*下降为代价。报告没有把 equal-logit 描述为所有工作点显著占优，而是以主要指标、P95护栏、零拟合参数、低方差和实现简单性联合选取。
- 报告明确指出当前数据不能证明 equal-logit 与近邻融合器之间具有统计显著差异，也不能从缺失的六成员 raw logits 重建融合公式。

因此，推荐强度应维持为 `A-` 的输出层政策判断，而不是成员级复现或方法族优越性结论。若目标政策改为 P95 单指标优先，必须在补齐成员数组、group manifest 和直接配对区间后重新审计，不得沿用本批准自动替换 anchor。

### 3.2 mAP* warning — PASS

报告在结论区和证据审计区均清楚写明：`mAP* = (P@R90 + P@R95) / 2`，它不是标准 PR-curve Average Precision，也不是 AP50/AP50-95；对外交付应使用 `High-Recall Score` 或保留星号并紧邻公式。MiMo 对全部七种输出和五折条目独立确认该定义。

该警告足以防止本研究指导报告内部误读。任何后续摘录、表格或外部发布若删除星号/公式，均超出本批准并触发回滚。

### 3.3 Evidence grades — PASS

A/A-/B/C+ /C 分级与可复现边界一致：

- A/A- 仅用于融合输出指标、逐折结果、R95错误身份，以及七个已提供输出间的政策权衡。
- 双头增量、成员相关性、Person-ROI/320/640归因、参数拓扑等保留为 B 级或报告规格事实。
- random-validation 保持 C+ 且不参与继续选型；sealed-test/URFD 未访问只作为 C 级一致声明，不被写成可独立证明的否定事实。

MiMo 的 `PARTIAL` 与 Terra 的 `PASS` 不冲突：前者描述复现闭包不完整，后者判断报告是否忠实披露并正确约束这些缺口。

### 3.4 P0 blockers — PASS as disclosed blockers; NOT CLOSED

报告正确列出并保留以下 P0 缺口：

1. 六成员 raw clip logits与成员→equal-logit 重建；
2. 双头 baseline 数组、配对 delta 及 rescue/introduced 集合复算；
3. `clip_id→template_group→fold` manifest 与 grouped bootstrap；
4. 代码、配置、checkpoint metadata、评测脚本和参数/权重闭包；
5. random-validation 逐 clip 数组（若继续保留该摘要）；
6. pose→track→skeleton→320/640 YOLO→six heads→aggregation 的端到端 P50/P95、峰值显存、FP32体积及目标硬件测量；
7. 随机分层错误审计和 fold-3 专项解释；
8. 五折配对审计 `protocol=paired_random_validation_prediction_audit_v1` 的错误来源标签修正与重新签名。

这些缺口阻断复现、部署、外部发布和指标变更批准，但不阻断一份已经明确标注边界的研究指导报告交付。特别是 protocol 元数据缺陷必须在外部发布前修正；本裁决不批准带该缺陷的证据包作为发布工件。

### 3.5 Next-experiment priorities — PASS

优先级与现有证据及截止期相称：

- 截止前只完成 P0 事实闭包和无训练部署预检，不再启动 P1–P6 训练。
- 研究顺序先做随机分层错误审计与 fold-3 诊断，再做 track-first 无训练 replay；只有 actor/track 恢复证据成立才进入 bounded canary。
- 新 transition 候选必须使用新的原始时序信息，并以“一换一”替代弱成员而非增加第七头；准入条件包含 OOF、P90/P95、unique rescue、introduced errors 和条件互补。
- SWA、metric surrogate、floor/support、dense causal memory 与 stacking 被合理后置；没有把论文机制或预期收益外推为本项目事实。

该排序直接针对可观测性、track连续性、static/slow fall和条件互补，而不是继续堆同构头、gate或同源 suppressor，方向一致。

## 4. Blocking-edit determination

**本次报告交付不需要 blocking edit。** 当前文本已经包含必要的范围限制、mAP*公式、证据等级、缺失工件、P0门和停止条件。

以下属于后续工件修复或发布门，而不是本指导报告的阻断性文字修改：修正五折 pair-audit protocol 字段、补齐成员/双头/group工件、重建 grouped bootstrap、完成全链路 benchmark，以及做随机分层错误审计。

非阻断性表述约束：后续摘要不得把“当前最佳架构”“必须保留”从“当前证据下的研究 anchor”语境中截取为已独立复现、无泄漏、部署合规或发布就绪的结论。

## 5. Residual risks

- 缺失成员 logits 时，不能证明所提供 fused array 确由声明的六成员 equal-logit 公式生成，也不能复算成员相关性。
- 缺失 baseline array 时，六头相对双头的增量、5/5 folds P95改善和 rescue/introduced 数只能维持 B 级。
- 缺失 template-group manifest 时，无法排除模板泄漏或复做 grouped bootstrap；若分组失效，研究 anchor 的选择依据将被实质削弱。
- 缺失代码/config/weights 时，参数量、共享 backbone 语义、训练配方和可重建性仍是规格事实。
- 双分辨率 YOLO 可能使端到端 P95 latency、显存或体积超过 `≤100 ms/≤20M/≤80MB`；现有结果不能批准部署。
- 80 条审计是严重度尾部而非总体随机样本，不能外推全部 993 FP/93 FN 的原因比例；contact sheet 不能替代完整时序/track审计。
- fold-3 明显较弱，提示 domain/template shift 风险；总体 pooled 指标不能掩盖该风险。
- random-validation 数组缺失且模板重叠，因此不能承担继续选型、调权或阈值搜索。

## 6. Budget and resource compliance

本裁决遵守任务预算：仅本地只读核验与文档写入；未使用网络，未训练，未运行测试，未访问 sealed test 或 URFD test，未修改模型代码、配置、权重、指标或阈值，未执行部署或发布。

**No model or training budget is authorized.** 本批准不产生任何新的算力、数据访问或实施授权。

## 7. Required follow-up and rollback trigger

`default/Hermes` 应将本裁决作为报告交付批准，而不是执行批准。若后续请求训练、实现、指标变更、sealed/URFD访问、部署或发布，必须提交新的独立决策卡并重新审计相应证据。

优先 follow-up：

1. 保持指导报告与本裁决的已核验哈希；
2. 修正 pair-audit protocol 元数据并重新签名；
3. 补齐成员 raw logits、双头 baseline、group manifest/bootstrap、config/checkpoint/eval provenance；
4. 从 raw logits 重建 equal-logit输出并复算全部主指标、逐折结果和配对集合；
5. 完成随机分层错误审计、fold-3诊断和完整端到端资源 benchmark；
6. 在上述闭包通过前，继续标记复现/部署/发布状态为 `PARTIAL/BLOCKED`。

以下任一条件触发立即撤回研究-anchor认可并将后续动作置为 `BLOCK`，直至重新裁决：

- 任一不可变输入哈希不匹配或工件被静默替换；
- 成员 logits 不能重建所提供 equal-logit数组，或指标超出预注册容差；
- clip缺失/重复、标签或fold污染、template-group跨fold泄漏；
- 双头增量或错误救回结论与原始数组实质矛盾；
- mAP*被当作标准 AP 传播，或星号/公式被删除；
- 报告范围被升级为训练、部署、发布或sealed/URFD访问批准；
- 端到端参数、FP32体积、显存或 P95 latency 不满足声明门；
- 新审计发现严重 provenance 错误、未披露 test 访问或足以改变推荐顺序的系统性证据。

## 8. Final principal statement

**APPROVE for report-delivery scope only.** 该报告对 equal-logit 的定位、mAP*警告、证据分级、P0缺口和后续研究优先级均连贯，并且把可复算的融合输出与不可复现的成员、分组、训练和部署闭包明确分开。当前没有阻断报告交付的文字编辑；所有已知缺口继续作为复现、部署和发布的硬门，不能由本批准豁免。
