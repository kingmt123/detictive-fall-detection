VERDICT: BLOCK

Decision scope:
The Stage-S1 document is acceptable as a cautious research synthesis and draft experiment agenda, but the current evidence package is not comparable or reproducible enough to authorize architecture changes, training, OOF fusion, or five-fold ROI execution.

Blocking findings:

1. The authoritative baseline is not materialized or revision-bound.

- The worktree is dirty and contains substantial untracked experimental code. Current repository state is `master@b18c2c2291120d41934720549176a1f98488b88c`.
- The reviewed implementation and training/evaluation paths are untracked:
  - `models/multiscale_multistream_tcn.py`
  - `tools/train_multiscale_multistream_mil.py`
  - `tools/train_tcn.py`
- The canonical config, run, checkpoint, aggregator, and two key audit documents named by the attachment do not exist at their declared paths:
  - `configs/multiscale_multistream_distilled_stage_s1_v1.json`
  - `runs/multiscale_multistream_tcn/distilled_stage_s1_v1/run.json`
  - `runs/multiscale_multistream_tcn/distilled_stage_s1_v1/best.pt`
  - `models/clip_aggregator.py`
  - `docs/audits/2026-08-24-stage-hflip-fixed-ensemble.md`
  - `docs/audits/2026-08-26-clip-fusion-order-and-specialist-seeds.md`
- Only an untracked config copy exists under `parallel_worker_20260824/configs/`. This directly confirms the report’s own disclosure at `docs/research/2026-08-26_stage_s1_architecture_failure_and_fusion_review.md:32-42`.
- Therefore the reported checkpoint SHA, cache signatures, Stage-S1 metrics, ensemble metrics, and negative-experiment tables cannot currently be tied to one immutable code/config/data/prediction tuple.

Consequence:
The reported numbers may be valid historical observations, but they are not presently auditable baselines for a Lane-B comparison.

2. The available OOF implementation does not implement the proposed leakage-free protocol.

The only located fusion implementation, `parallel_worker_20260824/tools/evaluate_oof_multistream_fusion.py`, conflicts materially with the new report:

- It assigns folds by label-stratified individual clip hashing, not by template group: `evaluate_oof_multistream_fusion.py:44-67`.
- It contains no `template_group`, actor/view parser, group-disjoint assertion, or fold group hashes.
- It fits the meta-model on all OOF rows and reports performance on those same rows:
  - fitting: `evaluate_oof_multistream_fusion.py:362-367`
  - reported `fusion_oof`: `evaluate_oof_multistream_fusion.py:408-424`
- That is not an unbiased outer-fold estimate of the complete stacking procedure. Lambda selection, standardization, coefficient fitting, member selection, and evaluation require a clearly nested or otherwise independently held-out meta-evaluation contract.
- Its logistic fit is unconstrained: `evaluate_oof_multistream_fusion.py:78-116`. It therefore does not enforce the report’s proposed `w_i >= 0`.
- Its tests cover only deterministic clip-level fold allocation and finite coefficient shapes, not template-group isolation, nested meta-fitting, missing predictions, fold alignment, or non-negative coefficients: `parallel_worker_20260824/tests/test_oof_multistream_fusion.py:6-39`.

Consequence:
Existing “OOF” outputs cannot be reused as evidence for the proposed template-grouped, non-negative, nested static stack without a new protocol implementation and validation. Card B’s “export existing members” budget is insufficient unless compatible nested artifacts already exist elsewhere and are materialized.

3. The template leakage claim is disclosed but not independently reproducible.

- The report correctly states that random validation and grouped OOF are different protocols and must not be compared directly: `2026-08-26_stage_s1_architecture_failure_and_fusion_review.md:44-49`.
- However, no canonical template-group parser, clip-to-group manifest, fold assignment, parser version/hash, or machine-readable overlap audit was located.
- The “759/759 groups overlap and 1,200/1,200 validation clips match train templates” statement is repeated from the attachment rather than backed by a materialized result artifact.
- It remains unproven that actor/view extraction captures every relevant synthetic template dependency. At minimum, the exact clip-ID grammar and grouping key must be frozen and audited.

Consequence:
The proposed folds cannot yet support a no-leakage claim, and member-to-member comparability cannot be checked.

4. The Lane-B cards are drafts, not executable decision cards.

Card A, `DET-ARCH-P1`:

- Explicitly marks the authoritative baseline as `UNKNOWN/BLOCKING`: report lines 320-334.
- Does not freeze commit, config, cache/split signatures, baseline prediction hash, seed set, or practical success margin.
- “明确下降” is not a numeric stop threshold.
- The proposed one-fold canary may be used only for early futility screening; it cannot authorize a success claim.

Card B, `DET-FUSION-F1`:

- Primary grouped-OOF baseline does not exist: lines 338-353.
- Member set is not frozen.
- The discrete lambda grid, standardization scope, bootstrap unit, operating point for “hard FP,” and coefficient-stability threshold are unspecified.
- It does not explicitly require inner-cross-fitted base predictions for meta-training within each outer fold.
- The report’s proposed artifact schema at lines 229-245 is appropriate, but it is only a contract, not existing evidence.

Card C, `DET-ROI-F1-O5`:

- Lacks authoritative baseline/config/checkpoint/cache/fold hashes, controlled variables, seed policy, minimum replication, artifact paths, and a numeric definition of “fold1大幅反向”: lines 355-369.
- A data-dependent “run fold 1, then decide whether to complete” rule needs a predeclared futility boundary and must not be used to claim five-fold success selectively.
- ROI cache construction and template isolation are guardrail labels, not yet executable checks.

Consequence:
None of the three cards satisfies the required baseline, controlled-variable, replication, threshold, and artifact requirements for training authorization.

5. Internal experimental conclusions exceed the available raw evidence unless read as attachment-derived synthesis.

The report is generally careful about this limitation, especially at lines 32-42 and 384-388. Nevertheless, many negative-result tables use categorical language such as “关闭” or “失败” without materialized per-run configs, predictions, seed records, or paired-comparison artifacts in the current tree.

Consequence:
These conclusions can guide prioritization and prevent casual repetition, but they cannot yet establish irreversible architecture-family rejection. They should remain scoped to “the reported implementation/configuration failed.”

Leakage and conclusion assessment:

- Test seal: adequately respected. Both inputs explicitly prohibit further OF-Syn test access, and no sealed data was accessed during this audit.
- Random-validation leakage: correctly identified. The 71.1794% result is not evidence of cross-template generalization.
- OOF leakage controls: conceptually sound in the report but not implemented or evidenced.
- Architecture conclusions: mostly appropriately bounded. The report correctly avoids generalizing ST-GCN, InfoGCN, PoseC3D, long-context, or RGB failures beyond tested implementations.
- Training authorization: not justified.
- Static fusion authorization: not justified.
- Dynamic gating, distillation, or architecture expansion: correctly not justified.

Non-blocking corrections:

1. Treat the repeatedly used random validation only as a descriptive compatibility check. Calling a future access “validation once” does not restore statistical independence after that split informed architecture, member, and failure-family decisions.

2. Replace “current code parameter count” with a snapshot-qualified statement tied to the reviewed untracked source hash:
   - `models/multiscale_multistream_tcn.py`
   - SHA-256 `7ce32c3492234ad43d1ba08a30b8439370713424fa1aae42e6435ffb63a700bb`
   The count should not be presented as revision-reproducible until that source is frozen.

3. The per-joint masking defect is real in the reviewed source:
   - frame-level `observed`: `models/multiscale_multistream_tcn.py:69-74`
   - frame-pair motion masking: `models/multiscale_multistream_tcn.py:76-81`
   This supports a quality audit and a candidate single-variable repair, but not an expected performance gain before slice evidence exists.

4. Define “hard FP does not increase” at a frozen operating point—such as P@R95 or an explicitly frozen threshold—and freeze the cohort membership/hash. Raw FP totals are otherwise incomparable.

5. Give every positive gate a minimum practically meaningful delta and uncertainty rule. “Any improvement” is not adequate given five-fold variability and extensive prior candidate exploration.

Minimum next evidence:

1. Freeze one authoritative snapshot:
   - commit or immutable source archive;
   - clean/dirty manifest;
   - exact source hashes;
   - environment/dependency versions.

2. Materialize the Stage-S1 evidence bundle:
   - canonical config and config hash;
   - run record and exact command;
   - initialization and best-checkpoint hashes;
   - train/validation cache and manifest signatures;
   - full per-clip Stage-S1 predictions;
   - four-member predictions and fixed-fusion config;
   - raw metric outputs and invalidated-run markers.

3. Materialize the grouping contract:
   - versioned clip-ID parser;
   - `clip_id → template_group` manifest;
   - parser/group-manifest hash;
   - label and group counts;
   - machine-checked zero outer- and inner-fold group overlap;
   - identical clip/fold/label rows across members.

4. Repair Card B before any fusion execution:
   - specify nested grouped cross-fitting or a genuinely independent meta-evaluation set;
   - freeze member set, lambda grid, standardization scope, seed policy, bootstrap unit, coefficient constraints, and numeric gates;
   - require missing predictions to fail closed;
   - do not reuse the current clip-stratified fusion script as template-grouped evidence.

5. Complete each Lane-B card with concrete baseline hashes, data/split version, exact controlled variables, fixed seeds, numeric success/futility thresholds, compute/storage budget, and non-overwriting artifact root.

Smallest repair:
Do not rerun training yet. First materialize and hash the authoritative Stage-S1 baseline, group manifest, fold assignments, and existing per-clip predictions; then revise the cards against those artifacts. After that, a new review can determine whether a one-fold mask canary or read-only OOF export is authorized.
