# 5060 并行工作包接收记录（2026-08-24）

## 来源与完整性

- 交接包：`D:/HermesWorkspace/Detictive/parallel_worker_20260824`
- 谱系（用户确认）：本机完成 Gate2A 后，项目在另一台 RTX 5060 电脑上
  继续开发至本交接包；本机若干“最佳模型”文件源自该包，但此前只复制了
  部分文件，造成当前缺失依赖的半集成状态。
- 本地基线：`b18c2c2`
- 包随附清单：`parallel_worker_20260824/SHA256SUMS.json`
- 清单条目：331
- SHA-256 验证：331 / 331 通过；无缺失、无不匹配。
- 初始化 checkpoint：`checkpoints/distilled_tcn_initialization.pt`
  - SHA-256：`45a40f762d0f6c53b0b7aeb8f239b7260cdc5fb529776cce2b722afe131f8e0f`
  - 结构：checkpoint dict，包含 `model_state`（474 keys）、optimizer/scheduler 状态、epoch、metrics 与 run signature。
  - 保存指标：epoch 10 的 validation `clip_map_percent=69.6307%`。
    这与交接审计的约 69.7% control 一致，但缺少原始 manifest/split hash，
    不得与本机任何历史或当前结果直接横比。

## 已读取交接结论

来源：`2026-08-23-distilled-tcn-controlled-improvement-audit.md`

- OF-Syn 仅使用 train/val cache；sealed test 未读取。
- hard-negative ranking 候选未满足预注册的 `+0.3 mAP` gate，且 P@R90 与固定 hard-negative FP 更差；**不得作为当前最佳模型替换**。
- 在下一次 stage 训练前，必须修复并测试：
  1. stage target builder 覆盖 `fall_process` / `post_fall_state` 的语义标签；
  2. hard-negative / OOF loader 未重建 `use_stage_auxiliary` 架构标志。

## 本机验证

- 交接包的定向模型/训练测试：`28 passed, 3 warnings`。
- 交接包的全量测试：`288 passed, 15 warnings in 9.68s`。
  - 该包按 README 有意不携带 `infer.py`；测试时以本机根目录的
    `infer.py` 作为运行时桥接，并创建测试专用的 `runs/tmp` 父目录。
  - warnings 均为已知 PyTorch nested-tensor warning。
- 本机根目录存在与交接包逐字节相同的
  `models/multiscale_multistream_tcn.py`，但当前不可导入：
  `ModuleNotFoundError: models.tcn_multistream`。
  这证实本机已有半集成状态；不得单独导入 checkpoint 或该模型文件。

## 范围与隔离

- 此记录不代表任何模型性能、可复现性或发布通过。
- 禁止导入或运行 sealed OF-Syn test。
- 不覆盖 `data/manifest.csv`，不训练、不生成 pose cache、不调参。
- FallVision 的视频/CSV 映射尚未验证，相关预训练及 mixed-data 路径保持隔离。
- 由 `t_780b86d4`（Terra）先给出 `PASS / BLOCK / NEEDS-RERUN`，随后由
  `t_73ca8568`（Sol）决定能否将最小 G2 依赖闭包导入根目录。

## 候选最小 G2 导入闭包（尚未批准）

为修复本地现有多流 TCN 的缺失依赖并支持交接包预注册的 G2 residual ST-GCN 配置，静态分析显示至少需要：

- 模型：`models/tcn_multistream.py`、`models/tcn_dataset.py`、`models/tcn_window.py`、`models/lstm.py`
- 工具：`tools/train_tcn.py`、`tools/train_multiscale_multistream_tcn.py`、
  `tools/train_multiscale_multistream_mil.py`、
  `tools/build_tcn_multistream_sidecar.py`、`tools/clip_ids.py`
- 只读产物：G2 config、初始化 checkpoint、原始审计报告。

任何导入都必须保留本地 58 个同路径但内容不同的文件，除非后续逐文件审计和明确批准。
