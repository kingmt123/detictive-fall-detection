# Distilled TCN Controlled-Improvement Audit (2026-08-23)

## Scope and protocol

This audit covers the matched continuation control and the isolated clip-ranking
experiment. Only OF-Syn train/val caches were used. The sealed OF-Syn test was not
read or evaluated. Both runs started from checkpoint SHA-256
`45a40f762d0f6c53b0b7aeb8f239b7260cdc5fb529776cce2b722afe131f8e0f`, used the
same 12-epoch schedule, seed, sampling quota, data and model size (159,866
parameters). The ranking JSON differs only by ranking weight `0.15` and margin
`0.5`.

## Results

| Run | mAP | P@R90 | P@R95 | Fixed hard FP |
|---|---:|---:|---:|---:|
| Matched control | 69.6996% | 74.0741% | 65.3251% | 48/500 |
| Hard-negative ranking | 69.8824% | 72.9927% | 66.7722% | 50/500 |
| Joint-only Transformer reference | 70.2288% | 73.2601% | 67.1975% | 48/500 |

Ranking changed the matched control by `+0.1829/-1.0814/+1.4471` percentage
points. It did not meet the preregistered `+0.3 mAP` canary gate, reduced P@R90,
and increased fixed hard false positives by two; both added errors were
`lie_down`. The candidate is therefore rejected and must not replace the current
best single model. Checkpoint SHA-256 values are
`cbd78e7f6db09d49237ac692a695cd543d6244bb01f663c9e1845d987c0e253e` (control)
and `f7dd4d685e9b5a1c580917203ef3e515e19f27cc7bbf29e54aa19bb172b66d87`
(ranking).

## Implementation findings before the next experiment

1. The prepared stage-target builder assigns fall/fallen first and then
   unconditionally overwrites controlled-activity windows. In the full train
   cache this mislabels 333 `fall_process` and 307 `post_fall_state` windows.
   Semantic positive stages must take priority over the activity-directory name.
2. Hard-negative and OOF model loaders do not reconstruct
   `use_stage_auxiliary`; strict checkpoint loading would fail for a stage-head
   checkpoint. All audited loaders must support the architecture flag before
   stage training starts.
3. Ranking loss is included only in the aggregate training loss and is not logged
   separately. Future ranking experiments need active-pair counts and ranking-loss
   values per epoch to prove the intended supervision was exercised.
4. Control and ranking runs have different source signatures because optional
   stage support was added after the control process started. Review confirms the
   optional path is disabled in the ranking run, but this is not a bit-identical
   code-revision control and should be recorded as a reproducibility limitation.

Regression status: `284 passed, 9 warnings`; Ruff passed. The warnings are the
existing PyTorch nested-tensor notices. No stage experiment should run until the
first two findings are fixed and covered by regression tests.
