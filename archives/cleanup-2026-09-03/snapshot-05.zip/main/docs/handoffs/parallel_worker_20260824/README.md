# Parallel Training Worker

This package intentionally excludes all datasets, videos, pose caches, window caches, existing logs, cloud credentials, and sealed test content. Use only your own already-present data and a locally rewritten manifest. Do not copy the source repository's `data/manifest.csv`: it contains machine-specific paths and sealed splits.

## Setup

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m pytest tests -q --basetemp runs\tmp\pytest-worker
```

Create `data\manifest_local.csv` with the documented manifest header, valid local video paths, and only `train`/`val` rows. Never include OF-Syn `test`; it is sealed.

## Prepare local caches

Use the repository cache/audit and sidecar tools against your local data. Paths below are examples and must remain local to this machine:

```powershell
python -m tools.audit_pose_cache --manifest data\manifest_local.csv --cache-root runs\pose_cache --dataset of-syn --split train --split val --output runs\audits\ofsyn_train_val_pose_cache.json
```

Then build the 16-frame window caches and sidecars using the same train/val protocol. Do not transfer cached data between machines unless its hashes are verified.

## Pre-registered worker task

Run the paused G2 residual ST-GCN experiment after preparing caches/sidecars:

```powershell
python -m tools.train_multiscale_multistream_mil --manifest data\manifest_local.csv --pose-cache-root runs\pose_cache --audit-report runs\audits\ofsyn_train_val_pose_cache.json --window-cache-root runs\tcn_windows --output-dir runs\multiscale_multistream_tcn\worker_g2_residual_stgcn --config configs\multiscale_multistream_distilled_stage_s1_g2_residual_stgcn_v1.json --train-sidecar runs\tcn_multistream_sidecar\of-syn\train --val-sidecar runs\tcn_multistream_sidecar\of-syn\val --initialization-checkpoint checkpoints\distilled_tcn_initialization.pt --device cuda:0
```

Report mAP, P@R90, P@R95, fixed 500 hard-negative FP, `run.json`, `summary.json`, `history.jsonl`, checkpoint SHA-256, and environment versions. Do not tune on val beyond the pre-registered protocol.
