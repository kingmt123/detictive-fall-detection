# Gate2A 后 5060 G2 闭包恢复：干净 Worktree 审计附录

## 范围与授权

- **用户确认的谱系**：本机完成 Gate2A 后，项目在另一台 RTX 5060 电脑上继续开发，形成 `parallel_worker_20260824`；本机先前仅复制了其中一部分最佳模型文件，因而缺少其依赖。
- **Sol 决策**：`t_73ca8568` 于 2026-08-24 作出 `APPROVE`，仅批准零 GPU 的干净 worktree G2 闭包恢复与兼容性审计。
- **Terra 前置结论**：`t_780b86d4` 为 `NEEDS-RERUN`；要求最小闭包、代码层验证和附录，不授予训练、评测或性能主张许可。
- **非目标**：不训练、不生成 cache、不读取/改变数据 manifest 或 split、不访问 sealed test、不做性能结论、不提交/推送/合并。

## 不可变输入

| 项目 | 值 |
|---|---|
| 干净基线 | `b18c2c2291120d41934720549176a1f98488b88c` |
| worktree | `D:/HermesWorkspace/Detictive/.worktrees/handoff_g2_reconcile_20260824` |
| 交接源 | `D:/HermesWorkspace/Detictive/parallel_worker_20260824` |
| 交接清单 | `parallel_worker_20260824/SHA256SUMS.json`（此前已验证 331/331） |
| 初始化 checkpoint | `checkpoints/handoff_20260824/distilled_tcn_initialization.pt` |
| checkpoint SHA-256 | `45a40f762d0f6c53b0b7aeb8f239b7260cdc5fb529776cce2b722afe131f8e0f` |
| G2 config SHA-256 | `54b1c8ea1960daa7de4b3c9978a334e67c37acd05b294c6a3d280c304f6091a8` |

## 导入边界

逐字节从交接源导入、并在复制后重新比较 SHA-256 的 11 个 G2 闭包文件：

- `models/multiscale_multistream_tcn.py` — `7ce32c3492234ad43d1ba08a30b8439370713424fa1aae42e6435ffb63a700bb`
- `models/tcn_multistream.py` — `a690d34fe0b230bb390278db91f6744512e5e5dc0607370b0ea649eeb06c942a`
- `models/tcn_dataset.py` — `764897b32339009f5d19368cc592f6deb09e524e4ce3bac2281ed208beba4154`
- `models/tcn_window.py` — `76075586a8cb8e986a1ba4a5c34d3b59f5a64806e88b919c39fa3855e19ae9d4`
- `models/lstm.py` — `43a81ad4dbd83321105843256b8f3e65783a9346afee7ad87a78bf9df574663a`
- `tools/train_tcn.py` — `8dc5d4fcbe671e829d32566b2b1168063ca632d821f169069a041a59d0f10c5b`
- `tools/train_multiscale_multistream_tcn.py` — `daa770db3ac32425b74bcb11e62c619e725941788313c7f21fe82b72e592e0fb`
- `tools/train_multiscale_multistream_mil.py` — `49bf7dd4634960034497d414bb136f05d9221daf08e50f9c36c1ee519e1b8a5c`
- `tools/build_tcn_multistream_sidecar.py` — `aa3b778887ad2de73d187c7ae99c84cabaa5fb0cdbd42186328f65491749dc8c`
- `tools/clip_ids.py` — `e52e6d38e4b0ecb2ed034358cd93eed6689017cca0c5cd59dff2827aec979077`
- `tools/audit_pose_cache.py` — `a51c7333b05f0223263248f9cd4b0f40926c5f84deef35014c0f0aa51a2b9ab6`

同时暂存但未执行：交接 README、SHA 清单、受控审计报告、`data_manifest_template.csv`、唯一允许的 G2 config、初始化 checkpoint。

明确未导入：整个 worker tree、`__pycache__`/`.pytest_cache`、所有 FallVision/mixed/expert/reranker 家族、hard-negative ranking、非 G2 config、requirements 替换、任何数据/测试产物。

## 唯一 reconciliation：`pipeline/pose_cache.py`

G2 窗口数据层调用 `read_pose_cache(path)` 读取已冻结的训练 cache，而基线只有带 resume 签名比对的 `load_pose_cache(...)`。为保持基线的 resume 安全契约，采用最小合并：

1. `read_pose_cache`：无调用方签名要求地读取并完整 schema 校验只读 cache；
2. `load_pose_cache`：复用 `read_pose_cache`，随后保留原有 source identity 与 extractor signature 比对；
3. 对有效观测增加交接版本已有的 keypoint confidence `[0,1]` 与 bbox `x2>x1,y2>y1` 约束；
4. bbox 检查置于既有 track-id 打包/排序检查之后，以保留基线对于双重非法输入的 `track_ids` 错误优先级。

最终 `pipeline/pose_cache.py` SHA-256：`08b44c1b5e7d7336d30d05c028e8ee83636c26139a3819fa24f426a515f3881a`。

新增测试：`tests/test_handoff_g2_pose_cache_reader.py`，以 RED→GREEN 覆盖只读读取、置信度边界、bbox 几何。

## 实际验证

| Gate | 命令/结果 |
|---|---|
| TDD RED | 新 reader 测试在基线以 `AttributeError: read_pose_cache` 失败；置信度与 bbox 测试均以“未抛出 ValueError”失败。 |
| TDD GREEN | `python -m pytest tests/test_handoff_g2_pose_cache_reader.py -q` → **3 passed**。 |
| 导入 smoke | 导入 `models.multiscale_multistream_tcn`、`models.tcn_multistream`、`models.tcn_dataset`、`tools.train_multiscale_multistream_mil` 均来自本 worktree。 |
| CLI smoke | `python -m tools.train_multiscale_multistream_mil --help` → exit 0。 |
| CPU checkpoint 审计 | 模型 state 522 keys；checkpoint 474 keys；**474 compatible，0 缺失/形状不匹配**；48 个预期新初始化键，均为 `stage_classifier` 与 `streams.0.graph_residual.*`。参数量 184,830。 |
| 闭包测试 | 从交接源运行 8 个 G2 相关测试模块、导入根固定为本 worktree：**63 passed，11.80s**。 |
| 完整本地测试 | `python -m pytest tests -q` → **124 passed，8.56s**。 |
| diff 卫生 | `git diff --check` → exit 0。 |

在闭包选择中有意排除的独立失败：

- `test_tcn_multitask.py` 要求 `models.tcn_multitask`，它不在 Sol 批准的 G2 闭包中；
- `test_extract_keypoints.py` 要求未导入的 `tools.extract_keypoints._select_rows(..., shard_index=...)`；
- 这些模块和所有 FallVision/专家/reranker/ranking 路径均不构成本次运行成功或性能声明。

## 结论与限制

**代码层恢复 gate：PASS（仅限 worktree）**。G2 最小闭包现已可导入、CLI 可解析、初始化 checkpoint 完全键/形状兼容，闭包与全本地测试均通过。

这不是 MAP≥75% 或“当前最佳模型”性能结论。checkpoint 自带历史 validation clip mAP 为 69.6307%，且交接不含可与本机直接比较的原始 manifest/split hash。训练、评测、数据选择或将 worktree 改动合入脏根目录，均需要新的 Lane-B 实验/合并决策。

## 后续所需复核

请 Terra 对本附录及 `pipeline/pose_cache.py` 的最小差异给出 `PASS / BLOCK / NEEDS-RERUN`；如通过，再交 Sol 单独决定是否允许将该已验证 worktree 整合到主工作区。