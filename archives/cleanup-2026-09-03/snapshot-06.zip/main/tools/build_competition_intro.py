"""Create the <=300-character competition work introduction."""
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "tmp" / "competition_intro"
TEAM = "抹茶吃不饱"
PROJECT = "面向低算力平台的实时跌倒检测"
TEXT = (
    "本项目面向养老、康复与无人值守场景，构建纯视觉跌倒检测系统。"
    "以 RGB 视频为输入，YOLO11n-pose 提取 17 个关键点、人体框和轨迹，"
    "结合 16/48 帧双尺度骨架编码与 ROI token，由七个冻结分类头等权融合。"
    "创新在于以“姿态时序+ROI视觉”双证据链，在不读取标签或人物 ID 的前提下，"
    "输出风险分数、候选区间和成员分数。模型为 4.053M 参数、15.46 MiB FP32 参数量；"
    "OF-Syn validation（1,200 clips）mAP 为 75.208%，P@R90/P@R95 为 77.907%/72.509%。"
    "附权重与 SHA-256 清单。"
)


def font(run, size: float, bold: bool = False) -> None:
    run.font.name = "宋体"
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")
    run.font.size = Pt(size)
    run.bold = bold


def main() -> None:
    if len(TEXT) > 300:
        raise ValueError(f"简介超出 300 字：{len(TEXT)}")
    OUT.mkdir(parents=True, exist_ok=True)
    doc = Document()
    section = doc.sections[0]
    section.top_margin = section.bottom_margin = Cm(2.54)
    section.left_margin = section.right_margin = Cm(2.54)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    font(title.add_run("参赛作品简介"), 20, True)
    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    font(meta.add_run(f"{TEAM}  |  {PROJECT}"), 11)
    body = doc.add_paragraph()
    body.paragraph_format.first_line_indent = Cm(0.74)
    body.paragraph_format.line_spacing = 1.6
    font(body.add_run(TEXT), 11)
    note = doc.add_paragraph()
    note.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    font(note.add_run(f"正文 {len(TEXT)} 字"), 9)
    doc.save(OUT / "intro.docx")
    print(len(TEXT))


if __name__ == "__main__":
    main()
