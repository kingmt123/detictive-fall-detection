"""Render publication-like project figures with Pillow only."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


INK = "#17324D"
BLUE = "#335C81"
TEAL = "#2A9D8F"
ORANGE = "#D97757"
GRID = "#D9E2EC"
MUTED = "#52606D"
PALE = "#F4F8FC"


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    path = "C:/Windows/Fonts/msyhbd.ttc" if bold else "C:/Windows/Fonts/msyh.ttc"
    return ImageFont.truetype(path, size)


def title(draw: ImageDraw.ImageDraw, text: str, subtitle: str) -> None:
    draw.text((70, 36), text, font=font(36, True), fill=INK)
    draw.text((70, 90), subtitle, font=font(20), fill=MUTED)
    draw.line((70, 132, 1930, 132), fill=BLUE, width=3)


def arrow(draw: ImageDraw.ImageDraw, start: tuple[int, int], end: tuple[int, int]) -> None:
    draw.line((*start, *end), fill="#477CA8", width=5)
    x, y = end
    draw.polygon([(x, y), (x - 18, y - 10), (x - 18, y + 10)], fill="#477CA8")


def architecture(path: Path) -> None:
    image = Image.new("RGB", (2000, 720), "white")
    draw = ImageDraw.Draw(image)
    title(draw, "端到端无标签推理架构", "因果时序窗口、共享视觉主干与无可学习参数的等权 logit 融合")
    boxes = [
        (70, 285, 290, 470, "RGB 视频流", "H×W×3\n30 FPS"),
        (355, 285, 625, 470, "姿态估计与跟踪", "17 joints + bbox\ntrack_id"),
        (710, 175, 980, 330, "短时骨架编码器", "16-frame, 6-stream\ne16 ∈ R³⁸⁴"),
        (710, 430, 980, 585, "长时骨架编码器", "48-frame, causal\ne48 ∈ R³⁸⁴"),
        (1060, 285, 1305, 470, "共享 ROI 编码", "P3/P4 person ROI\n320 / 640 token"),
        (1385, 285, 1630, 470, "七个分类头", "6×short + 1×long\nraw logits z₁…z₇"),
        (1710, 285, 1930, 470, "固定融合", "σ(Σzᵢ/7)\nscore + proposal"),
    ]
    arrow(draw, (290, 378), (355, 378))
    arrow(draw, (625, 378), (710, 252))
    arrow(draw, (625, 378), (710, 508))
    arrow(draw, (980, 252), (1060, 340))
    arrow(draw, (980, 508), (1060, 425))
    arrow(draw, (1305, 378), (1385, 378))
    arrow(draw, (1630, 378), (1710, 378))
    for x1, y1, x2, y2, label, detail in boxes:
        draw.rounded_rectangle((x1, y1, x2, y2), radius=12, fill=PALE, outline=BLUE, width=3)
        draw.text(((x1 + x2) // 2, y1 + 42), label, font=font(23, True), fill=INK, anchor="mm")
        draw.multiline_text(((x1 + x2) // 2, y1 + 112), detail, font=font(18), fill=MUTED, anchor="mm", align="center", spacing=6)
    draw.text((1000, 660), "部署约束：仅使用视频及运行时生成的轨迹，不读取类别标签、真实事件区间或真实人物 ID", font=font(18), fill="#8A3B12", anchor="mm")
    image.save(path)


def selection(path: Path) -> None:
    image = Image.new("RGB", (2000, 760), "white")
    draw = ImageDraw.Draw(image)
    title(draw, "模型选择证据：互补长时专家带来总体增益", "相同五折 train-OOF 身份、相同指标实现与配对审计")
    panel_x = [70, 710, 1350]
    for x in panel_x:
        draw.rounded_rectangle((x, 165, x + 580, 655), radius=10, outline=GRID, width=2)

    draw.text((360, 198), "六头与七头总体性能", font=font(22, True), fill=INK, anchor="mm")
    labels = ["mAP", "P@R90", "P@R95"]
    six = [70.831, 77.562, 64.100]
    seven = [72.166, 78.762, 65.570]
    base_y = 585
    for i, label in enumerate(labels):
        x = 125 + i * 175
        h1 = int((six[i] - 55) * 12)
        h2 = int((seven[i] - 55) * 12)
        draw.rectangle((x, base_y - h1, x + 52, base_y), fill="#A7B7C7")
        draw.rectangle((x + 60, base_y - h2, x + 112, base_y), fill=BLUE)
        draw.text((x + 56, 610), label, font=font(17), fill=MUTED, anchor="mm")
        draw.text((x + 86, base_y - h2 - 18), f"+{seven[i]-six[i]:.3f}", font=font(14, True), fill="#0B5D48", anchor="mm")
    draw.rectangle((160, 242, 195, 260), fill="#A7B7C7")
    draw.text((205, 251), "六头", font=font(15), fill=MUTED, anchor="lm")
    draw.rectangle((285, 242, 320, 260), fill=BLUE)
    draw.text((330, 251), "七头", font=font(15), fill=MUTED, anchor="lm")

    draw.text((1000, 198), "逐折 ΔmAP", font=font(22, True), fill=INK, anchor="mm")
    deltas = [0.648, 0.500, -0.456, 2.375, 0.234]
    zero_y = 480
    draw.line((765, zero_y, 1235, zero_y), fill="#6B7280", width=2)
    for i, value in enumerate(deltas):
        x = 800 + i * 88
        height = int(abs(value) * 90)
        if value >= 0:
            draw.rectangle((x, zero_y - height, x + 46, zero_y), fill=TEAL)
            label_y = zero_y - height - 16
        else:
            draw.rectangle((x, zero_y, x + 46, zero_y + height), fill=ORANGE)
            label_y = zero_y + height + 16
        draw.text((x + 23, label_y), f"{value:+.3f}", font=font(13), fill=MUTED, anchor="mm")
        draw.text((x + 23, 600), f"F{i}", font=font(16), fill=MUTED, anchor="mm")
    draw.text((1000, 630), "mAP 增益 95% CI [+0.055, +2.333]", font=font(16), fill="#0B5D48", anchor="mm")

    draw.text((1640, 198), "结构搜索收敛轨迹", font=font(22, True), fill=INK, anchor="mm")
    candidates = ["六头", "+Dense48", "+Part8", "Part替换"]
    values = [70.831, 72.166, 71.947, 71.902]
    points = []
    for i, value in enumerate(values):
        x = 1405 + i * 155
        y = 560 - int((value - 70.5) * 190)
        points.append((x, y))
    draw.line([coord for point in points for coord in point], fill=INK, width=4, joint="curve")
    for i, (x, y) in enumerate(points):
        color = TEAL if i == 1 else BLUE
        r = 11 if i == 1 else 8
        draw.ellipse((x - r, y - r, x + r, y + r), fill=color)
        draw.text((x, y - 28), f"{values[i]:.3f}", font=font(14, True), fill=color, anchor="mm")
        draw.text((x, 605), candidates[i], font=font(15), fill=MUTED, anchor="mm")
    draw.text((1000, 714), "注：这是结构选择轨迹，不等同于 epoch-wise 训练损失曲线。", font=font(17), fill=MUTED, anchor="mm")
    image.save(path)


def runtime(path: Path, smoke: dict) -> None:
    image = Image.new("RGB", (2000, 760), "white")
    draw = ImageDraw.Draw(image)
    title(draw, "运行时证据：耗时、成员输出与时间定位可独立复核", "URFD fall-01-cam1，160 帧端到端 CPU 烟测")
    for x in [70, 710, 1350]:
        draw.rounded_rectangle((x, 165, x + 580, 655), radius=10, outline=GRID, width=2)
    draw.text((360, 198), "平均耗时分解 / ms·frame⁻¹", font=font(21, True), fill=INK, anchor="mm")
    components = [
        ("Pose", smoke["latency_ms"]["pose"] / smoke["frames"], BLUE),
        ("ROI", smoke["latency_ms"]["roi"] / smoke["frames"], "#5E8C6A"),
        ("Skeleton", smoke["latency_ms"]["skeleton"] / smoke["frames"], "#C08457"),
        ("Heads+fusion", smoke["latency_ms"]["heads_and_fusion"] / smoke["frames"], "#8E6C8A"),
    ]
    for i, (name, value, color) in enumerate(components):
        y = 270 + i * 78
        draw.text((120, y), name, font=font(17), fill=MUTED, anchor="lm")
        draw.rectangle((260, y - 14, 260 + max(3, int(value * 7.5)), y + 16), fill=color)
        draw.text((585, y), f"{value:.2f}", font=font(16, True), fill=INK, anchor="rm")

    draw.text((1000, 198), "七个成员 raw logits", font=font(21, True), fill=INK, anchor="mm")
    axis_x = 1000
    draw.line((axis_x, 250, axis_x, 585), fill="#6B7280", width=2)
    for i, value in enumerate(smoke["member_logits"]):
        y = 275 + i * 45
        x = axis_x + int(value * 100)
        draw.line((axis_x, y, x, y), fill="#99A8B7", width=3)
        draw.ellipse((x - 7, y - 7, x + 7, y + 7), fill=BLUE)
        draw.text((770, y), f"H{i+1}", font=font(16), fill=MUTED, anchor="lm")
        draw.text((1230, y), f"{value:+.3f}", font=font(15), fill=INK, anchor="rm")

    draw.text((1640, 198), "无标签候选区间", font=font(21, True), fill=INK, anchor="mm")
    x1, x2 = 1415, 1875
    y = 410
    duration = smoke["frames"] / smoke["fps"]
    draw.line((x1, y, x2, y), fill="#A7B7C7", width=8)
    start = smoke["proposal"]["start_time"]
    end = smoke["proposal"]["end_time"]
    peak = smoke["proposal"]["peak_time"]
    sx = x1 + int(start / duration * (x2 - x1))
    ex = x1 + int(end / duration * (x2 - x1))
    px = x1 + int(peak / duration * (x2 - x1))
    draw.line((sx, y, ex, y), fill=ORANGE, width=18)
    draw.polygon([(px, y - 20), (px + 16, y), (px, y + 20), (px - 16, y)], fill="#8A2D1A")
    for tick in range(6):
        tx = x1 + int(tick / duration * (x2 - x1))
        draw.line((tx, y + 18, tx, y + 28), fill=MUTED, width=2)
        draw.text((tx, y + 48), f"{tick}s", font=font(14), fill=MUTED, anchor="mm")
    draw.text((1640, 545), f"proposal {start:.2f}-{end:.2f}s · peak {peak:.2f}s", font=font(17, True), fill=INK, anchor="mm")
    draw.text((1640, 590), f"clip score = {smoke['score']:.6f}", font=font(18), fill=BLUE, anchor="mm")
    image.save(path)


def build_academic_figures(smoke: dict, assets: Path) -> dict[str, Path]:
    assets.mkdir(parents=True, exist_ok=True)
    paths = {
        "architecture": assets / "architecture_academic.png",
        "selection": assets / "model_selection_convergence.png",
        "runtime": assets / "runtime_evidence.png",
    }
    architecture(paths["architecture"])
    selection(paths["selection"])
    runtime(paths["runtime"], smoke)
    return paths
