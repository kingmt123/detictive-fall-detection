"""Create an anonymous MP4 demonstration for the frozen seven-head runtime."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "deploy" / "final_model"
sys.path.insert(0, str(RUNTIME))

from pipeline.inference_engine import crop_frame  # noqa: E402
from pipeline.pose_extractor import PoseExtractor  # noqa: E402

OUT = ROOT / "deliverables" / "fall_detection_demo.mp4"
SOURCE = ROOT / "data" / "sources" / "urfd" / "fall-01-cam1.mp4"
SMOKE = ROOT / "reports" / "final_model_smoke.json"
WIDTH, HEIGHT, FPS = 1280, 720, 30
FONT = Path("C:/Windows/Fonts/msyh.ttc")
FONT_BOLD = Path("C:/Windows/Fonts/msyhbd.ttc")
NAVY, BLUE, WHITE, INK, MUTED, PALE = "#172B4D", "#2E74B5", "#FFFFFF", "#111827", "#5B6573", "#F4F6F9"
SKELETON = ((5, 7), (7, 9), (6, 8), (8, 10), (5, 6), (5, 11), (6, 12), (11, 12), (11, 13), (13, 15), (12, 14), (14, 16))


def font(size: int, bold: bool = False):
    return ImageFont.truetype(str(FONT_BOLD if bold and FONT_BOLD.exists() else FONT), size)


def slide(kicker: str, title: str, lines: list[str]) -> Image.Image:
    image = Image.new("RGB", (WIDTH, HEIGHT), WHITE)
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, 18, HEIGHT), fill=BLUE)
    draw.text((72, 56), kicker, font=font(22, True), fill=BLUE)
    draw.text((72, 112), title, font=font(42, True), fill=NAVY)
    y = 225
    for line in lines:
        draw.ellipse((96, y + 12, 108, y + 24), fill=BLUE)
        draw.text((132, y), line, font=font(27), fill=INK)
        y += 72
    draw.text((72, 676), "实时跌倒检测系统 · 匿名提交", font=font(16), fill=MUTED)
    return image


def static(writer, image: Image.Image, seconds: float) -> None:
    frame = cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR)
    for _ in range(round(seconds * FPS)):
        writer.write(frame)


def raw_demo(writer, payload: dict) -> None:
    capture = cv2.VideoCapture(str(SOURCE))
    if not capture.isOpened():
        raise RuntimeError(f"cannot open {SOURCE}")
    proposal = payload["proposal"]
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            frame, _ = crop_frame(frame, "auto")
            frame = cv2.resize(frame, (WIDTH, HEIGHT), interpolation=cv2.INTER_AREA)
            banner = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(banner)
            draw.rectangle((0, 0, WIDTH, 112), fill=NAVY)
            draw.text((32, 21), "最终七头模型 · 原始视频在线推理", font=font(25, True), fill=WHITE)
            draw.text((32, 66), f"score {payload['score']:.6f}  |  候选轨迹 {proposal['track_id']}  |  候选区间 {proposal['start_time']:.2f}s–{proposal['end_time']:.2f}s", font=font(19), fill="#DDE8F2")
            writer.write(cv2.cvtColor(np.asarray(banner), cv2.COLOR_RGB2BGR))
    finally:
        capture.release()


def _draw_pose(frame: np.ndarray, keypoints: np.ndarray, box: np.ndarray, track_id: int, active: bool) -> None:
    color = (54, 67, 244) if active else (55, 170, 45)
    for start, end in SKELETON:
        if keypoints[start, 2] >= 0.15 and keypoints[end, 2] >= 0.15:
            cv2.line(frame, tuple(keypoints[start, :2].astype(int)), tuple(keypoints[end, :2].astype(int)), color, 3, cv2.LINE_AA)
    for x, y, confidence in keypoints:
        if confidence >= 0.15:
            cv2.circle(frame, (int(x), int(y)), 4, color, -1, cv2.LINE_AA)
    x1, y1, x2, y2 = box.astype(int)
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    cv2.putText(frame, f"track {track_id}", (x1, max(22, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2, cv2.LINE_AA)


def pose_demo(writer, payload: dict) -> None:
    extractor = PoseExtractor(RUNTIME / "weights" / "yolo11n-pose.pt", device="cpu")
    sequence = extractor.extract(SOURCE, crop="auto")
    extractor.close()
    capture = cv2.VideoCapture(str(SOURCE))
    if not capture.isOpened():
        raise RuntimeError(f"cannot open {SOURCE}")
    proposal = payload["proposal"]
    logits = payload["member_logits"]
    try:
        index = 0
        while True:
            ok, raw = capture.read()
            if not ok or index >= sequence.frame_indices.size:
                break
            frame, _ = crop_frame(raw, "auto")
            frame = cv2.resize(frame, (900, HEIGHT), interpolation=cv2.INTER_AREA)
            scale_x, scale_y = 900 / sequence.frame_size[1], HEIGHT / sequence.frame_size[0]
            time_s = index / sequence.fps
            active = proposal["start_time"] <= time_s <= proposal["end_time"]
            for person in range(sequence.valid_mask.shape[1]):
                if not sequence.valid_mask[index, person]:
                    continue
                keypoints = sequence.keypoints[index, person].copy()
                box = sequence.bboxes[index, person].copy()
                keypoints[:, 0] *= scale_x
                keypoints[:, 1] *= scale_y
                box[[0, 2]] *= scale_x
                box[[1, 3]] *= scale_y
                _draw_pose(frame, keypoints, box, int(sequence.track_ids[index, person]), active and int(sequence.track_ids[index, person]) == proposal["track_id"])
            canvas = np.full((HEIGHT, WIDTH, 3), 255, dtype=np.uint8)
            canvas[:, :900] = frame
            cv2.rectangle(canvas, (0, 0), (900, 70), (77, 43, 23), -1)
            cv2.putText(canvas, "Pose tracking and candidate event", (24, 43), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2, cv2.LINE_AA)
            panel = Image.fromarray(cv2.cvtColor(canvas[:, 900:], cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(panel)
            draw.text((24, 28), "七头融合输出", font=font(25, True), fill=NAVY)
            draw.text((24, 80), f"融合分数  {payload['score']:.3f}", font=font(22, True), fill=BLUE)
            draw.text((24, 125), f"轨迹  {proposal['track_id']}", font=font(18), fill=INK)
            draw.text((24, 157), f"候选  {proposal['start_time']:.2f}s–{proposal['end_time']:.2f}s", font=font(16), fill=INK)
            draw.text((24, 196), f"当前帧  {time_s:.2f}s", font=font(16), fill="#A61B1B" if active else MUTED)
            draw.text((24, 246), "七个 raw logits", font=font(18, True), fill=NAVY)
            for member, value in enumerate(logits, start=1):
                y = 286 + (member - 1) * 48
                draw.text((24, y), f"H{member}", font=font(16), fill=INK)
                left, right = 75, 280
                draw.rounded_rectangle((left, y + 4, right, y + 24), radius=5, fill="#E6EAF0")
                width = int((value + 3.0) / 4.0 * (right - left))
                draw.rounded_rectangle((left, y + 4, max(left + 3, min(right, left + width)), y + 24), radius=5, fill=BLUE if value < 0 else "#D55E00")
                draw.text((24, y + 25), f"{value:+.2f}", font=font(13), fill=MUTED)
            canvas[:, 900:] = cv2.cvtColor(np.asarray(panel), cv2.COLOR_RGB2BGR)
            writer.write(canvas)
            index += 1
    finally:
        capture.release()


def main() -> None:
    payload = json.loads(SMOKE.read_text(encoding="utf-8"))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(str(OUT), cv2.VideoWriter_fourcc(*"mp4v"), FPS, (WIDTH, HEIGHT))
    if not writer.isOpened():
        raise RuntimeError("cannot create output MP4")
    try:
        static(writer, slide("最终提交", "面向低算力平台的实时跌倒检测", ["YOLO11n-pose + 共享 ROI + 七头等权融合", "匿名运行包 · 无标签部署 · 可复现校验"]), 5)
        static(writer, slide("检测链路", "从原始视频到可解释输出", ["输入：普通 RGB 视频", "中间结果：人体框、17 个关键点和连续轨迹", "决策：运动候选区间、七头 logits 与融合分数"]), 7)
        raw_demo(writer, payload)
        pose_demo(writer, payload)
        static(writer, slide("验证证据", "冻结验证与运行时核验", ["OF-Syn validation：MAP 75.208%", "P@R90 77.907%  ·  P@R95 72.509%", "4.053M 参数  ·  FP32 参数量 15.46 MiB", "174 个运行包文件已按 SHA-256 核验"]), 10)
        static(writer, slide("交付说明", "可复现的匿名运行包", ["演示使用公开 URFD 视频，不含封存 test", "本机端到端烟测验证视频解码、姿态、ROI 与七头融合链路", "运行包包含冻结权重、源码、依赖清单和 SHA-256 清单"]), 8)
    finally:
        writer.release()
    capture = cv2.VideoCapture(str(OUT))
    if not capture.isOpened():
        raise RuntimeError("cannot reopen output MP4")
    info = {"frames": int(capture.get(cv2.CAP_PROP_FRAME_COUNT)), "fps": float(capture.get(cv2.CAP_PROP_FPS)), "width": int(capture.get(cv2.CAP_PROP_FRAME_WIDTH)), "height": int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT)), "bytes": OUT.stat().st_size}
    capture.release()
    info["duration_s"] = info["frames"] / info["fps"]
    print(json.dumps(info, ensure_ascii=False))


if __name__ == "__main__":
    main()
