"""Build anonymous competition documents for the frozen seven-head runtime."""
from __future__ import annotations

import json
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables"
MANIFEST = ROOT / "deploy" / "final_model" / "MANIFEST.json"
SMOKE = ROOT / "reports" / "final_model_smoke.json"
TOTAL_DXA = 9360
INK, BLUE, MUTED, LIGHT = "172B4D", "2E74B5", "5B6573", "F2F4F7"


def run_font(run, size: float, *, bold: bool = False, color: str = "000000") -> None:
    run.font.name = "Calibri"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Calibri")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Calibri")
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(size)
    run.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)


def shade(cell, fill: str) -> None:
    props = cell._tc.get_or_add_tcPr()
    node = props.find(qn("w:shd"))
    if node is None:
        node = OxmlElement("w:shd")
        props.append(node)
    node.set(qn("w:fill"), fill)


def cell_margins(cell) -> None:
    props = cell._tc.get_or_add_tcPr()
    node = props.first_child_found_in("w:tcMar")
    if node is None:
        node = OxmlElement("w:tcMar")
        props.append(node)
    for side, value in (("top", 80), ("start", 120), ("bottom", 80), ("end", 120)):
        item = node.find(qn(f"w:{side}"))
        if item is None:
            item = OxmlElement(f"w:{side}")
            node.append(item)
        item.set(qn("w:w"), str(value))
        item.set(qn("w:type"), "dxa")


def geometry(table, widths: list[int]) -> None:
    if sum(widths) != TOTAL_DXA:
        raise ValueError("table width mismatch")
    table.autofit = False
    props = table._tbl.tblPr
    width = props.first_child_found_in("w:tblW")
    width.set(qn("w:w"), str(TOTAL_DXA))
    width.set(qn("w:type"), "dxa")
    indent = props.first_child_found_in("w:tblInd")
    if indent is None:
        indent = OxmlElement("w:tblInd")
        props.append(indent)
    indent.set(qn("w:w"), "120")
    indent.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for node in list(grid):
        grid.remove(node)
    for value in widths:
        node = OxmlElement("w:gridCol")
        node.set(qn("w:w"), str(value))
        grid.append(node)
    for row in table.rows:
        for index, cell in enumerate(row.cells):
            props = cell._tc.get_or_add_tcPr()
            width = props.first_child_found_in("w:tcW")
            width.set(qn("w:w"), str(widths[index]))
            width.set(qn("w:type"), "dxa")
            cell.width = Inches(widths[index] / 1440)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cell_margins(cell)


def set_cell(cell, value: str, *, bold: bool = False, color: str = "000000", center: bool = False) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.LEFT
    paragraph.paragraph_format.space_after = Pt(0)
    paragraph.paragraph_format.line_spacing = 1.1
    run_font(paragraph.add_run(value), 9.2, bold=bold, color=color)


def repeat_header(row) -> None:
    props = row._tr.get_or_add_trPr()
    node = OxmlElement("w:tblHeader")
    node.set(qn("w:val"), "true")
    props.append(node)


def table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[int]) -> None:
    result = doc.add_table(rows=1, cols=len(headers))
    result.style = "Table Grid"
    geometry(result, widths)
    repeat_header(result.rows[0])
    for index, value in enumerate(headers):
        shade(result.rows[0].cells[index], LIGHT)
        set_cell(result.rows[0].cells[index], value, bold=True, color=INK, center=True)
    for values in rows:
        cells = result.add_row().cells
        for index, value in enumerate(values):
            set_cell(cells[index], value, center=index > 0 and len(value) <= 20)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def configure(doc: Document, running_title: str) -> None:
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.top_margin = section.right_margin = section.bottom_margin = section.left_margin = Inches(1)
    section.header_distance = section.footer_distance = Inches(0.492)
    normal = doc.styles["Normal"]
    normal.font.name, normal.font.size = "Calibri", Pt(11)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.paragraph_format.space_after, normal.paragraph_format.line_spacing = Pt(6), 1.1
    for name, size, color, before, after in (("Heading 1", 16, BLUE, 16, 8), ("Heading 2", 13, BLUE, 12, 6)):
        style = doc.styles[name]
        style.font.name, style.font.size, style.font.bold = "Calibri", Pt(size), True
        style.font.color.rgb = RGBColor.from_string(color)
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.paragraph_format.space_before, style.paragraph_format.space_after = Pt(before), Pt(after)
        style.paragraph_format.keep_with_next = True
    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run_font(header.add_run(running_title), 8.5, bold=True, color=MUTED)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run_font(footer.add_run("匿名参赛材料"), 8.5, color=MUTED)
    doc.core_properties.author = doc.core_properties.company = doc.core_properties.last_modified_by = ""
    doc.core_properties.comments = "Anonymous competition submission"


def title(doc: Document, main: str, subtitle: str, *, compact: bool = False) -> None:
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(24 if compact else 72)
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_after = Pt(12)
    run_font(paragraph.add_run("实时视觉智能 · 匿名提交"), 10, bold=True, color=BLUE)
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_after = Pt(8)
    run_font(paragraph.add_run(main), 25 if compact else 29, bold=True, color=INK)
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_after = Pt(26)
    run_font(paragraph.add_run(subtitle), 12.5, color=MUTED)


def body(doc: Document, text: str) -> None:
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.widow_control = True
    run_font(paragraph.add_run(text), 11)


def bullets(doc: Document, items: list[str]) -> None:
    for item in items:
        paragraph = doc.add_paragraph(style="List Bullet")
        paragraph.paragraph_format.left_indent = Inches(0.5)
        paragraph.paragraph_format.first_line_indent = Inches(-0.25)
        paragraph.paragraph_format.space_after = Pt(6)
        run_font(paragraph.add_run(item), 11)


def metric_strip(doc: Document) -> None:
    result = doc.add_table(rows=1, cols=4)
    result.style = "Table Grid"
    geometry(result, [2340] * 4)
    repeat_header(result.rows[0])
    for cell, (value, label) in zip(result.rows[0].cells, (("4.053M", "总参数"), ("15.46 MiB", "FP32 参数"), ("75.208%", "OF-Syn val MAP"), ("7", "等权 logit 头")), strict=True):
        shade(cell, LIGHT)
        cell.text = ""
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run_font(p.add_run(value), 14, bold=True, color=INK)
        p = cell.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run_font(p.add_run(label), 8.5, color=MUTED)


def brief(path: Path) -> None:
    intro = "本项目面向低算力平台构建纯视觉实时跌倒检测系统。运行时以 YOLO11n-pose 提取人体姿态和共享 ROI 特征，结合短时与长时骨架编码及七个冻结分类头进行等权 logit 融合，输出无标签视频的跌倒风险分数与候选时间区间。模型共405.3万参数、FP32参数量15.46MiB；在 OF-Syn validation 上 MAP 为75.208%，P@R90/P@R95 为77.907%/72.509%。部署包附带权重、源码和 SHA-256 清单。"
    if len(intro.replace(" ", "")) > 300:
        raise ValueError("brief too long")
    doc = Document()
    configure(doc, "项目简介 | 匿名提交")
    title(doc, "面向低算力平台的实时跌倒检测", "纯视觉 · 七头融合 · 可复现运行包", compact=True)
    metric_strip(doc)
    doc.add_paragraph("项目简介", style="Heading 1")
    body(doc, intro)
    path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(path)


def report(path: Path, smoke: dict) -> None:
    doc = Document()
    configure(doc, "实时跌倒检测系统 | 项目文档 | 匿名提交")
    title(doc, "面向低算力端侧平台\n基于视觉的实时跌倒检测", "最终七头运行时：技术方案、验证证据与部署说明")
    metric_strip(doc)
    body(doc, "本报告对应冻结的 edgefall_seven_head_label_blind_runtime_v1 运行包。所有分数由无标签视频的姿态、ROI 与固定权重产生；本版本不读取类别标签、真实事件区间或真实人物 ID。")
    doc.add_page_break()
    doc.add_paragraph("1. 项目概述", style="Heading 1")
    body(doc, "系统面向普通 RGB 视频的实时跌倒风险评估，目标是在受限端侧预算内提供可复现的 clip 评分和可追溯运动候选区间。运行包独立携带 YOLO11n-pose 与七头融合权重，并通过哈希清单约束源码和模型文件。")
    doc.add_paragraph("2. 运行时架构", style="Heading 1")
    table(doc, ["阶段", "模块", "职责"], [["1", "YOLO11n-pose", "逐帧人体姿态和轨迹"], ["2", "骨架窗口", "16 帧短时与 48 帧长时因果窗口"], ["3", "共享 ROI 编码", "在 320/640 输入上提取人物区域视觉 token"], ["4", "七头融合", "6 个短时头和 1 个长时头输出 raw logits"], ["5", "输出", "七个 raw logits 算术平均后 sigmoid，并生成运动候选区间"]], [900, 2550, 5910])
    body(doc, "七个头采用固定等权融合，不在部署视频上搜索阈值或调整权重。候选区间只从运行时姿态运动生成，便于复核关键轨迹。")
    doc.add_paragraph("3. 冻结验证证据", style="Heading 1")
    table(doc, ["数据/环境", "MAP", "P@R90", "P@R95", "状态"], [["OF-Syn validation（1,200 clips）", "75.208%", "77.907%", "72.509%", "冻结验证"], ["URFD fall-01-cam1（160 帧）", f"score {smoke['score']:.3f}", "—", "—", "端到端烟测完成"], ["OF-Syn sealed test", "—", "—", "—", "本包未读取"]], [2700, 1500, 1500, 1500, 2160])
    body(doc, f"已在本机完成原始视频端到端烟测：{smoke['frames']} 帧、{smoke['fps']:.0f} FPS，最终 score 为 {smoke['score']:.6f}，候选轨迹 ID 为 {smoke['proposal']['track_id']}。该检查覆盖视频解码、姿态、ROI 与七头融合的完整运行链路。")
    doc.add_paragraph("4. 模型规模与合规", style="Heading 1")
    table(doc, ["项目", "冻结值", "要求/解释"], [["总参数", "4.053M", "低于 20M 上限"], ["FP32 参数量", "15.46 MiB", "低于 80MB 上限"], ["融合规则", "mean(logits) → sigmoid", "固定、无标签、无部署调参"], ["输入数据", "原始视频 + 视频元数据 + 在线姿态轨迹", "不读取标签、事件区间或真实 ID"], ["完整性", "174 个文件 SHA-256", "MANIFEST.json 已逐项核验"]], [2550, 2300, 4510])
    doc.add_paragraph("5. 适用边界", style="Heading 1")
    bullets(doc, ["当前公开指标来自 OF-Syn validation，不能替代赛事官方评分。", "多人长期遮挡、姿态缺失或运动候选不足时，模型会拒绝生成有效窗口或降低可靠性。", "本材料不宣称已经访问或使用封存 test；任何后续测试结果只应按赛事规则报告。"])
    doc.add_paragraph("6. 复现与交付", style="Heading 1")
    body(doc, "运行包包含 weights/edgefall_seven_head_label_blind_v1.pt、weights/yolo11n-pose.pt、推理入口、依赖清单和 MANIFEST.json。推理命令为 python -m tools.infer_seven_head <input.mp4> --artifact weights/edgefall_seven_head_label_blind_v1.pt --yolo-checkpoint weights/yolo11n-pose.pt --output result.json --device cuda:0。")
    doc.save(path)


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if manifest["fusion"] != "mean(seven raw logits) then sigmoid" or manifest["status"] != "deployment_candidate_pending_v100_p95":
        raise ValueError("unexpected final runtime manifest")
    smoke = json.loads(SMOKE.read_text(encoding="utf-8"))
    brief(OUT / "fall_detection_project_brief.docx")
    report(OUT / "fall_detection_project_report.docx", smoke)
    print(json.dumps({"brief": str(OUT / "fall_detection_project_brief.docx"), "report": str(OUT / "fall_detection_project_report.docx")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
