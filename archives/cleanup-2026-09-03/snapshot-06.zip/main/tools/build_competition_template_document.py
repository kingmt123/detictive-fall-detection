"""Build the competition project document using the supplied chapter template."""
from __future__ import annotations

import json
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables"
MANIFEST = ROOT / "deploy" / "final_model" / "MANIFEST.json"
SMOKE = ROOT / "reports" / "final_model_smoke.json"
PROJECT = "面向低算力平台的实时跌倒检测"
TEAM = "抹茶吃不饱"
GROUP = "企业赛题七"
VERSION = "V1.0"
DATE = "2026.09.01"
TOTAL_DXA = 9020


def figure_font(size: int, bold: bool = False):
    font = "C:/Windows/Fonts/msyhbd.ttc" if bold else "C:/Windows/Fonts/msyh.ttc"
    return ImageFont.truetype(font, size)


def build_figures() -> tuple[Path, Path]:
    assets = OUT / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    route = assets / "technical_route.png"
    result = assets / "result_evidence.png"
    canvas = Image.new("RGB", (1800, 720), "white")
    draw = ImageDraw.Draw(canvas)
    title = figure_font(42, True)
    body = figure_font(25)
    small = figure_font(20)
    draw.text((72, 42), "图 1  技术路线：从普通 RGB 视频到可解释的跌倒风险输出", font=title, fill="#102a43")
    blocks = [
        (70, 220, 310, 430, "视频输入", "普通 RGB / 本地解码"),
        (390, 220, 670, 430, "姿态与跟踪", "17 关键点、人体框、track_id"),
        (750, 220, 1030, 430, "双尺度编码", "16 / 48 帧骨架 + ROI token"),
        (1110, 220, 1390, 430, "七头融合", "mean(raw logits) → sigmoid"),
        (1470, 220, 1730, 430, "可解释输出", "风险分数、候选区间、证据"),
    ]
    for x1, y1, x2, y2, label, detail in blocks:
        draw.rounded_rectangle((x1, y1, x2, y2), radius=22, fill="#EAF4FF", outline="#2470B3", width=4)
        draw.text((x1 + 22, y1 + 54), label, font=figure_font(28, True), fill="#102a43")
        draw.multiline_text((x1 + 22, y1 + 112), detail, font=small, fill="#334E68", spacing=8)
    for index in range(len(blocks) - 1):
        x = blocks[index][2]
        draw.line((x + 12, 325, blocks[index + 1][0] - 18, 325), fill="#3D8DFF", width=7)
        draw.polygon([(blocks[index + 1][0] - 18, 325), (blocks[index + 1][0] - 38, 313), (blocks[index + 1][0] - 38, 337)], fill="#3D8DFF")
    draw.text((80, 540), "约束：无标签推理；不读取真实事件区间、人物 ID 或封存测试数据。", font=body, fill="#52606D")
    canvas.save(route)

    canvas = Image.new("RGB", (1800, 760), "white")
    draw = ImageDraw.Draw(canvas)
    draw.text((72, 42), "图 2  冻结模型的验证与端到端运行证据", font=title, fill="#102a43")
    metrics = [("4.053M", "总参数"), ("15.46 MiB", "FP32 参数量"), ("75.208%", "OF-Syn val mAP"), ("15.45 ms/帧", "3,960 帧平均推理")]
    for idx, (value, label) in enumerate(metrics):
        x = 70 + idx * 430
        draw.rounded_rectangle((x, 155, x + 360, 330), radius=18, fill="#F1F7FE", outline="#BCD7F1", width=3)
        draw.text((x + 30, 194), value, font=figure_font(38, True), fill="#175E9E")
        draw.text((x + 30, 260), label, font=body, fill="#334E68")
    draw.rounded_rectangle((70, 400, 1730, 650), radius=18, fill="#FAFBFC", outline="#D9E2EC", width=3)
    rows = [("OF-Syn validation (1,200 clips)", "mAP 75.208%", "P@R90 77.907%", "P@R95 72.509%"), ("URFD fall-01-cam1 (160 帧)", "融合分数 0.178005", "track_id 3", "候选区间 0.77s - 4.77s")]
    headers = ["验证对象", "核心结果", "附加证据", "附加证据"]
    widths = [620, 355, 335, 350]
    x = 105
    for label, width in zip(headers, widths):
        draw.text((x, 430), label, font=figure_font(23, True), fill="#102A43")
        x += width
    for r, row in enumerate(rows):
        y = 495 + r * 70
        x = 105
        draw.line((100, y - 15, 1700, y - 15), fill="#D9E2EC", width=2)
        for value, width in zip(row, widths):
            draw.text((x, y), value, font=small, fill="#334E68")
            x += width
    canvas.save(result)
    return route, result


def set_font(run, size: float, *, bold: bool = False, name: str = "宋体") -> None:
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Times New Roman")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Times New Roman")
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), name)
    run.font.size = Pt(size)
    run.bold = bold


def set_page(doc: Document) -> None:
    section = doc.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin, section.bottom_margin = Cm(2.54), Cm(2.54)
    section.left_margin, section.right_margin = Cm(2.54), Cm(2.54)
    section.header_distance, section.footer_distance = Cm(1.27), Cm(1.27)
    normal = doc.styles["Normal"]
    normal.font.name, normal.font.size = "宋体", Pt(10.5)
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.paragraph_format.line_spacing = 1.5
    normal.paragraph_format.space_after = Pt(0)
    for name, size, before, after in (("Heading 1", 18, 16, 12), ("Heading 2", 15, 12, 8), ("Heading 3", 12, 8, 6)):
        style = doc.styles[name]
        style.font.name, style.font.size, style.font.bold = "黑体", Pt(size), True
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        style.paragraph_format.space_before, style.paragraph_format.space_after = Pt(before), Pt(after)
        style.paragraph_format.keep_with_next = True


def line(paragraph) -> None:
    props = paragraph._p.get_or_add_pPr()
    borders = props.first_child_found_in("w:pBdr")
    if borders is None:
        borders = OxmlElement("w:pBdr")
        props.append(borders)
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "8")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "000000")
    borders.append(bottom)


def header_footer(section, page_label: str) -> None:
    section.header.is_linked_to_previous = False
    section.footer.is_linked_to_previous = False
    header = section.header.paragraphs[0]
    header.clear()
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_font(header.add_run(PROJECT), 9)
    line(header)
    footer = section.footer.paragraphs[0]
    footer.clear()
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if page_label == "PAGE":
        run = footer.add_run()
        set_font(run, 9)
        begin = OxmlElement("w:fldChar")
        begin.set(qn("w:fldCharType"), "begin")
        instruction = OxmlElement("w:instrText")
        instruction.set(qn("xml:space"), "preserve")
        instruction.text = " PAGE "
        separate = OxmlElement("w:fldChar")
        separate.set(qn("w:fldCharType"), "separate")
        end = OxmlElement("w:fldChar")
        end.set(qn("w:fldCharType"), "end")
        run._r.extend([begin, instruction, separate, end])
    else:
        set_font(footer.add_run(page_label), 9)


def p(doc: Document, text: str = "", *, align=None, size: float = 10.5, bold: bool = False, font: str = "宋体", indent: bool = True) -> None:
    paragraph = doc.add_paragraph()
    if align is not None:
        paragraph.alignment = align
    if indent:
        paragraph.paragraph_format.first_line_indent = Cm(0.74)
    paragraph.paragraph_format.line_spacing = 1.5
    run = paragraph.add_run(text)
    set_font(run, size, bold=bold, name=font)
    return paragraph


def heading(doc: Document, text: str, level: int) -> None:
    paragraph = doc.add_paragraph(style=f"Heading {level}")
    paragraph.paragraph_format.first_line_indent = Cm(0)
    set_font(paragraph.add_run(text), {1: 18, 2: 15, 3: 12}[level], bold=True, name="黑体")


def figure(doc: Document, image_path: Path, caption: str) -> None:
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.add_run().add_picture(str(image_path), width=Cm(15.5))
    caption_paragraph = p(doc, caption, align=WD_ALIGN_PARAGRAPH.CENTER, size=9.5, indent=False)
    caption_paragraph.paragraph_format.space_after = Pt(8)


def geometry(table, widths: list[int]) -> None:
    if sum(widths) != TOTAL_DXA:
        raise ValueError("invalid table widths")
    table.autofit = False
    props = table._tbl.tblPr
    width = props.first_child_found_in("w:tblW")
    width.set(qn("w:w"), str(TOTAL_DXA))
    width.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for item in list(grid):
        grid.remove(item)
    for value in widths:
        item = OxmlElement("w:gridCol")
        item.set(qn("w:w"), str(value))
        grid.append(item)
    for row in table.rows:
        for index, cell in enumerate(row.cells):
            cell.width = Cm(widths[index] / 567)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            props = cell._tc.get_or_add_tcPr()
            item = props.first_child_found_in("w:tcW")
            item.set(qn("w:w"), str(widths[index]))
            item.set(qn("w:type"), "dxa")


def table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[int]) -> None:
    result = doc.add_table(rows=1, cols=len(headers))
    result.style = "Table Grid"
    geometry(result, widths)
    header_properties = result.rows[0]._tr.get_or_add_trPr()
    header_marker = OxmlElement("w:tblHeader")
    header_marker.set(qn("w:val"), "true")
    header_properties.append(header_marker)
    for row_index, values in enumerate([headers, *rows]):
        cells = result.rows[0].cells if row_index == 0 else result.add_row().cells
        for index, value in enumerate(values):
            cells[index].text = ""
            paragraph = cells[index].paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER if row_index == 0 or len(value) < 18 else WD_ALIGN_PARAGRAPH.LEFT
            paragraph.paragraph_format.space_after = Pt(0)
            paragraph.paragraph_format.line_spacing = 1.2
            set_font(paragraph.add_run(value), 9.5, bold=row_index == 0)
    doc.add_paragraph().paragraph_format.space_after = Pt(4)


def page_break(doc: Document) -> None:
    doc.add_page_break()


def cover(doc: Document) -> None:
    p(doc, "第八届中国研究生人工智能创新大赛", align=WD_ALIGN_PARAGRAPH.CENTER, size=26, bold=True, font="黑体", indent=False)
    for _ in range(8):
        p(doc, "", indent=False)
    p(doc, f"【{PROJECT}】", align=WD_ALIGN_PARAGRAPH.CENTER, size=22, bold=True, font="黑体", indent=False)
    p(doc, "项目文档", align=WD_ALIGN_PARAGRAPH.CENTER, size=20, bold=True, font="黑体", indent=False)
    p(doc, VERSION, align=WD_ALIGN_PARAGRAPH.CENTER, size=14, bold=True, indent=False)
    for _ in range(5):
        p(doc, "", indent=False)
    for item in (DATE, TEAM, GROUP):
        p(doc, item, align=WD_ALIGN_PARAGRAPH.CENTER, size=14, bold=True, indent=False)


def toc(doc: Document) -> None:
    heading(doc, "目录", 1)
    entries = [
        ("1  项目概况", "1"), ("1.1  背景和基础", "1"), ("1.2  场景和价值", "1"), ("1.3  所需支持", "1"), ("1.4  数据、知识、算法与硬件来源", "2"),
        ("2  项目规划", "3"), ("2.1  整体目标", "3"), ("2.2  技术创新点", "3"), ("2.3  技术调研与对比分析", "3"),
        ("3  实施方案", "4"), ("3.1  技术可行性分析", "4"), ("3.2  技术细节", "5"), ("3.3  结果展示与 Inference 指标", "5"), ("3.4  计划和分工", "5"), ("4  参考资料", "6"),
    ]
    for text, number in entries:
        paragraph = p(doc, "", indent=False)
        paragraph.paragraph_format.left_indent = Cm(0.5 if "." not in text[:4] else 1.2)
        paragraph.paragraph_format.tab_stops.add_tab_stop(Cm(15.5), 2, 1)
        run = paragraph.add_run(text + "\t" + number)
        set_font(run, 12, bold="  " in text and "." not in text[:4])


def history(doc: Document) -> None:
    heading(doc, "记录更改历史", 1)
    table(doc, ["序号", "更改原因", "版本", "作者", "更改日期", "备注"], [["1", "首次形成参赛项目文档", VERSION, TEAM, DATE, "最终七头模型"], ["2", "补充检测可视化与验证证据", VERSION, TEAM, DATE, "视频同步更新"]], [700, 2400, 1100, 1500, 1700, 1620])


def content(doc: Document, smoke: dict, route: Path, result: Path) -> None:
    heading(doc, "1  项目概况", 1)
    heading(doc, "1.1  背景和基础", 2)
    p(doc, "老年居住、康复训练、公共空间与无陪护值守场景中，跌倒事件具有突发性和高风险特征。传统穿戴式方案存在佩戴依从性和维护成本问题，深度相机方案又受设备成本与安装条件限制。本项目以普通 RGB 视频为输入，在本地完成姿态估计、轨迹关联、视觉特征提取和时序判别，形成可直接运行的跌倒风险检测原型。")
    p(doc, "项目已完成从原始视频到结构化 JSON 输出的闭环：运行时生成候选轨迹、候选区间、七个成员 logit 和融合分数。冻结运行包含 174 个文件，并由 MANIFEST.json 对源码、权重和依赖清单逐项记录 SHA-256。")
    figure(doc, route, "技术路线图：所有中间证据在本地推理过程中产生，可与最终分数对应复核。")
    heading(doc, "1.2  场景和价值", 2)
    p(doc, "系统适用于养老机构房间、家庭看护、病房、康复区和低算力边缘摄像头等场景。输出不止给出单帧标签，还提供轨迹编号和候选时间区间，便于值守人员回看、事件登记和后续联动。轻量化参数规模也使其具备在受限 GPU 或边缘服务器部署的条件。")
    heading(doc, "1.3  所需支持", 2)
    p(doc, "当前原型所需资源包括支持 CUDA 的推理设备、普通 RGB 摄像头或录像、Python 3.11 运行环境和预置的 YOLO11n-pose 权重。赛事环境中需要提供指定 GPU、1080P 以上测试输入和统一依赖镜像，用于完成正式端到端测评。")
    heading(doc, "1.4  数据、知识、算法与硬件来源", 2)
    table(doc, ["要素", "来源与使用边界", "引用 / 说明"], [["训练与验证数据", "OF-Syn 合成视频与 OmniFall 标注；仅按上游 random clip split 使用。", "项目数据准备记录 [1]"], ["工程演示数据", "URFD 公开视频 fall-01-cam1；仅用于端到端可视化与烟测。", "URFD 官方页 [2]"], ["行业与算法知识", "RGB 视觉、人体姿态、时序动作分析；不使用个人身份信息。", "YOLO 姿态文档 [3]"], ["推理硬件与软件", "Python 3.11、PyTorch、Ultralytics YOLO11n-pose、CUDA GPU；本地推理。", "框架文档 [3][4]"]], [1700, 5050, 2270])
    page_break(doc)

    heading(doc, "2  项目规划", 1)
    heading(doc, "2.1  整体目标", 2)
    p(doc, "参赛阶段的目标是交付一套可复现、可审计且满足低算力约束的纯视觉跌倒检测系统：在不读取部署视频标签、真实事件区间或真实人物 ID 的前提下，输出 clip 风险评分和基于姿态运动的候选区间。模型参数控制在 20M 以内，FP32 参数体积控制在 80MB 以内。")
    table(doc, ["目标维度", "冻结状态", "验证方式"], [["模型规模", "4.053M 参数；15.46 MiB FP32 参数量", "权重与模型结构统计"], ["部署完整性", "174 个运行包文件", "SHA-256 清单核验"], ["验证指标", "MAP 75.208%；P@R90 77.907%；P@R95 72.509%", "OF-Syn validation 1,200 clips"], ["端到端功能", f"{smoke['frames']} 帧视频处理成功", "视频解码、姿态、ROI、融合与 JSON 输出烟测"]], [1900, 3900, 3220])
    heading(doc, "2.2  技术创新点", 2)
    p(doc, "第一，采用“骨架时序 + 人体 ROI 视觉 token”双证据链。骨架分支保留人体运动几何，ROI 分支补充姿态难以表达的外观与场景线索；二者复用同一 YOLO11n-pose 视觉主干，避免额外引入完整 RGB backbone。")
    p(doc, "第二，构建短时与长时双尺度骨架编码。16 帧窗口响应快速动作转变，48 帧窗口保留较长时间的姿态演化；二者分别服务于短时头和长时头。第三，七个冻结分类头直接输出 raw logits，采用固定算术平均后 sigmoid，避免在部署数据上进行阈值搜索或融合调参。")
    heading(doc, "2.3  技术调研与对比分析", 2)
    table(doc, ["路线", "优势", "局限", "本项目取舍"], [["可穿戴传感器", "对光照不敏感", "需要佩戴与维护", "采用无穿戴 RGB 方案"], ["深度相机 / RGB-D", "具备几何深度线索", "专用硬件成本与安装约束", "采用普通 RGB，复用姿态证据"], ["单帧人体检测", "链路短", "缺少动作上下文", "采用 16/48 帧双尺度时序"], ["本项目七头融合", "多头证据、固定融合、可追溯", "依赖姿态检测质量", "输出轨迹、候选区间与成员分数"]], [1700, 2550, 2380, 2390])
    page_break(doc)

    heading(doc, "3  实施方案", 1)
    heading(doc, "3.1  技术可行性分析", 2)
    p(doc, "输入端只要求普通视频文件。系统通过 OpenCV 解码视频帧，由 YOLO11n-pose 提取 17 个 COCO 关键点、人体框和检测置信度；轻量 IoU 与常速度预测维持多目标 track_id。姿态序列随后被转换为 16 帧和 48 帧时序窗口，ROI 编码器从同一视觉主干提取人物区域 token。")
    p(doc, "已完成的原始视频烟测表明该链路可以闭环运行：对 URFD fall-01-cam1 的 160 帧输入，模型输出融合分数 {:.6f}，选择轨迹 {}，并给出 {:.2f}s 至 {:.2f}s 的姿态运动候选区间。该过程只使用视频和在线生成的姿态轨迹。".format(smoke["score"], smoke["proposal"]["track_id"], smoke["proposal"]["start_time"], smoke["proposal"]["end_time"]))
    table(doc, ["模块", "输入", "输出", "作用"], [["姿态与跟踪", "RGB 帧", "17 关键点、人体框、track_id", "建立稳定的人体时序证据"], ["短时骨架编码", "16 帧窗口", "短时 embedding", "捕捉快速下坠和姿态改变"], ["长时骨架编码", "48 帧窗口", "长时 embedding", "保留完整动作上下文"], ["ROI 编码", "人物区域 320/640", "视觉 token", "补充空间和外观信息"], ["七头融合", "embedding 与 token", "raw logits、融合分数", "固定等权输出风险评分"]], [1600, 2200, 2500, 2720])
    page_break(doc)

    heading(doc, "3.2  技术细节", 2)
    p(doc, "（1）姿态轨迹。每帧所有有效人体检测由 MultiPoseTracker 以 IoU 匹配和中心速度预测进行关联。输出采用 padded 张量保存 keypoints、bboxes、track_ids 与 valid_mask；这使得视频中人数变化、短时漏检和窗口构造均可被显式处理。")
    p(doc, "（2）候选区间。对每条轨迹计算人体框中心下移、宽高比变化和横向姿态增益，在仅回看前 1.25 秒的条件下生成运动分数。得分最高轨迹确定候选起止区间，供 ROI 解码、视频可视化和结果复核使用。")
    p(doc, "（3）特征与融合。短时和长时骨架窗口分别经共享骨架模型编码并进行最大池化；ROI token 由共享 YOLO 特征提取器在 320 或 640 输入上生成。前六个头使用短时骨架证据与交替分辨率 ROI token，第七头使用长时骨架证据和 320 ROI token。最终严格执行 mean(seven raw logits) then sigmoid。")
    p(doc, "（4）结果与可解释性。推理 JSON 固定包含 protocol、score、member_logits、proposal、frames、fps 与分阶段延迟。演示视频同步显示原始 RGB、骨架、人体框、track_id、候选区间和七个成员分数，让最终分数可回溯到中间检测证据。")
    heading(doc, "3.3  结果展示与 Inference 指标", 2)
    figure(doc, result, "结果展示图：验证集指标、模型规模与原始视频端到端输出分别来自冻结运行包和本地烟测记录。")
    heading(doc, "3.4  计划和分工", 2)
    table(doc, ["阶段", "工作内容", "产出"], [["模型冻结", "权重、源码和配置归档；逐文件哈希", "最终运行包与 MANIFEST.json"], ["赛事测评", "在指定 GPU、镜像与输入规格上运行统一基准", "性能报告与可复现实验日志"], ["材料提交", "项目文档、演示视频、运行说明与辅助包", "四类规范化提交材料"], ["后续迭代", "补充真实低照度、遮挡和跨场景数据", "新版本的独立验证证据"]], [1500, 4400, 3120])

    heading(doc, "4  参考资料", 1)
    references = [
        "[1] 项目数据准备记录：OmniFall 标注与 OF-Syn 12,000 个合成视频；上游 random clip split 的使用边界见项目 README.md。",
        "[2] Kępski, M. UR Fall Detection Dataset, University of Rzeszów. https://fenix.ur.edu.pl/~mkepski/ds/uf.html （访问日期：2026-09-01）。",
        "[3] Ultralytics. Pose Estimation with Ultralytics YOLO. https://docs.ultralytics.com/tasks/pose/ （访问日期：2026-09-01）。",
        "[4] PyTorch Foundation. PyTorch Documentation. https://pytorch.org/docs/ （访问日期：2026-09-01）。",
        "[5] 项目运行包 MANIFEST.json：edgefall_seven_head_label_blind_runtime_v1，冻结七头融合与文件完整性记录。",
        "[6] 项目 OF-Syn validation 评测归档：1,200 clips，mAP、P@R90 与 P@R95 指标；不读取 sealed test。",
        "[7] URFD 数据集视频 fixture：fall-01-cam1，用于原始视频端到端功能演示。",
    ]
    for item in references:
        p(doc, item, indent=False)


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if manifest["fusion"] != "mean(seven raw logits) then sigmoid":
        raise ValueError("final runtime manifest mismatch")
    smoke = json.loads(SMOKE.read_text(encoding="utf-8"))
    doc = Document()
    set_page(doc)
    cover(doc)
    header_footer(doc.sections[0], "I")
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    header_footer(section, "II")
    toc(doc)
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    header_footer(section, "III")
    history(doc)
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    header_footer(section, "PAGE")
    page_number_start = OxmlElement("w:pgNumType")
    page_number_start.set(qn("w:start"), "1")
    section._sectPr.append(page_number_start)
    route, result = build_figures()
    content(doc, smoke, route, result)
    doc.core_properties.author = TEAM
    doc.core_properties.title = PROJECT
    doc.core_properties.subject = "第八届中国研究生人工智能创新大赛项目文档"
    OUT.mkdir(parents=True, exist_ok=True)
    output = OUT / f"{TEAM}_{PROJECT}_项目文档.docx"
    doc.save(output)
    print(output)


if __name__ == "__main__":
    main()
