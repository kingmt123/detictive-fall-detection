param(
    [string]$Ffmpeg = "C:\Users\kingmt\AppData\Local\Microsoft\WinGet\Links\ffmpeg.exe"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$slides = Join-Path $root "tmp\competition_ppt_academic_render_final"
$demo = Join-Path $root "deliverables\fall_detection_demo.mp4"
$fall02 = Join-Path $root "data\sources\urfd\fall-02-cam1.mp4"
$fall10 = Join-Path $root "reports\demo_fall10_final.mp4"
$fall04 = Join-Path $root "reports\demo_fall04_final.mp4"
$work = Join-Path $root "tmp\competition_submission_video_v3"
$pptSegment = Join-Path $work "ppt_academic_segment.mp4"
$dynamicSegment = Join-Path $work "extended_dynamic_detection.mp4"
$outroSegment = Join-Path $work "academic_outro.mp4"
$output = Join-Path $root "deliverables\抹茶吃不饱_面向低算力平台的实时跌倒检测_项目视频.mp4"

New-Item -ItemType Directory -Force -Path $work | Out-Null

& $Ffmpeg -y -framerate "2/7" -start_number 1 -i (Join-Path $slides "slide-%02d.png") -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=white,setsar=1,fps=30" -t 28 -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -an $pptSegment
if ($LASTEXITCODE -ne 0) { throw "学术 PPT 视频段生成失败" }

$dynamicFilter = @"
[0:v]trim=start=14.5:end=17.333333,setpts=3.0*(PTS-STARTPTS),fps=30,format=yuv420p[fall01];
[1:v]crop=iw/2:ih:iw/2:0,setpts=2.5*(PTS-STARTPTS),scale=960:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=white,fps=30[fall02];
[2:v]setpts=2.5*(PTS-STARTPTS),scale=960:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=white,fps=30[fall10];
[3:v]setpts=2.5*(PTS-STARTPTS),scale=960:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=white,fps=30[fall04];
[fall10][fall04][fall02][fall01]concat=n=4:v=1:a=0[dynamic]
"@

& $Ffmpeg -y -i $demo -i $fall02 -i $fall10 -i $fall04 -filter_complex $dynamicFilter -map "[dynamic]" -c:v libx264 -preset medium -crf 19 -pix_fmt yuv420p -movflags +faststart $dynamicSegment
if ($LASTEXITCODE -ne 0) { throw "动态检测演示段生成失败" }

& $Ffmpeg -y -loop 1 -i (Join-Path $slides "slide-11.png") -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=white,setsar=1,fps=30" -t 4 -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -an $outroSegment
if ($LASTEXITCODE -ne 0) { throw "结尾画面生成失败" }

& $Ffmpeg -y -i $pptSegment -i $dynamicSegment -i $outroSegment -filter_complex "[0:v]setsar=1[ppt];[1:v]setsar=1[demo];[2:v]setsar=1[outro];[ppt][demo][outro]concat=n=3:v=1:a=0[v]" -map "[v]" -c:v libx264 -preset medium -crf 19 -pix_fmt yuv420p -movflags +faststart $output
if ($LASTEXITCODE -ne 0) { throw "最终项目视频拼接失败" }

Write-Output $output
