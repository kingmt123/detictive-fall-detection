"""Build an expanded, academic-style competition project document."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

from build_competition_template_document import (
    DATE,
    GROUP,
    MANIFEST,
    OUT,
    PROJECT,
    SMOKE,
    TEAM,
    VERSION,
    cover,
    figure,
    header_footer,
    heading,
    p,
    page_break,
    set_font,
    set_page,
    table,
)
from build_academic_figures_pil import build_academic_figures as build_academic_figures_pil


RESEARCH_AUDIT = Path("docs/research/2026-08-29-dense48-and-confidence-part-roi.md")


def _plot_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Microsoft YaHei", "SimHei", "Arial"],
            "axes.unicode_minus": False,
            "axes.titlesize": 12,
            "axes.labelsize": 10,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "figure.dpi": 160,
        }
    )


def build_academic_figures(smoke: dict) -> dict[str, Path]:
    _plot_style()
    assets = OUT / "assets" / "academic"
    assets.mkdir(parents=True, exist_ok=True)
    paths = {
        "architecture": assets / "architecture_academic.png",
        "selection": assets / "model_selection_convergence.png",
        "runtime": assets / "runtime_evidence.png",
    }

    fig, ax = plt.subplots(figsize=(12, 4.8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 5)
    ax.axis("off")
    stages = [
        (0.2, 1.8, "RGB 视频流", "H×W×3\n30 FPS"),
        (2.2, 1.8, "姿态估计与跟踪", "17 joints + bbox\ntrack_id"),
        (4.6, 2.9, "短时骨架编码器", "16-frame, 6-stream\ne16 ∈ R³⁸⁴"),
        (4.6, 0.7, "长时骨架编码器", "48-frame, causal\ne48 ∈ R³⁸⁴"),
        (7.1, 1.8, "共享 ROI 编码", "P3/P4 person ROI\n320 / 640 token"),
        (9.3, 1.8, "七个分类头", "6×short + 1×long\nraw logits z₁…z₇"),
        (11.1, 1.8, "固定融合", "σ(Σzᵢ/7)\nscore + proposal"),
    ]
    for x, y, title, detail in stages:
        ax.add_patch(plt.Rectangle((x, y), 1.55, 1.15, facecolor="#F4F8FC", edgecolor="#335C81", lw=1.4))
        ax.text(x + 0.775, y + 0.77, title, ha="center", va="center", fontsize=10, weight="bold", color="#17324D")
        ax.text(x + 0.775, y + 0.30, detail, ha="center", va="center", fontsize=8.5, color="#4A5B6A")
    arrows = [((1.75, 2.38), (2.2, 2.38)), ((3.75, 2.38), (4.6, 3.47)), ((3.75, 2.38), (4.6, 1.27)), ((6.15, 3.47), (7.1, 2.65)), ((6.15, 1.27), (7.1, 2.05)), ((8.65, 2.38), (9.3, 2.38)), ((10.85, 2.38), (11.1, 2.38))]
    for start, end in arrows:
        ax.annotate("", xy=end, xytext=start, arrowprops=dict(arrowstyle="->", color="#477CA8", lw=1.7))
    ax.text(0.2, 4.55, "端到端无标签推理架构", fontsize=15, weight="bold", color="#17324D")
    ax.text(0.2, 4.15, "因果时序窗口、共享视觉主干与无可学习参数的等权 logit 融合", fontsize=10, color="#52606D")
    ax.text(6.0, 0.15, "部署约束：仅使用视频及运行时生成的轨迹，不读取类别标签、真实事件区间或真实人物 ID", ha="center", fontsize=9, color="#8A3B12")
    fig.tight_layout()
    fig.savefig(paths["architecture"], bbox_inches="tight", facecolor="white")
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.5), gridspec_kw={"width_ratios": [1.05, 1.2, 1.15]})
    metrics = ["mAP", "P@R90", "P@R95"]
    six = np.array([70.831, 77.562, 64.100])
    seven = np.array([72.166, 78.762, 65.570])
    x = np.arange(3)
    axes[0].bar(x - 0.18, six, 0.36, label="六头", color="#A7B7C7")
    axes[0].bar(x + 0.18, seven, 0.36, label="七头", color="#1F6F8B")
    axes[0].set_xticks(x, metrics)
    axes[0].set_ylim(58, 82)
    axes[0].set_ylabel("指标 / %")
    axes[0].set_title("五折 train-OOF 总体性能")
    axes[0].legend(frameon=False, ncols=2, loc="upper center")
    axes[0].grid(axis="y", alpha=0.25)
    for idx, value in enumerate(seven - six):
        axes[0].text(idx + 0.18, seven[idx] + 0.55, f"+{value:.3f}", ha="center", fontsize=8, color="#0B5D48")

    folds = np.arange(5)
    delta = np.array([0.648, 0.500, -0.456, 2.375, 0.234])
    axes[1].axhline(0, color="#6B7280", lw=1)
    axes[1].bar(folds, delta, color=np.where(delta >= 0, "#2A9D8F", "#D97757"))
    axes[1].axhspan(0.055, 2.333, color="#2A9D8F", alpha=0.10, label="paired bootstrap 95% CI")
    axes[1].set_xticks(folds, [f"F{i}" for i in folds])
    axes[1].set_ylabel("ΔmAP / percentage points")
    axes[1].set_title("七头相对六头的逐折增益")
    axes[1].legend(frameon=False, fontsize=8)
    axes[1].grid(axis="y", alpha=0.25)

    candidates = ["六头基线", "+ dense-48", "+ Part 第八头", "Part 替换"]
    values = [70.831, 72.166, 71.947, 71.902]
    axes[2].plot(range(4), values, marker="o", lw=2.2, color="#264653")
    axes[2].scatter([1], [values[1]], s=110, color="#2A9D8F", zorder=3, label="冻结选择")
    axes[2].set_xticks(range(4), candidates, rotation=20, ha="right")
    axes[2].set_ylim(70.4, 72.5)
    axes[2].set_ylabel("train-OOF mAP / %")
    axes[2].set_title("结构搜索的性能收敛轨迹")
    axes[2].grid(alpha=0.25)
    axes[2].legend(frameon=False)
    fig.suptitle("模型选择证据：互补长时专家带来稳定总体增益", fontsize=15, weight="bold", color="#17324D")
    fig.text(0.5, 0.01, "注：该图来自已归档的五折 train-OOF 配对审计，属于结构选择轨迹，不等同于 epoch-wise 训练损失曲线。", ha="center", fontsize=9, color="#52606D")
    fig.tight_layout(rect=(0, 0.05, 1, 0.92))
    fig.savefig(paths["selection"], bbox_inches="tight", facecolor="white")
    plt.close(fig)

    components = {
        "Pose": smoke["latency_ms"]["pose"] / smoke["frames"],
        "ROI": smoke["latency_ms"]["roi"] / smoke["frames"],
        "Skeleton": smoke["latency_ms"]["skeleton"] / smoke["frames"],
        "Heads+fusion": smoke["latency_ms"]["heads_and_fusion"] / smoke["frames"],
    }
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.3), gridspec_kw={"width_ratios": [1.15, 1.15, 1.1]})
    axes[0].barh(list(components), list(components.values()), color=["#335C81", "#5E8C6A", "#C08457", "#8E6C8A"])
    axes[0].invert_yaxis()
    axes[0].set_xlabel("CPU 烟测平均耗时 / ms·frame⁻¹")
    axes[0].set_title("端到端耗时分解")
    axes[0].grid(axis="x", alpha=0.25)
    for i, value in enumerate(components.values()):
        axes[0].text(value + 0.35, i, f"{value:.2f}", va="center", fontsize=8)

    logits = np.array(smoke["member_logits"])
    axes[1].axvline(0, color="#6B7280", lw=1)
    axes[1].hlines(np.arange(1, 8), 0, logits, color="#99A8B7", lw=2)
    axes[1].scatter(logits, np.arange(1, 8), color="#1F6F8B", s=48, zorder=3)
    axes[1].set_yticks(np.arange(1, 8), [f"H{i}" for i in range(1, 8)])
    axes[1].set_xlabel("raw logit")
    axes[1].set_title("七个成员的单片段输出")
    axes[1].grid(axis="x", alpha=0.25)

    fps = smoke["fps"]
    duration = smoke["frames"] / fps
    axes[2].plot([0, duration], [0.18, 0.18], color="#A7B7C7", lw=5, solid_capstyle="round")
    start = smoke["proposal"]["start_time"]
    end = smoke["proposal"]["end_time"]
    peak = smoke["proposal"]["peak_time"]
    axes[2].plot([start, end], [0.18, 0.18], color="#D97757", lw=10, solid_capstyle="round", label="候选区间")
    axes[2].scatter([peak], [0.18], marker="D", s=75, color="#8A2D1A", zorder=3, label="运动峰值")
    axes[2].set_xlim(0, duration)
    axes[2].set_ylim(0, 0.4)
    axes[2].set_yticks([])
    axes[2].set_xlabel("video time / s")
    axes[2].set_title("无标签候选区间定位")
    axes[2].legend(frameon=False, loc="upper center")
    fig.suptitle("运行时证据：耗时、成员输出与时间定位可被独立复核", fontsize=15, weight="bold", color="#17324D")
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    fig.savefig(paths["runtime"], bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return paths


def toc_academic(doc: Document) -> None:
    heading(doc, "目录", 1)
    entries = [
        ("1  项目概况", "1"), ("1.1  研究背景与问题定义", "1"), ("1.2  研究目标与应用价值", "2"), ("1.3  数据、知识与软硬件来源", "3"),
        ("2  项目规划与创新性论证", "3"), ("2.1  总体目标与评价协议", "3"), ("2.2  相关路线比较", "3"), ("2.3  创新点与技术贡献", "4"),
        ("3  实施方案", "5"), ("3.1  总体架构", "5"), ("3.2  姿态轨迹与候选事件", "6"), ("3.3  双尺度时序与七头融合", "7"),
        ("3.4  训练、验证与模型选择", "7"), ("3.5  推理结果与运行证据", "8"), ("3.6  工程化与风险控制", "8"),
        ("4  结论与潜在应用", "9"), ("5  参考资料", "10"),
    ]
    for text, number in entries:
        paragraph = p(doc, "", indent=False)
        paragraph.paragraph_format.left_indent = Cm(0.5 if "." not in text[:4] else 1.2)
        paragraph.paragraph_format.tab_stops.add_tab_stop(Cm(15.5), 2, 1)
        set_font(paragraph.add_run(text + "\t" + number), 11.5, bold="  " in text and "." not in text[:4])


def history_academic(doc: Document) -> None:
    heading(doc, "记录更改历史", 1)
    table(doc, ["序号", "更改原因", "版本", "作者", "日期", "备注"], [
        ["1", "形成最终七头模型参赛文档", "V1.0", TEAM, DATE, "运行包冻结"],
        ["2", "补充学术论证、结构选择曲线与运行证据", "V1.1", TEAM, DATE, "文档与视频同步更新"],
    ], [700, 2500, 1000, 1500, 1500, 1820])


def content_academic(doc: Document, smoke: dict, figures: dict[str, Path]) -> None:
    heading(doc, "1  项目概况", 1)
    heading(doc, "1.1  研究背景与问题定义", 2)
    p(doc, "跌倒检测的核心难点并非识别某一静态姿态，而是从连续视频中区分正常坐卧、弯腰、快速下蹲与真实失衡过程。单帧分类容易忽略速度、持续时间和落地后的状态变化；完全依赖 RGB 的大规模视频模型虽然表达能力强，但对算力、数据规模和部署环境提出更高要求。本项目因此将问题定义为：在普通 RGB 视频上，以人体轨迹为分析单位，对短时姿态变化、长时动作上下文和人体区域视觉信息进行联合建模，输出片段级跌倒风险及可复核的候选时间区间。")
    p(doc, "系统坚持无标签推理约束：部署阶段只读取视频像素、帧率和运行时生成的人体框、关键点与轨迹，不读取类别标签、真实事件区间或真实人物 ID。该约束使离线验证、现场演示与最终运行包采用同一信息边界，降低因评测数据特定信息进入推理流程造成的偏差。")
    heading(doc, "1.2  研究目标与应用价值", 2)
    table(doc, ["研究问题", "设计目标", "可验证输出"], [
        ["如何兼顾精度与低算力部署？", "复用单一姿态视觉主干，用轻量时序编码和多头融合补充表达能力。", "4.053M 参数、15.46 MiB FP32 参数量"],
        ["如何降低单一时间尺度的遗漏？", "同时编码 16 帧局部动态和 48 帧连续上下文。", "六个短时头 + 一个长时专家"],
        ["如何使告警可解释？", "保留轨迹、候选区间、成员 logits 与融合规则。", "结构化 JSON 和逐帧可视化"],
        ["如何保证交付可复现？", "冻结权重、依赖、协议和逐文件 SHA-256。", "MANIFEST.json 与烟测记录"],
    ], [2500, 4000, 2520])
    p(doc, "潜在应用包括养老机构、家庭看护、病房与康复区域的风险辅助发现。系统定位为值守人员的辅助工具：告警用于触发人工回看和后续处置，不作为医疗诊断或唯一决策依据。")
    page_break(doc)

    heading(doc, "1.3  数据、行业知识、算法与硬件来源", 2)
    table(doc, ["类别", "来源", "用途", "边界与引用"], [
        ["训练/验证数据", "OmniFall 标注、OF-Syn 合成视频", "时序模型训练与验证", "沿用项目记录的数据划分；Schneider et al., 2025"],
        ["工程演示数据", "UR Fall Detection Dataset", "公开视频端到端演示", "fall-01 / fall-02 / fall-10；Kępski, n.d."],
        ["姿态算法", "YOLO11 Pose", "17 点姿态、人体框", "方法参考见 Khanam & Hussain, 2024；运行版本见冻结包"],
        ["深度学习框架", "PyTorch", "模型加载与推理", "版本与依赖由冻结运行包记录"],
        ["行业知识", "跌倒过程的运动学与持续性", "候选区间及解释设计", "不包含身份识别或医疗诊断"],
        ["运行硬件", "CUDA GPU / CPU 烟测环境", "模型推理与工程核验", "不同环境结果分开报告"],
    ], [1700, 2650, 2200, 2470])
    p(doc, "数据与第三方组件仅在各自许可和引用边界内使用。本项目提交包不重新分发原始数据集；最终运行包通过哈希清单记录源码、权重和依赖文件，便于复核来源与版本一致性。")
    page_break(doc)

    heading(doc, "2  项目规划与创新性论证", 1)
    heading(doc, "2.1  总体目标与评价协议", 2)
    p(doc, "项目以排序质量、工程效率和可审计性为三类目标。排序指标采用 mAP、P@R90 与 P@R95，重点观察高召回区域的精确率；工程指标包括参数量、FP32 参数体积和逐帧耗时；可审计性要求每个最终分数能回溯至轨迹、候选区间和七个成员输出。")
    table(doc, ["指标层级", "指标", "冻结结果", "解释"], [
        ["验证集排序", "mAP", "75.208%", "OF-Syn validation，1,200 clips"],
        ["高召回性能", "P@R90 / P@R95", "77.907% / 72.509%", "在高召回工作区间评估误报控制"],
        ["模型规模", "参数 / FP32", "4.053M / 15.46 MiB", "按共享视觉、时序模块与七头统计"],
        ["运行效率", "平均耗时", "15.45 ms/frame", "冻结运行记录，3,960 帧完整视频"],
        ["端到端功能", "烟测", f"{smoke['frames']} 帧全部处理", "视频解码至结构化 JSON 闭环"],
    ], [1600, 1800, 2500, 3120])
    heading(doc, "2.2  相关技术路线比较", 2)
    table(doc, ["技术路线", "信息来源", "主要优势", "主要局限", "本项目关系"], [
        ["可穿戴传感器", "加速度/陀螺仪", "不依赖光照", "依从性和维护成本", "目标是无穿戴视觉辅助"],
        ["RGB-D / 深度相机", "彩色+深度", "几何信息直接", "专用硬件和布设约束", "采用普通 RGB 降低门槛"],
        ["单帧姿态分类", "单帧关键点", "计算链路短", "缺少动作时序", "引入 16/48 帧因果编码"],
        ["大型 RGB 视频模型", "完整视频纹理", "表达能力强", "算力和数据需求高", "用共享 ROI token 作为补充"],
        ["本项目七头系统", "姿态+人体 ROI", "多尺度、可解释、轻量", "依赖人体检测质量", "固定融合并保留成员证据"],
    ], [1500, 1700, 2100, 2050, 1670])
    page_break(doc)

    heading(doc, "2.3  创新点与技术贡献", 2)
    p(doc, "（1）双尺度因果时序建模。短时分支以 16 帧窗口刻画快速下坠与姿态突变，长时分支使用原生连续 48 帧历史补充完整动作上下文；窗口只访问当前及过去帧，满足在线部署的信息约束。")
    p(doc, "（2）共享视觉主干下的双证据融合。骨架分支表达关节几何与运动学，ROI 分支从同一 YOLO 特征图提取人体区域 token，补充骨架无法表达的局部外观和空间信息，同时避免再引入独立大规模 RGB 主干。")
    p(doc, "（3）以互补性而非单头峰值选择成员。五折配对审计显示，48 帧单头并非最强单模型，但与六个短时成员的相关系数仅为 0.917-0.937；加入后总体 mAP、P@R90、P@R95 分别提升 1.335、1.200、1.470 个百分点，说明长时上下文提供了可利用的互补证据。")
    p(doc, "（4）无可学习参数的部署融合。最终严格执行七个 raw logits 的算术平均后 sigmoid；不在部署视频上搜索融合权重或阈值。该策略将模型选择与现场推理解耦，使冻结后的输出规则可直接复算。")
    figure(doc, figures["selection"], "图 1  模型结构选择的配对验证证据。六头基线与七头候选在相同五折 train-OOF 身份上比较；结构搜索轨迹用于说明模型选择收敛，不冒充缺失的逐 epoch 损失记录。")
    page_break(doc)

    heading(doc, "3  实施方案", 1)
    heading(doc, "3.1  总体架构", 2)
    figure(doc, figures["architecture"], "图 2  最终七头模型的端到端技术架构。前六个头使用 16 帧短时证据，第七头引入 48 帧长时证据，所有输出在 clip logit 层固定等权融合。")
    p(doc, "系统由视频解码、姿态与多目标跟踪、短/长时骨架编码、人体 ROI token、七个分类头和固定融合六个层级组成。人体检测与 ROI 特征共享 YOLO11n-pose 视觉主干；时序模块仅处理人物级特征，因此计算复杂度不会随整幅图像的大型视频 backbone 成倍增长。")
    p(doc, "在时刻 t，输入为 RGB 帧 I_t∈R^(H×W×3)。姿态主干输出每位候选人的 17 个 COCO 关键点 P_t∈R^(17×3)、人体框 b_t=(x,y,w,h) 和检测置信度。跟踪器将相邻帧中 IoU 与中心速度一致的检测关联为同一 track_id，并为短时漏检保留 valid_mask；因此时序网络接收的是“某一人”的连续证据，而非按帧独立的全图预测。")
    table(doc, ["层级", "输入对象", "核心变换", "输出对象"], [
        ["视觉与姿态", "RGB 帧 I_t", "YOLO11n-pose 一次前向，检测与特征共享", "17 点、人体框、置信度、特征图"],
        ["轨迹管理", "关键点、人体框、中心速度", "IoU 匹配、常速度预测、valid_mask", "按人分组的 track_id 序列"],
        ["骨架特征", "P_t、b_t 及相邻帧差分", "坐标归一化、骨骼向量、速度与运动学统计", "六类逐人时序特征"],
        ["视觉证据", "共享特征图 + 人体框", "对每个人体区域提取 320/640 ROI token", "与骨架同步的 ROI 表征"],
        ["时序与分类", "16 帧或 48 帧人物证据", "因果卷积、Joint-only Transformer、七个分类头", "7 个 raw logits"],
        ["决策输出", "clip 级 7 个 raw logits", "固定均值与 sigmoid", "score、候选区间、成员输出 JSON"],
    ], [1400, 2300, 3300, 2020])
    p(doc, "所有跨帧特征以人体框尺度进行归一化：关节坐标采用相对人体中心与宽高的表示，Bone 为相邻关节的有向差，Motion 为相邻时刻的坐标差。这样可降低拍摄距离和人体大小变化对时序量纲的影响；缺失帧不被伪造为真实姿态，而由 valid_mask 显式通知后续模块。")
    heading(doc, "3.2  姿态轨迹与候选事件", 2)
    p(doc, "每帧姿态检测输出 17 个 COCO 关键点、人体框和置信度。MultiPoseTracker 通过 IoU 匹配与中心速度预测维持 track_id；人数变化和短时漏检通过 valid_mask 与零填充显式表示。候选事件模块对每条轨迹计算人体框中心下移、宽高比变化及横向姿态增益，并在因果回看窗口内形成运动分数。")
    p(doc, "候选轨迹只用于定位需要进一步分析和展示的片段，并不读取真实人物 ID。烟测片段中，系统选择 track_id={}，候选区间为 {:.2f}-{:.2f} s，运动峰值位于 {:.2f} s。".format(smoke["proposal"]["track_id"], smoke["proposal"]["start_time"], smoke["proposal"]["end_time"], smoke["proposal"]["peak_time"]))
    page_break(doc)

    heading(doc, "3.3  双尺度时序编码与七头融合", 2)
    p(doc, "骨架编码器包含 Joint、Bone、Motion、Geometry、Rule 与 Kinematics 六类流。Joint/Bone 表达姿态拓扑，Motion 表达帧间变化，Geometry/Rule/Kinematics 提供框尺度、相对位置和运动学统计。各流通过轻量因果时序卷积与 Joint-only Transformer 汇聚为 384 维人物 embedding。")
    p(doc, "短时路径以最近 16 帧为因果窗口，只访问当前及历史帧，并通过因果时序卷积和 Joint-only Transformer 提炼局部姿态变化与关节协同；长时路径沿用同一特征定义、扩展为连续 48 帧，用于区分持续倒地与短暂弯腰、坐下或遮挡。")
    p(doc, "ROI 分支复用姿态主干的中间特征，并按同一 track_id 的人体框提取 person ROI token。320/640 两种尺度分别服务于低开销区域证据和更丰富的局部外观信息；骨架与 ROI 始终按同一人、同一时间窗对齐。")
    table(doc, ["成员", "骨架窗口", "ROI 输入", "作用"], [
        ["H1-H3", "16 帧", "320 person ROI", "短时运动 + 中分辨率人体视觉，多种随机种子"],
        ["H4-H6", "16 帧", "640 person ROI", "短时运动 + 高分辨率人体视觉，多种随机种子"],
        ["H7", "48 帧", "320 person ROI", "补充连续长时上下文与成员互补性"],
        ["Fusion", "clip 级", "7 raw logits", "z̄=(1/7)Σzᵢ，score=sigmoid(z̄)"],
    ], [1500, 1800, 2700, 3020])
    p(doc, "每个成员头先生成一个未归一化 logit z_i，而不是分别在各头上提前截断为概率。部署阶段的唯一融合规则为 z̄=(1/7)Σ_i z_i，score=σ(z̄)。该顺序保证七个成员具有相同的贡献权重，并使输出可由保存的 member_logits 逐项复算；候选事件只负责标记需要展示或复核的时间段，不参与在现场修改融合权重。")
    p(doc, "头部训练采用 balanced focal loss，并以动作子类辅助损失塑造表示；骨架与分类头各训练 12 epochs。冻结运行包保存了训练配置和最终权重，但不包含完整逐 epoch loss 日志，因此本文不生成虚构的训练损失曲线，而使用有原始配对审计支撑的结构搜索收敛轨迹。")
    heading(doc, "3.4  训练、验证与模型选择", 2)
    p(doc, "dense-48 候选在固定五折 template-grouped train-OOF 协议下与原六头基线进行逐 clip 配对。七头方案总体 mAP 从 70.831% 提升至 72.166%，2000 次 template-group paired bootstrap 给出的 mAP 增益 95% CI 为 [+0.055,+2.333] 个百分点。虽然 fold 2 出现 -0.456 点波动，其余四折均提升，且最弱 fold 3 提升 2.375 点。")
    p(doc, "进一步加入置信度约束 Part-ROI 第八头或以其替换既有成员时，总体 mAP 分别降至 71.947% 和 71.902%，因此未进入冻结模型。该过程体现了预注册式模型选择原则：只有在相同身份、相同聚合与相同指标实现下带来配对增益的成员才能晋级。")

    heading(doc, "3.5  推理结果与运行证据", 2)
    figure(doc, figures["runtime"], "图 3  端到端烟测的运行时证据。左图为 160 帧 CPU 烟测的平均耗时分解，中图为同一片段七个成员 raw logits，右图为完全由姿态运动生成的候选区间。")
    p(doc, "对 URFD fall-01-cam1 的 160 帧输入，系统完整执行视频解码、姿态、ROI、骨架时序和七头融合，输出 clip score={:.6f}。七个成员 logit 分布并不相同，说明最终分数不是重复复制单一输出；固定平均使每个成员贡献可直接复算。".format(smoke["score"]))
    table(doc, ["证据对象", "结果", "来源/口径"], [
        ["OF-Syn validation", "mAP 75.208%；P@R90 77.907%；P@R95 72.509%", "冻结运行包 README；1,200 clips"],
        ["完整视频基准", "15.45 ms/frame", "冻结运行记录；3,960 帧平均"],
        ["本机 CPU 烟测", f"{smoke['latency_ms']['per_frame']:.2f} ms/frame", "160 帧端到端功能核验"],
        ["模型规模", "4.053M；15.46 MiB FP32", "共享 YOLO、骨架与七头"],
        ["交付完整性", "174 个文件", "MANIFEST.json 逐文件 SHA-256"],
    ], [1900, 3700, 3420])
    heading(doc, "3.6  工程化、复现与风险控制", 2)
    p(doc, "运行包以 protocol=edgefall_seven_head_label_blind_runtime_v1 固定输入输出契约，并在 MANIFEST.json 中记录融合规则、模型和源码哈希。批量推理时复用模型实例以避免重复加载；结果 JSON 保存 fps、frames、proposal、member_logits、score 和各阶段耗时。")
    table(doc, ["风险", "影响", "控制措施"], [
        ["遮挡或多人交互", "姿态漏检、轨迹切换", "保留 valid_mask、track_id 与候选区间，部署场景独立验证"],
        ["摄像机视角变化", "人体尺度与运动方向变化", "人体归一化、ROI token 和跨场景样本补充"],
        ["误报带来的处置成本", "无效告警", "高召回区指标、人工复核和告警审计"],
        ["隐私与合规", "视频涉及个人信息", "本地推理、最小留存、访问控制和授权采集"],
        ["版本漂移", "结果不可复现", "冻结依赖、权重与 SHA-256 清单"],
    ], [1900, 2600, 4520])
    heading(doc, "4  结论与潜在应用", 1)
    p(doc, "本项目构建了从普通 RGB 视频到可解释跌倒风险输出的完整闭环。其主要贡献不是简单增加分类头数量，而是在共享视觉主干和低参数预算下，将 16 帧短时运动、48 帧长时上下文与人体 ROI 视觉证据按固定规则组合，并通过五折配对审计筛选互补成员。最终运行包保留候选区间、成员 logits、融合分数与文件哈希，使模型效果、运行过程和工程交付能够被分别复核。")
    p(doc, "从模型设计看，4.053M 参数的七头系统将姿态几何、帧间运动和共享 ROI 外观证据分层处理：姿态主干负责提供 17 点与人体框，跟踪模块保证证据以人而非以帧为单位累计，双尺度因果编码器覆盖突发下坠与倒地后的持续状态，固定 logit 融合则避免现场调权带来的不可复现性。该分工使系统既能保留轻量部署特征，也能输出可解释的中间证据。")
    p(doc, "在业务流程中，模型的定位是“风险发现—人工复核—事件留档”的第一环。摄像头输入经本地推理后，仅将候选时间段、track_id、风险分数和成员输出交给值守人员；值守人员结合原始视频、现场情况和既有处置规范确认是否升级通知。由此，算法输出不会被直接等同于医疗诊断或自动处置结论，而是成为缩短人工回看范围的辅助信息。")
    table(doc, ["环节", "系统输出", "人员/系统职责", "可审计证据"], [
        ["风险筛查", "clip score 与候选时间段", "发现需要回看的片段，不自动下医疗结论", "proposal、运动峰值、视频时间戳"],
        ["人工复核", "原视频与姿态轨迹", "核验遮挡、坐下、弯腰等易混淆场景", "track_id、关键点与 ROI 对齐记录"],
        ["通知与登记", "结构化 JSON", "按场景规范通知并登记处置结果", "成员 logits、融合分数、事件编号"],
        ["持续改进", "脱敏的误报/漏报回流", "独立验证阈值、鲁棒性与成本", "版本号、数据边界、SHA-256 清单"],
    ], [1700, 2400, 3000, 1920])
    p(doc, "在养老机构、家庭看护、康复训练和病房辅助值守中，后续产品化应围绕目标场景建立独立的数据闭环，并优先验证遮挡、多人交互、镜头视角变化和不同光照条件下的鲁棒性。同时应落实最小化采集、本地处理、分级访问、告知授权与留存期限等隐私治理措施；对于误报带来的人员负担，则以高召回区间指标、人工复核时间和处置成本共同评估。")
    p(doc, "本项目冻结的模型、协议和清单提供了可复现实验与演示的起点，但不替代真实场景的前瞻性验证。下一阶段将以统一标注口径开展跨场景测试，报告按人群、遮挡程度、机位和事件类型分层的结果，并在不改变冻结基线的前提下比较阈值策略和告警交互设计。")
    page_break(doc)
    heading(doc, "5  参考资料", 1)
    references = [
        "Khanam, R., & Hussain, M. (2024). YOLOv11: An overview of the key architectural enhancements. arXiv. https://arxiv.org/abs/2410.17725",
        "Kępski, M. (n.d.). UR fall detection dataset. University of Rzeszów. Retrieved September 1, 2026, from https://www.fenix.ur.edu.pl/~mkepski/ds/uf.html",
        "Kępski, M., & Kwolek, B. (2018). Event-driven system for fall detection using body-worn accelerometer and depth sensor. IET Computer Vision, 12(1), 48–58. https://doi.org/10.1049/iet-cvi.2017.0119",
        "Schneider, D., Marinov, Z., Baur, R., Zhong, Z., Düger, R., & Stiefelhagen, R. (2025). OmniFall: A unified staged-to-wild benchmark for human fall detection. arXiv. https://arxiv.org/abs/2505.19889",
    ]
    for item in references:
        paragraph = p(doc, item, indent=False)
        paragraph.paragraph_format.left_indent = Cm(0.74)
        paragraph.paragraph_format.first_line_indent = Cm(-0.74)


def main() -> None:
    if not RESEARCH_AUDIT.exists():
        raise FileNotFoundError(RESEARCH_AUDIT)
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    if manifest["fusion"] != "mean(seven raw logits) then sigmoid":
        raise ValueError("final runtime manifest mismatch")
    smoke = json.loads(SMOKE.read_text(encoding="utf-8"))
    figures = build_academic_figures_pil(smoke, OUT / "assets" / "academic")
    doc = Document()
    set_page(doc)
    cover(doc)
    for paragraph in doc.paragraphs:
        if paragraph.text.strip() == VERSION:
            paragraph.runs[0].text = "V1.1"
            break
    header_footer(doc.sections[0], "I")
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    header_footer(section, "II")
    toc_academic(doc)
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    header_footer(section, "III")
    history_academic(doc)
    section = doc.add_section(WD_SECTION.NEW_PAGE)
    header_footer(section, "PAGE")
    page_number_start = OxmlElement("w:pgNumType")
    page_number_start.set(qn("w:start"), "1")
    section._sectPr.append(page_number_start)
    content_academic(doc, smoke, figures)
    doc.core_properties.author = TEAM
    doc.core_properties.title = PROJECT
    doc.core_properties.subject = "第八届中国研究生人工智能创新大赛项目文档（学术增强版）"
    output = OUT / f"{TEAM}_{PROJECT}_项目文档.docx"
    doc.save(output)
    print(output)


if __name__ == "__main__":
    main()
