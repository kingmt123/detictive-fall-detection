param(
    [string]$Ffmpeg = "C:\Users\kingmt\AppData\Local\Microsoft\WinGet\Links\ffmpeg.exe"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$slides = Join-Path $root "tmp\competition_ppt_render_v2"
$demo = Join-Path $root "deliverables\fall_detection_demo.mp4"
$output = Join-Path $root "deliverables\抹茶吃不饱_面向低算力平台的实时跌倒检测_项目视频.mp4"
$work = Join-Path $root "tmp\competition_submission_video"
New-Item -ItemType Directory -Force -Path $work | Out-Null

$slideList = Join-Path $work "slides.txt"
$lines = @()
for ($index = 1; $index -le 9; $index++) {
    $path = (Join-Path $slides "slide-$index.png").Replace("\", "/")
    $lines += "file '$path'"
    $lines += "duration 8"
}
$lines += "file '" + (Join-Path $slides "slide-9.png").Replace("\", "/") + "'"
Set-Content -LiteralPath $slideList -Value $lines -Encoding utf8

$pptSegment = Join-Path $work "ppt_segment.mp4"
& $Ffmpeg -y -f concat -safe 0 -i $slideList -vf "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,fps=30" -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -an $pptSegment
if ($LASTEXITCODE -ne 0) { throw "PPT 视频段生成失败" }

& $Ffmpeg -y -i $pptSegment -i $demo -filter_complex "[0:v][1:v]concat=n=2:v=1:a=0[v]" -map "[v]" -c:v libx264 -preset medium -crf 20 -pix_fmt yuv420p -movflags +faststart $output
if ($LASTEXITCODE -ne 0) { throw "项目视频拼接失败" }

Write-Output $output
