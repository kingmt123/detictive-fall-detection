"""以 clip-batched Top-k MIL 辅助损失训练当前多流因果 TCN。

此实验保留逐窗口 BCE、特征和模型不变，只加入每个视频窗口 logit 的
Top-k 均值 clip 损失，避免训练目标与最终 clip-max 评分完全脱节。
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn

from models.multiscale_multistream_tcn import (
    MultiStreamMultiScaleAttentionTCN,
    count_params,
)
from models.tcn_dataset import SEMANTIC_TO_CODE, WindowMemmapCache, build_window_cache
from tools.build_tcn_multistream_sidecar import load_sidecar
from tools.train_multiscale_multistream_tcn import MultiStreamConfig, _activity_groups
from tools.train_tcn import (
    _append_sidecar,
    _atomic_checkpoint,
    _atomic_json,
    _canonical_json,
    _materialize,
    _run_signature,
    _sha256_file,
    evaluate_model,
    select_training_indices,
    set_deterministic,
)

_COCO_FLIP_INDEX = torch.tensor(
    [0, 2, 1, 4, 3, 6, 5, 8, 7, 10, 9, 12, 11, 14, 13, 16, 15],
    dtype=torch.long,
)


def augment_training_features(
    features: torch.Tensor, config: MILConfig, *, seed: int
) -> torch.Tensor:
    """Apply deterministic, label-preserving pose perturbations to a train batch."""
    if features.ndim != 3 or features.shape[-1] < 51:
        raise ValueError("训练增强需要形状 (B, T, >=51) 的特征")
    if not any(
        (
            config.pose_jitter_std,
            config.joint_dropout_probability,
            config.horizontal_flip_probability,
            config.temporal_augmentation_probability,
            config.joint_occlusion_probability,
        )
    ):
        return features
    generator = torch.Generator(device=features.device)
    generator.manual_seed(seed)
    augmented = features.clone()
    poses = augmented[..., :51].reshape(*augmented.shape[:2], 17, 3)
    observed = poses[..., 2] > 0
    if config.pose_jitter_std:
        noise = torch.randn(
            poses[..., :2].shape, device=features.device, generator=generator
        )
        # Low-confidence keypoints are less reliable, so they receive a larger
        # (but bounded) coordinate perturbation. Missing joints stay exactly zero.
        confidence_scale = (1.5 - poses[..., 2]).clamp(0.5, 1.5)
        poses[..., :2].add_(
            noise
            * config.pose_jitter_std
            * confidence_scale.unsqueeze(-1)
            * observed.unsqueeze(-1)
        )
    if config.joint_dropout_probability:
        missing = torch.rand(
            observed.shape, device=features.device, generator=generator
        )
        poses.masked_fill_(
            (observed & (missing < config.joint_dropout_probability)).unsqueeze(-1), 0.0
        )
    if config.horizontal_flip_probability:
        selected = (
            torch.rand(features.shape[0], device=features.device, generator=generator)
            < config.horizontal_flip_probability
        )
        if selected.any():
            flipped = poses[selected][
                :, :, _COCO_FLIP_INDEX.to(features.device)
            ].clone()
            flipped[..., 0].neg_()
            poses[selected] = flipped
            if augmented.shape[-1] >= 57:
                augmented[selected, :, 51] = 1.0 - augmented[selected, :, 51]
    if config.temporal_augmentation_probability:
        selected = torch.rand(features.shape[0], device=features.device, generator=generator) < config.temporal_augmentation_probability
        count = max(1, int(features.shape[1] * config.temporal_max_frame_fraction))
        for batch_index in torch.nonzero(selected, as_tuple=False).flatten():
            positions = torch.randperm(features.shape[1] - 1, device=features.device, generator=generator)[:count] + 1
            # Repeat the immediate past frame; this is causal and is equivalent to
            # a short local slow-down followed by a skipped observation.
            augmented[batch_index, positions] = augmented[batch_index, positions - 1]
    if config.joint_occlusion_probability:
        limbs = ((5, 7, 9), (6, 8, 10), (11, 13, 15), (12, 14, 16))
        selected = torch.rand(features.shape[0], device=features.device, generator=generator) < config.joint_occlusion_probability
        for batch_index in torch.nonzero(selected, as_tuple=False).flatten():
            span = int(torch.randint(2, 5, (), device=features.device, generator=generator))
            start = int(torch.randint(0, features.shape[1] - span + 1, (), device=features.device, generator=generator))
            limb = limbs[int(torch.randint(len(limbs), (), device=features.device, generator=generator))]
            poses[batch_index, start : start + span, limb] = 0.0
    return augmented


@dataclass(frozen=True)
class MILConfig(MultiStreamConfig):
    mil_topk_fraction: float = 0.2
    mil_loss_weight: float = 0.5
    mil_clip_batch_size: int = 8
    transition_aux_weight: float = 0.5
    hard_negative_ranking_weight: float = 0.0
    hard_negative_ranking_margin: float = 0.5
    stage_aux_weight: float = 0.2
    physics_aux_weight: float = 0.1
    backbone_learning_rate: float | None = None
    new_head_learning_rate: float | None = None
    warmup_epochs: int = 0

    @classmethod
    def from_json(cls, path: Path) -> MILConfig:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise TypeError("MIL 配置必须是 JSON 对象")
        unknown = set(payload) - set(cls.__dataclass_fields__)
        if unknown:
            raise ValueError(f"MIL 配置包含未知字段: {sorted(unknown)}")
        if "channels" in payload:
            payload["channels"] = tuple(payload["channels"])
        if "hard_negative_activities" in payload:
            payload["hard_negative_activities"] = tuple(
                payload["hard_negative_activities"]
            )
        config = cls(**payload)
        config.validate()
        return config

    def validate(self) -> None:
        super().validate()
        if not 0.0 < self.mil_topk_fraction <= 1.0:
            raise ValueError("mil_topk_fraction 必须位于 (0, 1]")
        if self.mil_loss_weight <= 0.0:
            raise ValueError("mil_loss_weight 必须为正")
        if self.mil_clip_batch_size < 1:
            raise ValueError("mil_clip_batch_size 必须为正")
        if self.transition_aux_weight <= 0.0:
            raise ValueError("transition_aux_weight 必须为正")
        if self.hard_negative_ranking_weight < 0.0:
            raise ValueError("hard_negative_ranking_weight 不能为负")
        if self.hard_negative_ranking_margin <= 0.0:
            raise ValueError("hard_negative_ranking_margin 必须为正")
        if self.stage_aux_weight <= 0.0:
            raise ValueError("stage_aux_weight 必须为正")
        if self.physics_aux_weight <= 0.0:
            raise ValueError("physics_aux_weight 必须为正")
        rates = (self.backbone_learning_rate, self.new_head_learning_rate)
        if any(rate is not None for rate in rates) and any(
            rate is None or rate <= 0.0 for rate in rates
        ):
            raise ValueError("分层学习率必须同时提供两个正值")
        if not 0 <= self.warmup_epochs < self.epochs:
            raise ValueError("warmup_epochs 必须位于 [0, epochs)")


def aggregate_topk_logits(
    logits: torch.Tensor, group_sizes: list[int], fraction: float
) -> torch.Tensor:
    """Aggregate contiguous per-clip logits with a differentiable Top-k mean."""
    if logits.ndim != 1 or not group_sizes or sum(group_sizes) != logits.numel():
        raise ValueError("logits 与 group_sizes 不匹配")
    if not 0.0 < fraction <= 1.0:
        raise ValueError("fraction 必须位于 (0, 1]")
    values: list[torch.Tensor] = []
    offset = 0
    for size in group_sizes:
        if size < 1:
            raise ValueError("每个 clip 至少需要一个窗口")
        count = max(1, math.ceil(size * fraction))
        values.append(torch.topk(logits[offset : offset + size], count).values.mean())
        offset += size
    return torch.stack(values)


def hard_negative_ranking_loss(
    clip_logits: torch.Tensor,
    clip_labels: torch.Tensor,
    activities: np.ndarray,
    *,
    margin: float,
) -> torch.Tensor:
    """Require fall clips to outrank confusing posture-transition clips."""
    if clip_logits.ndim != 1 or clip_labels.shape != clip_logits.shape:
        raise ValueError("clip logits/labels 必须为同形一维张量")
    if len(activities) != clip_logits.numel() or margin <= 0.0:
        raise ValueError("activities 或 margin 无效")
    positive = clip_logits[clip_labels > 0.5]
    hard_mask = torch.from_numpy(
        np.isin(activities, ("lie_down", "lying", "stand_up"))
    ).to(clip_logits.device)
    negative = clip_logits[(clip_labels < 0.5) & hard_mask]
    if not positive.numel() or not negative.numel():
        return clip_logits.new_zeros(())
    return torch.relu(margin - (positive[:, None] - negative[None, :])).mean()


STAGE_NAMES = (
    "fall_process",
    "fallen",
    "controlled_transition",
    "stationary_nonfall",
)


def build_stage_targets(semantic_codes: np.ndarray, activities: np.ndarray) -> np.ndarray:
    """Map immutable window semantics to a four-way training-only stage task."""
    semantic_codes = np.asarray(semantic_codes)
    activities = np.asarray(activities, dtype=object)
    if semantic_codes.ndim != 1 or semantic_codes.shape != activities.shape:
        raise ValueError("semantic_codes/activities 必须为同形一维数组")
    if not np.isin(semantic_codes, tuple(SEMANTIC_TO_CODE.values())).all():
        raise ValueError("semantic_codes 包含未知值")
    targets = np.full(semantic_codes.shape, 3, dtype=np.int64)
    controlled = np.isin(activities, ("lie_down", "sit_down", "stand_up"))
    targets[controlled] = 2
    # Immutable event semantics take precedence over a source-directory activity:
    # a positive incident stored below a confusing-activity directory is still a
    # fall/fallen window, not a controlled non-fall transition.
    targets[semantic_codes == SEMANTIC_TO_CODE["post_fall_state"]] = 1
    targets[semantic_codes == SEMANTIC_TO_CODE["fall_process"]] = 0
    return targets


def physics_targets(features: torch.Tensor) -> torch.Tensor:
    """Build causal, bounded supervision for torso orientation and descent."""
    from models.multiscale_multistream_tcn import build_pifr_features

    pifr = build_pifr_features(features)
    height_delta = (pifr[:, -1, 1] - pifr[:, 0, 1]).clamp(-1.0, 1.0)
    bbox_aspect = (features[:, -1, 54] / features[:, -1, 55].clamp_min(1e-4)).clamp(0.0, 4.0) / 4.0
    return torch.stack((pifr[:, -1, 2], height_delta, bbox_aspect), dim=1)


def _clip_groups(
    clip_indices: np.ndarray, clips: list[dict[str, Any]]
) -> tuple[list[np.ndarray], np.ndarray]:
    if clip_indices.ndim != 1:
        raise ValueError("clip_indices 必须为一维")
    groups: list[np.ndarray] = []
    labels: list[float] = []
    for clip_index in np.unique(clip_indices):
        if clip_index < 0 or clip_index >= len(clips):
            raise ValueError("clip_indices 超出 clips metadata")
        group = np.flatnonzero(clip_indices == clip_index)
        if not group.size:
            continue
        has_fall = clips[int(clip_index)].get("has_fall")
        if not isinstance(has_fall, bool):
            raise TypeError("clips metadata 缺少 bool has_fall")
        groups.append(group)
        labels.append(float(has_fall))
    if not groups or not any(labels) or all(labels):
        raise ValueError("MIL 训练 clip 必须同时包含正负样本")
    return groups, np.asarray(labels, dtype=np.float32)


def train_epoch_mil(
    model: nn.Module,
    optimizer: torch.optim.Optimizer,
    features: torch.Tensor,
    labels: torch.Tensor,
    groups: list[np.ndarray],
    clip_labels: np.ndarray,
    transition_targets: torch.Tensor | None = None,
    clip_activities: np.ndarray | None = None,
    stage_targets: torch.Tensor | None = None,
    *,
    device: torch.device,
    config: MILConfig,
    epoch: int,
) -> float:
    """Run one deterministic epoch over batches of complete clips."""
    model.train()
    clip_order = np.random.default_rng(config.seed + epoch).permutation(len(groups))
    window_pos_weight = float((labels.numel() - labels.sum()) / labels.sum())
    clip_pos_weight = float((clip_labels.size - clip_labels.sum()) / clip_labels.sum())
    window_criterion = nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor(window_pos_weight, device=device)
    )
    clip_criterion = nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor(clip_pos_weight, device=device)
    )
    transition_criterion = None
    if config.use_transition_rule_late_fusion:
        if transition_targets is None or transition_targets.shape != labels.shape:
            raise ValueError("转变规则辅助监督需要与窗口标签同形的 targets")
        positives = float(transition_targets.sum())
        if positives <= 0.0 or positives >= transition_targets.numel():
            raise ValueError("转变规则 targets 必须同时含正负样本")
        transition_criterion = nn.BCEWithLogitsLoss(
            pos_weight=torch.tensor(
                (transition_targets.numel() - positives) / positives, device=device
            )
        )
    if config.hard_negative_ranking_weight and clip_activities is None:
        raise ValueError("困难负例排序损失需要每个训练 clip 的 activity")
    stage_criterion = None
    if config.use_stage_auxiliary:
        if stage_targets is None or stage_targets.shape != labels.shape:
            raise ValueError("阶段辅助监督需要与窗口标签同形的 targets")
        counts = torch.bincount(stage_targets, minlength=len(STAGE_NAMES)).float()
        if torch.any(counts == 0):
            raise ValueError("阶段辅助监督必须覆盖全部类别")
        stage_criterion = nn.CrossEntropyLoss(weight=(counts.sum() / counts).to(device))
    loss_sum = 0.0
    seen_clips = 0
    for start in range(0, len(groups), config.mil_clip_batch_size):
        selected = clip_order[start : start + config.mil_clip_batch_size]
        group_sizes = [int(groups[int(index)].size) for index in selected]
        window_indices = np.concatenate([groups[int(index)] for index in selected])
        batch_x = augment_training_features(
            features[window_indices].to(device),
            config,
            seed=config.seed + epoch * 1_000_003 + start,
        )
        batch_y = labels[window_indices].to(device)
        batch_clip_y = torch.from_numpy(clip_labels[selected]).to(device)
        optimizer.zero_grad(set_to_none=True)
        physics_prediction = None
        if config.use_transition_rule_late_fusion:
            if not isinstance(model, MultiStreamMultiScaleAttentionTCN):
                raise TypeError(
                    "转变规则 late fusion 需要 MultiStreamMultiScaleAttentionTCN"
                )
            logits, transition_logits = model.forward_with_transition(batch_x)
        else:
            if config.use_stage_auxiliary:
                logits, stage_logits = model.forward_with_stage(batch_x)
                if config.use_physics_auxiliary:
                    _, physics_prediction = model.forward_with_physics(batch_x)
            elif config.use_physics_auxiliary:
                logits, physics_prediction = model.forward_with_physics(batch_x)
            else:
                logits = model(batch_x)
                stage_logits = None
            transition_logits = None
        clip_logits = aggregate_topk_logits(
            logits, group_sizes, config.mil_topk_fraction
        )
        loss = window_criterion(
            logits, batch_y
        ) + config.mil_loss_weight * clip_criterion(clip_logits, batch_clip_y)
        if config.hard_negative_ranking_weight:
            assert clip_activities is not None
            loss = loss + config.hard_negative_ranking_weight * hard_negative_ranking_loss(
                clip_logits,
                batch_clip_y,
                clip_activities[selected],
                margin=config.hard_negative_ranking_margin,
            )
        if transition_criterion is not None and transition_logits is not None:
            loss = loss + config.transition_aux_weight * transition_criterion(
                transition_logits, transition_targets[window_indices].to(device)
            )
        if stage_criterion is not None and stage_logits is not None:
            loss = loss + config.stage_aux_weight * stage_criterion(
                stage_logits, stage_targets[window_indices].to(device)
            )
        if config.use_physics_auxiliary and physics_prediction is not None:
            loss = loss + config.physics_aux_weight * nn.functional.smooth_l1_loss(
                physics_prediction, physics_targets(batch_x)
            )
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), config.grad_clip)
        optimizer.step()
        loss_sum += float(loss.detach()) * len(selected)
        seen_clips += len(selected)
    return loss_sum / seen_clips


def train_mil(
    *,
    config: MILConfig,
    train_cache: WindowMemmapCache,
    val_cache: WindowMemmapCache,
    train_sidecar: np.ndarray,
    val_sidecar: np.ndarray,
    output_dir: Path,
    device_name: str,
    joint_pretrain_checkpoint: Path | None = None,
    initialization_checkpoint: Path | None = None,
) -> dict[str, Any]:
    config.validate()
    if device_name.startswith("cuda") and not torch.cuda.is_available():
        raise ValueError("请求 CUDA 训练，但 torch.cuda.is_available() 为 False")
    output_dir = Path(output_dir)
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValueError("输出目录非空；MIL 训练不支持 resume")
    set_deterministic(config.seed)
    train_indices = select_training_indices(
        train_cache.array("labels"),
        negative_ratio=config.negative_ratio,
        seed=config.seed,
        activity_groups=_activity_groups(train_cache),
        hard_negative_activities=config.hard_negative_activities,
        hard_negative_fraction=config.hard_negative_fraction,
    )
    train_x, train_y, train_clip_indices = _materialize(train_cache, train_indices)
    val_x, val_y, val_clip_indices = _materialize(val_cache, None)
    train_x = _append_sidecar(train_x, train_sidecar, train_indices)
    val_x = _append_sidecar(val_x, val_sidecar, None)
    groups, clip_labels = _clip_groups(
        train_clip_indices, train_cache.metadata["clips"]
    )
    clip_activities = np.asarray(
        [
            str(
                train_cache.metadata["clips"][
                    int(train_clip_indices[int(indices[0])])
                ]["clip_id"]
            ).split("/", 1)[0]
            for indices in groups
        ],
        dtype=object,
    )
    window_activities = _activity_groups(train_cache)[train_indices]
    stage_targets = (
        torch.from_numpy(
            build_stage_targets(
                np.asarray(train_cache.array("semantic_codes")[train_indices]),
                window_activities,
            )
        )
        if config.use_stage_auxiliary
        else None
    )
    transition_targets = (
        torch.from_numpy(
            (
                np.asarray(train_cache.array("semantic_codes")[train_indices])
                == SEMANTIC_TO_CODE["fall_process"]
            ).astype(np.float32, copy=False)
        )
        if config.use_transition_rule_late_fusion
        else None
    )
    device = torch.device(device_name)
    model = MultiStreamMultiScaleAttentionTCN(
        stream_channels=config.stream_channels,
        stream_output_dim=config.stream_output_dim,
        dropout=config.dropout,
        use_geometry=True,
        stream_lstm_layers=config.stream_lstm_layers,
        use_rule_features=config.use_rule_features,
        use_pifr_features=config.use_pifr_features,
        use_stgcn_joint=config.use_stgcn_joint,
        use_stgcn_residual_joint=config.use_stgcn_residual_joint,
        use_transformer_encoder=config.use_transformer_encoder,
        transformer_joint_only=config.transformer_joint_only,
        use_transition_rule_late_fusion=config.use_transition_rule_late_fusion,
        use_discriminative_kinematics=config.use_discriminative_kinematics,
        kinematic_feature_dim=config.kinematic_feature_dim,
        use_gated_conv=config.use_gated_conv,
        use_motion_guided_fusion=config.use_motion_guided_fusion,
        use_stage_auxiliary=config.use_stage_auxiliary,
        use_physics_auxiliary=config.use_physics_auxiliary,
    ).to(device)
    joint_pretrain_sha256 = None
    initialization_checkpoint_sha256 = None
    initialization_loaded_keys = 0
    if initialization_checkpoint is not None:
        payload = torch.load(initialization_checkpoint, map_location="cpu", weights_only=False)
        state = payload.get("model_state") if isinstance(payload, dict) else None
        if not isinstance(state, dict):
            raise TypeError("初始化 checkpoint 缺少 model_state")
        current = model.state_dict()
        compatible = {
            key: value
            for key, value in state.items()
            if key in current and current[key].shape == value.shape
        }
        if not compatible:
            raise ValueError("初始化 checkpoint 没有形状兼容的参数")
        current.update(compatible)
        model.load_state_dict(current, strict=True)
        initialization_loaded_keys = len(compatible)
        initialization_checkpoint_sha256 = _sha256_file(initialization_checkpoint)
    if joint_pretrain_checkpoint is not None:
        if config.use_stgcn_joint:
            raise ValueError("ST-GCN joint 流不能加载 StreamEncoder 预训练权重")
        joint_pretrain_checkpoint = Path(joint_pretrain_checkpoint)
        payload = torch.load(joint_pretrain_checkpoint, map_location="cpu", weights_only=False)
        if not isinstance(payload, dict) or not isinstance(payload.get("encoder_state"), dict):
            raise ValueError("Joint 预训练 checkpoint 缺少 encoder_state")
        load_result = model.streams[0].load_state_dict(
            payload["encoder_state"], strict=not config.use_stgcn_residual_joint
        )
        if config.use_stgcn_residual_joint and (
            load_result.unexpected_keys
            or any(
                not key.startswith("graph_residual.")
                for key in load_result.missing_keys
            )
        ):
            raise ValueError("Residual ST-GCN Joint 预训练权重不兼容")
        joint_pretrain_sha256 = _sha256_file(joint_pretrain_checkpoint)
    if config.backbone_learning_rate is None:
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay,
        )
    else:
        assert config.new_head_learning_rate is not None
        head_parameters = []
        if config.use_stage_auxiliary and model.stage_classifier is not None:
            head_parameters.extend(model.stage_classifier.parameters())
        if config.use_physics_auxiliary and model.physics_auxiliary is not None:
            head_parameters.extend(model.physics_auxiliary.parameters())
        if config.use_stgcn_residual_joint:
            head_parameters.extend(model.streams[0].graph_residual.parameters())
        if not head_parameters:
            raise ValueError("分层学习率需要至少一个新辅助头")
        head_ids = {id(parameter) for parameter in head_parameters}
        backbone_parameters = [
            parameter for parameter in model.parameters() if id(parameter) not in head_ids
        ]
        optimizer = torch.optim.AdamW(
            [
                {"params": backbone_parameters, "lr": config.backbone_learning_rate},
                {"params": head_parameters, "lr": config.new_head_learning_rate},
            ],
            weight_decay=config.weight_decay,
        )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(1, config.epochs - config.warmup_epochs)
    )
    if config.warmup_epochs:
        for group in optimizer.param_groups:
            group["lr"] = group["initial_lr"] * 0.1
    architecture = {
        "name": "MultiStreamMultiScaleAttentionTCN",
        "streams": {
            "joint": 51,
            "bone": 32,
            "motion": 34,
            "geometry_observed": 6,
            **({"rule_features": 12} if config.use_rule_features else {}),
            **({"pifr_features": 9} if config.use_pifr_features else {}),
            **(
                {"transition_rule_features": 8}
                if config.use_transition_rule_late_fusion
                else {}
            ),
            **(
                {"discriminative_kinematics": config.kinematic_feature_dim}
                if config.use_discriminative_kinematics
                else {}
            ),
        },
        "dilations": [1, 2, 4, 8],
        "kernels": [3, 5, 7],
        "attention_heads": 4,
        "stream_channels": config.stream_channels,
        "stream_output_dim": config.stream_output_dim,
        "stream_lstm_layers": config.stream_lstm_layers,
        "use_rule_features": config.use_rule_features,
        "use_pifr_features": config.use_pifr_features,
        "use_stgcn_joint": config.use_stgcn_joint,
        "use_stgcn_residual_joint": config.use_stgcn_residual_joint,
        "use_transformer_encoder": config.use_transformer_encoder,
        "transformer_joint_only": config.transformer_joint_only,
        "use_transition_rule_late_fusion": config.use_transition_rule_late_fusion,
        "use_discriminative_kinematics": config.use_discriminative_kinematics,
        "kinematic_feature_dim": config.kinematic_feature_dim,
        "use_gated_conv": config.use_gated_conv,
        "use_motion_guided_fusion": config.use_motion_guided_fusion,
        "use_stage_auxiliary": config.use_stage_auxiliary,
        "use_physics_auxiliary": config.use_physics_auxiliary,
        "training_augmentation": {
            "pose_jitter_std": config.pose_jitter_std,
            "joint_dropout_probability": config.joint_dropout_probability,
            "horizontal_flip_probability": config.horizontal_flip_probability,
            "temporal_augmentation_probability": config.temporal_augmentation_probability,
            "temporal_max_frame_fraction": config.temporal_max_frame_fraction,
            "joint_occlusion_probability": config.joint_occlusion_probability,
            "train_only": True,
        },
        "optimization": {
            "backbone_learning_rate": config.backbone_learning_rate,
            "new_head_learning_rate": config.new_head_learning_rate,
            "warmup_epochs": config.warmup_epochs,
            "scheduler": "warmup_then_cosine",
        },
        "mil": {
            "aggregate": "topk_mean",
            "topk_fraction": config.mil_topk_fraction,
            "loss_weight": config.mil_loss_weight,
            "clip_batch_size": config.mil_clip_batch_size,
            "transition_aux_weight": (
                config.transition_aux_weight
                if config.use_transition_rule_late_fusion
                else None
            ),
            "hard_negative_ranking": {
                "weight": config.hard_negative_ranking_weight,
                "margin": config.hard_negative_ranking_margin,
                "activities": ["lie_down", "lying", "stand_up"],
            },
            "stage_auxiliary": {
                "enabled": config.use_stage_auxiliary,
                "weight": config.stage_aux_weight if config.use_stage_auxiliary else None,
                "classes": list(STAGE_NAMES) if config.use_stage_auxiliary else None,
            },
        },
        "causal": True,
        "joint_pretrain": (
            {"protocol": "fallvision_joint_clip_mil_v1", "checkpoint_sha256": joint_pretrain_sha256}
            if joint_pretrain_sha256 is not None
            else None
        ),
        "initialization": (
            {
                "checkpoint_sha256": initialization_checkpoint_sha256,
                "compatible_state_keys": initialization_loaded_keys,
            }
            if initialization_checkpoint_sha256 is not None
            else None
        ),
    }
    root = Path(__file__).parent.parent
    signature_sha256, signature = _run_signature(
        config=config,
        train_cache=train_cache,
        val_cache=val_cache,
        device=device_name,
        max_train_samples=None,
        max_val_samples=None,
        protocol="multiscale_multistream_topk_mil_v1",
        code_paths=(
            root / "models" / "multiscale_multistream_tcn.py",
            root / "models" / "tcn_dataset.py",
            root / "tools" / "train_tcn.py",
            root / "tools" / "train_multiscale_multistream_tcn.py",
            root / "tools" / "train_multiscale_multistream_mil.py",
            *(
                (root / "models" / "fallvision_joint_mil.py",)
                if joint_pretrain_sha256 is not None
                else ()
            ),
        ),
        extra_signature=architecture,
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    _atomic_json(
        output_dir / "run.json",
        {
            "signature_sha256": signature_sha256,
            "signature": signature,
            "architecture": architecture,
            "parameter_count": count_params(model),
            "train_samples": int(train_y.numel()),
            "train_positive": int(train_y.sum()),
            "train_clips": len(groups),
            "val_samples": int(val_y.numel()),
            "pilot": False,
        },
    )
    best_map = -math.inf
    history: list[dict[str, Any]] = []
    for epoch in range(config.epochs):
        if config.warmup_epochs and epoch < config.warmup_epochs:
            warmup_factor = 0.1 + 0.9 * float(epoch) / float(config.warmup_epochs)
            for group in optimizer.param_groups:
                group["lr"] = group["initial_lr"] * warmup_factor
        train_loss = train_epoch_mil(
            model,
            optimizer,
            train_x,
            train_y,
            groups,
            clip_labels,
            transition_targets,
            clip_activities,
            stage_targets,
            device=device,
            config=config,
            epoch=epoch,
        )
        metrics = evaluate_model(
            model,
            val_x,
            val_y,
            val_clip_indices,
            val_cache.metadata["clips"],
            device=device,
            batch_size=config.batch_size,
        )
        if config.warmup_epochs and epoch + 1 == config.warmup_epochs:
            for group in optimizer.param_groups:
                group["lr"] = group["initial_lr"]
        elif epoch >= config.warmup_epochs:
            scheduler.step()
        record = {
            "epoch": epoch,
            "train_loss": train_loss,
            "learning_rate": optimizer.param_groups[0]["lr"],
            "val": metrics,
        }
        with (output_dir / "history.jsonl").open(
            "a", encoding="utf-8", newline="\n"
        ) as handle:
            handle.write(_canonical_json(record) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        history.append(record)
        improved = metrics["clip_map"] > best_map
        if improved:
            best_map = metrics["clip_map"]
        checkpoint = {
            "epoch": epoch,
            "run_signature_sha256": signature_sha256,
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "scheduler_state": scheduler.state_dict(),
            "torch_rng_state": torch.get_rng_state(),
            "cuda_rng_state_all": torch.cuda.get_rng_state_all()
            if device.type == "cuda"
            else [],
            "best_map": best_map,
            "metrics": record,
        }
        _atomic_checkpoint(output_dir / "last.pt", checkpoint)
        if improved:
            _atomic_checkpoint(output_dir / "best.pt", checkpoint)
        print(_canonical_json({"stage": "epoch", **record}), flush=True)
    summary = {
        "run_signature_sha256": signature_sha256,
        "epochs_completed": config.epochs,
        "best_clip_map": best_map,
        "last": history[-1],
        "output_dir": str(output_dir.resolve()),
    }
    _atomic_json(output_dir / "summary.json", summary)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--pose-cache-root", type=Path, required=True)
    parser.add_argument("--audit-report", type=Path, required=True)
    parser.add_argument("--window-cache-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--train-sidecar", type=Path, required=True)
    parser.add_argument("--val-sidecar", type=Path, required=True)
    parser.add_argument("--dataset", default="of-syn")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--epochs", type=int)
    parser.add_argument("--joint-pretrain-checkpoint", type=Path)
    parser.add_argument("--initialization-checkpoint", type=Path)
    args = parser.parse_args()
    config = MILConfig.from_json(args.config)
    if args.epochs is not None:
        config = replace(config, epochs=args.epochs)
        config.validate()
    caches = {
        split: build_window_cache(
            args.manifest,
            args.pose_cache_root,
            args.audit_report,
            args.window_cache_root,
            dataset=args.dataset,
            split=split,
            window_size=config.window_size,
            stride=config.stride,
            min_observed_frames=config.min_observed_frames,
        )
        for split in ("train", "val")
    }
    summary = train_mil(
        config=config,
        train_cache=caches["train"],
        val_cache=caches["val"],
        train_sidecar=load_sidecar(args.train_sidecar, caches["train"]),
        val_sidecar=load_sidecar(args.val_sidecar, caches["val"]),
        output_dir=args.output_dir,
        device_name=args.device,
        joint_pretrain_checkpoint=args.joint_pretrain_checkpoint,
        initialization_checkpoint=args.initialization_checkpoint,
    )
    print(_canonical_json({"stage": "complete", **summary}), flush=True)


if __name__ == "__main__":
    main()
