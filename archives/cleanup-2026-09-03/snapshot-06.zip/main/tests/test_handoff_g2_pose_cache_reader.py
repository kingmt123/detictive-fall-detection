"""Regression coverage for the handoff G2 cache-consumer entry point."""
from pathlib import Path

import numpy as np
import pytest

import pipeline.pose_cache as pose_cache


def test_training_reader_reads_valid_frozen_cache_without_resume_signature(
    tmp_path: Path,
):
    record = pose_cache.PoseCacheRecord(
        clip_id="fall/example",
        dataset="of-syn",
        split="train",
        source_identity={"kind": "tar", "member": "./fall/example.mp4"},
        source_content_sha256="a" * 64,
        extractor_signature={"protocol": "pose-cache-v1", "model_sha256": "b" * 64},
        fps=16.0,
        frame_indices=np.array([0], dtype=np.int64),
        timestamps=np.array([0.0], dtype=np.float64),
        keypoints=np.zeros((1, 1, 17, 3), dtype=np.float32),
        bboxes=np.array([[[1, 2, 10, 20]]], dtype=np.float32),
        track_ids=np.array([[3]], dtype=np.int64),
        valid_mask=np.array([[True]], dtype=np.bool_),
        frame_size=np.array([720, 1280], dtype=np.int64),
    )
    path = tmp_path / "frozen.npz"
    pose_cache.write_pose_cache(path, record)

    loaded = pose_cache.read_pose_cache(path)

    assert loaded.clip_id == record.clip_id
    assert loaded.extractor_signature == record.extractor_signature


def test_cache_writer_rejects_out_of_range_valid_keypoint_confidence(tmp_path: Path):
    keypoints = np.zeros((1, 1, 17, 3), dtype=np.float32)
    keypoints[0, 0, 0, 2] = 1.5
    record = pose_cache.PoseCacheRecord(
        clip_id="fall/invalid-confidence",
        dataset="of-syn",
        split="train",
        source_identity={"kind": "tar", "member": "./fall/example.mp4"},
        source_content_sha256="a" * 64,
        extractor_signature={"protocol": "pose-cache-v1", "model_sha256": "b" * 64},
        fps=16.0,
        frame_indices=np.array([0], dtype=np.int64),
        timestamps=np.array([0.0], dtype=np.float64),
        keypoints=keypoints,
        bboxes=np.array([[[1, 2, 10, 20]]], dtype=np.float32),
        track_ids=np.array([[3]], dtype=np.int64),
        valid_mask=np.array([[True]], dtype=np.bool_),
        frame_size=np.array([720, 1280], dtype=np.int64),
    )

    with pytest.raises(ValueError, match="confidence"):
        pose_cache.write_pose_cache(tmp_path / "invalid-confidence.npz", record)


def test_cache_writer_rejects_invalid_valid_bbox_geometry(tmp_path: Path):
    record = pose_cache.PoseCacheRecord(
        clip_id="fall/invalid-bbox",
        dataset="of-syn",
        split="train",
        source_identity={"kind": "tar", "member": "./fall/example.mp4"},
        source_content_sha256="a" * 64,
        extractor_signature={"protocol": "pose-cache-v1", "model_sha256": "b" * 64},
        fps=16.0,
        frame_indices=np.array([0], dtype=np.int64),
        timestamps=np.array([0.0], dtype=np.float64),
        keypoints=np.zeros((1, 1, 17, 3), dtype=np.float32),
        bboxes=np.array([[[10, 2, 1, 20]]], dtype=np.float32),
        track_ids=np.array([[3]], dtype=np.int64),
        valid_mask=np.array([[True]], dtype=np.bool_),
        frame_size=np.array([720, 1280], dtype=np.int64),
    )

    with pytest.raises(ValueError, match="x2>x1"):
        pose_cache.write_pose_cache(tmp_path / "invalid-bbox.npz", record)
