
import sys
sys.path.insert(0, r"D:\HermesWorkspace\Detictive\parallel_worker_20260824")
from pathlib import Path
from models.tcn_dataset import build_window_cache

manifest = Path(r"D:\HermesWorkspace\Detictive\runs\local_cache_20260824\e2-full-cache\training\manifest_filtered.csv")
pose_cache_root = Path(r"D:\HermesWorkspace\Detictive\runs\local_cache_20260824\e2-full-cache\cache")
audit_path = Path(r"D:\HermesWorkspace\Detictive\runs\local_cache_20260824\e2-full-cache\training\audit_filtered.json")
output_root = Path(r"D:\HermesWorkspace\Detictive\runs\local_cache_20260824\e2-full-cache\training\window_cache")

for split in ["train", "val"]:
    print(f"Building window cache for {split}...", flush=True)
    cache = build_window_cache(
        manifest, pose_cache_root, audit_path, output_root,
        dataset="of-syn", split=split,
        window_size=16, stride=1, min_observed_frames=8,
    )
    print(f"  {split}: {cache.samples} samples, {cache.positive_count} positive", flush=True)

# URFD
for split in ["train", "val"]:
    print(f"Building URFD window cache for {split}...", flush=True)
    cache = build_window_cache(
        manifest, pose_cache_root, audit_path, output_root,
        dataset="urfd", split=split,
        window_size=16, stride=1, min_observed_frames=8,
    )
    print(f"  urfd/{split}: {cache.samples} samples, {cache.positive_count} positive", flush=True)

print("ALL DONE", flush=True)
