import { Presentation, PresentationFile } from "@oai/artifact-tool";
import fs from "node:fs/promises";

const OUT = "D:/HermesWorkspace/Detictive/deliverables/抹茶吃不饱_面向低算力平台的实时跌倒检测_项目汇报PPT.pptx";
const ROOT = "D:/HermesWorkspace/Detictive";
const COLORS = { ink: "#102A43", blue: "#1F76B8", pale: "#EAF4FF", light: "#F6F8FA", gray: "#52606D", rule: "#D9E2EC", white: "#FFFFFF", green: "#18864B" };

function box(slide, x, y, w, h, fill = COLORS.white, line = COLORS.rule) {
  return slide.shapes.add({ geometry: "rect", position: { left: x, top: y, width: w, height: h }, fill, line: { style: "solid", fill: line, width: 1 } });
}
function text(slide, value, x, y, w, h, size = 24, color = COLORS.ink, bold = false, alignment = "left") {
  const shape = slide.shapes.add({ geometry: "textbox", position: { left: x, top: y, width: w, height: h }, fill: "none", line: { style: "solid", fill: "none", width: 0 } });
  shape.text = value;
  shape.text.style = { fontSize: size, fontFace: "Microsoft YaHei", color, bold, alignment, verticalAlignment: "middle" };
  return shape;
}
function title(slide, heading, eyebrow) {
  text(slide, eyebrow, 70, 36, 500, 28, 15, COLORS.blue, true);
  text(slide, heading, 70, 76, 1080, 58, 38, COLORS.ink, true);
  box(slide, 70, 145, 1140, 2, COLORS.blue, COLORS.blue);
}
function notes(slide, sources) {
  slide.speakerNotes.textFrame.setText(`[Sources]\n${sources}`);
  slide.speakerNotes.setVisible(true);
}
function metric(slide, value, label, x, color = COLORS.blue) {
  box(slide, x, 230, 240, 150, COLORS.pale, "#B7D8F4");
  text(slide, value, x + 22, 258, 205, 44, 31, color, true);
  text(slide, label, x + 22, 315, 205, 30, 17, COLORS.gray, false);
}

async function main() {
  const p = Presentation.create({ slideSize: { width: 1280, height: 720 } });
  const routeImage = await fs.readFile(`${ROOT}/deliverables/assets/technical_route.png`);
  const resultImage = await fs.readFile(`${ROOT}/deliverables/assets/result_evidence.png`);
  const demoImage = await fs.readFile(`${ROOT}/tmp/competition_video/frame-540.png`);

  let s = p.slides.add(); s.background.fill = COLORS.white;
  text(s, "企业赛题七", 72, 64, 260, 30, 16, COLORS.blue, true);
  text(s, "面向低算力平台的\n实时跌倒检测", 72, 154, 660, 160, 56, COLORS.ink, true);
  text(s, "抹茶吃不饱  |  第八届中国研究生人工智能创新大赛", 72, 347, 690, 32, 21, COLORS.gray);
  box(s, 72, 428, 500, 3, COLORS.blue, COLORS.blue);
  text(s, "普通 RGB 视频 → 姿态与轨迹 → 双尺度时序 → 七头融合 → 可解释输出", 72, 460, 790, 36, 22, COLORS.ink);
  s.images.add({ blob: routeImage, contentType: "image/png", alt: "从RGB视频到七头融合的技术路线图", fit: "contain", position: { left: 745, top: 95, width: 460, height: 430 } });
  text(s, "实时 · 低算力 · 可复现 · 可审计", 745, 565, 460, 32, 22, COLORS.blue, true, "center");
  notes(s, "Project MANIFEST.json and project technical route diagram.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "跌倒检测需要“看见动作过程”，而不是只看单帧姿态", "场景与目标");
  const scenarios = [["养老与家庭看护", "突发跌倒需要及时发现与回看"], ["康复与病房", "关注动作转变和持续卧倒风险"], ["低算力边缘摄像头", "使用普通 RGB 输入，降低额外硬件依赖"]];
  scenarios.forEach((item, i) => { const x = 80 + i * 385; box(s, x, 230, 335, 255, i === 2 ? "#EAF4FF" : COLORS.light); text(s, item[0], x + 24, 260, 285, 40, 26, COLORS.ink, true); text(s, item[1], x + 24, 330, 285, 95, 20, COLORS.gray); });
  text(s, "项目目标：在不读取部署视频标签、真实事件区间或人物 ID 的前提下，输出风险分数、候选时间区间和可复核证据。", 80, 548, 1120, 56, 24, COLORS.ink, true, "center");
  notes(s, "Project design statement; no external claim.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "双证据链兼顾运动几何与人体区域视觉线索", "技术路线");
  s.images.add({ blob: routeImage, contentType: "image/png", alt: "技术路线图", fit: "contain", position: { left: 70, top: 185, width: 1140, height: 380 } });
  text(s, "姿态轨迹提供动作变化证据；ROI token 补充外观与场景线索；固定七头等权融合确保输出规则可复现。", 90, 600, 1100, 36, 22, COLORS.gray, false, "center");
  notes(s, "Project MANIFEST.json: fusion = mean(seven raw logits) then sigmoid.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "创新点集中在多尺度时序、共享视觉主干与固定融合", "创新性论证");
  const innovations = [["01", "双尺度骨架编码", "16 帧捕捉快速下坠；48 帧保留完整动作上下文。"], ["02", "姿态 + ROI 双证据", "共享 YOLO11n-pose 视觉主干，减少额外 RGB backbone 负担。"], ["03", "固定七头融合", "对七个 raw logits 取算术平均后 sigmoid，避免部署侧再调参。"]];
  innovations.forEach((it, i) => { const y = 198 + i * 132; text(s, it[0], 82, y, 90, 52, 35, COLORS.blue, true); box(s, 188, y - 2, 990, 95, i === 1 ? COLORS.pale : COLORS.light); text(s, it[1], 218, y + 12, 270, 34, 24, COLORS.ink, true); text(s, it[2], 495, y + 12, 645, 58, 20, COLORS.gray); });
  text(s, "输出链条可被逐段检查：关键点 → track_id → 候选区间 → 成员分数 → 融合分数。", 82, 610, 1100, 35, 23, COLORS.green, true, "center");
  notes(s, "Project source code and MANIFEST.json.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "数据、行业知识、算法与硬件来源均明确标注", "来源与合规边界");
  const rows = [["训练 / 验证", "OmniFall 标注与 OF-Syn 合成视频", "上游 random clip split；不宣称身份独立"], ["演示视频", "URFD 公开 fall-01-cam1", "仅用于端到端可视化与烟测"], ["算法与框架", "Ultralytics YOLO11n-pose + PyTorch", "17 关键点、人体框与时序特征"], ["硬件与部署", "Python 3.11 + CUDA GPU", "本地推理；冻结权重与清单"]];
  text(s, "要素", 95, 200, 200, 28, 20, COLORS.gray, true); text(s, "来源", 335, 200, 360, 28, 20, COLORS.gray, true); text(s, "使用边界", 760, 200, 390, 28, 20, COLORS.gray, true);
  rows.forEach((row, i) => { const y = 242 + i * 82; box(s, 80, y, 1090, 70, i % 2 ? COLORS.light : COLORS.white); text(s, row[0], 95, y + 15, 205, 35, 19, COLORS.ink, true); text(s, row[1], 335, y + 15, 370, 36, 18, COLORS.ink); text(s, row[2], 760, y + 15, 390, 38, 18, COLORS.gray); });
  notes(s, "URFD: https://fenix.ur.edu.pl/~mkepski/ds/uf.html; Ultralytics Pose docs: https://docs.ultralytics.com/tasks/pose/; PyTorch docs: https://pytorch.org/docs/; project README.md.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "冻结验证与推理证据覆盖模型规模、排序指标和视频闭环", "结果展示");
  s.images.add({ blob: resultImage, contentType: "image/png", alt: "模型参数、验证指标和端到端烟测结果", fit: "contain", position: { left: 70, top: 180, width: 1140, height: 390 } });
  text(s, "验证集为 OF-Syn validation（1,200 clips）；URFD 片段用于原始视频端到端烟测。", 80, 606, 1120, 30, 21, COLORS.gray, false, "center");
  notes(s, "Frozen runtime README.md and reports/final_model_smoke.json. Metrics: mAP 75.208%; P@R90 77.907%; P@R95 72.509%; 4.053M parameters; 15.46 MiB FP32.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "检测实录把最终分数还原为可见的中间证据", "现场演示");
  s.images.add({ blob: demoImage, contentType: "image/png", alt: "骨架、人体框、轨迹ID和七头分数可视化", fit: "contain", position: { left: 70, top: 185, width: 770, height: 430 } });
  box(s, 875, 205, 300, 340, COLORS.light); text(s, "演示同步呈现", 905, 235, 240, 34, 24, COLORS.ink, true); ["原始 RGB 视频", "17 点姿态骨架", "人体框与 track_id", "候选时间区间", "七个成员 raw logits", "融合风险分数"].forEach((item, i) => text(s, `• ${item}`, 910, 295 + i * 38, 230, 30, 20, i === 5 ? COLORS.blue : COLORS.gray, i === 5));
  notes(s, "Local generated detection demo from URFD fall-01-cam1. Project runtime smoke JSON.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "从视频输入到结构化 JSON，部署包保留可复现与审计链", "工程可行性");
  const steps = [["视频解码", "OpenCV 读取原始视频帧"], ["姿态与跟踪", "生成关键点、人体框、轨迹"], ["时序与融合", "构造窗口并输出七头成员分数"], ["结构化输出", "score、proposal、fps、分阶段延迟"]];
  steps.forEach((it, i) => { const x = 72 + i * 282; box(s, x, 260, 235, 180, i === 3 ? COLORS.pale : COLORS.light); text(s, `${i + 1}`, x + 20, 283, 38, 38, 27, COLORS.blue, true); text(s, it[0], x + 20, 340, 190, 34, 22, COLORS.ink, true); text(s, it[1], x + 20, 390, 188, 48, 17, COLORS.gray); if (i < 3) text(s, "→", x + 240, 325, 32, 32, 27, COLORS.blue, true, "center"); });
  text(s, "174 个运行包文件按 SHA-256 清单核验；权重、源码与依赖清单均可追溯。", 80, 550, 1120, 40, 24, COLORS.green, true, "center");
  notes(s, "Project MANIFEST.json; frozen runtime README.md.");

  s = p.slides.add(); s.background.fill = COLORS.white; title(s, "面向低算力场景的跌倒检测：可展示、可解释、可复现", "总结");
  metric(s, "4.053M", "模型参数", 115); metric(s, "75.208%", "OF-Syn val mAP", 390); metric(s, "7", "固定等权融合头", 665); metric(s, "174", "核验运行包文件", 940);
  text(s, "核心价值：以普通 RGB 视频支撑可回看、可核验的跌倒风险发现，为养老、康复与无人值守场景提供工程化原型。", 95, 470, 1090, 70, 26, COLORS.ink, true, "center");
  text(s, "抹茶吃不饱  |  企业赛题七", 95, 600, 1090, 28, 20, COLORS.gray, false, "center");
  notes(s, "Project summary. Evidence sources listed in project document references.");

  const out = await PresentationFile.exportPptx(p);
  await out.save(OUT);
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
