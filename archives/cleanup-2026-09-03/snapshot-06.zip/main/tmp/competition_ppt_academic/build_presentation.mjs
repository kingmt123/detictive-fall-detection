import { Presentation, PresentationFile } from "@oai/artifact-tool";
import fs from "node:fs/promises";

const OUT = "D:/HermesWorkspace/Detictive/deliverables/抹茶吃不饱_面向低算力平台的实时跌倒检测_项目汇报PPT.pptx";
const ROOT = "D:/HermesWorkspace/Detictive";
const C = { ink: "#15324B", blue: "#315E81", teal: "#2A8C82", orange: "#D27752", gray: "#536575", pale: "#F4F7F9", grid: "#D7E0E7", white: "#FFFFFF", red: "#A23B2A" };
const FONT = "Microsoft YaHei";

function rect(slide, x, y, w, h, fill = C.white, line = C.grid, width = 1) {
  return slide.shapes.add({ geometry: "rect", position: { left: x, top: y, width: w, height: h }, fill, line: { style: "solid", fill: line, width } });
}
function line(slide, x, y, w, color = C.grid, width = 1) { return rect(slide, x, y, w, width, color, color, 0); }
function txt(slide, value, x, y, w, h, size = 22, color = C.ink, bold = false, alignment = "left") {
  const shape = slide.shapes.add({ geometry: "textbox", position: { left: x, top: y, width: w, height: h }, fill: "none", line: { style: "solid", fill: "none", width: 0 } });
  shape.text = value;
  shape.text.style = { fontSize: size, fontFace: FONT, color, bold, alignment, verticalAlignment: "middle" };
  return shape;
}
function slideTitle(slide, claim, section, page) {
  txt(slide, section.toUpperCase(), 72, 34, 520, 24, 14, C.blue, true);
  txt(slide, claim, 72, 68, 1136, 58, 36, C.ink, true);
  line(slide, 72, 142, 1136, C.blue, 2);
  txt(slide, String(page).padStart(2, "0"), 1150, 674, 58, 20, 13, C.gray, false, "right");
  txt(slide, "抹茶吃不饱 · 企业赛题七", 72, 674, 300, 20, 13, C.gray);
}
function notes(slide, sources) {
  slide.speakerNotes.textFrame.setText(`[Sources]\n${sources}`);
  slide.speakerNotes.setVisible(true);
}
function bullet(slide, text, x, y, w, emphasis = false) {
  rect(slide, x, y + 12, 8, 8, emphasis ? C.orange : C.blue, emphasis ? C.orange : C.blue, 0);
  txt(slide, text, x + 22, y, w - 22, 52, 20, emphasis ? C.ink : C.gray, emphasis);
}
function arrow(slide, x1, y1, x2, y2) {
  const shaft = slide.shapes.add({ geometry: "line", position: { left: Math.min(x1, x2), top: Math.min(y1, y2), width: Math.abs(x2 - x1), height: Math.abs(y2 - y1) }, fill: "none", line: { style: "solid", fill: C.blue, width: 2, endArrowType: "triangle" } });
  return shaft;
}

async function main() {
  const p = Presentation.create({ slideSize: { width: 1280, height: 720 } });
  const demoImage = await fs.readFile(`${ROOT}/tmp/competition_video/frame-540.png`);
  const rawImage = await fs.readFile(`${ROOT}/reports/urfd_fall01_contact.jpg`);

  let s = p.slides.add(); s.background.fill = C.white;
  rect(s, 0, 0, 22, 720, C.blue, C.blue, 0);
  txt(s, "第八届中国研究生人工智能创新大赛 · 企业赛题七", 76, 64, 750, 28, 17, C.blue, true);
  txt(s, "面向低算力平台的\n实时跌倒检测", 76, 145, 690, 148, 55, C.ink, true);
  txt(s, "双尺度人体时序建模与七头可解释融合", 78, 320, 650, 38, 25, C.gray);
  line(s, 78, 393, 480, C.orange, 4);
  txt(s, "抹茶吃不饱", 78, 438, 230, 32, 22, C.ink, true);
  txt(s, "普通 RGB 视频 · 4.053M 参数 · 固定融合 · 结构化证据", 78, 487, 660, 32, 19, C.gray);
  s.images.add({ blob: demoImage, contentType: "image/png", alt: "最终模型的姿态跟踪和七头输出现场画面", fit: "contain", position: { left: 755, top: 118, width: 475, height: 380 } });
  txt(s, "动态演示：姿态、轨迹、候选区间与七头输出", 780, 525, 425, 34, 16, C.gray, false, "center");
  txt(s, "01 SEP 2026", 1030, 635, 178, 22, 13, C.gray, true, "right");
  notes(s, "Project runtime visualization and frozen runtime README.md.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "跌倒是一个时序事件，单帧姿态不足以完成可靠判别", "研究问题", 2);
  txt(s, "动作过程", 82, 196, 210, 34, 25, C.ink, true);
  arrow(s, 110, 310, 1100, 310);
  const phases = [[140, "直立/行走", "正常动态"], [400, "失衡/下坠", "快速姿态变化"], [675, "接触/落地", "短时冲击"], [950, "持续倒地", "长时上下文"]];
  phases.forEach((item, i) => { rect(s, item[0], 279, 18, 62, i === 1 || i === 2 ? C.orange : C.teal, i === 1 || i === 2 ? C.orange : C.teal, 0); txt(s, item[1], item[0] - 30, 365, 190, 30, 22, C.ink, true, "center"); txt(s, item[2], item[0] - 30, 405, 190, 28, 17, C.gray, false, "center"); });
  bullet(s, "短窗口需要捕捉快速下坠，长窗口需要确认完整动作上下文。", 130, 500, 980, true);
  bullet(s, "最终告警还应保留轨迹和时间区间，支持人工回看。", 130, 565, 980, false);
  notes(s, "Project problem definition; no external quantitative claim.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "研究目标同时约束排序性能、计算成本与可审计性", "目标与评价", 3);
  const goals = [["排序质量", "mAP / P@R90 / P@R95", "高召回工作区间的误报控制"], ["工程效率", "参数量 / FP32 / ms·frame⁻¹", "低算力平台可运行"], ["可审计性", "track_id / proposal / logits", "最终分数可回溯"]];
  goals.forEach((g, i) => { const y = 205 + i * 145; txt(s, `0${i+1}`, 90, y, 72, 56, 34, i === 1 ? C.orange : C.blue, true); txt(s, g[0], 180, y, 210, 38, 25, C.ink, true); txt(s, g[1], 410, y, 350, 38, 21, C.blue, true); txt(s, g[2], 790, y, 390, 54, 19, C.gray); line(s, 180, y + 80, 1000, C.grid, 1); });
  notes(s, "Frozen runtime README.md and reports/final_model_smoke.json.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "短时骨架、长时骨架和人体 ROI 在 clip 层形成互补证据", "方法", 4);
  rect(s, 195, 349, 125, 2, C.blue, C.blue, 0); rect(s, 320, 255, 2, 216, C.blue, C.blue, 0); rect(s, 320, 255, 86, 2, C.blue, C.blue, 0); rect(s, 320, 470, 86, 2, C.blue, C.blue, 0);
  rect(s, 659, 255, 65, 2, C.blue, C.blue, 0); rect(s, 659, 470, 65, 2, C.blue, C.blue, 0); rect(s, 724, 255, 2, 216, C.blue, C.blue, 0); rect(s, 724, 349, 96, 2, C.blue, C.blue, 0); rect(s, 1000, 349, 80, 2, C.blue, C.blue, 0);
  const nodes = [[70, 290, 125, 120, "RGB 视频", "video stream"], [406, 190, 253, 130, "16 帧骨架", "6-stream causal TCN"], [406, 405, 253, 130, "48 帧骨架", "long-context expert"], [820, 280, 180, 140, "共享 ROI", "P3/P4 · 320/640"], [1080, 290, 140, 120, "固定融合", "mean logits → σ"]];
  nodes.forEach((n, i) => { rect(s, n[0], n[1], n[2], n[3], i === 4 ? "#EDF7F5" : C.pale, i === 4 ? C.teal : C.blue, 2); txt(s, n[4], n[0] + 12, n[1] + 22, n[2] - 24, 34, 22, C.ink, true, "center"); txt(s, n[5], n[0] + 10, n[1] + 68, n[2] - 20, 34, 16, C.gray, false, "center"); });
  txt(s, "6 个短时成员 + 1 个长时成员", 730, 470, 360, 42, 20, C.orange, true, "center");
  txt(s, "部署阶段不读取标签、真实事件区间或真实人物 ID", 190, 590, 900, 38, 22, C.ink, true, "center");
  notes(s, "Project MANIFEST.json; docs/research/2026-08-29-dense48-and-confidence-part-roi.md.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "数据与评价协议分层记录，避免不同口径之间的横向混用", "数据与协议", 5);
  txt(s, "用途", 95, 190, 160, 28, 18, C.gray, true); txt(s, "来源", 315, 190, 300, 28, 18, C.gray, true); txt(s, "评价/使用边界", 690, 190, 430, 28, 18, C.gray, true);
  const rows = [["训练与选择", "OF-Syn train · 5-fold grouped OOF", "结构选择、配对 bootstrap；不读取 sealed test"], ["冻结验证", "OF-Syn validation · 1,200 clips", "报告 mAP、P@R90、P@R95"], ["现场演示", "URFD fall-01-cam1 · 160 frames", "仅用于端到端动态效果和功能烟测"], ["运行完整性", "MANIFEST.json · 174 files", "源码、权重、依赖逐文件 SHA-256"]];
  rows.forEach((r, i) => { const y = 235 + i * 95; line(s, 85, y + 74, 1090, C.grid, 1); txt(s, r[0], 95, y, 190, 58, 20, C.ink, true); txt(s, r[1], 315, y, 330, 58, 19, C.blue, i === 1); txt(s, r[2], 690, y, 460, 58, 18, C.gray); });
  notes(s, "Project README.md; URFD: https://fenix.ur.edu.pl/~mkepski/ds/uf.html; project model-selection audit.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "长时专家的价值来自互补性，而不是单头峰值", "模型选择", 6);
  s.charts.add("bar", { position: { left: 75, top: 200, width: 555, height: 360 }, categories: ["mAP", "P@R90", "P@R95"], series: [{ name: "六头", values: [70.831, 77.562, 64.100], fill: "#A7B7C7" }, { name: "七头", values: [72.166, 78.762, 65.570], fill: C.blue }], hasLegend: true, dataLabels: { showValue: true, position: "outEnd" }, yAxis: { majorGridlines: { style: "solid", fill: C.grid, width: 1 } } });
  txt(s, "+1.335", 705, 224, 180, 55, 37, C.teal, true); txt(s, "mAP points", 890, 235, 210, 38, 21, C.gray);
  txt(s, "+1.200", 705, 330, 180, 55, 37, C.teal, true); txt(s, "P@R90 points", 890, 341, 230, 38, 21, C.gray);
  txt(s, "+1.470", 705, 436, 180, 55, 37, C.teal, true); txt(s, "P@R95 points", 890, 447, 230, 38, 21, C.gray);
  txt(s, "paired bootstrap mAP Δ 95% CI [+0.055, +2.333]", 705, 550, 475, 38, 19, C.ink, true);
  notes(s, "docs/research/2026-08-29-dense48-and-confidence-part-roi.md, pooled five-fold train-OOF metrics.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "五折结果显示四折提升，最弱折获得最大的互补收益", "配对验证", 7);
  s.charts.add("bar", { position: { left: 90, top: 195, width: 720, height: 385 }, categories: ["Fold 0", "Fold 1", "Fold 2", "Fold 3", "Fold 4"], series: [{ name: "ΔmAP", values: [0.648, 0.500, -0.456, 2.375, 0.234], fill: C.teal }], hasLegend: false, dataLabels: { showValue: true, position: "outEnd" }, yAxis: { majorGridlines: { style: "solid", fill: C.grid, width: 1 } } });
  txt(s, "4 / 5", 900, 235, 220, 72, 48, C.blue, true, "center"); txt(s, "folds improved", 900, 305, 220, 35, 22, C.gray, false, "center");
  txt(s, "Fold 3", 900, 405, 220, 35, 25, C.orange, true, "center"); txt(s, "+2.375 mAP points", 875, 450, 270, 40, 23, C.ink, true, "center");
  txt(s, "Part-ROI 候选未带来总体增益，因此未进入冻结模型。", 850, 545, 320, 55, 18, C.gray, false, "center");
  notes(s, "docs/research/2026-08-29-dense48-and-confidence-part-roi.md, per-fold paired audit.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "冻结验证与工程指标共同说明效果和部署代价", "结果", 8);
  const metrics = [["75.208%", "OF-Syn val mAP"], ["77.907%", "P@R90"], ["72.509%", "P@R95"], ["4.053M", "parameters"], ["15.46 MiB", "FP32 size"], ["15.45 ms", "per frame · 3,960 frames"]];
  metrics.forEach((m, i) => { const col = i % 3, row = Math.floor(i / 3); const x = 105 + col * 385, y = 205 + row * 180; txt(s, m[0], x, y, 300, 58, 39, i < 3 ? C.blue : C.teal, true, "center"); txt(s, m[1], x, y + 64, 300, 34, 18, C.gray, false, "center"); if (col < 2) line(s, x + 330, y + 4, 1, C.grid, 100); });
  txt(s, "验证指标、模型规模和完整视频耗时分别按其原始口径报告。", 160, 590, 960, 36, 20, C.ink, true, "center");
  notes(s, "deploy/final_model/README.md; validation has 1,200 clips; runtime average covers 3,960 frames.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "现场演示同步显示动作、轨迹、候选时间与七头输出", "预期效果", 9);
  s.images.add({ blob: demoImage, contentType: "image/png", alt: "动态跌倒检测现场画面：姿态骨架、轨迹和七头输出", fit: "contain", position: { left: 72, top: 185, width: 790, height: 440 } });
  txt(s, "动态展示内容", 920, 205, 250, 34, 24, C.ink, true);
  ["原始 RGB 动作过程", "17 点姿态与人体框", "连续 track_id", "0.77-4.77 s 候选区间", "七个 raw logits", "固定融合风险分数"].forEach((item, i) => bullet(s, item, 920, 265 + i * 55, 280, i >= 3));
  notes(s, "Local dynamic visualization generated from URFD fall-01-cam1 and reports/final_model_smoke.json.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "可解释输出让系统更容易接入人工复核与告警审计", "工程价值", 10);
  s.images.add({ blob: rawImage, contentType: "image/jpeg", alt: "URFD 跌倒动作接触阶段示例", fit: "cover", position: { left: 72, top: 190, width: 520, height: 390 } });
  txt(s, "系统输出", 675, 205, 220, 34, 25, C.ink, true);
  const outputs = [["track_id", "定位具体人物轨迹"], ["proposal", "回看候选时间区间"], ["member_logits", "检查成员一致性"], ["score", "提供融合风险排序"], ["latency", "监测部署性能"]];
  outputs.forEach((o, i) => { txt(s, o[0], 680, 265 + i * 66, 210, 32, 20, C.blue, true); txt(s, o[1], 900, 265 + i * 66, 270, 32, 18, C.gray); line(s, 680, 307 + i * 66, 490, C.grid, 1); });
  txt(s, "定位为辅助风险发现，不作为医疗诊断或唯一决策依据。", 675, 610, 500, 35, 18, C.red, true);
  notes(s, "Project inference output protocol; URFD source image from local project fixture.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "研究贡献在于低预算下整合互补时序证据，并保留可复核链条", "结论", 11);
  txt(s, "01", 95, 200, 80, 60, 38, C.blue, true); txt(s, "方法", 190, 205, 130, 38, 25, C.ink, true); txt(s, "16/48 帧双尺度骨架 + 共享 ROI token + 七头固定融合", 350, 205, 770, 48, 22, C.gray);
  txt(s, "02", 95, 335, 80, 60, 38, C.teal, true); txt(s, "证据", 190, 340, 130, 38, 25, C.ink, true); txt(s, "五折配对增益、冻结验证指标、动态端到端演示", 350, 340, 770, 48, 22, C.gray);
  txt(s, "03", 95, 470, 80, 60, 38, C.orange, true); txt(s, "价值", 190, 475, 130, 38, 25, C.ink, true); txt(s, "普通 RGB 输入、低参数规模、轨迹与时间区间可回看", 350, 475, 770, 48, 22, C.gray);
  line(s, 95, 580, 1025, C.blue, 3);
  txt(s, "面向养老、家庭看护、康复与病房辅助值守的工程化原型", 130, 610, 950, 36, 24, C.ink, true, "center");
  notes(s, "Synthesis of project evidence; no additional external claim.");

  s = p.slides.add(); s.background.fill = C.white; slideTitle(s, "参考资料与可复核工件", "References", 12);
  const refs = ["[1] UR Fall Detection Dataset, University of Rzeszów.", "[2] Ultralytics, Pose Estimation with YOLO.", "[3] PyTorch Documentation.", "[4] 项目模型选择审计：dense-48 与 Part-ROI 五折配对实验，2026-08-29。", "[5] 项目最终运行包 README.md 与 MANIFEST.json。", "[6] reports/final_model_smoke.json：160 帧端到端烟测。", "[7] MIT Communication Lab, Slide Design for Scientific Presentations."];
  refs.forEach((r, i) => txt(s, r, 95, 185 + i * 58, 1080, 38, 18, i < 3 ? C.blue : C.gray, false));
  txt(s, "所有外部来源与项目证据路径已写入演讲者备注。", 95, 620, 1080, 32, 18, C.ink, true);
  notes(s, "https://fenix.ur.edu.pl/~mkepski/ds/uf.html; https://docs.ultralytics.com/tasks/pose/; https://pytorch.org/docs/; https://mitcommlab.mit.edu/aeroastro/commkit/slide-design/; project evidence paths listed on slide.");

  const out = await PresentationFile.exportPptx(p);
  await out.save(OUT);
}

main().catch((error) => { console.error(error); process.exitCode = 1; });
