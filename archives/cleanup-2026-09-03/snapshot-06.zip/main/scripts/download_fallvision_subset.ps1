param(
    [string]$Destination = (Join-Path $PSScriptRoot '..\data\fallvision_subset')
)

$ErrorActionPreference = 'Stop'
$datasetApi = 'https://dataverse.harvard.edu/api/datasets/:persistentId/?persistentId=doi:10.7910/DVN/75QPKK'

$rawIds = @(
    8138607, 8138612, 8138622, 8138623, 8138935, 8138941,
    8140287, 8140291, 8140307, 8140309, 8140315, 8140316
)

New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$files = (Invoke-RestMethod -Uri $datasetApi).data.latestVersion.files
$selected = $files | Where-Object {
    $_.dataFile.id -in $rawIds -or $_.dataFile.filename -match 'k(?:ey|e)t?points_csv\.rar$'
}

if ($selected.Count -ne 32) {
    throw "Expected 32 files (12 raw archives + 20 keypoint archives), found $($selected.Count)."
}

$manifest = $selected | ForEach-Object {
    [PSCustomObject]@{
        Id       = $_.dataFile.id
        FileName = $_.dataFile.filename
        Category = $_.directoryLabel
        Bytes    = $_.dataFile.filesize
        URL      = "https://dataverse.harvard.edu/api/access/datafile/$($_.dataFile.id)"
    }
}
$manifest | Export-Csv -NoTypeInformation -Encoding utf8 (Join-Path $Destination 'manifest.csv')

foreach ($file in $manifest) {
    $outputPath = Join-Path $Destination $file.FileName
    if ((Test-Path -LiteralPath $outputPath) -and ((Get-Item -LiteralPath $outputPath).Length -eq $file.Bytes)) {
        Write-Host "Already complete: $($file.FileName)"
        continue
    }

    Write-Host "Downloading: $($file.FileName)"
    & curl.exe --fail --location --retry 5 --retry-delay 3 --continue-at - --output $outputPath $file.URL
    if ($LASTEXITCODE -ne 0) {
        throw "Download failed for $($file.FileName) (curl exit code $LASTEXITCODE). Re-run this script to resume."
    }
    if ((Get-Item -LiteralPath $outputPath).Length -ne $file.Bytes) {
        throw "Size verification failed for $($file.FileName). Re-run this script to resume."
    }
}

Write-Host 'FallVision subset download completed and size-verified.'
